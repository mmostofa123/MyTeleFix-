/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import apiRouter from "./server/api.js";
import telegramBotRouter from "./server/telegramBot.js";
import { startInactivityEngine } from "./server/inactivityPurge.js";
import { autoMigrateLocalDataToFirestore } from "./server/firebase.js";
import { globalApiRateLimiter } from "./server/rateLimiter.js";
import { apiLatencyTracker } from "./server/health.js";
import { globalErrorHandler, apiNotFoundHandler } from "./server/errorHandler.js";

dotenv.config();

// Define __dirname in ES Modules context
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure persistent uploads directory exists for heavy media files
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const app = express();
// VRMS-3 ULTRA (Phase 16): Real-time API Latency, traffic, and error metrics tracker
app.use(apiLatencyTracker);
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ limit: "500mb", extended: true }));

// Dedicated High-Performance Media Streaming Handler (Supports HTTP 206 Range for Mobile/Desktop Players)
app.use("/uploads", (req, res, next) => {
  // CORS & Media Embedding Policy headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Range, Content-Type, Accept-Encoding, Authorization");
  res.setHeader("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges, Content-Type");
  res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  // Extract raw filename from request path
  const rawPath = req.path.replace(/^\//, "");
  const safeFilename = path.basename(rawPath);
  const filePath = path.join(uploadsDir, safeFilename);

  if (!safeFilename || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: "Media file not found" });
  }

  const stat = fs.statSync(filePath);
  if (stat.isDirectory()) {
    return res.status(403).json({ error: "Access forbidden" });
  }

  const fileSize = stat.size;
  const ext = path.extname(filePath).toLowerCase();

  const mimeTypes: Record<string, string> = {
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mov": "video/mp4",
    ".mkv": "video/mp4",
    ".m4v": "video/mp4",
    ".3gp": "video/3gpp",
    ".mp3": "audio/mpeg",
    ".wav": "audio/wav",
    ".ogg": "audio/ogg",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
  };

  const contentType = mimeTypes[ext] || "application/octet-stream";
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Cache-Control", "public, max-age=31536000, immutable");

  if (req.method === "HEAD") {
    res.setHeader("Content-Length", fileSize);
    res.setHeader("Content-Type", contentType);
    return res.status(200).end();
  }

  const range = req.headers.range;

  if (range) {
    // Parse range: e.g. "bytes=0-1000", "bytes=1000-", "bytes=-500"
    let start = 0;
    let end = fileSize - 1;

    const parts = range.replace(/bytes=/, "").trim().split("-");
    if (parts[0] !== "") {
      start = parseInt(parts[0], 10);
      if (parts[1] !== "") {
        end = parseInt(parts[1], 10);
      }
    } else if (parts[1] !== "") {
      // Suffix range
      start = Math.max(0, fileSize - parseInt(parts[1], 10));
    }

    if (isNaN(start)) start = 0;
    if (isNaN(end) || end >= fileSize) end = fileSize - 1;

    if (start >= fileSize || start > end) {
      res.setHeader("Content-Range", `bytes */${fileSize}`);
      return res.status(416).end();
    }

    const chunksize = (end - start) + 1;
    res.writeHead(206, {
      "Content-Range": `bytes ${start}-${end}/${fileSize}`,
      "Accept-Ranges": "bytes",
      "Content-Length": chunksize,
      "Content-Type": contentType,
    });

    const stream = fs.createReadStream(filePath, { start, end });
    stream.on("error", (err) => {
      console.warn("Media read stream error:", err);
      if (!res.headersSent) res.status(500).end();
    });
    req.on("close", () => {
      stream.destroy();
    });
    stream.pipe(res);
  } else {
    res.writeHead(200, {
      "Content-Length": fileSize,
      "Content-Type": contentType,
      "Accept-Ranges": "bytes",
    });

    const stream = fs.createReadStream(filePath);
    stream.on("error", (err) => {
      console.warn("Full media read stream error:", err);
      if (!res.headersSent) res.status(500).end();
    });
    req.on("close", () => {
      stream.destroy();
    });
    stream.pipe(res);
  }
});

const PORT = 3000;

// PHASE 3 UPTIME & 24/7 HOSTING PREPARATION
// Health-check endpoints for external uptime monitoring tools (UptimeRobot, Koyeb, Render)
// Placed before rate limiters to ensure 100% successful 24/7 pings without 429 throttling
app.get(["/health", "/ping", "/api/health", "/api/ping"], (req, res) => {
  const uptimeSec = Math.floor(process.uptime());
  const mem = process.memoryUsage();
  res.status(200).json({
    status: "ok",
    service: "myteleflix-24-7-telegram-engine",
    uptimeSeconds: uptimeSec,
    uptimeFormatted: `${Math.floor(uptimeSec / 3600)}h ${Math.floor((uptimeSec % 3600) / 60)}m ${uptimeSec % 60}s`,
    timestamp: new Date().toISOString(),
    memoryMb: {
      rss: Math.round(mem.rss / (1024 * 1024)),
      heapUsed: Math.round(mem.heapUsed / (1024 * 1024)),
    },
  });
});

// Telegram Bot Webhook endpoint (root level alias for Koyeb/Render webhook web traffic)
app.use(["/webhook", "/telegram/webhook"], telegramBotRouter);

// VRMS-3 ULTRA (Phase 16): Distributed Server-Side DDoS & Abuse Rate Limiter on API layer
app.use("/api", globalApiRateLimiter);

// Mount the Telegram Bot engine & Webhook Router on /api/telegram
app.use("/api", telegramBotRouter);

// Mount the modular API Layer containing all Auth, Database, Missions, Rewards, Referrals, Withdrawals, and Admin Controllers
app.use("/api", apiRouter);

// VRMS-3 ULTRA (Phase 16): 404 Route Not Found Handler for unknown API endpoints
app.all("/api/*", apiNotFoundHandler);

// VRMS-3 ULTRA (Phase 16): Zero-Downtime Global Exception Sanitizer
app.use(globalErrorHandler);

// Vite middleware / Production Client serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`My TeleFlix Platform full-stack server running on http://localhost:${PORT}`);
    // Start background 30-day inactivity purge engine
    startInactivityEngine();
    // Auto-migrate local data to Firestore Cloud Database in background
    autoMigrateLocalDataToFirestore().catch((err) => {
      console.warn("[Server] Firestore initial sync notice:", err);
    });
  });

  // Unlimited socket timeout for heavy 2GB-3GB+ media file streaming and uploads
  server.timeout = 0; // 0 disables HTTP server socket timeout
  server.keepAliveTimeout = 300000; // 5 minutes
  server.headersTimeout = 305000; // 5+ minutes
}

startServer();
