/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function normalizeGpuChipset(raw: string): string {
  if (!raw || raw === "no-webgl" || raw === "webgl-error" || raw === "no-webgl-ssr") return "standard-gpu";
  let s = raw.toLowerCase();
  s = s.replace(/google inc\.\s*/g, "");
  s = s.replace(/angle\s*\(/g, "");
  s = s.replace(/opengl\s*es\s*[\d.]*/g, "");
  s = s.replace(/direct3d\d*/g, "");
  s = s.replace(/vs_\d+_\d+/g, "");
  s = s.replace(/ps_\d+_\d+/g, "");
  s = s.replace(/d3d\d*/g, "");
  s = s.replace(/[~,()]/g, " ");
  s = s.replace(/\s+/g, " ").trim();
  return s || "standard-gpu";
}

export function normalizePhysicalScreen(raw: string): string {
  if (!raw) return "";
  const parts = raw.split("x");
  if (parts.length >= 2) {
    const w = parseInt(parts[0], 10) || 0;
    const h = parseInt(parts[1], 10) || 0;
    const minDim = Math.min(w, h);
    const maxDim = Math.max(w, h);
    return `${minDim}x${maxDim}`;
  }
  return raw;
}

export function getIpSubnet(ip: string): string {
  if (!ip) return "";
  const clean = ip.trim();
  if (clean.includes(":")) {
    const parts = clean.split(":");
    return parts.slice(0, 4).join(":") + "::/64";
  } else if (clean.includes(".")) {
    const parts = clean.split(".");
    return parts.slice(0, 3).join(".") + ".0/24";
  }
  return clean;
}

export interface DeviceLockMatchParams {
  hwid?: string;
  cross_browser_hwid?: string;
  hardware_uuid?: string;
  device_fingerprint?: string;
  gpu_renderer?: string;
  gpu_chipset?: string;
  screen_resolution?: string;
  physical_screen?: string;
  hardware_concurrency?: number;
  cpu_cores?: number;
  timezone?: string;
  ip_address?: string;
  platform?: string;
  platform_family?: string;
}

export function findDeviceLockMatch(db: any, params: DeviceLockMatchParams) {
  const locks = Array.isArray((db as any).device_locks) ? (db as any).device_locks : [];
  const normGpu = params.gpu_chipset || normalizeGpuChipset(params.gpu_renderer || "");
  const normScreen = normalizePhysicalScreen(params.physical_screen || params.screen_resolution || "");
  const normSubnet = getIpSubnet(params.ip_address || "");
  const cores = params.cpu_cores || params.hardware_concurrency || 0;
  const tz = params.timezone || "";

  // 1. Search in db.device_locks
  const matchedLock = locks.find((l: any) => {
    if (!l.primary_email) return false;

    // Direct hardware identifiers
    if (params.hwid && (l.hwid === params.hwid || l.cross_browser_hwid === params.hwid)) return true;
    if (params.cross_browser_hwid && (l.cross_browser_hwid === params.cross_browser_hwid || l.hwid === params.cross_browser_hwid)) return true;
    if (params.hardware_uuid && (l.hardware_uuid === params.hardware_uuid || l.hwid === params.hardware_uuid)) return true;
    if (params.device_fingerprint && (l.device_fingerprint === params.device_fingerprint || l.hwid === params.device_fingerprint)) return true;

    // Cross-browser hardware matching:
    const lockGpu = l.gpu_chipset || normalizeGpuChipset(l.gpu_renderer || "");
    const lockScreen = normalizePhysicalScreen(l.physical_screen || l.screen_resolution || "");
    const lockSubnet = getIpSubnet(l.ip_address || "");

    // Same GPU chipset + same physical screen
    if (normGpu && normScreen && lockGpu && lockScreen && lockGpu === normGpu && lockScreen === normScreen) {
      return true;
    }

    // Same IP subnet + same GPU chipset
    if (normSubnet && lockSubnet && normGpu && lockGpu && normSubnet === lockSubnet && normGpu === lockGpu) {
      return true;
    }

    // Same IP subnet + same physical screen + same CPU cores
    if (normSubnet && lockSubnet && normScreen && lockScreen && normSubnet === lockSubnet && normScreen === lockScreen && cores && l.hardware_concurrency === cores) {
      return true;
    }

    // Same GPU chipset + CPU cores + Timezone
    if (normGpu && lockGpu && normGpu === lockGpu && cores && l.hardware_concurrency === cores && tz && l.timezone === tz) {
      return true;
    }

    return false;
  });

  if (matchedLock && matchedLock.primary_email) {
    const boundEmail = matchedLock.primary_email.toLowerCase().trim();
    const boundUser = Array.isArray(db.users) ? db.users.find((u: any) => u.email && u.email.toLowerCase().trim() === boundEmail) : null;
    return {
      isLocked: true,
      primaryEmail: boundEmail,
      lock: matchedLock,
      user: boundUser
    };
  }

  // 2. Search db.users array for any registered user with matching device traits
  if (Array.isArray(db.users)) {
    const matchedUser = db.users.find((u: any) => {
      if (!u.email) return false;
      if (params.cross_browser_hwid && (u.cross_browser_hwid === params.cross_browser_hwid || u.hwid === params.cross_browser_hwid)) return true;
      if (params.hwid && (u.hwid === params.hwid || u.device_fingerprint === params.hwid)) return true;
      if (params.device_fingerprint && (u.device_fingerprint === params.device_fingerprint || u.deviceFingerprint === params.device_fingerprint)) return true;
      if (params.hardware_uuid && (u.hardware_uuid === params.hardware_uuid || u.device_hardware_uuid === params.hardware_uuid)) return true;

      const userGpu = u.gpu_chipset || normalizeGpuChipset(u.gpu_renderer || "");
      const userScreen = normalizePhysicalScreen(u.physical_screen || u.screen_resolution || "");
      const userSubnet = getIpSubnet(u.registered_ip || "");

      if (normGpu && normScreen && userGpu && userScreen && userGpu === normGpu && userScreen === normScreen) {
        return true;
      }
      if (normSubnet && userSubnet && normGpu && userGpu && normSubnet === userSubnet && userGpu === normGpu) {
        return true;
      }
      return false;
    });

    if (matchedUser && matchedUser.email) {
      const boundEmail = matchedUser.email.toLowerCase().trim();
      return {
        isLocked: true,
        primaryEmail: boundEmail,
        lock: null,
        user: matchedUser
      };
    }
  }

  return { isLocked: false, primaryEmail: null, lock: null, user: null };
}
