/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { readDB, writeDB, DBState, recordLedgerEntry } from "./db.js";

// Verify admin permission
export function verifyIsAdmin(email?: string) {
  if (!email) return false;
  const normalized = email.toLowerCase();
  return normalized === "mostofa7077a@gmail.com" || normalized === "mostofa70000@gmail.com";
}

// Aggregate admin statistics
export function getAdminAnalytics() {
  const db = readDB();
  
  const totalUsers = db.users.length;
  
  const totalPointsAwarded = db.transactions
    .filter((tx: any) => tx.amount > 0)
    .reduce((sum: number, tx: any) => sum + tx.amount, 0);

  const totalWithdrawals = db.withdrawals
    .filter((w: any) => w.status === "approved")
    .reduce((sum: number, w: any) => sum + w.amount, 0);

  const pendingWithdrawals = db.withdrawals
    .filter((w: any) => w.status === "pending")
    .length;

  const totalMissionsCompleted = db.missionLogs.length;
  const activeMissionsCount = db.missions.filter((m: any) => m.isActive).length;

  const userGrowth = [
    { date: "June 25", count: Math.max(1, totalUsers - 2) },
    { date: "June 27", count: Math.max(1, totalUsers - 1) },
    { date: "June 29", count: Math.max(1, totalUsers - 1) },
    { date: "July 01", count: totalUsers }
  ];

  const typesMap: { [key: string]: number } = {};
  db.transactions.forEach((t: any) => {
    if (t.amount > 0) {
      typesMap[t.type] = (typesMap[t.type] || 0) + t.amount;
    }
  });

  const pointsDistribution = Object.keys(typesMap).map(type => ({
    type: type.replace("_", " ").toUpperCase(),
    total: typesMap[type]
  }));

  return {
    totalUsers,
    totalPointsAwarded,
    totalWithdrawals,
    pendingWithdrawals,
    totalMissionsCompleted,
    activeMissionsCount,
    userGrowth,
    pointsDistribution
  };
}

// Fetch all payout requests
export function getAllWithdrawals() {
  const db = readDB();
  return db.withdrawals.sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// Process withdrawal status approval or rejection
export function processWithdrawalStatus(withdrawalId: string, status: 'approved' | 'paid' | 'rejected') {
  const db = readDB();

  const withdrawal = db.withdrawals.find((w: any) => w.id === withdrawalId);
  if (!withdrawal) {
    throw new Error("Specified payout request was not found.");
  }

  const normalizedStatus = (status === 'paid' || status === 'approved') ? 'approved' : 'rejected';
  withdrawal.status = normalizedStatus;

  // Sync the pending negative transaction ledger
  const ledger = db.transactions.find((tx: any) => 
    tx.userId === withdrawal.userId && 
    tx.type === "withdrawal" && 
    tx.amount === -withdrawal.amount && 
    (tx.status === "pending" || tx.status === "Pending")
  );
  
  if (ledger) {
    ledger.status = normalizedStatus === "approved" ? "completed" : "failed";
  }

  const user = db.users.find((u: any) => u.id === withdrawal.userId);

  if (normalizedStatus === "rejected") {
    // Refund the points back to user's modular wallet
    if (user) {
      user.wallet.points = (user.wallet.points || 0) + withdrawal.amount;
      user.wallet.updatedAt = new Date().toISOString();

      // Record Refund in Ledger
      db.transactions.push({
        id: "tx-refund-" + Date.now(),
        userId: withdrawal.userId,
        amount: withdrawal.amount,
        type: "bonus",
        status: "completed",
        description: `Refund: Rejected payout #${withdrawalId.substring(0, 8)} (${withdrawal.paymentMethod || 'Withdrawal'})`,
        timestamp: new Date().toISOString()
      });

      // Immutable Financial Ledger Entry (Phase 15 ARE)
      recordLedgerEntry({
        user_id: withdrawal.userId,
        transaction_type: 'REFUND',
        amount: withdrawal.amount,
        reference_type: 'WITHDRAWAL',
        reference_id: withdrawalId,
        metadata: {
          refund_reason: `Rejected payout #${withdrawalId.substring(0, 8)}`
        }
      }, db);

      // Send alert notification
      db.notifications.push({
        id: "nt-reject-" + Date.now(),
        userId: withdrawal.userId,
        title: "❌ Withdrawal Request Rejected & Refunded",
        message: `Your withdrawal request of ${withdrawal.amount.toLocaleString()} points via ${withdrawal.paymentMethod || 'Payout'} was rejected. The points have been fully refunded to your balance.`,
        isRead: false,
        timestamp: new Date().toISOString()
      });
    }
  } else if (normalizedStatus === "approved") {
    // Notify user of successful cashout completion
    if (user) {
      db.notifications.push({
        id: "nt-approve-" + Date.now(),
        userId: withdrawal.userId,
        title: "✅ Payout Approved & Paid!",
        message: `Your cashout of ${withdrawal.amount.toLocaleString()} points to ${withdrawal.paymentMethod || 'account'} (${withdrawal.accountNumber || withdrawal.walletAddress}) has been approved and paid!`,
        isRead: false,
        timestamp: new Date().toISOString()
      });
    }
  }

  writeDB(db);
  return withdrawal;
}

// Edit system settings
export function updateSystemSettings(newSettings: any) {
  const db = readDB();
  db.settings = { ...db.settings, ...newSettings };
  writeDB(db);
  return db.settings;
}
