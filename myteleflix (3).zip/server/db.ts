/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from "fs";
import path from "path";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";

const DB_FILE = path.join(process.cwd(), "db.json");

// Structure interfaces for database representation
export interface UserWallet {
  points: number;
  walletAddress: string;
  status: 'active' | 'frozen';
  updatedAt: string;
}

export interface TaskStats {
  missionsCompleted: number;
  totalPointsEarned: number;
  moviesWatched: number;
  videosWatched: number;
}

export interface UserActivityRecord {
  activity_id: string;
  user_id: string;
  activity_type: 'TASK' | 'CONTENT';
  source_reference: string;
  activity_date: string;
  validation_status: 'VALID' | 'INVALID' | 'DUPLICATE';
  idempotency_key: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export interface VerificationRecord {
  verification_id: string;
  user_id: string;
  active_days: number;
  valid_actions: number;
  quiz_status: 'PENDING' | 'PASSED' | 'FAILED';
  verification_status: 'UNVERIFIED' | 'VERIFIED' | 'PENDING' | 'REJECTED';
  rule_version: string;
  verified_at: string | null;
  updated_at: string;
  active_day_streak?: number;
  valid_action_count?: number;
  last_activity_at?: string;
  last_active_day_date?: string | null;
  today_tasks?: number;
  today_content?: number;
  today_active_day_earned?: boolean;
}

export interface QuizAttemptRecord {
  attempt_id: string;
  user_id: string;
  question_set_version: string;
  score: number;
  attempt_status: 'IN_PROGRESS' | 'PASSED' | 'FAILED' | 'RESET';
  reset_count: number;
  last_reset_at: string;
  created_at: string;
  questions?: Array<{
    id: number;
    questionBn: string;
    questionEn: string;
    options: Array<{ id: string; textBn: string; textEn: string }>;
    correctOptionId: string;
  }>;
}

export interface ReferralRecord {
  referral_id: string;
  referrer_id: string;
  referred_user_id: string;
  status: 'REGISTERED' | 'QUALIFIED' | 'PURGED';
  registered_at: string;
  qualified_at: string | null;
  purged_at: string | null;
  rule_version: string;
  bonus_amount?: number;
  referred_username?: string;
  referred_fullname?: string;
  // Compatibility fields
  id?: string;
  referrerId?: string;
  referredId?: string;
  referredUsername?: string;
  referredFullName?: string;
  pointsEarned?: number;
  timestamp?: string;
  activeDays?: number;
  tasksCompleted?: number;
  humanQuizCompleted?: boolean;
  subReferralsCount?: number;
  isVerified?: boolean;
  isClaimed?: boolean;
  claimableReward?: number;
  lifetimeCommission?: number;
  tier?: 1 | 2 | 3;
  plan?: 'PLAN_A' | 'PLAN_B';
}

export interface PurgeFinancialRetention {
  transaction_count: number;
  total_paid_tokens: number;
  wallet_address: string;
  audit_ledger_ids: string[];
}

export interface PurgeRecord {
  purge_id: string;
  user_id_hash: string;
  original_user_id: string;
  purged_user_id?: string;
  purge_reason: string;
  inactivity_days: number;
  purged_at: string;
  affected_referrer_ids: string[];
  financial_retention_reference: PurgeFinancialRetention;
}

// VRMS-3 ULTRA (Phase 6): Referral Milestone Reward Engine (RME) Schemas
export interface MilestoneConfig {
  milestone_id: string;
  campaign_id: string;
  threshold: number; // 1, 3, 5, 10, 20, 30, 50, 100
  amount: number;
  max_per_user: number;
  budget: number;
  total_claimed_amount?: number;
  status: 'ACTIVE' | 'PAUSED';
  rule_version: number;
  active_from: string;
  active_to: string | null;
  title?: string;
  description?: string;
}

export interface ReferralRewardRecord {
  reward_id: string;
  user_id: string;
  milestone_id: string;
  campaign_id: string;
  amount: number;
  status: 'LOCKED' | 'PENDING' | 'CLAIMABLE' | 'CREDITED' | 'REVIEW' | 'REVERSED';
  rule_version: number;
  created_at: string;
  claimed_at: string | null;
  reversed_at?: string | null;
  reversal_reason?: string | null;
  transaction_id?: string;
  reversal_tx_id?: string;
}

export const DEFAULT_MILESTONE_CONFIGS: MilestoneConfig[] = [
  {
    milestone_id: "m1",
    campaign_id: "default_campaign",
    threshold: 1,
    amount: 500,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "1st Recruit",
    description: "Refer 1 qualified member"
  },
  {
    milestone_id: "m2",
    campaign_id: "default_campaign",
    threshold: 3,
    amount: 1500,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Squad Builder",
    description: "Refer 3 qualified members"
  },
  {
    milestone_id: "m3",
    campaign_id: "default_campaign",
    threshold: 5,
    amount: 3000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Network Starter",
    description: "Refer 5 qualified members"
  },
  {
    milestone_id: "m4",
    campaign_id: "default_campaign",
    threshold: 10,
    amount: 7000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Community Leader",
    description: "Refer 10 qualified members"
  },
  {
    milestone_id: "m5",
    campaign_id: "default_campaign",
    threshold: 20,
    amount: 15000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Growth Champion",
    description: "Refer 20 qualified members"
  },
  {
    milestone_id: "m6",
    campaign_id: "default_campaign",
    threshold: 30,
    amount: 25000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Elite Recruiter",
    description: "Refer 30 qualified members"
  },
  {
    milestone_id: "m7",
    campaign_id: "default_campaign",
    threshold: 50,
    amount: 45000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Master Ambassador",
    description: "Refer 50 qualified members"
  },
  {
    milestone_id: "m8",
    campaign_id: "default_campaign",
    threshold: 100,
    amount: 100000,
    max_per_user: 1,
    budget: 50000000,
    total_claimed_amount: 0,
    status: "ACTIVE",
    rule_version: 1,
    active_from: "2026-01-01T00:00:00.000Z",
    active_to: null,
    title: "Legendary Partner",
    description: "Refer 100 qualified members"
  }
];

// VRMS-3 ULTRA (Phase 7): Wallet & Payment Profile Types
export type PaymentMethodType = 'bKash' | 'Nagad' | 'TRC20_USDT';

export interface WalletPaymentProfile {
  profile_id: string;
  user_id: string;
  payment_method: PaymentMethodType;
  account_number_or_wallet_address: string;
  account_holder_name: string;
  verified_status: 'UNVERIFIED' | 'VERIFIED' | 'REJECTED';
  updated_at: string;
  created_at?: string;
}

export interface PaymentProfileSnapshot {
  snapshot_id: string;
  profile_id: string;
  payment_method: PaymentMethodType;
  account_number_or_wallet_address: string;
  account_holder_name: string;
  verified_status: string;
  snapshotted_at: string;
}

// VRMS-3 ULTRA (Phase 9): Salary Request Types & Status
export type SalaryRequestStatus = 
  | 'CLAIMED' 
  | 'UNDER_REVIEW' 
  | 'APPROVED' 
  | 'AWAITING_MANUAL_PAYMENT' 
  | 'PAID' 
  | 'HOLD' 
  | 'REJECTED'
  | 'PENDING'
  | 'DISBURSED';

// VRMS-3 ULTRA (Phase 10): Admin Audit Logs
export interface AdminAuditLogRecord {
  log_id: string;
  admin_id: string;
  action: string;
  target_type: string;
  target_id: string;
  old_value: any;
  new_value: any;
  reason?: string;
  created_at: string;
}

export interface SalaryRequestRecord {
  request_id: string;
  snapshot_id: string;
  cycle_id: string;
  user_id: string;
  amount: number;
  status: SalaryRequestStatus;
  claim_idempotency_key: string;
  claimed_at: string;
  reviewed_at?: string;
  approved_at?: string;
  paid_at?: string;
  rejection_reason?: string;
  admin_note?: string;
  // Contextual and backward-compatibility fields
  tier?: string;
  payment_profile_snapshot?: PaymentProfileSnapshot;
  transaction_id?: string;
  telegram_message_text?: string;
  telegram_deep_link?: string;
}

// VRMS-3 ULTRA (Phase 8): Monthly Salary Engine Types
export type SalaryLevel = 1 | 2 | 3;

export interface SalaryCycle {
  cycle_id: string;
  start_at: string;
  end_at: string;
  distribution_at: string;
  rule_version: string;
  status: 'ACTIVE' | 'CLOSED';
}

export interface DetectedSignals {
  device_hash_overlap?: {
    overlap_count: number;
    matched_user_ids: string[];
    device_fingerprint?: string;
  };
  ip_anomalies?: {
    ip_reuse_count: number;
    matched_user_ids: string[];
    ip_address?: string;
  };
  fast_completion?: {
    duration_ms?: number;
    threshold_ms?: number;
    velocity_anomaly?: boolean;
    consecutive_rapid_completions?: number;
  };
  details?: string[];
}

export interface RiskAssessmentRecord {
  assessment_id: string;
  user_id: string;
  risk_score: number;
  detected_signals: DetectedSignals;
  recommended_action: 'NONE' | 'MONITOR' | 'RESTRICT' | 'BAN';
  created_at: string;
}

export interface SecurityAuditLogRecord {
  log_id: string;
  user_id: string;
  action_taken: 'FLAGGED' | 'RESTRICTED' | 'BANNED' | 'UNRESTRICTED' | 'CLEARED' | 'MONITORED';
  reason: string;
  enforced_by: 'SYSTEM' | 'ADMIN';
  created_at: string;
  metadata?: Record<string, any>;
}

// VRMS-3 ULTRA (Phase 12): Notification & Alert Engine (NAE) Schemas
export type NotificationType = 'SYSTEM' | 'VERIFICATION' | 'SALARY' | 'SECURITY' | 'MILESTONE';

export interface NotificationRecord {
  notification_id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  reference_id?: string;
  is_read: boolean;
  created_at: string;
  // Compatibility fields
  id?: string;
  userId?: string;
  isRead?: boolean;
  timestamp?: string;
}

// VRMS-3 ULTRA (Phase 13): Admin System Settings & Dynamic Campaign Engine (DCE)
export interface SystemConfigRecord {
  config_key: string; // PRIMARY
  config_value: any; // JSON or primitive (string, boolean, number, object)
  description: string;
  last_updated_by: string;
  updated_at: string;
}

export type CampaignStatus = 'UPCOMING' | 'ACTIVE' | 'COMPLETED';

export interface CampaignRecord {
  campaign_id: string; // PRIMARY
  title: string;
  start_date: string;
  end_date: string;
  status: CampaignStatus;
  target_metrics: Record<string, any>;
  created_at: string;
  updated_at?: string;
}

// VRMS-3 ULTRA (Phase 14): Dynamic Task & Content Sync Engine (TCE)
export type TaskType = 'EARNING' | 'SURVEY' | 'VIDEO';
export type TaskStatus = 'ACTIVE' | 'PAUSED' | 'EXPIRED';

export interface DynamicTaskRecord {
  task_id: string; // PRIMARY
  title: string;
  description: string;
  reward_points: number;
  task_type: TaskType;
  target_url: string;
  daily_limit_per_user: number;
  status: TaskStatus;
  created_at: string;
  updated_at?: string;
  completed_count?: number;
}

export type ContentCategory = 'MOVIE' | 'DRAMA' | 'APP';
export type ContentStatus = 'ACTIVE' | 'PAUSED';

export interface DynamicContentRecord {
  content_id: string; // PRIMARY
  title: string;
  category: ContentCategory;
  download_url: string;
  status: ContentStatus;
  created_at: string;
  description?: string;
  thumbnail_url?: string;
  file_size?: string;
  reward_points?: number;
  download_count?: number;
  updated_at?: string;
}

export interface SalarySnapshot {
  snapshot_id: string;
  cycle_id: string;
  user_id: string;
  salary_level: SalaryLevel;
  current_eligible_verified_referrals: number;
  new_verified_referrals: number;
  qualified_active_referrals: number;
  calculated_salary: number;
  payment_method: PaymentMethodType;
  payment_account_snapshot: string;
  account_holder_snapshot: string;
  verification_status: string;
  risk_status: 'LOW' | 'MEDIUM' | 'HIGH' | 'CLEARED' | 'NOT_RESTRICTED';
  created_at: string;
}

// VRMS-3 ULTRA (Phase 15): Automated Audit & Reconciliation Engine (ARE) Schemas
export type LedgerTransactionType = 
  | 'TASK_REWARD' 
  | 'MILESTONE_BONUS' 
  | 'SALARY_PAYOUT' 
  | 'REVERSAL'
  | 'WITHDRAWAL'
  | 'CONTENT_REWARD'
  | 'REFUND'
  | 'INITIAL_BALANCE'
  | 'SYSTEM_ADJUSTMENT';

export interface LedgerEntry {
  ledger_id: string; // PRIMARY
  user_id: string;
  transaction_type: LedgerTransactionType;
  amount: number; // Signed or discreet amount
  reference_type: 'TASK' | 'MILESTONE' | 'SALARY' | 'WITHDRAWAL' | 'CONTENT' | 'PURGE' | 'SYSTEM' | 'REFERRAL';
  reference_id: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export type ReconciliationRunType = 'SCHEDULED' | 'MANUAL';
export type ReconciliationStatus = 'PASSED' | 'DISCREPANCY_FOUND';
export type DiscrepancyCategory = 'BALANCE_MISMATCH' | 'REFERRAL_MISMATCH' | 'SALARY_MISMATCH';

export interface DiscrepancyDetail {
  record_id: string;
  category: DiscrepancyCategory;
  user_id: string;
  username?: string;
  expected_value: number;
  actual_value: number;
  discrepancy_delta: number;
  reason: string;
  timestamp: string;
}

export interface AuditReconciliationSummary {
  audited_users_count: number;
  audited_ledger_entries_count: number;
  audited_referrals_count: number;
  audited_salaries_count: number;
  balanced_users_count: number;
  flagged_users_count: number;
  discrepancies: DiscrepancyDetail[];
  execution_duration_ms: number;
  run_by: string;
  notes?: string;
}

export interface AuditReconciliation {
  reconciliation_id: string; // PRIMARY
  run_type: ReconciliationRunType;
  status: ReconciliationStatus;
  mismatched_records_count: number;
  summary_log: AuditReconciliationSummary;
  executed_at: string;
}

export interface UserProfile {
  id: string; // Telegram UID or Unique User ID
  telegramId: string;
  username: string;
  fullName: string;
  photoUrl?: string;
  email: string;
  role: 'user' | 'admin';
  isPremium: boolean;
  status: 'active' | 'suspended' | 'pending_verification' | 'banned';
  isBanned?: boolean;
  banReason?: string;
  isSuspicious?: boolean;
  suspiciousReason?: string;
  hardwareIdHistory?: string[];
  lastLogin: string;
  createdAt: string;
  referredBy?: string;
  device_fingerprint?: string;
  deviceFingerprint?: string;
  last_active_at?: string;
  lastActiveAt?: string;
  authProvider?: 'telegram' | 'google' | 'guest';
  googleId?: string;
  guest_device_id?: string;
  points?: number;
  
  // VRMS-3 ULTRA Activity & Verification fields
  active_day_streak?: number;
  valid_action_count?: number;
  last_active_day_date?: string;
  activeDaysCount?: number;
  activeDaysList?: string[];
  downloadsCount?: number;
  isQuizPassed?: boolean;
  isHumanVerified?: boolean;
  qualified_referral_count?: number;
  registered_referral_count?: number;

  // VRMS-3 ULTRA Phase 5: Inactivity & Purge Engine fields
  inactivity_status?: 'ACTIVE' | 'INACTIVE_WARNING' | 'PURGE_ELIGIBLE' | 'PURGED';
  last_authenticated_access_at?: string;
  purge_eligible_at?: string | null;
  purged_at?: string | null;
  inactivity_warning_sent_at?: string | null;
  monthly_salary_eligible?: boolean;
  monthly_salary_tier?: string;

  // VRMS-3 ULTRA Phase 11: Risk & Security Engine (RSE)
  risk_score?: number; // 0-100
  risk_status?: 'LOW' | 'MEDIUM' | 'HIGH' | 'RESTRICTED' | 'BANNED';
  restriction_reason?: string;
  restricted_at?: string | null;
  registered_ip?: string;
  last_ip?: string;

  // VRMS-3 ULTRA Phase 15: Automated Audit & Reconciliation Engine (ARE)
  is_reconciled?: boolean;
  discrepancy_flag?: boolean;
  discrepancy_details?: DiscrepancyDetail | null;

  // Embedded modular components for scalable architecture
  wallet: UserWallet;
  taskStats: TaskStats;
}

export interface DBState {
  users: UserProfile[];
  movies: any[];
  videos: any[];
  missions: any[];
  missionLogs: any[];
  transactions: any[];
  referrals: ReferralRecord[];
  requests: any[];
  notifications: NotificationRecord[];
  withdrawals: any[];
  taskSessions: any[];
  vipRequests?: any[];
  vip_requests?: any[];
  user_activity?: UserActivityRecord[];
  verification_records?: VerificationRecord[];
  quiz_attempts?: QuizAttemptRecord[];
  purge_records?: PurgeRecord[];
  milestone_configs?: MilestoneConfig[];
  referral_rewards?: ReferralRewardRecord[];
  wallet_payment_profiles?: WalletPaymentProfile[];
  salary_requests?: SalaryRequestRecord[];
  salary_cycles?: SalaryCycle[];
  salary_snapshots?: SalarySnapshot[];
  admin_audit_logs?: AdminAuditLogRecord[];
  risk_assessments?: RiskAssessmentRecord[];
  security_audit_logs?: SecurityAuditLogRecord[];
  system_configs?: SystemConfigRecord[];
  campaigns?: CampaignRecord[];
  tasks?: DynamicTaskRecord[];
  content_items?: DynamicContentRecord[];
  ledger_entries?: LedgerEntry[];
  audit_reconciliations?: AuditReconciliation[];
  device_locks?: any[];
  content_mappings?: any[];
  verification_tokens?: any[];
  download_requests?: any[];
  settings: {
    domain: string;
    referralReward: number;
    referralCommissionPercent: number;
    minimumWithdrawal: number;
    isMaintenance: boolean;
    telegramBotLink: string;
    default_reward_pts?: number;
    guide_video_url?: string;
    guideVideoUrl?: string;
    guide_audio_url?: string;
    guideAudioUrl?: string;
    guideVideoLogoUrl?: string;
    activeMagazines?: number;
    battery_site_urls?: string[];
    batterySites?: string[];
    telegramChannelUrl?: string;
    telegramPostId?: string;
    reactionRewardPoints?: number;
    referralPayoutPlan?: 'PLAN_A' | 'PLAN_B';
  };
}

export const DEFAULT_SYSTEM_CONFIGS: SystemConfigRecord[] = [
  {
    config_key: "MAINTENANCE_MODE",
    config_value: false,
    description: "Force entire client ecosystem into maintenance mode with restricted operations.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "MAINTENANCE_MESSAGE",
    config_value: "We are currently conducting scheduled infrastructure upgrades. All VRMS-3 Ultra services and rewards will resume shortly.",
    description: "User-facing banner and modal text displayed during active maintenance mode.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "MIN_APP_VERSION",
    config_value: "1.0.0",
    description: "Minimum required client build version to prevent outdated client fraud.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "APP_DOWNLOAD_LINK",
    config_value: "https://myteleflix.com/download",
    description: "Official verified client application and APK download portal URL.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "REFERRAL_TARGET_QUALIFIED",
    config_value: 10,
    description: "Required active days in 30-day window for a direct referee to qualify.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "SALARY_MAX_LEVEL",
    config_value: 3,
    description: "Hard ceiling maximum salary tier level (strictly 3 forever).",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "DEFAULT_REWARD_POINTS",
    config_value: 500,
    description: "Base mission reward points allocated to standard earning activities.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "COMMUNITY_TELEGRAM_LINK",
    config_value: "https://t.me/myteleflix_official",
    description: "Official community announcements and support telegram channel.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  },
  {
    config_key: "TELEGRAM_BOT_URL",
    config_value: "https://t.me/myteleflix_bot",
    description: "Primary Telegram bot gateway link.",
    last_updated_by: "system_init",
    updated_at: new Date().toISOString()
  }
];

export const DEFAULT_CAMPAIGNS: CampaignRecord[] = [
  {
    campaign_id: "campaign_genesis_2026",
    title: "VRMS-3 Ultra Pioneer Genesis Campaign",
    start_date: "2026-01-01T00:00:00.000Z",
    end_date: "2026-12-31T23:59:59.999Z",
    status: "ACTIVE",
    target_metrics: {
      target_referrals: 1000,
      budget: 50000000,
      bonus_multiplier: 1.0,
      description: "Genesis referral campaign powering network rewards under the DCE framework."
    },
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: new Date().toISOString()
  }
];

export const DEFAULT_DYNAMIC_TASKS: DynamicTaskRecord[] = [
  {
    task_id: "tsk-tg-join",
    title: "Join Official Telegram Channel",
    description: "Join our official announcements community on Telegram to stay updated on drops and rewards.",
    reward_points: 300,
    task_type: "EARNING",
    target_url: "https://t.me/myteleflix_official",
    daily_limit_per_user: 1,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 1420
  },
  {
    task_id: "tsk-daily-checkin",
    title: "Daily Platform Check-in",
    description: "Verify your attendance today and instantly earn active activity points.",
    reward_points: 250,
    task_type: "EARNING",
    target_url: "https://t.me/myteleflix_official",
    daily_limit_per_user: 1,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 3890
  },
  {
    task_id: "tsk-survey-feedback",
    title: "Platform Feature & UX Feedback Survey",
    description: "Answer 4 quick questions about streaming quality and referral experience to earn bonus points.",
    reward_points: 500,
    task_type: "SURVEY",
    target_url: "https://forms.gle/teleflix_ux_survey",
    daily_limit_per_user: 1,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 850
  },
  {
    task_id: "tsk-vid-trailer",
    title: "Watch VRMS-3 Ultra Feature Spotlight 4K",
    description: "Watch the full 60-second product walkthrough video to qualify for today's video quota.",
    reward_points: 350,
    task_type: "VIDEO",
    target_url: "https://www.w3schools.com/html/mov_bbb.mp4",
    daily_limit_per_user: 3,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 2190
  },
  {
    task_id: "tsk-vid-guide",
    title: "Watch Bangla Cinema Highlights",
    description: "Stream the curated movie teaser reel to complete one of your daily video tasks.",
    reward_points: 400,
    task_type: "VIDEO",
    target_url: "https://www.w3schools.com/html/mov_bbb.mp4",
    daily_limit_per_user: 2,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 1780
  },
  {
    task_id: "tsk-earn-sponsor",
    title: "Explore Partner Telegram Bot",
    description: "Interact with our verified partner mini-app to receive your promotional reward points.",
    reward_points: 450,
    task_type: "EARNING",
    target_url: "https://t.me/partner_spotlight_bot",
    daily_limit_per_user: 1,
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    completed_count: 940
  }
];

export const DEFAULT_DYNAMIC_CONTENT: DynamicContentRecord[] = [
  {
    content_id: "cnt-mov-01",
    title: "Dhaka Attack: Special Operations 4K",
    category: "MOVIE",
    download_url: "https://example.com/downloads/dhaka_attack_4k.mp4",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "High-octane action blockbuster featuring counter-terrorism squad in Dhaka.",
    thumbnail_url: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "1.4 GB",
    reward_points: 150,
    download_count: 3200
  },
  {
    content_id: "cnt-mov-02",
    title: "Hawa: Deep Sea Mystery UNCUT",
    category: "MOVIE",
    download_url: "https://example.com/downloads/hawa_uncut.mp4",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "National award-winning thriller set aboard a deep-sea fishing trawler in the Bay of Bengal.",
    thumbnail_url: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "1.2 GB",
    reward_points: 150,
    download_count: 4890
  },
  {
    content_id: "cnt-drm-01",
    title: "Bachelor Point Eid Fiesta HD",
    category: "DRAMA",
    download_url: "https://example.com/downloads/bachelor_point_eid.mp4",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "The beloved gang from Dhaka navigates unexpected holiday chaos in this laugh riot.",
    thumbnail_url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "650 MB",
    reward_points: 100,
    download_count: 7200
  },
  {
    content_id: "cnt-drm-02",
    title: "Punorjonmo: The Final Climax",
    category: "DRAMA",
    download_url: "https://example.com/downloads/punorjonmo_climax.mp4",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "The final culinary thriller conclusion starring Afran Nisho & Mehazabien Chowdhury.",
    thumbnail_url: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "720 MB",
    reward_points: 100,
    download_count: 5600
  },
  {
    content_id: "cnt-app-01",
    title: "MyTeleFlix Ultra Pro Player APK",
    category: "APP",
    download_url: "https://example.com/downloads/myteleflix_player_v3.apk",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "Official companion media player with hardware acceleration and background audio.",
    thumbnail_url: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "24 MB",
    reward_points: 200,
    download_count: 9100
  },
  {
    content_id: "cnt-app-02",
    title: "TurboStream Fast Proxy VPN",
    category: "APP",
    download_url: "https://example.com/downloads/turbostream_vpn.apk",
    status: "ACTIVE",
    created_at: "2026-01-01T00:00:00.000Z",
    description: "Ultra-low latency proxy engine optimized for Bangladeshi mobile networks.",
    thumbnail_url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&h=350&q=80",
    file_size: "18 MB",
    reward_points: 200,
    download_count: 6400
  }
];

export function getInitialDBState(): DBState {
  return {
    users: [],
    movies: [
      {
        id: "mv-101",
        title: "Interstellar Premiere (Bangla & Hindi Dubbed)",
        description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
        thumbnailUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Sci-Fi",
        duration: "2h 49m",
        pointsReward: 450,
        isPremiumOnly: false,
        rating: 8.7,
        releaseYear: 2014,
        isActive: true,
        views: 12409,
        contentType: "movie",
        languages: ["Bangla", "Hindi", "English", "Original"],
        banglaLink: "https://t.me/teleflix_bot?start=mv101_bn",
        hindiLink: "https://t.me/teleflix_bot?start=mv101_hi",
        englishLink: "https://t.me/teleflix_bot?start=mv101_en"
      },
      {
        id: "mv-102",
        title: "The Dark Knight 4K Ultra HD",
        description: "When the menace known as the Joker wreaks havoc and chaos on Gotham, Batman must accept one of the greatest tests.",
        thumbnailUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Action",
        duration: "2h 32m",
        pointsReward: 600,
        isPremiumOnly: true,
        rating: 9.0,
        releaseYear: 2008,
        isActive: true,
        views: 28402,
        contentType: "movie",
        languages: ["English", "Hindi"]
      },
      {
        id: "mv-107",
        title: "Oppenheimer IMAX Enhanced Dubbed",
        description: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.",
        thumbnailUrl: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Biography",
        duration: "3h 00m",
        pointsReward: 550,
        isPremiumOnly: false,
        rating: 8.9,
        releaseYear: 2023,
        isActive: true,
        views: 34100,
        contentType: "movie",
        languages: ["Bangla", "Hindi", "English"]
      },
      {
        id: "mv-108",
        title: "Avatar: The Way of Water 3D",
        description: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora once more under siege.",
        thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Sci-Fi",
        duration: "3h 12m",
        pointsReward: 600,
        isPremiumOnly: false,
        rating: 8.5,
        releaseYear: 2024,
        isActive: true,
        views: 41200,
        contentType: "movie",
        languages: ["Hindi", "English"]
      },
      {
        id: "ser-105",
        title: "Mirzapur Complete Season 3 (Full Episodes)",
        description: "The battle for Purvanchal intensifies with Guddu Pandit and Kaleen Bhaiya.",
        thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "Season 3 • All 10 Episodes Pack",
        duration: "45m/Ep",
        pointsReward: 500,
        isPremiumOnly: false,
        rating: 8.8,
        releaseYear: 2024,
        isActive: true,
        views: 48900,
        contentType: "series",
        languages: ["Hindi", "Bangla"]
      },
      {
        id: "ser-106",
        title: "Sacred Games Season 1 & 2 Pack",
        description: "A link in their pasts leads an honest cop to a fugitive gang boss whose cryptic warning spurs crime mystery.",
        thumbnailUrl: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "Complete 16 Episodes",
        duration: "50m/Ep",
        pointsReward: 480,
        isPremiumOnly: false,
        rating: 8.6,
        releaseYear: 2023,
        isActive: true,
        views: 39400,
        contentType: "series",
        languages: ["Hindi", "English"]
      },
      {
        id: "ser-111",
        title: "Farzi Season 1 Complete Dual Audio",
        description: "An artist gets pulled into the murky high stakes of a con job and a task force officer on his trail.",
        thumbnailUrl: "https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "8 Full Episodes 4K",
        duration: "55m/Ep",
        pointsReward: 520,
        isPremiumOnly: false,
        rating: 8.7,
        releaseYear: 2024,
        isActive: true,
        views: 43200,
        contentType: "series",
        languages: ["Hindi", "Bangla"]
      },
      {
        id: "ser-112",
        title: "Money Heist (La Casa de Papel) Complete Pack",
        description: "The Professor and his gang embark on daring heists at the Royal Mint of Spain and Bank of Spain.",
        thumbnailUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "5 Seasons All Episodes",
        duration: "48m/Ep",
        pointsReward: 650,
        isPremiumOnly: false,
        rating: 8.9,
        releaseYear: 2024,
        isActive: true,
        views: 78900,
        contentType: "series",
        languages: ["Hindi", "English", "Spanish"]
      },
      {
        id: "ser-113",
        title: "Panchayat Season 1, 2 & 3 Complete",
        description: "An engineering graduate takes up a job as an Panchayat secretary in a remote Indian village.",
        thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "3 Seasons All Episodes",
        duration: "35m/Ep",
        pointsReward: 490,
        isPremiumOnly: false,
        rating: 9.0,
        releaseYear: 2024,
        isActive: true,
        views: 61200,
        contentType: "series",
        languages: ["Hindi", "Bangla"]
      },
      {
        id: "ser-114",
        title: "Stranger Things Season 1-4 Complete Pack",
        description: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments and terrifying supernatural forces.",
        thumbnailUrl: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Web Series",
        totalEpisodes: "4 Seasons Complete",
        duration: "50m/Ep",
        pointsReward: 580,
        isPremiumOnly: false,
        rating: 8.9,
        releaseYear: 2024,
        isActive: true,
        views: 84500,
        contentType: "series",
        languages: ["Hindi", "English"]
      },
      {
        id: "drm-103",
        title: "Bachelor Point Eid Special Natok HD",
        description: "Exclusive hilarious episode featuring Kabila, Habu, Passu and friends in Dhaka.",
        thumbnailUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Deshi Natok",
        category: "Deshi",
        duration: "48m",
        pointsReward: 300,
        isPremiumOnly: false,
        rating: 9.3,
        releaseYear: 2025,
        isActive: true,
        views: 54120,
        contentType: "drama",
        languages: ["Bangla"]
      },
      {
        id: "drm-104",
        title: "Buker Moddhe Agun Single Drama",
        description: "Romantic emotional Bangla telefilm starring Ziaul Faruq Apurba & Mehazabien.",
        thumbnailUrl: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Deshi Natok",
        category: "Deshi",
        duration: "42m",
        pointsReward: 250,
        isPremiumOnly: false,
        rating: 8.9,
        releaseYear: 2025,
        isActive: true,
        views: 31200,
        contentType: "drama",
        languages: ["Bangla"]
      },
      {
        id: "drm-109",
        title: "Punorjonmo The Final Chapter",
        description: "The thrilling climax of Rafat Mozumder Rinku's culinary thriller masterpiece starring Afran Nisho.",
        thumbnailUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Deshi Natok",
        category: "Deshi",
        duration: "55m",
        pointsReward: 350,
        isPremiumOnly: false,
        rating: 9.4,
        releaseYear: 2025,
        isActive: true,
        views: 62800,
        contentType: "drama",
        languages: ["Bangla"]
      },
      {
        id: "drm-110",
        title: "Senior vs Junior Love Story",
        description: "Campus romantic comedy drama featuring Jovan and Tanjin Tisha.",
        thumbnailUrl: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Deshi Natok",
        category: "Deshi",
        duration: "38m",
        pointsReward: 220,
        isPremiumOnly: false,
        rating: 8.8,
        releaseYear: 2025,
        isActive: true,
        views: 29800,
        contentType: "drama",
        languages: ["Bangla"]
      },
      {
        id: "amv-101",
        title: "Deshi Midnight Romance 18+ UNCUT HDR",
        description: "Exclusive premium adult feature film in full 1080p uncut version.",
        thumbnailUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Adult 18+",
        category: "Deshi",
        duration: "1h 38m",
        pointsReward: 600,
        isPremiumOnly: false,
        rating: 9.1,
        releaseYear: 2025,
        isActive: true,
        views: 64200,
        contentType: "adult_movie",
        languages: ["Bangla", "Hindi"]
      },
      {
        id: "amv-102",
        title: "Russian Passion Ultra HD 4K 18+",
        description: "High budget international adult drama uncut cinematic release with multi audio.",
        thumbnailUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Adult 18+",
        category: "Russian",
        duration: "1h 45m",
        pointsReward: 650,
        isPremiumOnly: false,
        rating: 9.3,
        releaseYear: 2026,
        isActive: true,
        views: 89400,
        contentType: "adult_movie",
        languages: ["Russian", "English", "Hindi"]
      },
      {
        id: "amv-103",
        title: "Indian Secret Nights Web Episode 18+",
        description: "Trending Indian spicy romantic drama uncut version with high quality dubbing.",
        thumbnailUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Adult 18+",
        category: "Indian",
        duration: "1h 22m",
        pointsReward: 580,
        isPremiumOnly: false,
        rating: 8.9,
        releaseYear: 2025,
        isActive: true,
        views: 51200,
        contentType: "adult_movie",
        languages: ["Hindi", "Bangla"]
      },
      {
        id: "amv-104",
        title: "Hollywood Velvet Desire 18+ Directors Cut",
        description: "Sensational Hollywood adult romantic thriller with uncensored footage.",
        thumbnailUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&h=350&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        genre: "Adult 18+",
        category: "English",
        duration: "1h 50m",
        pointsReward: 620,
        isPremiumOnly: false,
        rating: 9.2,
        releaseYear: 2026,
        isActive: true,
        views: 72800,
        contentType: "adult_movie",
        languages: ["English", "Hindi"]
      }
    ],
    videos: [
      {
        id: "vd-1",
        title: "Grand Theft Auto VI Trailer 1",
        description: "The official first trailer of GTA VI exploring Vice City in breathtaking high-fidelity next-gen realism.",
        thumbnailUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&h=450&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        duration: "1h 30m",
        pointsReward: 150,
        requiredMissionId: "",
        isActive: true,
        views: 4560
      },
      {
        id: "vd-2",
        title: "Inside Out 2 Teaser Reveal",
        description: "Meet the new emotion, Anxiety, joining Riley's mind in this beautiful upcoming Pixar sequel.",
        thumbnailUrl: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&h=450&q=80",
        videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
        duration: "2m 15s",
        pointsReward: 100,
        requiredMissionId: "",
        isActive: true,
        views: 2900
      }
    ],
    missions: [
      {
        id: "ms-1",
        title: "Join TES Official Telegram",
        description: "Join our official announcement channel on Telegram to stay updated with latest movies and referral updates.",
        type: "telegram_join",
        rewardPoints: 500,
        url: "https://t.me/tes_platform_announcements",
        isActive: true,
        order: 1
      },
      {
        id: "ms-2",
        title: "Subscribe to TES Youtube",
        description: "Subscribe to our channel to watch movie reviews, gaming trailers and exclusive video clips.",
        type: "youtube_subscribe",
        rewardPoints: 400,
        url: "https://youtube.com/tes_platform_shorts",
        isActive: true,
        order: 2
      },
      {
        id: "ms-3",
        title: "Follow TES on Twitter / X",
        description: "Follow us on Twitter to participate in weekly platform giveaways and points drops.",
        type: "twitter_follow",
        rewardPoints: 300,
        url: "https://twitter.com/tes_platform",
        isActive: true,
        order: 3
      },
      {
        id: "ms-4",
        title: "Daily Check-in Reward",
        description: "Claim your daily check-in streak bonus of 100 points! Resets every 24 hours.",
        type: "daily_checkin",
        rewardPoints: 100,
        isActive: true,
        order: 4,
        cooldownHours: 24
      },
      {
        id: "ms-5",
        title: "Watch Premium Sponsoring Ad",
        description: "Support the platform by watching a short sponsored visual ad and instantly receive points.",
        type: "watch_ad",
        rewardPoints: 250,
        isActive: true,
        order: 5,
        cooldownHours: 1
      }
    ],
    missionLogs: [],
    transactions: [],
    referrals: [],
    requests: [],
    notifications: [],
    withdrawals: [],
    taskSessions: [],
    user_activity: [],
    verification_records: [],
    quiz_attempts: [],
    purge_records: [],
    milestone_configs: DEFAULT_MILESTONE_CONFIGS,
    referral_rewards: [],
    wallet_payment_profiles: [],
    salary_requests: [],
    salary_cycles: [],
    salary_snapshots: [],
    admin_audit_logs: [],
    ledger_entries: [],
    audit_reconciliations: [],
    device_locks: [],
    settings: {
      domain: "t.me/myteleflix_bot",
      referralReward: 300,
      referralCommissionPercent: 10,
      minimumWithdrawal: 1000,
      isMaintenance: false,
      telegramBotLink: "https://t.me/myteleflix_bot",
      default_reward_pts: 500,
      guide_video_url: "https://www.w3schools.com/html/mov_bbb.mp4",
      guideVideoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
      guideVideoLogoUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&h=450&q=80",
      activeMagazines: 3,
      battery_site_urls: [
        "https://battery1.myteleflix.com",
        "https://battery2.myteleflix.com",
        "https://battery3.myteleflix.com"
      ],
      batterySites: [
        "https://battery1.myteleflix.com",
        "https://battery2.myteleflix.com",
        "https://battery3.myteleflix.com"
      ],
      referralPayoutPlan: 'PLAN_A'
    },
    system_configs: DEFAULT_SYSTEM_CONFIGS,
    campaigns: DEFAULT_CAMPAIGNS,
    tasks: DEFAULT_DYNAMIC_TASKS,
    content_items: DEFAULT_DYNAMIC_CONTENT
  };
}

export function readDB(): DBState {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const state = getInitialDBState();
      writeDB(state);
      return state;
    }
    const raw = fs.readFileSync(DB_FILE, "utf-8").trim();
    if (!raw) {
      console.warn("Database file is empty, repairing with initial state...");
      const state = getInitialDBState();
      writeDB(state);
      return state;
    }
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") {
      throw new Error("Invalid database format: root must be an object");
    }
    
    // Auto-migrate legacy user objects in DB to include wallet and stats if missing
    let migrated = false;
    if (parsed.users && Array.isArray(parsed.users)) {
      parsed.users.forEach((u: any) => {
        if (!u.wallet) {
          u.wallet = {
            points: typeof u.points === 'number' ? u.points : 1000,
            walletAddress: "",
            status: "active",
            updatedAt: new Date().toISOString()
          };
          migrated = true;
        }
        if (!u.taskStats) {
          u.taskStats = {
            missionsCompleted: 0,
            totalPointsEarned: typeof u.points === 'number' ? u.points : 1000,
            moviesWatched: 0,
            videosWatched: 0
          };
          migrated = true;
        }
        if (!u.status) {
          u.status = "active";
          migrated = true;
        }
        if (!u.lastLogin) {
          u.lastLogin = new Date().toISOString();
          migrated = true;
        }
        // Sync root level user points to be backwards compatible with existing frontend parts
        if (typeof u.points === 'undefined' || u.points !== u.wallet.points) {
          u.points = u.wallet.points;
        }
      });
    }

    if (!parsed.taskSessions) {
      parsed.taskSessions = [];
      migrated = true;
    }

    if (!parsed.vipRequests) {
      parsed.vipRequests = [];
      migrated = true;
    }

    if (!parsed.vip_requests) {
      parsed.vip_requests = parsed.vipRequests;
      migrated = true;
    }

    if (!parsed.user_activity) {
      parsed.user_activity = [];
      migrated = true;
    }

    if (!parsed.verification_records) {
      parsed.verification_records = [];
      migrated = true;
    }

    if (!parsed.quiz_attempts) {
      parsed.quiz_attempts = [];
      migrated = true;
    }

    if (!parsed.purge_records) {
      parsed.purge_records = [];
      migrated = true;
    }

    if (!parsed.milestone_configs || !Array.isArray(parsed.milestone_configs) || parsed.milestone_configs.length === 0) {
      parsed.milestone_configs = DEFAULT_MILESTONE_CONFIGS;
      migrated = true;
    }

    if (!parsed.referral_rewards || !Array.isArray(parsed.referral_rewards)) {
      parsed.referral_rewards = [];
      migrated = true;
    }

    if (!parsed.wallet_payment_profiles || !Array.isArray(parsed.wallet_payment_profiles)) {
      parsed.wallet_payment_profiles = [];
      migrated = true;
    }

    if (!parsed.salary_requests || !Array.isArray(parsed.salary_requests)) {
      parsed.salary_requests = [];
      migrated = true;
    }

    if (!parsed.salary_cycles || !Array.isArray(parsed.salary_cycles)) {
      parsed.salary_cycles = [];
      migrated = true;
    }

    if (!parsed.salary_snapshots || !Array.isArray(parsed.salary_snapshots)) {
      parsed.salary_snapshots = [];
      migrated = true;
    }

    if (!parsed.admin_audit_logs || !Array.isArray(parsed.admin_audit_logs)) {
      parsed.admin_audit_logs = [];
      migrated = true;
    }

    if (!parsed.risk_assessments || !Array.isArray(parsed.risk_assessments)) {
      parsed.risk_assessments = [];
      migrated = true;
    }

    if (!parsed.security_audit_logs || !Array.isArray(parsed.security_audit_logs)) {
      parsed.security_audit_logs = [];
      migrated = true;
    }

    if (parsed.users && Array.isArray(parsed.users)) {
      parsed.users.forEach((u: any) => {
        if (typeof u.active_day_streak === 'undefined') {
          u.active_day_streak = u.activeDaysCount || 0;
          migrated = true;
        }
        if (typeof u.valid_action_count === 'undefined') {
          u.valid_action_count = (u.taskStats?.missionsCompleted || 0) + (u.taskStats?.moviesWatched || 0) + (u.taskStats?.videosWatched || 0) + (u.downloadsCount || 0);
          migrated = true;
        }
        if (!u.last_activity_at) {
          u.last_activity_at = u.lastActiveAt || u.lastLogin || u.createdAt || new Date().toISOString();
          migrated = true;
        }
        if (!u.last_authenticated_access_at) {
          u.last_authenticated_access_at = u.last_activity_at || u.lastLogin || u.createdAt || new Date().toISOString();
          migrated = true;
        }
        if (!u.inactivity_status) {
          u.inactivity_status = u.isBanned ? 'PURGED' : 'ACTIVE';
          migrated = true;
        }
        if (typeof u.risk_score === 'undefined') {
          u.risk_score = u.isBanned ? 100 : u.isSuspicious ? 60 : 0;
          migrated = true;
        }
        if (!u.risk_status) {
          u.risk_status = u.isBanned ? 'BANNED' : u.status === 'suspended' ? 'RESTRICTED' : u.isSuspicious ? 'HIGH' : 'LOW';
          migrated = true;
        }
        if (typeof u.is_reconciled === 'undefined') {
          u.is_reconciled = true;
          migrated = true;
        }
        if (typeof u.discrepancy_flag === 'undefined') {
          u.discrepancy_flag = false;
          migrated = true;
        }
        if (typeof u.discrepancy_details === 'undefined') {
          u.discrepancy_details = null;
          migrated = true;
        }
      });
    }

    if (parsed.settings) {
      if (!parsed.settings.default_reward_pts) {
        parsed.settings.default_reward_pts = 500;
        migrated = true;
      }
      if (!parsed.settings.guide_video_url) {
        parsed.settings.guide_video_url = parsed.settings.guideVideoUrl || "https://www.w3schools.com/html/mov_bbb.mp4";
        migrated = true;
      }
      if (!parsed.settings.guideVideoUrl) {
        parsed.settings.guideVideoUrl = parsed.settings.guide_video_url || "https://www.w3schools.com/html/mov_bbb.mp4";
        migrated = true;
      }
      if (!parsed.settings.guideVideoLogoUrl) {
        parsed.settings.guideVideoLogoUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&h=450&q=80";
        migrated = true;
      }
      if (typeof parsed.settings.activeMagazines === 'undefined') {
        parsed.settings.activeMagazines = 3;
        migrated = true;
      }
      if (!parsed.settings.battery_site_urls || parsed.settings.battery_site_urls.length === 0) {
        parsed.settings.battery_site_urls = parsed.settings.batterySites || [
          "https://battery1.myteleflix.com",
          "https://battery2.myteleflix.com",
          "https://battery3.myteleflix.com"
        ];
        migrated = true;
      }
      if (!parsed.settings.batterySites || parsed.settings.batterySites.length === 0) {
        parsed.settings.batterySites = parsed.settings.battery_site_urls || [
          "https://battery1.myteleflix.com",
          "https://battery2.myteleflix.com",
          "https://battery3.myteleflix.com"
        ];
        migrated = true;
      }
      if (!parsed.settings.telegramChannelUrl) {
        parsed.settings.telegramChannelUrl = "https://t.me/myteleflix_official";
        migrated = true;
      }
      if (!parsed.settings.telegramPostId) {
        parsed.settings.telegramPostId = "https://t.me/myteleflix_official/124";
        migrated = true;
      }
      if (!parsed.settings.reactionRewardPoints) {
        parsed.settings.reactionRewardPoints = 50;
        migrated = true;
      }
      if (!parsed.settings.referralPayoutPlan) {
        parsed.settings.referralPayoutPlan = 'PLAN_A';
        migrated = true;
      }
    }

    if (!parsed.system_configs || !Array.isArray(parsed.system_configs) || parsed.system_configs.length === 0) {
      parsed.system_configs = [...DEFAULT_SYSTEM_CONFIGS];
      migrated = true;
    } else {
      for (const defCfg of DEFAULT_SYSTEM_CONFIGS) {
        if (!parsed.system_configs.some((c: SystemConfigRecord) => c.config_key === defCfg.config_key)) {
          parsed.system_configs.push({ ...defCfg });
          migrated = true;
        }
      }
    }

    if (!parsed.campaigns || !Array.isArray(parsed.campaigns) || parsed.campaigns.length === 0) {
      parsed.campaigns = [...DEFAULT_CAMPAIGNS];
      migrated = true;
    }

    if (!parsed.tasks || !Array.isArray(parsed.tasks) || parsed.tasks.length === 0) {
      parsed.tasks = [...DEFAULT_DYNAMIC_TASKS];
      migrated = true;
    }

    if (!parsed.content_items || !Array.isArray(parsed.content_items) || parsed.content_items.length === 0) {
      parsed.content_items = [...DEFAULT_DYNAMIC_CONTENT];
      migrated = true;
    }

    // VRMS-3 ULTRA (Phase 15): Automated Audit & Reconciliation Engine (ARE) collections
    if (!parsed.ledger_entries || !Array.isArray(parsed.ledger_entries)) {
      parsed.ledger_entries = [];
      migrated = true;
      // Double-entry backfill: populate ledger entries for any existing transactions
      if (parsed.transactions && Array.isArray(parsed.transactions)) {
        parsed.transactions.forEach((tx: any) => {
          let refType: 'TASK' | 'MILESTONE' | 'SALARY' | 'WITHDRAWAL' | 'CONTENT' | 'PURGE' | 'SYSTEM' | 'REFERRAL' = 'SYSTEM';
          let txType: LedgerTransactionType = 'TASK_REWARD';
          if (tx.type === 'referral_milestone') {
            refType = 'MILESTONE';
            txType = 'MILESTONE_BONUS';
          } else if (tx.type === 'salary_payout' || tx.type === 'salary') {
            refType = 'SALARY';
            txType = 'SALARY_PAYOUT';
          } else if (tx.type === 'withdrawal') {
            refType = 'WITHDRAWAL';
            txType = 'WITHDRAWAL';
          } else if (tx.type === 'reward_content' || tx.type === 'content_reward') {
            refType = 'CONTENT';
            txType = 'CONTENT_REWARD';
          } else if (tx.type === 'deposit') {
            refType = 'SYSTEM';
            txType = 'INITIAL_BALANCE';
          } else if (tx.type === 'bonus') {
            refType = 'SYSTEM';
            txType = 'REFUND';
          }
          parsed.ledger_entries.push({
            ledger_id: `led_${tx.id || Math.random().toString(36).slice(2, 9)}`,
            user_id: tx.userId,
            transaction_type: txType,
            amount: typeof tx.amount === 'number' ? tx.amount : 0,
            reference_type: refType,
            reference_id: tx.id || 'initial_tx',
            created_at: tx.timestamp || new Date().toISOString()
          });
        });
      }
    }

    if (!parsed.audit_reconciliations || !Array.isArray(parsed.audit_reconciliations)) {
      parsed.audit_reconciliations = [];
      migrated = true;
    }

    if (!parsed.device_locks || !Array.isArray(parsed.device_locks)) {
      parsed.device_locks = [];
      migrated = true;
    }

    if (migrated) {
      writeDB(parsed);
    }

    syncAllDbIndexes(parsed);
    return parsed;
  } catch (err) {
    console.error("Error reading database file, repairing with default initial state:", err);
    const fallback = getInitialDBState();
    try {
      writeDB(fallback);
    } catch (writeErr) {
      console.error("Failed to repair database file with fallback state:", writeErr);
    }
    syncAllDbIndexes(fallback);
    return fallback;
  }
}

export function writeDB(data: DBState) {
  try {
    // Keep top-level points in-sync with nested wallet points for client legacy safety
    if (data.users && Array.isArray(data.users)) {
      data.users.forEach((u: any) => {
        if (u.wallet) {
          u.points = u.wallet.points;
        }
      });
    }
    const jsonStr = JSON.stringify(data, null, 2);
    // Write atomically via temporary file to prevent zero-byte corruptions
    const tempFile = `${DB_FILE}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
    fs.writeFileSync(tempFile, jsonStr, "utf-8");
    fs.renameSync(tempFile, DB_FILE);
    syncAllDbIndexes(data);
  } catch (err) {
    console.error("Error writing database file atomically:", err);
    // Direct fallback write in case rename fails
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
      syncAllDbIndexes(data);
    } catch (directErr) {
      console.error("Direct fallback write to DB_FILE also failed:", directErr);
    }
  }

  // Non-blocking Firestore synchronization to ensure cloud database resilience
  try {
    if (data.settings) {
      isFirestoreWritable().then((writable) => {
        if (writable) {
          setDoc(doc(firestore, "system_configs", "app_settings"), {
            ...data.settings,
            updatedAt: new Date().toISOString()
          }, { merge: true }).catch(() => {});
        }
      }).catch(() => {});
    }
  } catch {}
}

// ============================================================================
// VRMS-3 ULTRA (Phase 16): Comprehensive Query Indexes & Fast Cache Maps
// ============================================================================
const userByIdIndex = new Map<string, UserProfile>();
const userByTelegramIdIndex = new Map<string, UserProfile>();
const userByUsernameIndex = new Map<string, UserProfile>();
const userActivityByUserIdIndex = new Map<string, UserActivityRecord[]>();
const userActiveDatesIndex = new Map<string, Set<string>>();
const verificationRecordByUserIdIndex = new Map<string, VerificationRecord>();
const referralsByReferrerIdIndex = new Map<string, ReferralRecord[]>();
const referralByReferredUserIdIndex = new Map<string, ReferralRecord>();
const salaryRequestByIdIndex = new Map<string, SalaryRequestRecord>();
const salaryRequestByUserCycleIndex = new Map<string, SalaryRequestRecord>();
const ledgerEntriesByUserIdIndex = new Map<string, LedgerEntry[]>();
const ledgerSumsByUserIdIndex = new Map<string, number>();
const tasksByIdIndex = new Map<string, DynamicTaskRecord>();
const contentByIdIndex = new Map<string, DynamicContentRecord>();
const systemConfigByKeyIndex = new Map<string, SystemConfigRecord>();

/**
 * Rebuilds all in-memory database query indexes in a single high-performance O(N) pass
 */
export function syncAllDbIndexes(db: DBState): void {
  // 1. Users Indexes
  userByIdIndex.clear();
  userByTelegramIdIndex.clear();
  userByUsernameIndex.clear();
  if (Array.isArray(db.users)) {
    for (const u of db.users) {
      if (u.id) userByIdIndex.set(u.id, u);
      if (u.telegramId) userByTelegramIdIndex.set(u.telegramId, u);
      if (u.username) userByUsernameIndex.set(u.username.toLowerCase(), u);
    }
  }

  // 2. User Activity & Active Dates Indexes
  userActivityByUserIdIndex.clear();
  userActiveDatesIndex.clear();
  if (Array.isArray(db.user_activity)) {
    for (const act of db.user_activity) {
      if (act.user_id) {
        let acts = userActivityByUserIdIndex.get(act.user_id);
        if (!acts) {
          acts = [];
          userActivityByUserIdIndex.set(act.user_id, acts);
        }
        acts.push(act);

        if (act.activity_date) {
          let dateSet = userActiveDatesIndex.get(act.user_id);
          if (!dateSet) {
            dateSet = new Set<string>();
            userActiveDatesIndex.set(act.user_id, dateSet);
          }
          dateSet.add(act.activity_date);
        }
      }
    }
  }

  // 3. Verification Records Index
  verificationRecordByUserIdIndex.clear();
  if (Array.isArray(db.verification_records)) {
    for (const v of db.verification_records) {
      if (v.user_id) {
        verificationRecordByUserIdIndex.set(v.user_id, v);
      }
    }
  }

  // 4. Referrals Indexes
  referralsByReferrerIdIndex.clear();
  referralByReferredUserIdIndex.clear();
  if (Array.isArray(db.referrals)) {
    for (const r of db.referrals) {
      const referrer = r.referrer_id || (r as any).referrerId;
      const referred = r.referred_user_id || (r as any).referredId;
      if (referrer) {
        let refs = referralsByReferrerIdIndex.get(referrer);
        if (!refs) {
          refs = [];
          referralsByReferrerIdIndex.set(referrer, refs);
        }
        refs.push(r);
      }
      if (referred) {
        referralByReferredUserIdIndex.set(referred, r);
      }
    }
  }

  // 5. Salary Requests Indexes
  salaryRequestByIdIndex.clear();
  salaryRequestByUserCycleIndex.clear();
  if (Array.isArray(db.salary_requests)) {
    for (const req of db.salary_requests) {
      if (req.request_id) {
        salaryRequestByIdIndex.set(req.request_id, req);
      }
      if (req.user_id && req.cycle_id) {
        salaryRequestByUserCycleIndex.set(`${req.user_id}::${req.cycle_id}`, req);
      }
    }
  }

  // 6. Ledger Entries & Pre-Aggregated Sums Indexes
  ledgerEntriesByUserIdIndex.clear();
  ledgerSumsByUserIdIndex.clear();
  if (Array.isArray(db.ledger_entries)) {
    for (const entry of db.ledger_entries) {
      if (entry.user_id) {
        let entries = ledgerEntriesByUserIdIndex.get(entry.user_id);
        if (!entries) {
          entries = [];
          ledgerEntriesByUserIdIndex.set(entry.user_id, entries);
        }
        entries.push(entry);

        const currentSum = ledgerSumsByUserIdIndex.get(entry.user_id) || 0;
        ledgerSumsByUserIdIndex.set(entry.user_id, currentSum + (entry.amount || 0));
      }
    }
  }

  // 7. Dynamic Tasks Index
  tasksByIdIndex.clear();
  if (Array.isArray(db.tasks)) {
    for (const t of db.tasks) {
      if (t.task_id) tasksByIdIndex.set(t.task_id, t);
    }
  }

  // 8. Dynamic Content Index
  contentByIdIndex.clear();
  if (Array.isArray(db.content_items)) {
    for (const c of db.content_items) {
      if (c.content_id) contentByIdIndex.set(c.content_id, c);
    }
  }

  // 9. System Config Index
  systemConfigByKeyIndex.clear();
  if (Array.isArray(db.system_configs)) {
    for (const cfg of db.system_configs) {
      if (cfg.config_key) systemConfigByKeyIndex.set(cfg.config_key, cfg);
    }
  }
}

/**
 * Backwards compatibility alias for syncSalaryRequestIndexes
 */
export function syncSalaryRequestIndexes(db: DBState): void {
  syncAllDbIndexes(db);
}

/**
 * Fast O(1) indexed lookup of User by ID
 */
export function getUserById(userId: string, db?: DBState): UserProfile | undefined {
  if (!userId) return undefined;
  if (userByIdIndex.has(userId)) return userByIdIndex.get(userId);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return userByIdIndex.get(userId);
}

/**
 * Fast O(1) indexed lookup of User by Telegram ID
 */
export function getUserByTelegramId(telegramId: string, db?: DBState): UserProfile | undefined {
  if (!telegramId) return undefined;
  if (userByTelegramIdIndex.has(telegramId)) return userByTelegramIdIndex.get(telegramId);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return userByTelegramIdIndex.get(telegramId);
}

/**
 * Fast O(1) indexed retrieval of user's active dates in a given time window
 */
export function getUserActiveDatesInWindow(userId: string, sinceDateStr: string, db?: DBState): Set<string> {
  const result = new Set<string>();
  if (!userId) return result;

  let allDates = userActiveDatesIndex.get(userId);
  if (!allDates) {
    const targetDb = db || readDB();
    syncAllDbIndexes(targetDb);
    allDates = userActiveDatesIndex.get(userId);
  }

  if (allDates) {
    for (const date of allDates) {
      if (date >= sinceDateStr) {
        result.add(date);
      }
    }
  }
  return result;
}

/**
 * Fast O(1) indexed retrieval of Verification Record by User ID
 */
export function getVerificationRecordByUserId(userId: string, db?: DBState): VerificationRecord | undefined {
  if (!userId) return undefined;
  if (verificationRecordByUserIdIndex.has(userId)) return verificationRecordByUserIdIndex.get(userId);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return verificationRecordByUserIdIndex.get(userId);
}

/**
 * Fast O(1) indexed retrieval of direct referrals by Referrer ID
 */
export function getReferralsByReferrer(referrerId: string, db?: DBState): ReferralRecord[] {
  if (!referrerId) return [];
  if (referralsByReferrerIdIndex.has(referrerId)) return referralsByReferrerIdIndex.get(referrerId) || [];
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return referralsByReferrerIdIndex.get(referrerId) || [];
}

/**
 * Fast O(1) indexed retrieval of ledger entries by User ID
 */
export function getLedgerEntriesByUserId(userId: string, db?: DBState): LedgerEntry[] {
  if (!userId) return [];
  if (ledgerEntriesByUserIdIndex.has(userId)) return ledgerEntriesByUserIdIndex.get(userId) || [];
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return ledgerEntriesByUserIdIndex.get(userId) || [];
}

/**
 * Fast O(1) indexed retrieval of user ledger sum
 */
export function getUserLedgerSum(userId: string, db?: DBState): number {
  if (!userId) return 0;
  if (ledgerSumsByUserIdIndex.has(userId)) return ledgerSumsByUserIdIndex.get(userId) || 0;
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return ledgerSumsByUserIdIndex.get(userId) || 0;
}

/**
 * Fast O(1) indexed retrieval of dynamic task
 */
export function getTaskById(taskId: string, db?: DBState): DynamicTaskRecord | undefined {
  if (!taskId) return undefined;
  if (tasksByIdIndex.has(taskId)) return tasksByIdIndex.get(taskId);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return tasksByIdIndex.get(taskId);
}

/**
 * Fast O(1) indexed retrieval of dynamic content item
 */
export function getContentById(contentId: string, db?: DBState): DynamicContentRecord | undefined {
  if (!contentId) return undefined;
  if (contentByIdIndex.has(contentId)) return contentByIdIndex.get(contentId);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return contentByIdIndex.get(contentId);
}

/**
 * Fast O(1) indexed retrieval of system config
 */
export function getSystemConfigByKey(key: string, db?: DBState): SystemConfigRecord | undefined {
  if (!key) return undefined;
  if (systemConfigByKeyIndex.has(key)) return systemConfigByKeyIndex.get(key);
  const targetDb = db || readDB();
  syncAllDbIndexes(targetDb);
  return systemConfigByKeyIndex.get(key);
}

/**
 * Fast indexed lookup by request_id
 */
export function findSalaryRequestById(requestId: string, db?: DBState): SalaryRequestRecord | undefined {
  if (!requestId) return undefined;
  if (salaryRequestByIdIndex.has(requestId)) {
    return salaryRequestByIdIndex.get(requestId);
  }
  const targetDb = db || readDB();
  syncSalaryRequestIndexes(targetDb);
  return salaryRequestByIdIndex.get(requestId);
}

/**
 * Unique constraint & lookup by (user_id, cycle_id)
 */
export function findSalaryRequestByUserAndCycle(userId: string, cycleId: string, db?: DBState): SalaryRequestRecord | undefined {
  if (!userId || !cycleId) return undefined;
  const key = `${userId}::${cycleId}`;
  if (salaryRequestByUserCycleIndex.has(key)) {
    return salaryRequestByUserCycleIndex.get(key);
  }
  const targetDb = db || readDB();
  syncSalaryRequestIndexes(targetDb);
  return salaryRequestByUserCycleIndex.get(key);
}

/**
 * Record an audit trail entry for administrative actions
 */
export function recordAdminAuditLog(entry: {
  admin_id: string;
  action: string;
  target_type: string;
  target_id: string;
  old_value?: any;
  new_value?: any;
  reason?: string;
}, db?: DBState): AdminAuditLogRecord {
  const targetDb = db || readDB();
  if (!targetDb.admin_audit_logs || !Array.isArray(targetDb.admin_audit_logs)) {
    targetDb.admin_audit_logs = [];
  }
  const logRecord: AdminAuditLogRecord = {
    log_id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    admin_id: entry.admin_id || 'admin',
    action: entry.action,
    target_type: entry.target_type,
    target_id: entry.target_id,
    old_value: entry.old_value !== undefined ? entry.old_value : null,
    new_value: entry.new_value !== undefined ? entry.new_value : null,
    reason: entry.reason || '',
    created_at: new Date().toISOString()
  };
  targetDb.admin_audit_logs.unshift(logRecord);
  if (targetDb.admin_audit_logs.length > 2000) {
    targetDb.admin_audit_logs = targetDb.admin_audit_logs.slice(0, 2000);
  }
  if (!db) {
    writeDB(targetDb);
  }
  return logRecord;
}

/**
 * Fetch filtered admin audit logs
 */
export function getAdminAuditLogs(filter?: {
  target_type?: string;
  target_id?: string;
  action?: string;
  limit?: number;
}, db?: DBState): AdminAuditLogRecord[] {
  const targetDb = db || readDB();
  let logs = targetDb.admin_audit_logs || [];
  if (filter?.target_type) {
    logs = logs.filter(l => l.target_type === filter.target_type);
  }
  if (filter?.target_id) {
    logs = logs.filter(l => l.target_id === filter.target_id);
  }
  if (filter?.action) {
    logs = logs.filter(l => l.action === filter.action);
  }
  const limit = filter?.limit || 50;
  return logs.slice(0, limit);
}

/**
 * Record an immutable security audit trail entry for risk actions and restrictions (VRMS-3 ULTRA Phase 11)
 */
export function recordSecurityAuditLog(entry: {
  user_id: string;
  action_taken: 'FLAGGED' | 'RESTRICTED' | 'BANNED' | 'UNRESTRICTED' | 'CLEARED' | 'MONITORED';
  reason: string;
  enforced_by: 'SYSTEM' | 'ADMIN';
  metadata?: Record<string, any>;
}, db?: DBState): SecurityAuditLogRecord {
  const targetDb = db || readDB();
  if (!targetDb.security_audit_logs || !Array.isArray(targetDb.security_audit_logs)) {
    targetDb.security_audit_logs = [];
  }
  const logRecord: SecurityAuditLogRecord = {
    log_id: `sec_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    user_id: entry.user_id,
    action_taken: entry.action_taken,
    reason: entry.reason || 'Automated risk security evaluation',
    enforced_by: entry.enforced_by,
    created_at: new Date().toISOString(),
    metadata: entry.metadata || {}
  };
  targetDb.security_audit_logs.unshift(logRecord);
  if (targetDb.security_audit_logs.length > 5000) {
    targetDb.security_audit_logs = targetDb.security_audit_logs.slice(0, 5000);
  }
  return logRecord;
}

/**
 * Fetch filtered security audit logs
 */
export function getSecurityAuditLogs(filter?: {
  user_id?: string;
  action_taken?: string;
  enforced_by?: string;
  limit?: number;
}, db?: DBState): SecurityAuditLogRecord[] {
  const targetDb = db || readDB();
  let logs = targetDb.security_audit_logs || [];
  if (filter?.user_id) {
    logs = logs.filter(l => l.user_id === filter.user_id);
  }
  if (filter?.action_taken) {
    logs = logs.filter(l => l.action_taken === filter.action_taken);
  }
  if (filter?.enforced_by) {
    logs = logs.filter(l => l.enforced_by === filter.enforced_by);
  }
  const limit = filter?.limit || 100;
  return logs.slice(0, limit);
}

/**
 * Retrieve all system configurations (VRMS-3 ULTRA Phase 13)
 */
export function getSystemConfigs(db?: DBState): SystemConfigRecord[] {
  const targetDb = db || readDB();
  return targetDb.system_configs || DEFAULT_SYSTEM_CONFIGS;
}

/**
 * Retrieve a specific system configuration value by key with fallback
 */
export function getSystemConfigValue<T = any>(key: string, defaultValue: T, db?: DBState): T {
  const configs = getSystemConfigs(db);
  const found = configs.find(c => c.config_key === key);
  if (!found || typeof found.config_value === 'undefined') {
    return defaultValue;
  }
  return found.config_value as T;
}

/**
 * Set or update a system configuration key-value pair
 */
export function setSystemConfig(
  key: string,
  value: any,
  description?: string,
  adminId: string = "system",
  db?: DBState
): { config: SystemConfigRecord; oldConfig?: SystemConfigRecord } {
  const targetDb = db || readDB();
  if (!targetDb.system_configs) {
    targetDb.system_configs = [...DEFAULT_SYSTEM_CONFIGS];
  }
  const existingIdx = targetDb.system_configs.findIndex(c => c.config_key === key);
  let oldConfig: SystemConfigRecord | undefined = undefined;
  const now = new Date().toISOString();

  let updatedRecord: SystemConfigRecord;
  if (existingIdx >= 0) {
    oldConfig = { ...targetDb.system_configs[existingIdx] };
    updatedRecord = {
      ...targetDb.system_configs[existingIdx],
      config_value: value,
      description: description || targetDb.system_configs[existingIdx].description || '',
      last_updated_by: adminId,
      updated_at: now
    };
    targetDb.system_configs[existingIdx] = updatedRecord;
  } else {
    updatedRecord = {
      config_key: key,
      config_value: value,
      description: description || `Custom system configuration ${key}`,
      last_updated_by: adminId,
      updated_at: now
    };
    targetDb.system_configs.push(updatedRecord);
  }

  // Also sync with legacy settings object if applicable (e.g. isMaintenance)
  if (key === 'MAINTENANCE_MODE' && targetDb.settings) {
    targetDb.settings.isMaintenance = Boolean(value);
  }

  if (!db) {
    writeDB(targetDb);
  }

  return { config: updatedRecord, oldConfig };
}

/**
 * Retrieve all registered dynamic campaigns
 */
export function getCampaigns(db?: DBState): CampaignRecord[] {
  const targetDb = db || readDB();
  return targetDb.campaigns || DEFAULT_CAMPAIGNS;
}

/**
 * Retrieve the single currently ACTIVE campaign (One Active Campaign Rule)
 */
export function getActiveCampaign(db?: DBState): CampaignRecord | null {
  const campaigns = getCampaigns(db);
  const active = campaigns.find(c => c.status === 'ACTIVE');
  return active || null;
}

/**
 * Save, create, or update a campaign enforcing ONE ACTIVE CAMPAIGN RULE
 */
export function saveCampaign(
  campaignInput: Partial<CampaignRecord> & { title: string },
  adminId: string = "admin",
  db?: DBState
): { campaign: CampaignRecord; deactivatedPreviousId?: string } {
  const targetDb = db || readDB();
  if (!targetDb.campaigns) {
    targetDb.campaigns = [...DEFAULT_CAMPAIGNS];
  }

  const now = new Date().toISOString();
  const campaignId = campaignInput.campaign_id || `camp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const status: CampaignStatus = campaignInput.status || 'UPCOMING';
  let deactivatedPreviousId: string | undefined = undefined;

  // ONE ACTIVE CAMPAIGN RULE:
  // If this campaign is set to ACTIVE, any other currently ACTIVE campaign MUST transition to COMPLETED.
  if (status === 'ACTIVE') {
    targetDb.campaigns.forEach(c => {
      if (c.campaign_id !== campaignId && c.status === 'ACTIVE') {
        c.status = 'COMPLETED';
        c.updated_at = now;
        deactivatedPreviousId = c.campaign_id;
      }
    });
  }

  const existingIdx = targetDb.campaigns.findIndex(c => c.campaign_id === campaignId);
  let savedRecord: CampaignRecord;

  if (existingIdx >= 0) {
    savedRecord = {
      ...targetDb.campaigns[existingIdx],
      ...campaignInput,
      campaign_id: campaignId,
      status,
      updated_at: now
    };
    targetDb.campaigns[existingIdx] = savedRecord;
  } else {
    savedRecord = {
      campaign_id: campaignId,
      title: campaignInput.title,
      start_date: campaignInput.start_date || now,
      end_date: campaignInput.end_date || new Date(Date.now() + 30 * 86400000).toISOString(),
      status,
      target_metrics: campaignInput.target_metrics || {},
      created_at: now,
      updated_at: now
    };
    targetDb.campaigns.push(savedRecord);
  }

  if (!db) {
    writeDB(targetDb);
  }

  return { campaign: savedRecord, deactivatedPreviousId };
}

/**
 * ============================================================================
 * VRMS-3 ULTRA (Phase 14): Dynamic Task & Content Sync Engine (TCE) Helper Methods
 * ============================================================================
 */

/**
 * Retrieve all registered dynamic tasks
 */
export function getDynamicTasks(db?: DBState): DynamicTaskRecord[] {
  const targetDb = db || readDB();
  return targetDb.tasks || DEFAULT_DYNAMIC_TASKS;
}

/**
 * Retrieve all registered dynamic content items
 */
export function getDynamicContent(db?: DBState): DynamicContentRecord[] {
  const targetDb = db || readDB();
  return targetDb.content_items || DEFAULT_DYNAMIC_CONTENT;
}

/**
 * Create or update a dynamic task record (Server-Authoritative)
 */
export function saveDynamicTask(
  taskInput: Partial<DynamicTaskRecord> & { title: string },
  adminEmail: string = "system",
  db?: DBState
): DynamicTaskRecord {
  const targetDb = db || readDB();
  if (!targetDb.tasks) {
    targetDb.tasks = [...DEFAULT_DYNAMIC_TASKS];
  }

  const now = new Date().toISOString();
  const taskId = taskInput.task_id || `tsk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const status: TaskStatus = taskInput.status || 'ACTIVE';
  const taskType: TaskType = taskInput.task_type || 'EARNING';

  const existingIdx = targetDb.tasks.findIndex(t => t.task_id === taskId);
  let savedRecord: DynamicTaskRecord;

  if (existingIdx >= 0) {
    savedRecord = {
      ...targetDb.tasks[existingIdx],
      ...taskInput,
      task_id: taskId,
      task_type: taskType,
      status,
      updated_at: now
    };
    targetDb.tasks[existingIdx] = savedRecord;
  } else {
    savedRecord = {
      task_id: taskId,
      title: taskInput.title,
      description: taskInput.description || '',
      reward_points: typeof taskInput.reward_points === 'number' ? taskInput.reward_points : 300,
      task_type: taskType,
      target_url: taskInput.target_url || 'https://t.me/myteleflix_official',
      daily_limit_per_user: typeof taskInput.daily_limit_per_user === 'number' ? taskInput.daily_limit_per_user : 1,
      status,
      created_at: now,
      updated_at: now,
      completed_count: 0
    };
    targetDb.tasks.push(savedRecord);
  }

  // Audit log entry
  if (targetDb.admin_audit_logs) {
    targetDb.admin_audit_logs.push({
      log_id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      admin_id: adminEmail,
      action_type: existingIdx >= 0 ? 'UPDATE_TASK' : 'CREATE_TASK',
      target_resource: `tasks/${taskId}`,
      details: { title: savedRecord.title, status: savedRecord.status, reward_points: savedRecord.reward_points },
      timestamp: now
    });
  }

  if (!db) {
    writeDB(targetDb);
  }

  return savedRecord;
}

/**
 * Toggle or update task lifecycle state ('ACTIVE' | 'PAUSED' | 'EXPIRED')
 */
export function setDynamicTaskStatus(
  taskId: string,
  status: TaskStatus,
  adminEmail: string = "system",
  db?: DBState
): DynamicTaskRecord | null {
  const targetDb = db || readDB();
  if (!targetDb.tasks) targetDb.tasks = [...DEFAULT_DYNAMIC_TASKS];

  const task = targetDb.tasks.find(t => t.task_id === taskId);
  if (!task) return null;

  task.status = status;
  task.updated_at = new Date().toISOString();

  if (targetDb.admin_audit_logs) {
    targetDb.admin_audit_logs.push({
      log_id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      admin_id: adminEmail,
      action_type: 'UPDATE_TASK_STATUS',
      target_resource: `tasks/${taskId}`,
      details: { status },
      timestamp: new Date().toISOString()
    });
  }

  if (!db) {
    writeDB(targetDb);
  }

  return task;
}

/**
 * Create or update a dynamic content catalog item (Server-Authoritative)
 */
export function saveDynamicContent(
  contentInput: Partial<DynamicContentRecord> & { title: string },
  adminEmail: string = "system",
  db?: DBState
): DynamicContentRecord {
  const targetDb = db || readDB();
  if (!targetDb.content_items) {
    targetDb.content_items = [...DEFAULT_DYNAMIC_CONTENT];
  }

  const now = new Date().toISOString();
  const contentId = contentInput.content_id || `cnt_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const category: ContentCategory = contentInput.category || 'MOVIE';
  const status: ContentStatus = contentInput.status || 'ACTIVE';

  const existingIdx = targetDb.content_items.findIndex(c => c.content_id === contentId);
  let savedRecord: DynamicContentRecord;

  if (existingIdx >= 0) {
    savedRecord = {
      ...targetDb.content_items[existingIdx],
      ...contentInput,
      content_id: contentId,
      category,
      status,
      updated_at: now
    };
    targetDb.content_items[existingIdx] = savedRecord;
  } else {
    savedRecord = {
      content_id: contentId,
      title: contentInput.title,
      category,
      download_url: contentInput.download_url || 'https://example.com/downloads/sample.mp4',
      status,
      created_at: now,
      updated_at: now,
      description: contentInput.description || '',
      thumbnail_url: contentInput.thumbnail_url || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&h=350&q=80',
      file_size: contentInput.file_size || '500 MB',
      reward_points: typeof contentInput.reward_points === 'number' ? contentInput.reward_points : 100,
      download_count: 0
    };
    targetDb.content_items.push(savedRecord);
  }

  if (targetDb.admin_audit_logs) {
    targetDb.admin_audit_logs.push({
      log_id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      admin_id: adminEmail,
      action_type: existingIdx >= 0 ? 'UPDATE_CONTENT' : 'CREATE_CONTENT',
      target_resource: `content_items/${contentId}`,
      details: { title: savedRecord.title, category: savedRecord.category, status: savedRecord.status },
      timestamp: now
    });
  }

  if (!db) {
    writeDB(targetDb);
  }

  return savedRecord;
}

/**
 * Toggle dynamic content status ('ACTIVE' | 'PAUSED')
 */
export function setDynamicContentStatus(
  contentId: string,
  status: ContentStatus,
  adminEmail: string = "system",
  db?: DBState
): DynamicContentRecord | null {
  const targetDb = db || readDB();
  if (!targetDb.content_items) targetDb.content_items = [...DEFAULT_DYNAMIC_CONTENT];

  const content = targetDb.content_items.find(c => c.content_id === contentId);
  if (!content) return null;

  content.status = status;
  content.updated_at = new Date().toISOString();

  if (targetDb.admin_audit_logs) {
    targetDb.admin_audit_logs.push({
      log_id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      admin_id: adminEmail,
      action_type: 'UPDATE_CONTENT_STATUS',
      target_resource: `content_items/${contentId}`,
      details: { status },
      timestamp: new Date().toISOString()
    });
  }

  if (!db) {
    writeDB(targetDb);
  }

  return content;
}

/**
 * VRMS-3 ULTRA (Phase 15): Automated Audit & Reconciliation Engine (ARE) DB Helpers
 */

/**
 * Records an immutable double-entry ledger record
 */
export function recordLedgerEntry(
  entryInput: Omit<LedgerEntry, 'ledger_id' | 'created_at'> & { ledger_id?: string; created_at?: string },
  db?: DBState
): LedgerEntry {
  const targetDb = db || readDB();
  if (!targetDb.ledger_entries) targetDb.ledger_entries = [];

  const ledgerId = entryInput.ledger_id || `led_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const now = entryInput.created_at || new Date().toISOString();

  const newEntry: LedgerEntry = {
    ledger_id: ledgerId,
    user_id: entryInput.user_id,
    transaction_type: entryInput.transaction_type,
    amount: entryInput.amount,
    reference_type: entryInput.reference_type,
    reference_id: entryInput.reference_id,
    created_at: now,
    metadata: entryInput.metadata
  };

  targetDb.ledger_entries.push(newEntry);

  if (!db) {
    writeDB(targetDb);
  }

  // Non-blocking Firestore sync
  isFirestoreWritable().then((writable) => {
    if (writable) {
      setDoc(doc(firestore, "ledger_entries", ledgerId), newEntry, { merge: true }).catch(() => {});
    }
  }).catch(() => {});

  return newEntry;
}

/**
 * Retrieves ledger entries with optional userId filter and limits
 */
export function getLedgerEntries(
  options: { userId?: string; limit?: number; type?: LedgerTransactionType } = {},
  db?: DBState
): LedgerEntry[] {
  const targetDb = db || readDB();
  let entries = targetDb.ledger_entries || [];

  if (options.userId) {
    entries = entries.filter(e => e.user_id === options.userId);
  }

  if (options.type) {
    entries = entries.filter(e => e.transaction_type === options.type);
  }

  // Sort newest first
  const sorted = [...entries].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  if (options.limit && options.limit > 0) {
    return sorted.slice(0, options.limit);
  }
  return sorted;
}

/**
 * Saves an audit reconciliation run record
 */
export function saveAuditReconciliation(
  reconciliation: AuditReconciliation,
  db?: DBState
): AuditReconciliation {
  const targetDb = db || readDB();
  if (!targetDb.audit_reconciliations) targetDb.audit_reconciliations = [];

  targetDb.audit_reconciliations.unshift(reconciliation);

  if (!db) {
    writeDB(targetDb);
  }

  // Non-blocking Firestore sync
  isFirestoreWritable().then((writable) => {
    if (writable) {
      setDoc(doc(firestore, "audit_reconciliations", reconciliation.reconciliation_id), reconciliation, { merge: true }).catch(() => {});
    }
  }).catch(() => {});

  return reconciliation;
}

/**
 * Retrieves audit reconciliation history
 */
export function getAuditReconciliations(
  limit: number = 20,
  db?: DBState
): AuditReconciliation[] {
  const targetDb = db || readDB();
  const list = targetDb.audit_reconciliations || [];
  return [...list]
    .sort((a, b) => new Date(b.executed_at).getTime() - new Date(a.executed_at).getTime())
    .slice(0, limit);
}

/**
 * Completely resets and wipes all user-authored accounts, activity, transactions,
 * and security records to restore the platform to a pristine 100% fresh start state.
 * Core catalogs (movies, videos, missions, settings) are kept fully intact.
 */
export function resetAllPlatformUserData(): { success: boolean; clearedCounts: Record<string, number> } {
  const db = readDB();
  const counts = {
    users: db.users?.length || 0,
    transactions: db.transactions?.length || 0,
    withdrawals: db.withdrawals?.length || 0,
    notifications: db.notifications?.length || 0,
    missionLogs: db.missionLogs?.length || 0,
    taskSessions: db.taskSessions?.length || 0,
    vipRequests: db.vipRequests?.length || 0,
    referrals: db.referrals?.length || 0,
    requests: db.requests?.length || 0,
  };

  db.users = [];
  db.transactions = [];
  db.withdrawals = [];
  db.notifications = [];
  db.missionLogs = [];
  db.taskSessions = [];
  db.vipRequests = [];
  db.vip_requests = [];
  db.referrals = [];
  db.requests = [];
  db.user_activity = [];
  db.verification_records = [];
  db.quiz_attempts = [];
  db.purge_records = [];
  db.referral_rewards = [];
  db.wallet_payment_profiles = [];
  db.salary_requests = [];
  db.salary_cycles = [];
  db.salary_snapshots = [];
  db.admin_audit_logs = [];
  db.ledger_entries = [];
  db.audit_reconciliations = [];

  writeDB(db);
  return { success: true, clearedCounts: counts };
}



