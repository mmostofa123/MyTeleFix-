/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Server Telegram Bot Entry Point & AI Customer Support Gateway
 */

export * from "./telegramBot.js";
export * from "./aiSupportAssistant.js";
import telegramBotRouter from "./telegramBot.js";
export default telegramBotRouter;
