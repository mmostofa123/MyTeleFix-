/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { readDB, writeDB, UserProfile } from "./db.js";
import { evaluateInactivityAndPurge, executeUserPurge } from "./purgeEngine.js";
import { recordEngineRun } from "./health.js";

export { evaluateInactivityAndPurge, executeUserPurge };

export const MASTER_ADMIN_EMAIL = "mostofa7077a@gmail.com";
export const SUPER_ADMIN_EMAILS = [
  MASTER_ADMIN_EMAIL
];
export const SUPER_ADMIN_EMAIL = MASTER_ADMIN_EMAIL;
export const SUPER_ADMIN_TELEGRAM_ID = "703119315615";
export const SUPER_ADMIN_USERNAME = "mostofashowkat";

export const isSuperAdminEmail = (email?: string | null): boolean => {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  if (clean === MASTER_ADMIN_EMAIL.toLowerCase().trim()) return true;
  try {
    const db = readDB();
    const assigned: string[] = (db as any).assignedAdmins || (db.settings as any)?.assignedAdmins || [];
    if (Array.isArray(assigned) && assigned.some(a => a.toLowerCase().trim() === clean)) {
      return true;
    }
  } catch (e) {}
  return false;
};

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000; // 720 hours
export const SEVENTY_TWO_HOURS_MS = 72 * 60 * 60 * 1000; // 72 hours

/**
 * 72-Hour Inactivity Rule:
 * Evaluates all users and resets verification progress counters (Active Days, Completed Tasks, Quiz status)
 * back to 0 if inactive for > 72 hours, while keeping the user account, balance, and identity intact.
 */
export function reset72HourInactiveVerificationProgress(maxInactiveMs: number = SEVENTY_TWO_HOURS_MS): {
  resetCount: number;
  resetUserIds: string[];
} {
  const db = readDB();
  const now = Date.now();
  const cutoffTime = now - maxInactiveMs;
  const resetUserIds: string[] = [];

  for (const user of db.users) {
    const isSuperAdmin =
      isSuperAdminEmail(user.email) ||
      user.telegramId === SUPER_ADMIN_TELEGRAM_ID ||
      user.username === SUPER_ADMIN_USERNAME;

    if (isSuperAdmin) continue;

    const activityTimestampVal = (user as any).lastActiveTimestamp || user.last_active_at || user.lastActiveAt || user.lastLogin || user.createdAt;
    const activityTime = typeof activityTimestampVal === 'number' 
      ? activityTimestampVal 
      : (activityTimestampVal ? new Date(activityTimestampVal).getTime() : 0);

    if (activityTime > 0 && activityTime < cutoffTime) {
      const currentStreak = user.active_day_streak || user.activeDaysCount || 0;

      if (currentStreak > 0) {
        console.log(`[Inactivity Engine] 72h Inactivity Streak Reset applied to user ${user.id} (${user.email || user.username}). active_day_streak reset to 0. Cumulative valid_action_count (${user.valid_action_count || 0}) preserved.`);
        user.active_day_streak = 0;
        user.activeDaysCount = 0;
        user.activeDaysList = [];
        // CRITICAL VRMS-3 ULTRA: Cumulative lifetime valid actions (valid_action_count) are NOT deleted or reset.
        (user as any).lastActiveTimestamp = now;
        user.last_active_at = new Date(now).toISOString();
        resetUserIds.push(user.id);
      }
    }
  }

  if (resetUserIds.length > 0) {
    writeDB(db);
    console.log(`[Inactivity Engine] Successfully reset verification progress for ${resetUserIds.length} users after 72h inactivity.`);
  }

  return {
    resetCount: resetUserIds.length,
    resetUserIds,
  };
}

/**
 * Evaluates all users and purges any user with more than 30 days of continuous inactivity.
 * Protected accounts (Super Admin) are strictly excluded from purging.
 */
export function purgeInactiveUsers(maxInactiveMs: number = THIRTY_DAYS_MS): {
  purgedCount: number;
  purgedUserIds: string[];
  remainingUsersCount: number;
} {
  const result = evaluateInactivityAndPurge();
  const db = readDB();
  const activeCount = db.users.filter(u => u.inactivity_status !== "PURGED").length;

  return {
    purgedCount: result.purgedCount,
    purgedUserIds: result.purgedUserIds,
    remainingUsersCount: activeCount
  };
}

/**
 * Initializes the background Inactivity Engine:
 * - Runs on server boot
 * - Schedules regular hourly checks
 */
export function startInactivityEngine(intervalMs: number = 60 * 60 * 1000): NodeJS.Timeout {
  console.log("[Inactivity Engine] Initializing 30-day purge & 72-hour verification reset engine...");
  
  // Initial check on server boot
  try {
    const purgeResult = purgeInactiveUsers();
    console.log(`[Inactivity Engine] Boot purge completed: ${purgeResult.purgedCount} users purged.`);
    const resetResult = reset72HourInactiveVerificationProgress();
    console.log(`[Inactivity Engine] Boot 72h check: ${resetResult.resetCount} users reset.`);
    recordEngineRun("inactivity_purge_engine", {
      status: "ACTIVE",
      message: `Boot evaluation finished: ${purgeResult.purgedCount} purged, ${resetResult.resetCount} verification progress reset.`
    });
  } catch (err: any) {
    console.error("[Inactivity Engine] Initial boot error:", err);
    recordEngineRun("inactivity_purge_engine", {
      status: "ERROR",
      message: err.message || "Failed during boot evaluation"
    });
  }

  // Periodic recurring check
  const interval = setInterval(() => {
    try {
      const purgeResult = purgeInactiveUsers();
      const resetResult = reset72HourInactiveVerificationProgress();
      recordEngineRun("inactivity_purge_engine", {
        status: "ACTIVE",
        message: `Cycle finished: ${purgeResult.purgedCount} purged, ${resetResult.resetCount} verification progress reset.`
      });
    } catch (err: any) {
      console.error("[Inactivity Engine] Scheduled check error:", err);
      recordEngineRun("inactivity_purge_engine", {
        status: "ERROR",
        message: err.message || "Failed during scheduled cycle"
      });
    }
  }, intervalMs);

  return interval;
}
