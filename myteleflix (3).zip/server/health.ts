/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 16): Real-Time System Health Monitoring Engine
 * 
 * Aggregates live system telemetry:
 * 1. Database connection status & storage footprint
 * 2. Background Cron & Engine runtimes (Inactivity Purge, ARE, TCE)
 * 3. Ledger consistency & double-entry financial integrity
 * 4. Real-time API latency moving average & error rate metrics
 * 5. Process memory footprint & host runtime specifications
 */

import fs from "fs";
import path from "path";
import { Request, Response, NextFunction } from "express";
import { readDB, DBState } from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { getRateLimiterMetrics } from "./rateLimiter.js";

const DB_FILE = path.join(process.cwd(), "db.json");

// Latency & Traffic Rolling Metrics
const LATENCY_BUFFER_SIZE = 100;
const latencySamples: number[] = [];
let totalRequestsServed = 0;
let totalServerErrors = 0; // 5xx
let totalClientErrors = 0; // 4xx
const serverStartTime = Date.now();

// Background Engine Telemetry States
interface EngineTelemetry {
  status: "ACTIVE" | "IDLE" | "ERROR";
  lastRunAt: string | null;
  lastRunDurationMs?: number;
  lastMessage?: string;
}

const backgroundEnginesStatus: Record<string, EngineTelemetry> = {
  inactivity_purge_engine: {
    status: "ACTIVE",
    lastRunAt: new Date().toISOString(),
    lastMessage: "Running 30-day inactivity evaluation on 24h cron loop."
  },
  audit_reconciliation_engine: {
    status: "ACTIVE",
    lastRunAt: new Date().toISOString(),
    lastMessage: "Automated double-entry ledger invariance check ready."
  },
  task_content_sync_engine: {
    status: "ACTIVE",
    lastRunAt: new Date().toISOString(),
    lastMessage: "Dynamic campaigns and content catalogs synchronized."
  }
};

/**
 * Updates an engine's runtime telemetry status
 */
export function recordEngineRun(engineKey: string, result: {
  status: "ACTIVE" | "IDLE" | "ERROR";
  durationMs?: number;
  message?: string;
}) {
  backgroundEnginesStatus[engineKey] = {
    status: result.status,
    lastRunAt: new Date().toISOString(),
    lastRunDurationMs: result.durationMs,
    lastMessage: result.message
  };
}

/**
 * Express Middleware to track API Latency, traffic volume, and HTTP status codes
 */
export function apiLatencyTracker(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();
  totalRequestsServed += 1;

  res.on("finish", () => {
    const duration = Date.now() - start;
    latencySamples.push(duration);
    if (latencySamples.length > LATENCY_BUFFER_SIZE) {
      latencySamples.shift();
    }

    if (res.statusCode >= 500) {
      totalServerErrors += 1;
    } else if (res.statusCode >= 400) {
      totalClientErrors += 1;
    }
  });

  next();
}

/**
 * Calculates current average API latency in milliseconds
 */
export function getAverageLatencyMs(): number {
  if (latencySamples.length === 0) return 0;
  const sum = latencySamples.reduce((acc, val) => acc + val, 0);
  return Math.round((sum / latencySamples.length) * 10) / 10;
}

/**
 * Returns formatted uptime string (e.g., "1d 4h 12m 30s")
 */
export function getFormattedUptime(): string {
  const seconds = Math.floor((Date.now() - serverStartTime) / 1000);
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;

  const parts: string[] = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0 || days > 0) parts.push(`${hours}h`);
  if (minutes > 0 || hours > 0 || days > 0) parts.push(`${minutes}m`);
  parts.push(`${remainingSeconds}s`);

  return parts.join(" ");
}

/**
 * Performs deep system health diagnostics
 */
export async function collectSystemHealthReport(options: { deepDbPing?: boolean } = {}) {
  const now = new Date().toISOString();
  const uptimeSeconds = Math.floor((Date.now() - serverStartTime) / 1000);
  const mem = process.memoryUsage();

  // 1. Local Database Status
  let localDbHealthy = false;
  let localDbSizeKb = 0;
  let localDbLastModified: string | null = null;
  let recordCounts: Record<string, number> = {};

  try {
    if (fs.existsSync(DB_FILE)) {
      const stats = fs.statSync(DB_FILE);
      localDbHealthy = stats.size > 0;
      localDbSizeKb = Math.round(stats.size / 1024);
      localDbLastModified = stats.mtime.toISOString();

      const db = readDB();
      recordCounts = {
        users: db.users?.length || 0,
        transactions: db.transactions?.length || 0,
        ledger_entries: db.ledger_entries?.length || 0,
        user_activity: db.user_activity?.length || 0,
        verification_records: db.verification_records?.length || 0,
        referrals: db.referrals?.length || 0,
        salary_requests: db.salary_requests?.length || 0,
        tasks: db.tasks?.length || 0,
        content_items: db.content_items?.length || 0,
        audit_reconciliations: db.audit_reconciliations?.length || 0,
        security_audit_logs: db.security_audit_logs?.length || 0
      };
    }
  } catch (err: any) {
    localDbHealthy = false;
  }

  // 2. Firestore Cloud Database Connection
  let firestoreConnected = false;
  let firestorePingMs = 0;
  let firestoreWritable = false;

  if (options.deepDbPing) {
    const fsStart = Date.now();
    try {
      firestoreWritable = await isFirestoreWritable();
      if (firestoreWritable) {
        const pingDoc = doc(firestore, "test", "health_ping");
        await setDoc(pingDoc, { ping: now }, { merge: true });
        firestorePingMs = Date.now() - fsStart;
        firestoreConnected = true;
      }
    } catch {
      firestoreConnected = false;
    }
  } else {
    try {
      firestoreWritable = await isFirestoreWritable();
      firestoreConnected = firestoreWritable;
    } catch {
      firestoreConnected = false;
    }
  }

  // 3. Ledger Consistency Check
  let ledgerStatus: "BALANCED" | "DISCREPANCY_DETECTED" = "BALANCED";
  let totalLedgerPoints = 0;
  let totalWalletPoints = 0;
  let balanceVariance = 0;

  try {
    const db = readDB();
    if (db.ledger_entries && Array.isArray(db.ledger_entries)) {
      totalLedgerPoints = db.ledger_entries.reduce((sum, entry) => sum + (entry.amount || 0), 0);
    }
    if (db.users && Array.isArray(db.users)) {
      totalWalletPoints = db.users.reduce((sum, u) => {
        const pts = u.wallet?.points ?? u.points ?? 0;
        return sum + pts;
      }, 0);
    }
    balanceVariance = totalWalletPoints - totalLedgerPoints;
    if (Math.abs(balanceVariance) > 0.001) {
      ledgerStatus = "DISCREPANCY_DETECTED";
    }
  } catch {}

  // 4. Rate Limiter Telemetry
  const rateLimitMetrics = getRateLimiterMetrics();

  // 5. System Status Calculation
  let overallStatus: "HEALTHY" | "DEGRADED" | "DOWN" = "HEALTHY";
  if (!localDbHealthy) {
    overallStatus = "DOWN";
  } else if (ledgerStatus === "DISCREPANCY_DETECTED" || !firestoreConnected) {
    overallStatus = "DEGRADED";
  }

  const avgLatency = getAverageLatencyMs();
  const errorRatePercent = totalRequestsServed > 0 
    ? Math.round(((totalServerErrors + totalClientErrors) / totalRequestsServed) * 10000) / 100 
    : 0;

  return {
    status: overallStatus,
    timestamp: now,
    uptime: {
      seconds: uptimeSeconds,
      formatted: getFormattedUptime()
    },
    performance: {
      average_latency_ms: avgLatency,
      total_requests_served: totalRequestsServed,
      total_server_errors: totalServerErrors,
      total_client_errors: totalClientErrors,
      error_rate_percent: errorRatePercent
    },
    database: {
      local_file_healthy: localDbHealthy,
      local_file_size_kb: localDbSizeKb,
      last_modified: localDbLastModified,
      records: recordCounts,
      cloud_firestore: {
        connected: firestoreConnected,
        writable: firestoreWritable,
        ping_latency_ms: firestorePingMs
      }
    },
    ledger_integrity: {
      status: ledgerStatus,
      total_ledger_points: totalLedgerPoints,
      total_wallet_points: totalWalletPoints,
      variance_delta: balanceVariance,
      is_invariance_maintained: Math.abs(balanceVariance) <= 0.001
    },
    background_engines: backgroundEnginesStatus,
    rate_limiting: rateLimitMetrics,
    process: {
      node_version: process.version,
      platform: process.platform,
      arch: process.arch,
      pid: process.pid,
      memory_mb: {
        rss: Math.round(mem.rss / (1024 * 1024)),
        heap_total: Math.round(mem.heapTotal / (1024 * 1024)),
        heap_used: Math.round(mem.heapUsed / (1024 * 1024)),
        external: Math.round(mem.external / (1024 * 1024))
      }
    }
  };
}
