/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { readDB, writeDB } from "./db.js";
import { qualifyReferral } from "./referrals.js";

interface MissionRewardsResult {
  newPointsTotal: number;
}

// REQUIREMENT: Centralized reward calculation. Never store reward logic inside blogger/mission websites.
// Every reward must be linked to the authenticated account.
export function processMissionRewards(
  userId: string,
  missionId: string,
  rewardPoints: number,
  missionTitle: string
): MissionRewardsResult {
  const db = readDB();

  const user = db.users.find((u: any) => u.id === userId);
  if (!user) {
    throw new Error("Reward attribution failed: Authenticated user not found.");
  }

  // 1. Credit base reward points to the user's modular wallet
  user.wallet.points = (user.wallet.points || 0) + rewardPoints;
  user.wallet.updatedAt = new Date().toISOString();

  // 2. Increment user task statistics
  user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + rewardPoints;

  // 3. Ledger entry for Reward History
  db.transactions.push({
    id: "tx-reward-" + Date.now(),
    userId,
    amount: rewardPoints,
    type: "reward_mission",
    status: "completed",
    description: `Completed task: ${missionTitle}`,
    timestamp: new Date().toISOString()
  });

  // 4. Handle Referral commission calculation inside the Main Platform
  if (user.referredBy) {
    const referrer = db.users.find((u: any) => u.id === user.referredBy);
    if (referrer && referrer.status === "active") {
      const commissionPercent = db.settings.referralCommissionPercent || 10;
      const commissionPoints = Math.round(rewardPoints * (commissionPercent / 100));

      if (commissionPoints > 0) {
        // Credit commission to inviter's wallet
        referrer.wallet.points = (referrer.wallet.points || 0) + commissionPoints;
        referrer.taskStats.totalPointsEarned = (referrer.taskStats.totalPointsEarned || 0) + commissionPoints;
        referrer.wallet.updatedAt = new Date().toISOString();

        // Inviter's Ledger Entry
        db.transactions.push({
          id: "tx-comm-" + Date.now(),
          userId: user.referredBy,
          amount: commissionPoints,
          type: "referral_commission",
          status: "completed",
          description: `${commissionPercent}% Network Commission from referred friend ${user.fullName} completing task: ${missionTitle}`,
          timestamp: new Date().toISOString()
        });

        // Inviter's Notification
        db.notifications.push({
          id: "nt-comm-" + Date.now(),
          userId: user.referredBy,
          title: "💰 Referral Commission Received!",
          message: `You earned +${commissionPoints} points commission because your referred partner "${user.fullName}" completed: ${missionTitle}`,
          isRead: false,
          timestamp: new Date().toISOString()
        });
      }
    }
  }

  writeDB(db);

  // 5. Qualify referral if this was the user's first completed task session
  qualifyReferral(userId);

  // Re-read DB to return updated wallet points after potential referral qualification welcome gift
  const finalDb = readDB();
  const finalUser = finalDb.users.find((u: any) => u.id === userId) || user;

  return {
    newPointsTotal: finalUser.wallet?.points || user.wallet.points
  };
}
