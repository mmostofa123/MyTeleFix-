/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 16): Zero-Downtime Global Exception Sanitizer
 * 
 * Intercepts unhandled synchronous and asynchronous exceptions across all Express routes.
 * Logs full diagnostic tracebacks securely to server console while delivering sanitized,
 * structured, and safe JSON responses to clients with incident correlation IDs.
 */

import { Request, Response, NextFunction } from "express";

export interface SanitizedErrorResponse {
  success: false;
  error: string;
  message: string;
  incident_id: string;
  timestamp: string;
  code?: string | number;
}

/**
 * Standard Application Error class for predictable business rule exceptions
 */
export class AppError extends Error {
  public statusCode: number;
  public errorCode: string;
  public isOperational: boolean;

  constructor(message: string, statusCode = 400, errorCode = "BAD_REQUEST") {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
    this.errorCode = errorCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Global Express Error-Handling Middleware
 */
export function globalErrorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  // If response headers have already been sent, delegate to default Express handler
  if (res.headersSent) {
    return next(err);
  }

  const incidentId = `inc_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const timestamp = new Date().toISOString();

  // Determine status code
  let statusCode = 500;
  let errorCode = "INTERNAL_SERVER_ERROR";
  let clientMessage = "An unexpected server error occurred. Our engineers have been notified.";

  if (err instanceof AppError || (err.statusCode && typeof err.statusCode === "number")) {
    statusCode = err.statusCode || 400;
    errorCode = err.errorCode || "APPLICATION_ERROR";
    clientMessage = err.message;
  } else if (err.name === "SyntaxError" && "body" in err) {
    // Malformed JSON body
    statusCode = 400;
    errorCode = "INVALID_JSON_BODY";
    clientMessage = "The request payload contains malformed JSON syntax.";
  } else if (err.name === "UnauthorizedError") {
    statusCode = 401;
    errorCode = "UNAUTHORIZED";
    clientMessage = "Authentication credentials are required or have expired.";
  }

  // Secure Server-Side Logging (Never leaks to browser/client)
  console.error(`[GlobalErrorHandler] [${incidentId}] ${req.method} ${req.originalUrl}:`, {
    name: err.name || "Error",
    message: err.message,
    statusCode,
    errorCode,
    stack: err.stack,
    ip: req.headers["x-forwarded-for"] || req.socket?.remoteAddress,
    user: (req as any).auth?.userId || (req as any).user?.id || "anonymous"
  });

  const responseBody: SanitizedErrorResponse = {
    success: false,
    error: errorCode,
    message: statusCode >= 500 
      ? `A system error occurred. Please retry shortly. (Reference: ${incidentId})`
      : clientMessage,
    incident_id: incidentId,
    timestamp,
    code: statusCode
  };

  res.status(statusCode).json(responseBody);
}

/**
 * 404 Route Not Found Handler for unmatched API endpoints
 */
export function apiNotFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    success: false,
    error: "NOT_FOUND",
    message: `API route ${req.method} ${req.originalUrl} does not exist.`,
    timestamp: new Date().toISOString()
  });
}
