/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  writeBatch, 
  serverTimestamp,
  setLogLevel 
} from "firebase/firestore";
import fs from "fs";
import path from "path";

// Silence gRPC stream error noise in Node.js server runtime
try {
  setLogLevel('silent');
} catch {}

// Active Firebase Configuration
export const firebaseConfig = {
  apiKey: "AIzaSyB2cLgll1nSEc3TrKZz97L_1pBF8qO6IYw",
  authDomain: "playmint-2f3b1.firebaseapp.com",
  projectId: "playmint-2f3b1",
  storageBucket: "playmint-2f3b1.firebasestorage.app",
  messagingSenderId: "503182419097",
  appId: "1:503182419097:web:318802940e3e2d407fc408"
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const firestore = getFirestore(app);

export const MASTER_ADMIN_EMAIL = "mostofa7077a@gmail.com";
export const MASTER_ADMIN_TELEGRAM_ID = "703119315615";

function sanitizeForFirestore<T>(data: T): T {
  if (!data) return data;
  return JSON.parse(JSON.stringify(data));
}

let firestoreCheckPromise: Promise<boolean> | null = null;
let firestoreIsWritable: boolean | null = null;

/**
 * Checks if the server environment has active permissions to write to Firestore
 * without throwing unhandled gRPC streams or permission denials.
 */
export async function isFirestoreWritable(): Promise<boolean> {
  if (firestoreIsWritable !== null) return firestoreIsWritable;
  if (firestoreCheckPromise) return firestoreCheckPromise;

  firestoreCheckPromise = (async () => {
    try {
      const probeRef = doc(firestore, "system_configs", "probe");
      await getDoc(probeRef);
      firestoreIsWritable = true;
      return true;
    } catch {
      firestoreIsWritable = false;
      return false;
    } finally {
      firestoreCheckPromise = null;
    }
  })();

  return firestoreCheckPromise;
}

/**
 * Migration helper: loads current db.json data and transfers it to Firestore collections
 * with batching, preserving all records, admin bindings, and IDs.
 */
export async function autoMigrateLocalDataToFirestore() {
  const dbPath = path.join(process.cwd(), "db.json");
  if (!fs.existsSync(dbPath)) {
    console.log("[Firestore Migration] No db.json found to migrate.");
    return { success: true, count: 0 };
  }

  // Pre-flight authorization check to avoid unauthenticated gRPC stream errors
  const writable = await isFirestoreWritable();
  if (!writable) {
    console.log("[Firestore Migration] Server running in local persistence mode. Local DB (db.json) active; cloud sync delegated to authenticated Admin client.");
    return { success: true, count: 0 };
  }

  try {
    const raw = fs.readFileSync(dbPath, "utf-8");
    if (!raw.trim()) return { success: true, count: 0 };
    const localData = JSON.parse(raw);

    console.log("[Firestore Migration] Initiating cloud sync from db.json...");

    // 1. Sync System Settings
    if (localData.settings) {
      try {
        const cleanSettings = sanitizeForFirestore({
          ...localData.settings,
          updatedAt: new Date().toISOString()
        });
        await setDoc(doc(firestore, "system_configs", "app_settings"), cleanSettings, { merge: true });
        await setDoc(doc(firestore, "settings", "global"), cleanSettings, { merge: true });
        console.log("[Firestore Migration] Synced system settings.");
      } catch (err: any) {
        console.warn("[Firestore Migration] Settings sync notice:", err?.message || err);
      }
    }

    // 2. Sync Users
    if (Array.isArray(localData.users) && localData.users.length > 0) {
      for (const u of localData.users) {
        if (!u.id) continue;
        try {
          const userRef = doc(firestore, "users", u.id);
          const cleanUser = { ...u };
          
          // Ensure master admin role and permissions
          if (cleanUser.email?.toLowerCase().trim() === MASTER_ADMIN_EMAIL.toLowerCase() || 
              cleanUser.telegramId === MASTER_ADMIN_TELEGRAM_ID) {
            cleanUser.role = "admin";
            cleanUser.isBanned = false;
          }

          await setDoc(userRef, sanitizeForFirestore(cleanUser), { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] User ${u.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.users.length} users to Firestore.`);
    }

    // 3. Sync Movies
    if (Array.isArray(localData.movies) && localData.movies.length > 0) {
      for (const m of localData.movies) {
        if (!m.id) continue;
        try {
          await setDoc(doc(firestore, "movies", m.id), sanitizeForFirestore(m), { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] Movie ${m.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.movies.length} movies to Firestore.`);
    }

    // 4. Sync Videos
    if (Array.isArray(localData.videos) && localData.videos.length > 0) {
      for (const v of localData.videos) {
        if (!v.id) continue;
        try {
          await setDoc(doc(firestore, "videos", v.id), sanitizeForFirestore(v), { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] Video ${v.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.videos.length} videos to Firestore.`);
    }

    // 5. Sync Transactions
    if (Array.isArray(localData.transactions) && localData.transactions.length > 0) {
      for (const t of localData.transactions) {
        if (!t.id) continue;
        try {
          const cleanTx = sanitizeForFirestore(t);
          await setDoc(doc(firestore, "transactions", t.id), cleanTx, { merge: true });
          await setDoc(doc(firestore, "wallet_transactions", t.id), cleanTx, { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] Transaction ${t.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.transactions.length} transactions to Firestore.`);
    }

    // 6. Sync Withdrawals
    if (Array.isArray(localData.withdrawals) && localData.withdrawals.length > 0) {
      for (const w of localData.withdrawals) {
        if (!w.id) continue;
        try {
          const cleanWd = sanitizeForFirestore(w);
          await setDoc(doc(firestore, "withdrawals", w.id), cleanWd, { merge: true });
          await setDoc(doc(firestore, "withdraw_requests", w.id), cleanWd, { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] Withdrawal ${w.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.withdrawals.length} withdrawals to Firestore.`);
    }

    // 7. Sync Missions
    if (Array.isArray(localData.missions) && localData.missions.length > 0) {
      for (const ms of localData.missions) {
        if (!ms.id) continue;
        try {
          const cleanMs = sanitizeForFirestore(ms);
          await setDoc(doc(firestore, "tasks", ms.id), cleanMs, { merge: true });
          await setDoc(doc(firestore, "earn_missions", ms.id), cleanMs, { merge: true });
        } catch (err: any) {
          console.warn(`[Firestore Migration] Mission ${ms.id} sync notice:`, err?.message || err);
        }
      }
      console.log(`[Firestore Migration] Synced ${localData.missions.length} tasks to Firestore.`);
    }

    console.log("[Firestore Migration] Cloud synchronization complete.");
    return { success: true };
  } catch (err) {
    console.warn("[Firestore Migration Notice]:", err);
    return { success: false, error: err };
  }
}
