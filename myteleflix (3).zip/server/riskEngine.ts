import { 
  readDB, 
  writeDB, 
  UserProfile, 
  RiskAssessmentRecord, 
  SecurityAuditLogRecord, 
  DetectedSignals, 
  recordSecurityAuditLog,
  getSecurityAuditLogs
} from "./db";
import { emitSecurityRestrictionAlert } from "./notificationEngine";
import { doc, setDoc } from "firebase/firestore";
import { firestore, isFirestoreWritable } from "./firebase";

/**
 * Check whether a user is currently restricted or banned by the Risk & Security Engine (RSE)
 */
export function isUserRestricted(user?: Partial<UserProfile> | null): boolean {
  if (!user) return false;
  return (
    user.risk_status === 'RESTRICTED' ||
    user.risk_status === 'BANNED' ||
    user.status === 'banned' ||
    user.status === 'suspended' ||
    Boolean(user.isBanned)
  );
}

/**
 * Throws a standard security error if the user is restricted or banned
 */
export function assertUserNotRestricted(user?: Partial<UserProfile> | null, operation: string = 'Operation'): void {
  if (isUserRestricted(user)) {
    const reason = user?.restriction_reason || user?.banReason || 'Account under security review. Earnings and payouts are paused.';
    throw new Error(`SECURITY_RESTRICTION: ${operation} blocked. ${reason}`);
  }
}

/**
 * Evaluates risk signals for a user:
 * 1. Device Hash / Hardware ID overlap across active accounts
 * 2. IP reuse velocity across accounts
 * 3. Task/activity completion velocity (impossible duration < 3000ms or rapid bursts)
 * 4. Bot/automation anomalies
 */
export async function evaluateUserRisk(params: {
  userId: string;
  actionType?: string;
  device_fingerprint?: string;
  ip_address?: string;
  completion_duration_ms?: number;
  metadata?: Record<string, any>;
  enforced_by?: 'SYSTEM' | 'ADMIN';
}): Promise<{
  assessment: RiskAssessmentRecord;
  user: UserProfile;
  statusChanged: boolean;
  message: string;
}> {
  const db = readDB();
  const user = db.users.find(u => u.id === params.userId || u.telegramId === params.userId);

  if (!user) {
    throw new Error(`User not found: ${params.userId}`);
  }

  const detectedSignals: DetectedSignals = {
    details: []
  };

  let riskScore = 0;
  const initialStatus = user.risk_status || (user.isBanned ? 'BANNED' : user.status === 'suspended' ? 'RESTRICTED' : user.isSuspicious ? 'HIGH' : 'LOW');

  // -------------------------------------------------------------
  // Signal 1: Device Fingerprint / Hardware ID Overlap Analysis
  // -------------------------------------------------------------
  const effectiveFp = params.device_fingerprint || user.device_fingerprint || user.deviceFingerprint;
  if (effectiveFp && effectiveFp !== 'guest' && effectiveFp !== 'unknown' && effectiveFp !== 'Unbound') {
    const matchedUsers = db.users.filter(u => {
      if (u.id === user.id) return false;
      const otherFp = u.device_fingerprint || u.deviceFingerprint;
      const historyMatches = Array.isArray(u.hardwareIdHistory) && u.hardwareIdHistory.includes(effectiveFp);
      return otherFp === effectiveFp || historyMatches;
    });

    const overlapCount = matchedUsers.length;
    if (overlapCount > 0) {
      detectedSignals.device_hash_overlap = {
        overlap_count: overlapCount,
        matched_user_ids: matchedUsers.map(u => u.id),
        device_fingerprint: effectiveFp
      };

      if (overlapCount >= 3) {
        riskScore += 55;
        detectedSignals.details?.push(`Severe multi-accounting: Hardware ID shared with ${overlapCount} other accounts.`);
      } else if (overlapCount === 2) {
        riskScore += 35;
        detectedSignals.details?.push(`Multi-accounting: Hardware ID shared with 2 other accounts.`);
      } else {
        riskScore += 25;
        detectedSignals.details?.push(`Hardware ID collision: Shared with account ${matchedUsers[0].id}.`);
      }
    }
  }

  // -------------------------------------------------------------
  // Signal 2: IP Reuse & Location Velocity Analysis
  // -------------------------------------------------------------
  const effectiveIp = params.ip_address || user.last_ip || user.registered_ip;
  if (effectiveIp && effectiveIp !== '127.0.0.1' && effectiveIp !== '::1') {
    user.last_ip = effectiveIp;
    if (!user.registered_ip) {
      user.registered_ip = effectiveIp;
    }

    const ipMatchedUsers = db.users.filter(u => {
      if (u.id === user.id) return false;
      return u.last_ip === effectiveIp || u.registered_ip === effectiveIp;
    });

    const ipReuseCount = ipMatchedUsers.length;
    if (ipReuseCount >= 2) {
      detectedSignals.ip_anomalies = {
        ip_reuse_count: ipReuseCount,
        matched_user_ids: ipMatchedUsers.map(u => u.id),
        ip_address: effectiveIp
      };

      if (ipReuseCount >= 4) {
        riskScore += 30;
        detectedSignals.details?.push(`High IP concentration: ${ipReuseCount} accounts operating on same IP.`);
      } else {
        riskScore += 15;
        detectedSignals.details?.push(`IP shared with ${ipReuseCount} other accounts.`);
      }
    }
  }

  // -------------------------------------------------------------
  // Signal 3: Task Execution Velocity & Impossible Speeds
  // -------------------------------------------------------------
  if (typeof params.completion_duration_ms === 'number' && params.completion_duration_ms >= 0) {
    const duration = params.completion_duration_ms;
    const thresholdMs = 3000; // Tasks completed faster than 3 seconds are physically impossible for humans

    if (duration < thresholdMs) {
      riskScore += 45;
      detectedSignals.fast_completion = {
        duration_ms: duration,
        threshold_ms: thresholdMs,
        velocity_anomaly: true
      };
      detectedSignals.details?.push(`Bot velocity anomaly: Task completed in ${duration}ms (Threshold: ${thresholdMs}ms).`);
    }
  }

  // Check recent user activity logs for rapid timestamp clusters (< 10 seconds apart)
  if (Array.isArray(db.user_activity)) {
    const userActivities = db.user_activity
      .filter(a => a.user_id === user.id)
      .slice(0, 10);

    let rapidClusterCount = 0;
    for (let i = 0; i < userActivities.length - 1; i++) {
      const t1 = new Date(userActivities[i].created_at).getTime();
      const t2 = new Date(userActivities[i + 1].created_at).getTime();
      if (Math.abs(t1 - t2) < 5000) {
        rapidClusterCount++;
      }
    }

    if (rapidClusterCount >= 3) {
      riskScore += 30;
      if (!detectedSignals.fast_completion) {
        detectedSignals.fast_completion = {
          velocity_anomaly: true,
          consecutive_rapid_completions: rapidClusterCount
        };
      } else {
        detectedSignals.fast_completion.consecutive_rapid_completions = rapidClusterCount;
      }
      detectedSignals.details?.push(`Rapid-fire activity anomaly: ${rapidClusterCount} actions logged within 5 seconds.`);
    }
  }

  // -------------------------------------------------------------
  // Signal 4: Existing Account Risk Flags
  // -------------------------------------------------------------
  if (user.isSuspicious) {
    riskScore += 20;
  }
  if (user.isBanned) {
    riskScore += 100;
  }

  // Bound score strictly between 0 and 100
  const finalRiskScore = Math.max(0, Math.min(100, Math.round(riskScore)));
  user.risk_score = finalRiskScore;

  // -------------------------------------------------------------
  // Dynamic Restriction Trigger Rules:
  // Score >= 90 => BANNED
  // Score >= 75 => RESTRICTED (Blocks earnings & payouts)
  // Score >= 50 => HIGH (Monitored)
  // Score >= 25 => MEDIUM
  // Else        => LOW
  // -------------------------------------------------------------
  let recommendedAction: 'NONE' | 'MONITOR' | 'RESTRICT' | 'BAN' = 'NONE';
  let targetStatus: 'LOW' | 'MEDIUM' | 'HIGH' | 'RESTRICTED' | 'BANNED' = 'LOW';

  if (finalRiskScore >= 90 || user.isBanned) {
    targetStatus = 'BANNED';
    recommendedAction = 'BAN';
    user.status = 'banned';
    user.isBanned = true;
    if (!user.banReason) {
      user.banReason = `System Auto-Ban: High risk score (${finalRiskScore}/100)`;
    }
  } else if (finalRiskScore >= 75) {
    targetStatus = 'RESTRICTED';
    recommendedAction = 'RESTRICT';
    user.status = 'suspended';
    user.isSuspicious = true;
    user.restriction_reason = detectedSignals.details?.join(' | ') || 'Account under security review due to anomalous activity.';
    user.restricted_at = new Date().toISOString();
  } else if (finalRiskScore >= 50) {
    targetStatus = 'HIGH';
    recommendedAction = 'MONITOR';
    user.isSuspicious = true;
    user.suspiciousReason = detectedSignals.details?.join(' | ') || 'Elevated risk indicators detected.';
  } else if (finalRiskScore >= 25) {
    targetStatus = 'MEDIUM';
    recommendedAction = 'MONITOR';
  } else {
    // If not locked in RESTRICTED or BANNED by Admin, reset to LOW
    if (user.risk_status !== 'RESTRICTED' && user.risk_status !== 'BANNED') {
      targetStatus = 'LOW';
      recommendedAction = 'NONE';
    } else {
      targetStatus = user.risk_status;
    }
  }

  const statusChanged = initialStatus !== targetStatus;
  user.risk_status = targetStatus;

  // Create immutable Risk Assessment record
  const assessmentRecord: RiskAssessmentRecord = {
    assessment_id: `risk_ass_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
    user_id: user.id,
    risk_score: finalRiskScore,
    detected_signals: detectedSignals,
    recommended_action: recommendedAction,
    created_at: new Date().toISOString()
  };

  if (!db.risk_assessments) {
    db.risk_assessments = [];
  }
  db.risk_assessments.unshift(assessmentRecord);
  if (db.risk_assessments.length > 3000) {
    db.risk_assessments = db.risk_assessments.slice(0, 3000);
  }

  // Audit log trigger on state changes or severe detections
  if (statusChanged || targetStatus === 'RESTRICTED' || targetStatus === 'BANNED') {
    const actionTaken = targetStatus === 'BANNED' ? 'BANNED' : targetStatus === 'RESTRICTED' ? 'RESTRICTED' : 'FLAGGED';
    recordSecurityAuditLog({
      user_id: user.id,
      action_taken: actionTaken,
      reason: detectedSignals.details?.join('; ') || `Evaluated risk score: ${finalRiskScore}`,
      enforced_by: params.enforced_by || 'SYSTEM',
      metadata: {
        score: finalRiskScore,
        actionType: params.actionType,
        device_fingerprint: effectiveFp,
        ip: effectiveIp
      }
    }, db);

    // VRMS-3 ULTRA (Phase 12): Internal Hook on Security Restriction
    if (targetStatus === 'RESTRICTED' && statusChanged) {
      emitSecurityRestrictionAlert(
        user.id,
        user.restriction_reason || detectedSignals.details?.join('; ') || 'High risk multi-signal threshold exceeded',
        assessmentRecord.assessment_id,
        db
      );
    }
  }

  writeDB(db);

  // Firestore sync for persistence
  try {
    isFirestoreWritable().then(writable => {
      if (writable) {
        setDoc(doc(firestore, "risk_assessments", assessmentRecord.assessment_id), assessmentRecord, { merge: true }).catch(() => {});
        setDoc(doc(firestore, "users", user.id), {
          risk_score: user.risk_score,
          risk_status: user.risk_status,
          restriction_reason: user.restriction_reason || null,
          restricted_at: user.restricted_at || null,
          status: user.status,
          isBanned: !!user.isBanned
        }, { merge: true }).catch(() => {});
      }
    }).catch(() => {});
  } catch {}

  const message = targetStatus === 'RESTRICTED'
    ? 'Account restricted due to security signals.'
    : targetStatus === 'BANNED'
    ? 'Account banned due to critical security violations.'
    : 'Risk evaluation completed successfully.';

  return {
    assessment: assessmentRecord,
    user,
    statusChanged,
    message
  };
}

/**
 * Execute an administrative security action on an account (UNRESTRICT, CONFIRM_BAN, RESTRICT, FLAG_RISK)
 */
export async function executeAdminSecurityAction(
  adminId: string,
  targetUserId: string,
  action: 'UNRESTRICT' | 'CONFIRM_BAN' | 'RESTRICT' | 'FLAG_RISK' | 'CLEAR_RISK',
  reason: string
): Promise<{
  success: boolean;
  user: UserProfile;
  audit_log: SecurityAuditLogRecord;
  message: string;
}> {
  const db = readDB();
  const user = db.users.find(u => u.id === targetUserId || u.telegramId === targetUserId);

  if (!user) {
    throw new Error(`Target user not found: ${targetUserId}`);
  }

  let auditAction: 'FLAGGED' | 'RESTRICTED' | 'BANNED' | 'UNRESTRICTED' | 'CLEARED' = 'CLEARED';
  let message = '';

  switch (action) {
    case 'UNRESTRICT': {
      user.risk_status = 'LOW';
      user.risk_score = Math.min(user.risk_score || 0, 15);
      user.status = 'active';
      user.isBanned = false;
      user.isSuspicious = false;
      user.restriction_reason = undefined;
      user.restricted_at = null;
      user.banReason = undefined;
      auditAction = 'UNRESTRICTED';
      message = `Account ${user.id} has been unrestricted and restored to active status.`;
      break;
    }
    case 'CONFIRM_BAN': {
      user.risk_status = 'BANNED';
      user.risk_score = 100;
      user.status = 'banned';
      user.isBanned = true;
      user.banReason = reason || 'Banned by Security Administrator';
      auditAction = 'BANNED';
      message = `Account ${user.id} has been permanently banned.`;
      break;
    }
    case 'RESTRICT': {
      user.risk_status = 'RESTRICTED';
      user.risk_score = Math.max(user.risk_score || 0, 80);
      user.status = 'suspended';
      user.restriction_reason = reason || 'Manually placed under security restriction by Administrator';
      user.restricted_at = new Date().toISOString();
      auditAction = 'RESTRICTED';
      message = `Account ${user.id} has been placed under restriction.`;

      // VRMS-3 ULTRA (Phase 12): Internal Hook on Admin Security Restriction
      emitSecurityRestrictionAlert(
        user.id,
        user.restriction_reason,
        `admin_sec_${Date.now()}`,
        db
      );
      break;
    }
    case 'FLAG_RISK': {
      user.isSuspicious = true;
      user.suspiciousReason = reason || 'Flagged for security monitoring by Administrator';
      user.risk_score = Math.max(user.risk_score || 0, 60);
      if (user.risk_status !== 'RESTRICTED' && user.risk_status !== 'BANNED') {
        user.risk_status = 'HIGH';
      }
      auditAction = 'FLAGGED';
      message = `Account ${user.id} has been flagged for risk.`;
      break;
    }
    case 'CLEAR_RISK': {
      user.isSuspicious = false;
      user.suspiciousReason = undefined;
      user.risk_score = 0;
      if (user.risk_status === 'HIGH' || user.risk_status === 'MEDIUM') {
        user.risk_status = 'LOW';
      }
      auditAction = 'CLEARED';
      message = `Risk flags cleared for account ${user.id}.`;
      break;
    }
    default:
      throw new Error(`Unknown security action: ${action}`);
  }

  const logRecord = recordSecurityAuditLog({
    user_id: user.id,
    action_taken: auditAction,
    reason: reason || `Admin action: ${action}`,
    enforced_by: 'ADMIN',
    metadata: {
      adminId,
      action
    }
  }, db);

  writeDB(db);

  // Sync to Firestore
  try {
    isFirestoreWritable().then(writable => {
      if (writable) {
        setDoc(doc(firestore, "security_audit_logs", logRecord.log_id), logRecord, { merge: true }).catch(() => {});
        setDoc(doc(firestore, "users", user.id), {
          risk_score: user.risk_score,
          risk_status: user.risk_status,
          status: user.status,
          isBanned: !!user.isBanned,
          restriction_reason: user.restriction_reason || null,
          restricted_at: user.restricted_at || null,
          banReason: user.banReason || null
        }, { merge: true }).catch(() => {});
      }
    }).catch(() => {});
  } catch {}

  return {
    success: true,
    user,
    audit_log: logRecord,
    message
  };
}

/**
 * Returns accounts flagged by the Risk & Security Engine along with their latest assessment
 */
export function getFlaggedAccounts(dbState?: any): Array<{
  user: UserProfile;
  latest_assessment?: RiskAssessmentRecord;
  security_logs_count: number;
}> {
  const db = dbState || readDB();
  const flaggedUsers = db.users.filter((u: UserProfile) => 
    u.risk_status === 'RESTRICTED' || 
    u.risk_status === 'BANNED' || 
    u.risk_status === 'HIGH' || 
    (u.risk_score && u.risk_score >= 50) || 
    u.isSuspicious || 
    u.isBanned
  );

  return flaggedUsers.map((u: UserProfile) => {
    const userAssessments = (db.risk_assessments || []).filter((a: RiskAssessmentRecord) => a.user_id === u.id);
    const latestAssessment = userAssessments[0];
    const logCount = (db.security_audit_logs || []).filter((l: SecurityAuditLogRecord) => l.user_id === u.id).length;

    return {
      user: u,
      latest_assessment: latestAssessment,
      security_logs_count: logCount
    };
  });
}
