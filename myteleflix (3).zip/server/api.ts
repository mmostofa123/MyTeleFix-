/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import { execFile } from "child_process";
import { promisify } from "util";
import multer from "multer";
import { 
  readDB, 
  writeDB, 
  findSalaryRequestById, 
  findSalaryRequestByUserAndCycle,
  recordAdminAuditLog,
  getAdminAuditLogs,
  getSecurityAuditLogs,
  syncSalaryRequestIndexes,
  getSystemConfigs,
  getSystemConfigValue,
  setSystemConfig,
  getCampaigns,
  getActiveCampaign,
  saveCampaign,
  getDynamicTasks,
  getDynamicContent,
  saveDynamicTask,
  saveDynamicContent,
  setDynamicTaskStatus,
  setDynamicContentStatus,
  resetAllPlatformUserData
} from "./db.js";
import { TaskContentSyncEngine } from "./taskContentSyncEngine.js";
import { AuditReconciliationEngine } from "./auditReconciliationEngine.js";
import { 
  getSystemConfigFromDb, 
  saveSystemConfigToDb, 
  getRealtimeMetricsFromDb,
  markDownloadRequestCompleted
} from "./firebaseAdmin.js";
import { generateAiSupportResponse } from "./aiSupportAssistant.js";
import {
  evaluateUserRisk,
  executeAdminSecurityAction,
  getFlaggedAccounts,
  isUserRestricted
} from "./riskEngine.js";
import {
  getUserNotifications,
  markNotificationsAsRead,
  createNotification,
  emitSalaryStatusAlert
} from "./notificationEngine.js";
import { handleAuthSwitch, handleTelegramAuth, handleGoogleAuth, verifyTelegramInitData } from "./auth.js";
import { getActiveMissions, getUserMissionLogs, verifyAndCompleteMission } from "./missions.js";
import { getReferralsForUser, recordPendingReferral, qualifyReferral, claimReferralReward, REFERRAL_PAYOUT_PLANS } from "./referrals.js";
import { getTransactionHistory, requestWithdrawal } from "./withdrawals.js";
import { getAdminAnalytics, getAllWithdrawals, processWithdrawalStatus, updateSystemSettings } from "./admin.js";
import { purgeInactiveUsers, SUPER_ADMIN_EMAIL, SUPER_ADMIN_TELEGRAM_ID, SUPER_ADMIN_USERNAME, isSuperAdminEmail } from "./inactivityPurge.js";
import { GoogleGenAI } from "@google/genai";
import { 
  requireAuthBearer, 
  requireAdminBearer, 
  acquireClaimLock, 
  releaseClaimLock, 
  getIdempotentResponse, 
  setIdempotentResponse, 
  evaluateWithdrawalRisk, 
  logHighRiskWithdrawalToFirestore 
} from "./securityGuard.js";
import { 
  recordAndValidateActivity, 
  getUserActivityStats, 
  evaluate72HourInactivityForUser 
} from "./userActivityEngine.js";
import {
  getOrCreateUserQuiz,
  submitUserQuizAnswers,
  resetUserQuiz,
  checkAccountVerificationStatus,
} from "./verificationEngine.js";
import {
  registerDirectReferral,
  getReferralOverviewForUser,
  onUserVerifiedReferralTrigger,
} from "./referralEngine.js";
import {
  evaluateInactivityAndPurge,
  executeUserPurge,
  getInactivityDays,
  touchAuthenticatedAccess,
  recalculateReferralCountsAndSalary
} from "./purgeEngine.js";
import {
  evaluateUserMilestones,
  claimMilestoneReward,
  reverseMilestoneReward,
  calculateCurrentQualifiedReferrals
} from "./milestoneRewardEngine.js";
import {
  SUPPORTED_PAYMENT_METHODS,
  isSupportedPaymentMethod,
  validatePaymentAccountFormat,
  sanitizePaymentInput,
  getUserPaymentProfiles,
  upsertPaymentProfile,
  deletePaymentProfile,
  createPaymentProfileSnapshot,
  claimMonthlySalaryWithSnapshot
} from "./paymentProfileEngine.js";
import {
  computeSalaryEligibility,
  generateSalarySnapshot,
  processSalaryClaim,
  generateSalaryRequestId,
  formatTelegramSalaryRequest,
  generateTelegramShareUrl,
  MAX_SALARY_LEVEL,
  SALARY_TIERS,
  getOrCreateActiveSalaryCycle
} from "./monthlySalaryEngine.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";
import {
  salaryClaimRateLimiter,
  quizResetRateLimiter,
  quizSubmitRateLimiter,
  authRateLimiter,
  taskSubmitRateLimiter,
  withdrawalRateLimiter
} from "./rateLimiter.js";
import { collectSystemHealthReport } from "./health.js";

const execFileAsync = promisify(execFile);

// Automatically optimize MP4/MOV/MKV/WebM videos with FastStart (+faststart)
// This puts the moov atom at the front so browsers play 100MB-3GB videos instantly with 0 latency
async function optimizeVideoForWeb(filePath: string): Promise<void> {
  try {
    const ext = path.extname(filePath).toLowerCase();
    if (!['.mp4', '.mov', '.m4v', '.3gp', '.webm', '.mkv'].includes(ext)) {
      return;
    }
    const tempOutput = `${filePath}.optimized.mp4`;
    await execFileAsync('ffmpeg', [
      '-y',
      '-i', filePath,
      '-c', 'copy',
      '-movflags', '+faststart',
      tempOutput
    ]);
    if (fs.existsSync(tempOutput)) {
      const tempStat = fs.statSync(tempOutput);
      if (tempStat.size > 1000) {
        fs.renameSync(tempOutput, filePath);
        console.log(`[Video Stream Optimizer] Successfully applied FastStart web optimization to ${path.basename(filePath)} (${tempStat.size} bytes)`);
      } else {
        try { fs.unlinkSync(tempOutput); } catch (e) {}
      }
    }
  } catch (err) {
    console.warn(`[Video Stream Optimizer] Faststart stream copy notice:`, err);
  }
}

const router = express.Router();

// VRMS-3 ULTRA (Phase 16): Distributed Rate Limiting on Authentication endpoints
router.use("/auth", authRateLimiter);

/**
 * GET /api/health or /health
 * Public/System health probe
 */
router.get(["/health", "/api/health"], async (req, res, next) => {
  try {
    const report = await collectSystemHealthReport({ deepDbPing: false });
    const statusCode = report.status === "DOWN" ? 503 : 200;
    return res.status(statusCode).json(report);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/admin/health or /admin/health
 * Comprehensive real-time telemetry for Admin Dashboard
 */
router.get(["/admin/health", "/api/admin/health"], async (req, res, next) => {
  try {
    const deep = req.query.deep === "true";
    const report = await collectSystemHealthReport({ deepDbPing: deep });
    return res.json(report);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/admin/health/ping or /admin/health/ping
 * Real-time roundtrip ping test for database & latency check
 */
router.post(["/admin/health/ping", "/api/admin/health/ping"], async (req, res, next) => {
  try {
    const report = await collectSystemHealthReport({ deepDbPing: true });
    return res.json({
      success: true,
      ping_timestamp: new Date().toISOString(),
      report
    });
  } catch (err) {
    next(err);
  }
});

// Universal Chronological Sorting: Newest posts always at top
function sortServerMediaNewestFirst<T extends { createdAt?: string; id?: string }>(items: T[]): T[] {
  if (!items || !Array.isArray(items)) return [];
  return [...items].sort((a, b) => {
    if (a.createdAt && b.createdAt) {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();
      if (!isNaN(timeA) && !isNaN(timeB) && timeA !== timeB) {
        return timeB - timeA;
      }
    }
    if (a.createdAt && !b.createdAt) return -1;
    if (!a.createdAt && b.createdAt) return 1;

    const extractTimestamp = (id?: string): number => {
      if (!id) return 0;
      const match = id.match(/\d{10,}/);
      return match ? parseInt(match[0], 10) : 0;
    };
    const tsA = extractTimestamp(a.id);
    const tsB = extractTimestamp(b.id);
    if (tsA > 0 && tsB > 0 && tsA !== tsB) {
      return tsB - tsA;
    }
    if (tsA > 0 && tsB === 0) return -1;
    if (tsA === 0 && tsB > 0) return 1;

    return 0;
  });
}

// Ensure uploads & chunk directories exist
const uploadsDir = path.join(process.cwd(), "uploads");
const chunksDir = path.join(uploadsDir, "chunks");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
if (!fs.existsSync(chunksDir)) {
  fs.mkdirSync(chunksDir, { recursive: true });
}

// Multer Storage Configuration for Standard Single Uploads
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + crypto.randomBytes(6).toString("hex");
    const ext = path.extname(file.originalname).toLowerCase() || (file.mimetype.includes("video") ? ".mp4" : file.mimetype.includes("audio") ? ".mp3" : ".jpg");
    const safeBase = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, "_").substring(0, 30);
    cb(null, `${safeBase}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 5 * 1024 * 1024 * 1024,
    fieldSize: 50 * 1024 * 1024,
  }
});

// Multer for 3MB-10MB individual slices/chunks using memoryStorage
const chunkUpload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB per chunk limit (typical chunk is 3-5MB)
  }
});

// Dedicated Media Upload Endpoint (Direct to Server Disk Storage)
router.post("/upload", (req, res) => {
  req.setTimeout(0);
  res.setTimeout(0);
  if (req.socket) req.socket.setTimeout(0);
  if (res.socket) res.socket.setTimeout(0);

  upload.single("file")(req, res, (err) => {
    if (err) {
      console.error("File upload multer error:", err);
      return res.status(400).json({ 
        error: err.code === 'LIMIT_FILE_SIZE' 
          ? "File exceeds the maximum upload size limit." 
          : (err.message || "Failed to process media upload.") 
      });
    }

    if (!req.file) {
      return res.status(400).json({ error: "No file was uploaded." });
    }

    const fileUrl = `/uploads/${req.file.filename}`;
    
    // Automatically apply FastStart streaming optimization in background or synchronously
    const filePath = path.join(uploadsDir, req.file.filename);
    optimizeVideoForWeb(filePath).catch(e => console.warn("Optimization error", e));

    return res.status(200).json({
      success: true,
      url: fileUrl,
      filename: req.file.filename,
      mimetype: req.file.mimetype,
      size: req.file.size,
      message: "Media file successfully uploaded and permanently saved."
    });
  });
});

// Resilient Chunk Upload Endpoint (Immune to multipart field ordering & proxy limits)
router.post("/upload/chunk", (req, res) => {
  req.setTimeout(0);
  res.setTimeout(0);
  if (req.socket) req.socket.setTimeout(0);
  if (res.socket) res.socket.setTimeout(0);

  chunkUpload.single("chunk")(req, res, (err) => {
    if (err) {
      console.error("Chunk upload error:", err);
      return res.status(400).json({ error: err.message || "Failed to upload file chunk." });
    }

    if (!req.file || !req.file.buffer) {
      return res.status(400).json({ error: "No chunk buffer received." });
    }

    const rawUploadId = req.body?.uploadId || req.query?.uploadId || req.headers['x-upload-id'] || "";
    const rawChunkIndex = req.body?.chunkIndex ?? req.query?.chunkIndex ?? req.headers['x-chunk-index'] ?? "0";
    const rawTotalChunks = req.body?.totalChunks ?? req.query?.totalChunks ?? req.headers['x-total-chunks'] ?? "1";

    const uploadId = String(rawUploadId).replace(/[^a-zA-Z0-9_-]/g, "");
    const chunkIndex = parseInt(String(rawChunkIndex), 10);
    const totalChunks = parseInt(String(rawTotalChunks), 10);

    if (!uploadId || isNaN(chunkIndex)) {
      return res.status(400).json({ error: "Invalid uploadId or chunkIndex" });
    }

    const partPath = path.join(chunksDir, `${uploadId}_part_${chunkIndex}`);
    try {
      fs.writeFileSync(partPath, req.file.buffer);
      return res.status(200).json({
        success: true,
        uploadId,
        chunkIndex,
        totalChunks,
        bytesReceived: req.file.buffer.length,
        message: `Chunk ${chunkIndex} received and saved successfully.`,
      });
    } catch (writeErr: any) {
      console.error("Failed to write chunk part:", writeErr);
      return res.status(500).json({ error: "Failed to persist chunk part to disk." });
    }
  });
});

// Complete & Assemble Chunked Upload Endpoint
router.post("/upload/complete", async (req, res) => {
  req.setTimeout(0);
  res.setTimeout(0);
  if (req.socket) req.socket.setTimeout(0);
  if (res.socket) res.socket.setTimeout(0);

  try {
    const rawUploadId = req.body?.uploadId || req.query?.uploadId || "";
    const rawTotalChunks = req.body?.totalChunks || req.query?.totalChunks || 0;
    const originalName = req.body?.originalName || req.query?.originalName || "video.mp4";
    const mimeType = req.body?.mimeType || req.query?.mimeType || "";

    const uploadId = String(rawUploadId).replace(/[^a-zA-Z0-9_-]/g, "");
    const total = parseInt(String(rawTotalChunks), 10);

    if (!uploadId || total <= 0) {
      return res.status(400).json({ error: "Missing uploadId or invalid totalChunks." });
    }
    
    // Check all chunks exist
    const missingChunks: number[] = [];
    for (let i = 0; i < total; i++) {
      const partPath = path.join(chunksDir, `${uploadId}_part_${i}`);
      if (!fs.existsSync(partPath)) {
        missingChunks.push(i);
      }
    }

    if (missingChunks.length > 0) {
      return res.status(400).json({ 
        error: `Missing chunk ${missingChunks[0]} of ${total}. (Missing ${missingChunks.length} parts). Please retry upload.` 
      });
    }

    // Determine target filename
    const uniqueSuffix = Date.now() + "-" + crypto.randomBytes(6).toString("hex");
    const ext = path.extname(originalName).toLowerCase() || (mimeType && mimeType.includes("video") ? ".mp4" : mimeType && mimeType.includes("audio") ? ".mp3" : ".mp4");
    const safeBase = path.basename(originalName, ext).replace(/[^a-zA-Z0-9_-]/g, "_").substring(0, 30);
    const finalFilename = `${safeBase}-${uniqueSuffix}${ext}`;
    const finalFilePath = path.join(uploadsDir, finalFilename);

    // Initialize clean destination file
    fs.writeFileSync(finalFilePath, Buffer.alloc(0));

    // Concatenate chunks sequentially to the final file with zero buffering loss
    let totalBytesWritten = 0;
    for (let i = 0; i < total; i++) {
      const partPath = path.join(chunksDir, `${uploadId}_part_${i}`);
      const chunkBuffer = fs.readFileSync(partPath);
      fs.appendFileSync(finalFilePath, chunkBuffer);
      totalBytesWritten += chunkBuffer.length;
      // Clean up part
      try {
        fs.unlinkSync(partPath);
      } catch (e) {
        // ignore part cleanup error
      }
    }

    // Optimize assembled video with FastStart for zero-delay browser streaming
    await optimizeVideoForWeb(finalFilePath);

    const stats = fs.statSync(finalFilePath);
    const fileUrl = `/uploads/${finalFilename}`;

    return res.status(200).json({
      success: true,
      url: fileUrl,
      filename: finalFilename,
      size: stats.size,
      message: "Media file successfully assembled and permanently saved."
    });
  } catch (err: any) {
    console.error("Assemble chunked upload error:", err);
    return res.status(500).json({ error: err.message || "Failed to assemble uploaded file." });
  }
});

// Media File Deletion Endpoint (Remove from Server Disk)
router.post("/upload/delete", (req, res) => {
  try {
    const { url, filename } = req.body;
    let targetName = filename;
    if (!targetName && url && typeof url === "string") {
      const match = url.match(/\/uploads\/([^/?#]+)/);
      if (match) {
        targetName = match[1];
      }
    }

    if (!targetName) {
      return res.status(400).json({ error: "Invalid file URL or filename." });
    }

    // Security check: prevent directory traversal
    const safeTarget = path.basename(targetName);
    const targetPath = path.join(uploadsDir, safeTarget);

    if (fs.existsSync(targetPath)) {
      fs.unlinkSync(targetPath);
      return res.json({ success: true, message: `File ${safeTarget} permanently deleted.` });
    }

    return res.json({ success: true, message: "File already removed or not found on disk." });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || "Failed to delete file from disk." });
  }
});

// Initialize Google GenAI
const aiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (aiApiKey && aiApiKey !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: aiApiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } catch (err) {
    console.error("Failed to initialize Gemini Client in API Layer:", err);
  }
}

// 1. Authentication Layer
router.get("/auth", (req, res) => {
  const db = readDB();
  const userId = req.query.userId as string;
  const device_fingerprint = req.query.device_fingerprint as string;

  if (!userId || userId === "tg-guest" || userId.startsWith("guest_")) {
    return res.json({ user: null, isGuest: true, settings: db.settings });
  }

  let user = db.users.find((u: any) => u.id === userId);
  
  if (!user) {
    return res.json({ user: null, isGuest: false, settings: db.settings });
  } else {
    // Evaluate 72h inactivity rule on user access before refreshing timestamp
    evaluate72HourInactivityForUser(user);
    user.lastLogin = new Date().toISOString();
    user.last_active_at = new Date().toISOString();
    if (device_fingerprint) {
      if (!user.device_fingerprint) {
        user.device_fingerprint = device_fingerprint;
      }
      // Check multi-account detection within 24h
      const otherUsersOnDevice = db.users.filter((u: any) => 
        (u.device_fingerprint === device_fingerprint || u.deviceFingerprint === device_fingerprint) && 
        u.id !== user.id
      );
      if (otherUsersOnDevice.length > 0) {
        const now = Date.now();
        const ONE_DAY_MS = 24 * 60 * 60 * 1000;
        const hasRecentSecondary = otherUsersOnDevice.some((u: any) => {
          const t = new Date(u.lastLogin || u.last_active_at || u.createdAt).getTime();
          return now - t < ONE_DAY_MS;
        });
        if (hasRecentSecondary) {
          user.isSuspicious = true;
          user.suspiciousReason = `High Risk / Multi-Account: 2+ profiles linked to Hardware ID (${device_fingerprint.slice(0, 10)}...) within 24h`;
          otherUsersOnDevice.forEach((u: any) => {
            u.isSuspicious = true;
            u.suspiciousReason = `High Risk / Multi-Account: 2+ profiles linked to Hardware ID (${device_fingerprint.slice(0, 10)}...) within 24h`;
          });
        }
      }
    }
    const isSuperAdmin = isSuperAdminEmail(user.email) ||
      user.telegramId === SUPER_ADMIN_TELEGRAM_ID ||
      (user.username && user.username.toLowerCase() === SUPER_ADMIN_USERNAME.toLowerCase());
    user.role = isSuperAdmin ? "admin" : "user";
    user.points = user.wallet?.points ?? user.points ?? 100;
    writeDB(db);
  }
  res.json({ user, settings: db.settings });
});

// Admin Security Guard: require valid Bearer token and administrative clearance for all /admin routes
router.use("/admin", requireAdminBearer);

// Admin Inactivity Auto-Purge Trigger Endpoint
router.get("/admin/purge-inactive", (req, res) => {
  try {
    const result = purgeInactiveUsers();
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/purge-inactive", (req, res) => {
  try {
    const days = req.body?.days ? Number(req.body.days) : 30;
    const ms = days * 24 * 60 * 60 * 1000;
    const result = purgeInactiveUsers(ms);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/auth/telegram", (req, res) => {
  try {
    const headerInitData = (req.headers["x-telegram-init-data"] || req.headers["x-telegram-initdata"]) as string;
    const result = handleTelegramAuth(req.body, headerInitData);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ============================================================================
// HARDWARE DEVICE SECURITY & ANTI-MULTI ACCOUNT ENGINE (CROSS-BROWSER)
// ============================================================================

import { normalizeGpuChipset, normalizePhysicalScreen, getIpSubnet, findDeviceLockMatch } from "./deviceSecurity.js";
export { normalizeGpuChipset, normalizePhysicalScreen, getIpSubnet, findDeviceLockMatch };

router.get("/auth/client-ip", (req, res) => {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '127.0.0.1';
  res.json({ ip: clientIp });
});

router.post("/auth/check-device", (req, res) => {
  try {
    const { 
      device_fingerprint, 
      hwid, 
      cross_browser_hwid, 
      hardware_uuid, 
      gpu_renderer, 
      gpu_chipset,
      screen_resolution, 
      physical_screen,
      hardware_concurrency,
      cpu_cores,
      timezone,
      ip_address, 
      userId, 
      email 
    } = req.body;
    const clientIp = ip_address || (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
    const cleanEmail = (email || '').toLowerCase().trim();

    // Super admin bypasses device checks
    if (isSuperAdminEmail(cleanEmail) || cleanEmail === 'mostofa7077a@gmail.com') {
      return res.json({ allowed: true, ip: clientIp });
    }

    const db = readDB();
    const match = findDeviceLockMatch(db, {
      hwid,
      cross_browser_hwid,
      hardware_uuid,
      device_fingerprint,
      gpu_renderer,
      gpu_chipset,
      screen_resolution,
      physical_screen,
      hardware_concurrency,
      cpu_cores,
      timezone,
      ip_address: clientIp
    });

    if (match.isLocked && match.primaryEmail) {
      if (cleanEmail && cleanEmail !== match.primaryEmail) {
        return res.status(403).json({
          allowed: false,
          blocked: true,
          error: "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          primaryEmail: match.primaryEmail,
          existingAccount: {
            id: match.user?.id || match.lock?.user_id,
            email: match.primaryEmail,
            username: match.user?.username || match.primaryEmail.split("@")[0],
            fullName: match.user?.fullName || match.primaryEmail.split("@")[0],
            photoUrl: match.user?.photoUrl,
            points: match.user?.points || 100
          },
          deviceFingerprint: device_fingerprint || hwid,
          ip: clientIp
        });
      }
    }

    res.json({ allowed: true, ip: clientIp });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/auth/google", (req, res) => {
  try {
    const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
    const result = handleGoogleAuth({ ...req.body, ip_address: req.body.ip_address || clientIp });
    res.json(result);
  } catch (err: any) {
    if (err.blocked || err.statusCode === 403) {
      return res.status(403).json({
        blocked: true,
        error: err.message || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
        primaryEmail: err.primaryEmail || (typeof err.existingAccount === 'object' ? err.existingAccount?.email : err.existingAccount),
        existingAccount: err.existingAccount,
        deviceFingerprint: err.deviceFingerprint,
        ip: err.ipAddress
      });
    }
    res.status(400).json({ error: err.message });
  }
});

// RESTORE PRIMARY AUTHORIZED ACCOUNT:
// When security violation is detected, clicking "মূল অ্যাকাউন্টে ফিরে যান" logs directly into the first registered account.
router.post("/auth/restore-primary", (req, res) => {
  try {
    const { 
      primary_email, 
      hwid, 
      cross_browser_hwid,
      gpu_chipset,
      physical_screen,
      cpu_cores,
      timezone
    } = req.body;
    const cleanEmail = (primary_email || '').toLowerCase().trim();
    const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
    const db = readDB();

    let targetEmail = cleanEmail;
    if (!targetEmail) {
      const match = findDeviceLockMatch(db, {
        hwid,
        cross_browser_hwid,
        gpu_chipset,
        physical_screen,
        cpu_cores,
        timezone,
        ip_address: clientIp
      });
      if (match.isLocked && match.primaryEmail) {
        targetEmail = match.primaryEmail;
      }
    }

    if (!targetEmail) {
      // Find latest device lock as ultimate fallback
      const locks = (db as any).device_locks || [];
      if (locks.length > 0 && locks[locks.length - 1].primary_email) {
        targetEmail = locks[locks.length - 1].primary_email.toLowerCase().trim();
      }
    }

    if (!targetEmail) {
      return res.status(404).json({ error: "Primary account not found for this device" });
    }

    let user = db.users.find((u: any) => u.email && u.email.toLowerCase().trim() === targetEmail);

    if (!user) {
      const calculatedUid = `g-${targetEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const isSuper = isSuperAdminEmail(targetEmail) || targetEmail === "mostofa7077a@gmail.com";
      user = {
        id: calculatedUid,
        googleId: calculatedUid,
        telegramId: "",
        username: targetEmail.split("@")[0],
        fullName: targetEmail.split("@")[0],
        email: targetEmail,
        photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
        role: isSuper ? "admin" : "user",
        points: 100,
        status: "active",
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        wallet: {
          points: 100,
          walletAddress: "",
          status: "active",
          updatedAt: new Date().toISOString()
        },
        taskStats: {
          missionsCompleted: 0,
          totalPointsEarned: 100,
          moviesWatched: 0,
          videosWatched: 0
        }
      };
      db.users.push(user);
    } else {
      user.lastLogin = new Date().toISOString();
      user.last_active_at = new Date().toISOString();
      if (!user.wallet) {
        user.wallet = {
          points: user.points || 100,
          walletAddress: "",
          status: "active",
          updatedAt: new Date().toISOString()
        };
      }
      if (!user.taskStats) {
        user.taskStats = {
          missionsCompleted: 0,
          totalPointsEarned: user.points || 100,
          moviesWatched: 0,
          videosWatched: 0
        };
      }
    }

    // Ensure persistent lock binding in db.device_locks
    if (!(db as any).device_locks) (db as any).device_locks = [];
    const lockKey = cross_browser_hwid || hwid;
    if (lockKey) {
      const existingLockIdx = (db as any).device_locks.findIndex((l: any) => 
        (cross_browser_hwid && l.cross_browser_hwid === cross_browser_hwid) ||
        (hwid && l.hwid === hwid) ||
        (l.primary_email === user.email.toLowerCase().trim())
      );
      const newLockRecord = {
        hwid: hwid || lockKey,
        cross_browser_hwid: cross_browser_hwid || hwid || lockKey,
        gpu_chipset: gpu_chipset || undefined,
        physical_screen: physical_screen || undefined,
        cpu_cores: cpu_cores || undefined,
        timezone: timezone || undefined,
        ip_address: clientIp,
        primary_email: user.email.toLowerCase().trim(),
        user_id: user.id,
        updated_at: new Date().toISOString()
      };
      if (existingLockIdx >= 0) {
        (db as any).device_locks[existingLockIdx] = { ...(db as any).device_locks[existingLockIdx], ...newLockRecord };
      } else {
        (db as any).device_locks.push({ ...newLockRecord, created_at: new Date().toISOString() });
      }
    }

    writeDB(db);

    res.json({
      success: true,
      user,
      primaryEmail: user.email,
      settings: db.settings
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// HARDWARE DEVICE SECURITY ENGINE: Device Lock & Anti-Multi Account Endpoints
router.get("/security/device-lock", (req, res) => {
  try {
    const hwid = req.query.hwid as string;
    if (!hwid) return res.status(400).json({ error: "Missing hwid parameter" });
    const db = readDB();
    const locks = (db as any).device_locks || [];
    const lock = locks.find((l: any) => l.hwid === hwid || l.cross_browser_hwid === hwid);
    res.json({ lock: lock || null });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/security/check-device-lock", (req, res) => {
  try {
    const { 
      hwid, 
      cross_browser_hwid, 
      hardware_uuid, 
      device_fingerprint,
      gpu_renderer, 
      gpu_chipset,
      screen_resolution, 
      physical_screen,
      hardware_concurrency, 
      cpu_cores,
      timezone, 
      email, 
      ip_address 
    } = req.body;
    const cleanEmail = (email || '').toLowerCase().trim();
    const clientIp = ip_address || (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';

    // Super admin bypass
    if (isSuperAdminEmail(cleanEmail) || cleanEmail === 'mostofa7077a@gmail.com') {
      return res.json({ isBlocked: false, isBound: false });
    }

    const db = readDB();
    const match = findDeviceLockMatch(db, {
      hwid,
      cross_browser_hwid,
      hardware_uuid,
      device_fingerprint,
      gpu_renderer,
      gpu_chipset,
      screen_resolution,
      physical_screen,
      hardware_concurrency,
      cpu_cores,
      timezone,
      ip_address: clientIp
    });

    if (match.isLocked && match.primaryEmail) {
      if (cleanEmail && cleanEmail !== match.primaryEmail) {
        return res.status(403).json({
          isBlocked: true,
          isBound: true,
          primaryEmail: match.primaryEmail,
          firstUser: match.user ? { 
            id: match.user.id, 
            email: match.user.email, 
            fullName: match.user.fullName, 
            photoUrl: match.user.photoUrl,
            points: match.user.points 
          } : null,
          hwid: match.lock?.hwid || hwid,
          reason: "Device is permanently locked in the database to authorized primary Google account."
        });
      }
      return res.json({
        isBlocked: false,
        isBound: true,
        primaryEmail: match.primaryEmail,
        firstUser: match.user ? { 
          id: match.user.id, 
          email: match.user.email, 
          fullName: match.user.fullName, 
          photoUrl: match.user.photoUrl,
          points: match.user.points 
        } : null,
        hwid: match.lock?.hwid || hwid
      });
    }

    res.json({ isBlocked: false, isBound: false, hwid });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/security/bind-device", (req, res) => {
  try {
    const { 
      hwid, 
      cross_browser_hwid, 
      hardware_uuid, 
      device_fingerprint,
      primary_email, 
      user_id, 
      platform, 
      screen_resolution, 
      physical_screen,
      gpu_renderer, 
      gpu_chipset,
      hardware_concurrency, 
      cpu_cores,
      timezone, 
      ip_address 
    } = req.body;
    if ((!hwid && !cross_browser_hwid) || !primary_email) {
      return res.status(400).json({ error: "Missing hwid or primary_email" });
    }
    const cleanEmail = primary_email.toLowerCase().trim();
    const clientIp = ip_address || (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.socket.remoteAddress || '';
    const normGpu = gpu_chipset || normalizeGpuChipset(gpu_renderer || "");
    const normScreen = normalizePhysicalScreen(physical_screen || screen_resolution || "");
    const normSubnet = getIpSubnet(clientIp);
    const cores = cpu_cores || hardware_concurrency || 4;

    const db = readDB();
    if (!(db as any).device_locks) {
      (db as any).device_locks = [];
    }

    const primaryLockId = cross_browser_hwid || hwid;
    const idx = (db as any).device_locks.findIndex((l: any) => 
      (hwid && l.hwid === hwid) || 
      (cross_browser_hwid && (l.cross_browser_hwid === cross_browser_hwid || l.hwid === cross_browser_hwid)) ||
      (l.primary_email === cleanEmail) ||
      (l.hwid === primaryLockId)
    );

    const lockRecord = {
      hwid: hwid || primaryLockId,
      cross_browser_hwid: cross_browser_hwid || hwid || primaryLockId,
      hardware_uuid: hardware_uuid,
      device_fingerprint: device_fingerprint || hwid,
      primary_email: cleanEmail,
      user_id: user_id || `u_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`,
      platform: platform || 'web',
      screen_resolution: normScreen || 'unknown',
      physical_screen: normScreen,
      gpu_renderer: gpu_renderer,
      gpu_chipset: normGpu,
      hardware_concurrency: cores,
      cpu_cores: cores,
      timezone: timezone || 'UTC',
      ip_address: clientIp,
      ip_subnet: normSubnet,
      created_at: idx >= 0 ? (db as any).device_locks[idx].created_at : new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    if (idx >= 0) {
      (db as any).device_locks[idx] = { ...(db as any).device_locks[idx], ...lockRecord };
    } else {
      (db as any).device_locks.push(lockRecord);
    }
    writeDB(db);
    res.json({ success: true, lock: lockRecord });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/auth/switch", (req, res) => {
  try {
    const result = handleAuthSwitch(req.body);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/auth/update-profile", (req, res) => {
  try {
    const userId = req.body.userId || req.body.uid || req.body.id;
    const { gender, fullName, displayName, photoUrl, photoURL, telegramUsername, username, isProfileCompleted, isOnboarded } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "Missing userId" });
    }
    const db = readDB();
    let user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      user = {
        id: userId,
        username: username || (telegramUsername ? telegramUsername.replace(/^@/, '') : `user_${userId.slice(0, 6)}`),
        role: 'user',
        points: 100,
        createdAt: new Date().toISOString()
      };
      db.users.push(user);
    }
    // Profile information can be updated via the edit profile modal (pencil icon)
    // and saved permanently into the database.
    if (gender) user.gender = gender;
    if (fullName) user.fullName = fullName;
    if (displayName) {
      user.displayName = displayName;
      user.fullName = fullName || displayName;
    }
    if (photoUrl) user.photoUrl = photoUrl;
    if (photoURL) user.photoURL = photoURL;
    if (telegramUsername !== undefined) user.telegramUsername = telegramUsername;
    if (username !== undefined) user.username = username;
    if (isProfileCompleted !== undefined) user.isProfileCompleted = isProfileCompleted;
    if (isOnboarded !== undefined) user.isOnboarded = isOnboarded;
    user.updatedAt = new Date().toISOString();
    touchAuthenticatedAccess(user.id, db);
    writeDB(db);
    return res.json({ success: true, user });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin System Reset Endpoint: Cleans all user data for fresh platform start
router.post("/admin/system/reset-all-user-data", (req, res) => {
  try {
    const result = resetAllPlatformUserData();
    return res.json({ success: true, message: "All user platform data has been completely cleared.", result });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

router.post("/auth/upgrade", (req, res) => {
  const { userId } = req.body;
  const db = readDB();
  const user = db.users.find((u: any) => u.id === userId);
  if (user) {
    user.isPremium = true;
    touchAuthenticatedAccess(user.id, db);
    
    // Add transaction ledger entry
    db.transactions.push({
      id: "tx-premium-" + Date.now(),
      userId: userId,
      amount: 0,
      type: "deposit",
      status: "completed",
      description: "My TeleFlix VIP Lifetime Activation",
      timestamp: new Date().toISOString()
    });

    // Notify user
    db.notifications.push({
      id: "nt-premium-" + Date.now(),
      userId: userId,
      title: "👑 VIP Status Activated!",
      message: "Congratulations! You are now a My TeleFlix VIP member. Enjoy unlimited, instant 1-click downloads!",
      isRead: false,
      timestamp: new Date().toISOString()
    });

    writeDB(db);
    return res.json({ success: true, user });
  }
  res.status(404).json({ error: "User not found" });
});

// User Streaming Heartbeat & Continuous Watch Time Tracker
// Updates last_active_at dynamically to protect active streaming viewers from the 30-day purge engine
router.post("/user/heartbeat", async (req, res) => {
  try {
    const { userId, watchTimeSeconds, mediaId, mediaType, title } = req.body;
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId || (userId && (u.guest_device_id === userId || u.device_fingerprint === userId)));
    
    const nowIso = new Date().toISOString();

    if (user) {
      user.last_active_at = nowIso;
      user.lastLogin = nowIso;
      const seconds = Math.max(0, Number(watchTimeSeconds) || 0);
      user.totalWatchTimeSeconds = (user.totalWatchTimeSeconds || 0) + seconds;
      
      if (!user.taskStats) {
        user.taskStats = { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 };
      }
      if (mediaType === 'video') {
        user.taskStats.videosWatched = (user.taskStats.videosWatched || 0) + 1;
      } else {
        user.taskStats.moviesWatched = (user.taskStats.moviesWatched || 0) + 1;
      }
      writeDB(db);
    }

    // Also record qualifying content activity in the User Activity Engine if watch time is significant (>=10s)
    let contentActivityResult: any = null;
    if (user && seconds >= 10 && (mediaId || title)) {
      try {
        const todayDate = new Date().toISOString().split("T")[0];
        const contentIdKey = `content_heartbeat_${user.id}_${mediaId || 'stream'}_${todayDate}_${Math.floor(Date.now() / (180 * 1000))}`;
        contentActivityResult = await recordAndValidateActivity({
          userId: user.id,
          activityType: 'CONTENT',
          sourceReference: String(mediaId || title || 'media_stream'),
          idempotencyKey: contentIdKey,
          metadata: {
            watchTimeSeconds: seconds,
            mediaType: mediaType || 'video',
            title
          }
        });
      } catch (actErr) {
        console.warn("[UAE] Content activity recording notice:", actErr);
      }
    }

    return res.json({
      success: true,
      last_active_at: nowIso,
      watchTimeRecorded: watchTimeSeconds || 0,
      totalWatchTimeSeconds: user?.totalWatchTimeSeconds || 0,
      userFound: !!user,
      activityStats: contentActivityResult?.stats || (user ? getUserActivityStats(user.id).today : null),
      activeDayNewlyAwarded: contentActivityResult?.activeDayNewlyAwarded || false,
      message: "Streaming activity recorded. Inactivity purge timer refreshed."
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// USER ACTIVITY ENGINE (UAE) - SERVER-AUTHORITATIVE ENDPOINTS
// -------------------------------------------------------------

// GET /api/user/activity-stats
// Server-authoritative source of truth for streak, lifetime valid actions,
// and daily breakdown (Tasks: X/10, Content: Y/5).
router.get("/user/activity-stats", (req, res) => {
  try {
    const userId = (req.query.userId || req.headers["x-user-id"]) as string;
    if (!userId) {
      return res.status(400).json({ error: "Missing required userId parameter." });
    }

    const stats = getUserActivityStats(userId);
    return res.json(stats);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/user/record-activity
// Server-authoritative validator for all TASK and CONTENT actions
router.post("/user/record-activity", async (req, res) => {
  try {
    const { userId, activityType, sourceReference, idempotencyKey, metadata } = req.body;

    if (!userId || !activityType || !sourceReference) {
      return res.status(400).json({
        error: "userId, activityType ('TASK' | 'CONTENT'), and sourceReference are required."
      });
    }

    if (activityType !== 'TASK' && activityType !== 'CONTENT') {
      return res.status(400).json({
        error: "activityType must be either 'TASK' or 'CONTENT'."
      });
    }

    const result = await recordAndValidateActivity({
      userId,
      activityType,
      sourceReference,
      idempotencyKey,
      metadata
    });

    if (result.code === 'DUPLICATE') {
      return res.status(409).json(result);
    }

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// VERIFICATION ENGINE (VE) & ANTI-BOT HUMAN QUIZ (PHASE 3)
// -------------------------------------------------------------

// GET /api/quiz/get-questions
// Returns 3 randomized questions WITHOUT answers to the client
router.get("/quiz/get-questions", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"] || "tg-101") as string;
    const result = getOrCreateUserQuiz(userId);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/quiz/submit-answers
// Server-authoritatively evaluates 3 submitted answers.
// 3/3 => PASSED; < 3 => FAILED, shuffles fresh questions, requires reset.
router.post("/quiz/submit-answers", quizSubmitRateLimiter, (req, res) => {
  try {
    const userId = (req.body.userId || req.body.user_id || req.headers["x-user-id"] || "tg-101") as string;
    const { attemptId, attempt_id, answers } = req.body;
    const targetAttemptId = attemptId || attempt_id;

    if (!answers || typeof answers !== "object") {
      return res.status(400).json({ error: "Answers object is required." });
    }

    const result = submitUserQuizAnswers(userId, targetAttemptId, answers);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/quiz/reset
// Rate-limited question set reset & shuffling (Max 5/hour)
router.post("/quiz/reset", quizResetRateLimiter, (req, res) => {
  try {
    const userId = (req.body.userId || req.body.user_id || req.headers["x-user-id"] || "tg-101") as string;
    const result = resetUserQuiz(userId);
    if (!result.success) {
      return res.status(429).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// POST /api/verification/check-status
// Server-authoritatively evaluates all 4 prerequisites:
// VERIFIED = ACCOUNT_VALID AND active_day_streak >= 10 AND valid_action_count >= 100 AND quiz_score >= 3/3 AND NOT_RESTRICTED
const handleVerificationCheck = (req: any, res: any) => {
  try {
    const userId = (req.body?.userId || req.body?.user_id || req.query?.userId || req.query?.user_id || req.headers["x-user-id"] || "tg-101") as string;
    const result = checkAccountVerificationStatus(userId);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
};
router.post("/verification/check-status", handleVerificationCheck);
router.get("/verification/check-status", handleVerificationCheck);

// 2. Movies Module
router.get("/movies", (req, res) => {
  const db = readDB();
  const activeOnly = req.query.all !== "true";
  const list = activeOnly ? db.movies.filter((m: any) => m.isActive) : db.movies;
  res.json(sortServerMediaNewestFirst(list));
});

router.post("/movies", (req, res) => {
  const db = readDB();
  const movie = req.body;
  
  if (!movie.createdAt) {
    movie.createdAt = new Date().toISOString();
  }

  if (!movie.id) {
    movie.id = "mv-" + Date.now();
    movie.views = 0;
    db.movies.unshift(movie);
  } else {
    const idx = db.movies.findIndex((m: any) => m.id === movie.id);
    if (idx !== -1) {
      db.movies[idx] = { ...db.movies[idx], ...movie };
    } else {
      db.movies.unshift(movie);
    }
  }

  db.movies = sortServerMediaNewestFirst(db.movies);
  writeDB(db);
  res.json({ success: true, movie });
});

router.post("/movies/delete", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  db.movies = db.movies.filter((m: any) => m.id !== id);
  writeDB(db);
  res.json({ success: true, message: "Movie deleted successfully", count: db.movies.length });
});

router.post("/movies/bulk-delete", (req, res) => {
  const { ids } = req.body;
  const db = readDB();
  if (Array.isArray(ids)) {
    db.movies = db.movies.filter((m: any) => !ids.includes(m.id));
    writeDB(db);
  }
  res.json({ success: true, count: db.movies.length });
});

router.post("/media/clear-all", (req, res) => {
  const { type } = req.body; // 'movies' | 'videos' | 'all'
  const db = readDB();
  if (type === 'movies' || type === 'all' || !type) {
    db.movies = [];
  }
  if (type === 'videos' || type === 'all' || !type) {
    db.videos = [];
  }
  writeDB(db);
  res.json({ success: true, message: "Catalog cleared successfully", moviesCount: db.movies.length, videosCount: db.videos.length });
});

// Full Catalog Client-Server Persistence Sync
router.post("/media/sync-all", (req, res) => {
  const { movies, videos } = req.body;
  const db = readDB();
  if (Array.isArray(movies)) {
    db.movies = sortServerMediaNewestFirst(movies);
  }
  if (Array.isArray(videos)) {
    db.videos = sortServerMediaNewestFirst(videos);
  }
  writeDB(db);
  res.json({ success: true, moviesCount: db.movies.length, videosCount: db.videos.length });
});

router.post("/movies/toggle", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const movie = db.movies.find((m: any) => m.id === id);
  if (movie) {
    movie.isActive = !movie.isActive;
    writeDB(db);
    return res.json({ success: true, isActive: movie.isActive });
  }
  res.status(404).json({ error: "Movie not found" });
});

router.post("/movies/view", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const movie = db.movies.find((m: any) => m.id === id);
  if (movie) {
    movie.views += 1;
    
    // Update watching stats for task statistics component
    const userId = req.body.userId;
    if (userId) {
      const user = db.users.find((u: any) => u.id === userId);
      if (user) {
        user.taskStats.moviesWatched = (user.taskStats.moviesWatched || 0) + 1;
      }
    }
    
    writeDB(db);
    return res.json({ success: true, views: movie.views });
  }
  res.status(404).json({ error: "Movie not found" });
});

// 3. Videos Module
router.get("/videos", (req, res) => {
  const db = readDB();
  const activeOnly = req.query.all !== "true";
  const list = activeOnly ? db.videos.filter((v: any) => v.isActive) : db.videos;
  res.json(sortServerMediaNewestFirst(list));
});

router.post("/videos", (req, res) => {
  const db = readDB();
  const video = req.body;
  
  if (!video.createdAt) {
    video.createdAt = new Date().toISOString();
  }

  if (!video.id) {
    video.id = "vd-" + Date.now();
    video.views = 0;
    db.videos.unshift(video);
  } else {
    const idx = db.videos.findIndex((v: any) => v.id === video.id);
    if (idx !== -1) {
      db.videos[idx] = { ...db.videos[idx], ...video };
    } else {
      db.videos.unshift(video);
    }
  }

  db.videos = sortServerMediaNewestFirst(db.videos);
  writeDB(db);
  res.json({ success: true, video });
});

router.post("/videos/delete", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  db.videos = db.videos.filter((v: any) => v.id !== id);
  writeDB(db);
  res.json({ success: true, message: "Video deleted successfully", count: db.videos.length });
});

router.post("/videos/toggle", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const video = db.videos.find((v: any) => v.id === id);
  if (video) {
    video.isActive = !video.isActive;
    writeDB(db);
    return res.json({ success: true, isActive: video.isActive });
  }
  res.status(404).json({ error: "Video not found" });
});

router.post("/videos/view", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const video = db.videos.find((v: any) => v.id === id);
  if (video) {
    video.views += 1;
    
    // Update watching stats for task statistics component
    const userId = req.body.userId;
    if (userId) {
      const user = db.users.find((u: any) => u.id === userId);
      if (user) {
        user.taskStats.videosWatched = (user.taskStats.videosWatched || 0) + 1;
      }
    }
    
    writeDB(db);
    return res.json({ success: true, views: video.views });
  }
  res.status(404).json({ error: "Video not found" });
});

// Dynamic Media Vault Search
router.get("/media/search", (req, res) => {
  const db = readDB();
  const query = (req.query.q as string || "").toLowerCase().trim();
  
  const allMovies = db.movies.filter((m: any) => m.isActive);
  const allVideos = db.videos.filter((v: any) => v.isActive);

  if (!query) {
    return res.json({ movies: allMovies, videos: allVideos });
  }

  const filteredMovies = allMovies.filter((m: any) => 
    m.title.toLowerCase().includes(query) ||
    (m.genre && m.genre.toLowerCase().includes(query)) ||
    (m.description && m.description.toLowerCase().includes(query))
  );

  const filteredVideos = allVideos.filter((v: any) =>
    v.title.toLowerCase().includes(query) ||
    (v.description && v.description.toLowerCase().includes(query))
  );

  res.json({ movies: filteredMovies, videos: filteredVideos });
});

// Create Task Session & Task Flow Redirection
router.post("/sessions/create", (req, res) => {
  const db = readDB();
  const { userId, mediaId, mediaType } = req.body;

  const sessionId = "sess-" + Date.now() + "-" + crypto.randomBytes(4).toString("hex");
  const sessionToken = "tok-" + crypto.randomBytes(16).toString("hex");

  const batterySites = db.settings.batterySites || [
    "https://battery1.myteleflix.com",
    "https://battery2.myteleflix.com",
    "https://battery3.myteleflix.com"
  ];
  
  const targetBatterySite = batterySites[0] || "https://battery1.myteleflix.com";
  
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 15 * 60 * 1000).toISOString(); // +15 mins

  const newSession = {
    sessionId,
    sessionToken,
    userId: userId || "guest",
    mediaId,
    mediaType: mediaType || "movie",
    currentStep: 1,
    totalSteps: db.settings.activeMagazines || batterySites.length,
    status: "INITIATED",
    createdAt: now.toISOString(),
    expiresAt,
    usedAt: null
  };

  db.taskSessions.push(newSession);
  writeDB(db);

  // Qualify referral on download task session creation
  if (userId && userId !== "guest") {
    qualifyReferral(userId);
  }

  // Return session details along with redirect URL
  const redirectUrl = `${targetBatterySite}?session_id=${sessionId}&session_token=${sessionToken}`;
  res.json({
    success: true,
    sessionId,
    sessionToken,
    expiresAt,
    redirectUrl,
    guideVideoUrl: db.settings.guideVideoUrl,
    guideVideoLogoUrl: db.settings.guideVideoLogoUrl
  });
});

// Single-Use Anti-Cheat Session Verification & Completion
router.post("/sessions/complete", (req, res) => {
  try {
    const { sessionId, sessionToken, userId } = req.body;
    const db = readDB();

    if (!sessionId && !sessionToken) {
      return res.status(400).json({ error: "Missing sessionId or sessionToken." });
    }

    const session = db.taskSessions.find((s: any) => 
      (sessionId && s.sessionId === sessionId) || 
      (sessionToken && s.sessionToken === sessionToken)
    );

    if (!session) {
      return res.status(404).json({ error: "Invalid or non-existent task session." });
    }

    // 1. Single-Use Check (Prevent multi-use point/link exploitation)
    if (session.status === "COMPLETED" || session.usedAt) {
      return res.status(400).json({ 
        error: "Task session already completed! Single-use session limit reached.",
        alreadyUsed: true,
        usedAt: session.usedAt
      });
    }

    // 2. Time Expiration Check (+15 mins)
    if (new Date() > new Date(session.expiresAt)) {
      session.status = "EXPIRED";
      writeDB(db);
      return res.status(400).json({ 
        error: "Task session expired (15-minute time limit exceeded).",
        expired: true
      });
    }

    // 3. Mark as COMPLETED & consume token
    session.status = "COMPLETED";
    session.usedAt = new Date().toISOString();

    const rewardPoints = 50;
    const effectiveUserId = userId || session.userId;
    const effectiveUser = db.users.find((u: any) => u.id === effectiveUserId);

    if (effectiveUser && effectiveUserId !== "guest") {
      effectiveUser.wallet.points = (effectiveUser.wallet.points || 0) + rewardPoints;
      effectiveUser.taskStats.totalPointsEarned = (effectiveUser.taskStats.totalPointsEarned || 0) + rewardPoints;
      
      db.transactions.push({
        id: "tx-task-" + Date.now(),
        userId: effectiveUser.id,
        amount: rewardPoints,
        type: "reward_task",
        status: "completed",
        description: `Download Task Verification Completed (+${rewardPoints})`,
        timestamp: new Date().toISOString()
      });

      writeDB(db);
      recordDailyUserActivity(effectiveUserId);
    } else {
      writeDB(db);
    }

    res.json({
      success: true,
      status: "COMPLETED",
      message: "Task session successfully verified and completed!",
      session
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/sessions/verify", (req, res) => {
  // Alias for /sessions/complete
  const db = readDB();
  const { sessionId, sessionToken } = req.body;
  const session = db.taskSessions.find((s: any) => 
    (sessionId && s.sessionId === sessionId) || 
    (sessionToken && s.sessionToken === sessionToken)
  );

  if (!session) {
    return res.status(404).json({ error: "Task session not found." });
  }

  const isExpired = new Date() > new Date(session.expiresAt);
  const isUsed = session.status === "COMPLETED" || !!session.usedAt;

  res.json({
    valid: !isExpired && !isUsed,
    status: isExpired ? "EXPIRED" : session.status,
    usedAt: session.usedAt,
    expiresAt: session.expiresAt
  });
});

// ==========================================
// TELEGRAM SHORTENER & ANTI-CHEAT TASK ENGINE
// ==========================================

// Task Session Generation Endpoint (Triggered after ad completion or media get link)
router.post("/tasks/start", (req, res) => {
  try {
    const { userId, taskId, requestedUrl, language } = req.body;
    const db = readDB();

    const effectiveUserId = userId || "tg-101";
    let user = db.users.find((u: any) => u.id === effectiveUserId || u.telegramId === effectiveUserId);
    if (!user) {
      user = db.users.find((u: any) => u.guest_device_id === effectiveUserId || u.device_fingerprint === effectiveUserId) || db.users[0];
    }
    const finalUserId = user ? user.id : (effectiveUserId || "guest");

    const targetTaskId = taskId || "ms-1";
    const mission = db.missions?.find((m: any) => m.id === targetTaskId);
    const movie = db.movies?.find((m: any) => m.id === targetTaskId);
    const video = db.videos?.find((v: any) => v.id === targetTaskId);

    // Generate unique temporary session token
    const session_token = "stok-" + Date.now() + "-" + crypto.randomBytes(12).toString("hex");
    const nowISO = new Date().toISOString();

    // Resolve target URL cleanly
    let rawTargetUrl = requestedUrl || mission?.url || movie?.banglaLink || movie?.videoUrl || video?.videoUrl || "https://t.me/myteleflix_official";
    if (rawTargetUrl && !rawTargetUrl.startsWith("http://") && !rawTargetUrl.startsWith("https://")) {
      rawTargetUrl = "https://" + rawTargetUrl;
    }

    let shortenerDomain = db.settings?.domain || "https://droplink.co";
    if (shortenerDomain && !shortenerDomain.startsWith("http://") && !shortenerDomain.startsWith("https://")) {
      shortenerDomain = "https://" + shortenerDomain;
    }

    const isDirectMedia = Boolean(movie || video || requestedUrl);
    const redirectUrl = isDirectMedia
      ? rawTargetUrl
      : `${shortenerDomain}/st?token=${session_token}&task_id=${targetTaskId}&url=${encodeURIComponent(rawTargetUrl)}`;

    const newSession = {
      user_id: finalUserId,
      task_id: targetTaskId,
      token: session_token,
      status: 'PENDING',
      created_at: nowISO,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString()
    };

    if (!db.taskSessions) {
      db.taskSessions = [];
    }
    db.taskSessions.push(newSession);
    writeDB(db);

    return res.json({
      success: true,
      session_token,
      redirectUrl,
      targetUrl: rawTargetUrl,
      created_at: nowISO,
      requiredSeconds: 25,
      message: isDirectMedia ? "Download link verified and generated!" : "Task session generated! Complete the 25-second verification."
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Anti-Cheat Timer & Verification Endpoint
router.post("/tasks/verify", async (req, res) => {
  try {
    const { session_token, token, userId } = req.body;
    const effectiveToken = session_token || token;

    if (!effectiveToken) {
      return res.status(400).json({ error: "Missing required session_token parameter." });
    }

    const db = readDB();
    if (!db.taskSessions) {
      db.taskSessions = [];
    }

    const session = db.taskSessions.find((s: any) => s.token === effectiveToken || s.sessionToken === effectiveToken);

    if (!session) {
      return res.status(404).json({ error: "Invalid or non-existent task session token." });
    }

    // 1. Anti-Replay Attack Check (Prevent multi-claim attacks)
    if (session.status !== 'PENDING' && session.status !== 'INITIATED') {
      return res.status(400).json({ 
        error: "Replay Attack Blocked: This task session token has already been claimed or processed.",
        alreadyProcessed: true,
        status: session.status
      });
    }

    // 2. Anti-Bypass Rule: Verify at least 25 seconds elapsed since created_at
    const createdTime = new Date(session.created_at || session.createdAt).getTime();
    const elapsedMs = Date.now() - createdTime;
    const elapsedSeconds = elapsedMs / 1000;

    if (elapsedSeconds < 25) {
      const remainingSeconds = Math.ceil(25 - elapsedSeconds);
      return res.status(400).json({
        error: `Anti-Cheat Violation: Minimum 25 seconds required on destination page. Elapsed: ${Math.floor(elapsedSeconds)}s / 25s required. Automated bypass attempt rejected.`,
        antiCheatTriggered: true,
        elapsedSeconds: Math.floor(elapsedSeconds),
        requiredSeconds: 25,
        remainingSeconds
      });
    }

    // 3. Mark status as COMPLETED
    session.status = 'COMPLETED';
    session.completed_at = new Date().toISOString();

    const effectiveUserId = userId || session.user_id || session.userId;
    const user = db.users.find((u: any) => u.id === effectiveUserId);
    const mission = db.missions.find((m: any) => m.id === session.task_id);

    const rewardPoints = mission?.rewardPoints || mission?.pointsReward || 150;

    let newBalance = rewardPoints;

    if (user) {
      if (!user.wallet) {
        user.wallet = { points: 0, walletAddress: "", status: "active", updatedAt: new Date().toISOString() };
      }
      user.wallet.points = (user.wallet.points || 0) + rewardPoints;
      user.points = user.wallet.points;
      newBalance = user.wallet.points;

      if (!user.taskStats) {
        user.taskStats = { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 };
      }
      user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + 1;
      user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + rewardPoints;

      // Atomic Ledger Entry in transactions/point_ledger
      if (!db.transactions) db.transactions = [];
      db.transactions.push({
        id: "tx-ledger-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex"),
        userId: user.id,
        amount: rewardPoints,
        type: "task_reward",
        status: "completed",
        description: `Anti-Cheat Shortener Verification Completed (+${rewardPoints})`,
        sessionToken: effectiveToken,
        timestamp: new Date().toISOString()
      });

      // Write row into missionLogs
      if (!db.missionLogs) db.missionLogs = [];
      db.missionLogs.push({
        id: "ml-" + Date.now(),
        userId: user.id,
        missionId: session.task_id || "ms-1",
        completedAt: new Date().toISOString(),
        pointsEarned: rewardPoints,
        sessionToken: effectiveToken
      });
    }

    // Server-authoritative UAE activity validation and record
    let uaeResult: any = null;
    if (user) {
      try {
        uaeResult = await recordAndValidateActivity({
          userId: user.id,
          activityType: 'TASK',
          sourceReference: session.task_id || "shortener_task",
          idempotencyKey: `task_verify_${effectiveToken}`,
          metadata: {
            rewardPoints,
            sessionToken: effectiveToken
          }
        });
      } catch (uaeErr) {
        console.warn("[UAE] Shortener task activity record notice:", uaeErr);
      }
    }

    writeDB(db);

    return res.json({
      success: true,
      status: "COMPLETED",
      pointsEarned: rewardPoints,
      newPointsTotal: newBalance,
      elapsedSeconds: Math.floor(elapsedSeconds),
      activityStats: uaeResult?.stats || (user ? getUserActivityStats(user.id).today : null),
      activeDayNewlyAwarded: uaeResult?.activeDayNewlyAwarded || false,
      activityMessage: uaeResult?.message || null,
      message: "Anti-cheat verification passed! Atomic ledger balance updated successfully."
    });

  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 4. Mission Module
router.get("/missions", (req, res) => {
  try {
    const all = req.query.all === "true";
    const missions = getActiveMissions(all);
    res.json(missions);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/missions", (req, res) => {
  const db = readDB();
  const mission = req.body;
  if (!mission.id) {
    mission.id = "ms-" + Date.now();
    mission.order = db.missions.length + 1;
    db.missions.push(mission);
  } else {
    const idx = db.missions.findIndex((m: any) => m.id === mission.id);
    if (idx !== -1) {
      db.missions[idx] = { ...db.missions[idx], ...mission };
    }
  }
  writeDB(db);
  res.json({ success: true, mission });
});

router.post("/missions/reorder", (req, res) => {
  const { orders } = req.body;
  const db = readDB();
  orders.forEach((o: any) => {
    const m = db.missions.find((x: any) => x.id === o.id);
    if (m) m.order = o.order;
  });
  writeDB(db);
  res.json({ success: true });
});

router.post("/missions/toggle", (req, res) => {
  const { id } = req.body;
  const db = readDB();
  const m = db.missions.find((x: any) => x.id === id);
  if (m) {
    m.isActive = !m.isActive;
    writeDB(db);
    return res.json({ success: true, isActive: m.isActive });
  }
  res.status(404).json({ error: "Mission not found" });
});

router.post("/missions/delete", (req, res) => {
  try {
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({ error: "Mission ID is required." });
    }
    const db = readDB();
    const initialLen = (db.missions || []).length;
    db.missions = (db.missions || []).filter((m: any) => m.id !== id);
    writeDB(db);
    const deleted = (db.missions.length !== initialLen);
    return res.json({ success: true, message: "Sponsored task deleted successfully", deleted, count: db.missions.length });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

router.get("/missions/logs", (req, res) => {
  try {
    const userId = req.query.userId as string;
    const logs = getUserMissionLogs(userId);
    res.json(logs);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/missions/verify", requireAuthBearer, async (req, res) => {
  const { userId, missionId } = req.body;
  if (!userId || !missionId) {
    return res.status(400).json({ error: "userId and missionId are required" });
  }

  // Anti-fraud concurrency check
  if (!acquireClaimLock(userId, missionId)) {
    return res.status(409).json({
      error: "Concurrent mission claim detected. Operation locked.",
      code: "CONCURRENT_CLAIM_LOCKED"
    });
  }

  try {
    const result = verifyAndCompleteMission(userId, missionId);
    recordDailyUserActivity(userId);

    // Record UAE activity
    let uaeResult: any = null;
    try {
      const todayDate = new Date().toISOString().split("T")[0];
      uaeResult = await recordAndValidateActivity({
        userId,
        activityType: 'TASK',
        sourceReference: String(missionId),
        idempotencyKey: `mission_${userId}_${missionId}_${todayDate}`,
        metadata: {
          missionId,
          pointsEarned: (result as any)?.pointsEarned
        }
      });
    } catch (uaeErr) {
      console.warn("[UAE] Mission activity record notice:", uaeErr);
    }

    res.json({
      ...result,
      activityStats: uaeResult?.stats || getUserActivityStats(userId).today,
      activeDayNewlyAwarded: uaeResult?.activeDayNewlyAwarded || false,
      activityMessage: uaeResult?.message || null
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  } finally {
    releaseClaimLock(userId, missionId);
  }
});

// 4b. REAL AD MONETIZATION & SECURE REWARD CLAIM (/api/rewards/claim)
router.post("/rewards/claim", requireAuthBearer, async (req, res) => {
  const { 
    userId, 
    missionId, 
    adNetwork, 
    impressionId, 
    adTitle, 
    rewardPoints, 
    device_fingerprint, 
    hardwareMetrics 
  } = req.body;

  const targetId = missionId || impressionId || `ad_${adNetwork || 'network'}_${Date.now()}`;
  
  if (!userId) {
    return res.status(400).json({ error: "userId is required for reward claims" });
  }

  // 1. Idempotency Check: prevent duplicate network retries from awarding twice
  const idempotencyKey = (
    req.headers["idempotency-key"] || 
    req.headers["Idempotency-Key"] || 
    `claim_${userId}_${targetId}`
  ) as string;

  const cachedResponse = getIdempotentResponse(idempotencyKey);
  if (cachedResponse) {
    return res.json({ ...cachedResponse, isCached: true });
  }

  // 2. Anti-Fraud Concurrency Lock: reject parallel script attempts
  if (!acquireClaimLock(userId, targetId)) {
    return res.status(409).json({
      error: "Concurrent reward claim detected for this mission. Transaction locked.",
      code: "CONCURRENT_CLAIM_LOCKED"
    });
  }

  try {
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: "User account not found." });
    }

    if (user.isBanned || user.status === "banned" || user.status === "suspended") {
      return res.status(403).json({ error: "Account is restricted. Cannot claim rewards." });
    }

    // Determine reward points from request or system settings
    const pointsToAward = Number(rewardPoints) || Number(db.settings.adRewardPoints) || 150;

    // 3. Impression idempotency check: verify this specific impression ID was not already used
    if (impressionId) {
      if (!db.ad_impressions) db.ad_impressions = [];
      const duplicateImpression = db.ad_impressions.find(
        (imp: any) => imp.impressionId === impressionId && imp.userId === userId
      );
      if (duplicateImpression) {
        return res.status(400).json({ error: "This ad impression has already been credited." });
      }

      // Record Ad Impression Record
      const impressionRecord = {
        id: `imp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        impressionId,
        userId,
        adNetwork: adNetwork || "monetag",
        rewardPoints: pointsToAward,
        device_fingerprint: device_fingerprint || user.device_fingerprint || "",
        hardwareMetrics: hardwareMetrics || null,
        timestamp: new Date().toISOString()
      };
      db.ad_impressions.push(impressionRecord);

      // Save to Firestore ad_impressions collection safely
      try {
        const writable = await isFirestoreWritable();
        if (writable) {
          const docRef = doc(firestore, "ad_impressions", impressionRecord.id);
          await setDoc(docRef, impressionRecord, { merge: true });
        }
      } catch (e) {
        console.warn("Notice syncing ad impression to Firestore:", e);
      }
    }

    // 4. Update user points & statistics
    user.points = (user.points || 0) + pointsToAward;
    if (!user.wallet) {
      user.wallet = { 
        points: user.points, 
        walletAddress: "", 
        status: "active", 
        updatedAt: new Date().toISOString() 
      };
    } else {
      user.wallet.points = (user.wallet.points || 0) + pointsToAward;
      user.wallet.updatedAt = new Date().toISOString();
    }

    if (!user.taskStats) {
      user.taskStats = { 
        missionsCompleted: 1, 
        totalPointsEarned: pointsToAward, 
        moviesWatched: 0, 
        videosWatched: 0 
      };
    } else {
      user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + 1;
      user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + pointsToAward;
    }
    user.last_active_at = new Date().toISOString();

    // 5. Append transaction ledger entry
    const txId = `tx-rew-${Date.now()}`;
    db.transactions.push({
      id: txId,
      userId,
      amount: pointsToAward,
      type: "reward",
      status: "completed",
      description: adTitle || `Real Ad Network Reward (+${pointsToAward})`,
      timestamp: new Date().toISOString()
    });

    // 6. Mission log entry
    db.missionLogs.push({
      id: `log-${Date.now()}`,
      userId,
      missionId: targetId,
      rewardPoints: pointsToAward,
      timestamp: new Date().toISOString()
    });

    // Inactivity heartbeat
    recordDailyUserActivity(userId);

    // Server-authoritative UAE activity validation and record
    let uaeResult: any = null;
    try {
      uaeResult = await recordAndValidateActivity({
        userId,
        activityType: 'TASK',
        sourceReference: String(targetId),
        idempotencyKey: idempotencyKey,
        metadata: {
          adTitle,
          rewardPoints: pointsToAward,
          adNetwork: adNetwork || 'network',
          impressionId
        }
      });
    } catch (uaeErr) {
      console.warn("[UAE] Claim activity record notice:", uaeErr);
    }

    writeDB(db);

    const responsePayload = {
      success: true,
      pointsEarned: pointsToAward,
      newPointsTotal: user.wallet.points,
      transactionId: txId,
      activityStats: uaeResult?.stats || getUserActivityStats(userId).today,
      activeDayNewlyAwarded: uaeResult?.activeDayNewlyAwarded || false,
      activityMessage: uaeResult?.message || null,
      message: `Verified! +${pointsToAward} credited to your wallet!`
    };

    // Cache idempotent response
    setIdempotentResponse(idempotencyKey, responsePayload);

    return res.json(responsePayload);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || "Failed to process reward claim" });
  } finally {
    releaseClaimLock(userId, targetId);
  }
});

// 5. Secure Wallet & Withdrawal Module
router.get("/wallet/transactions", (req, res) => {
  try {
    const userId = req.query.userId as string;
    const txs = getTransactionHistory(userId);
    res.json(txs);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Handler for both /api/withdrawals/request and /api/wallet/withdraw
const handleWithdrawalRequest = async (req: express.Request, res: express.Response) => {
  try {
    const { 
      userId, 
      amount, 
      walletAddress, 
      paymentMethod, 
      email, 
      accountNumber, 
      device_fingerprint, 
      hardwareMetrics 
    } = req.body;

    if (!userId || !amount) {
      return res.status(400).json({ error: "userId and amount are required." });
    }

    const numAmount = Number(amount);
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: "Authenticated account not found." });
    }

    // Anti-Fraud Risk Scoring & Analysis
    const riskAnalysis = evaluateWithdrawalRisk({
      user,
      amount: numAmount,
      device_fingerprint: device_fingerprint || user.device_fingerprint,
      ip_address: req.ip,
      hardwareMetrics
    });

    // Execute withdrawal request in local ledger
    const result = requestWithdrawal(
      userId, 
      numAmount, 
      walletAddress, 
      paymentMethod, 
      email, 
      accountNumber,
      {
        riskScore: riskAnalysis.riskScore,
        riskReasons: riskAnalysis.riskReasons,
        isHighRisk: riskAnalysis.isHighRisk,
        device_fingerprint: device_fingerprint || user.device_fingerprint,
        hardwareMetrics,
        ip_address: req.ip || "",
        userAgent: (req.headers["user-agent"] as string) || ""
      }
    );

    // ANTI-FRAUD SAFETY LOCK: If High Risk, log directly to Firestore collection `high_risk_withdrawals`
    if (riskAnalysis.isHighRisk || riskAnalysis.riskScore >= 40) {
      await logHighRiskWithdrawalToFirestore({
        withdrawalId: result.withdrawal.id,
        userId,
        username: user.username || user.fullName || "Member",
        email: user.email || email,
        amount: numAmount,
        riskScore: riskAnalysis.riskScore,
        riskReasons: riskAnalysis.riskReasons,
        device_fingerprint: device_fingerprint || user.device_fingerprint,
        ip_address: req.ip || "",
        userAgent: (req.headers["user-agent"] as string) || "",
        hardwareMetrics
      });
    }

    touchAuthenticatedAccess(user.id, db);

    return res.json({
      ...result,
      riskAnalysis: {
        isHighRisk: riskAnalysis.isHighRisk,
        riskScore: riskAnalysis.riskScore,
      }
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
};

router.post("/withdrawals/request", withdrawalRateLimiter, requireAuthBearer, handleWithdrawalRequest);
router.post("/wallet/withdraw", withdrawalRateLimiter, requireAuthBearer, handleWithdrawalRequest);

// VRMS-3 ULTRA (Phase 4): Server-Authoritative Referral Engine Endpoints
router.post("/referrals/register", (req, res) => {
  try {
    const {
      referralCode,
      referrerId,
      userId,
      referredUserId,
      referredUsername,
      referredFullName,
    } = req.body;

    const refIdentifier = referralCode || referrerId;
    const targetUserId = referredUserId || userId;

    if (!refIdentifier || !targetUserId) {
      return res.status(400).json({
        success: false,
        error: "referralCode/referrerId এবং userId/referredUserId আবশ্যক।",
      });
    }

    const result = registerDirectReferral({
      referrerIdentifier: String(refIdentifier),
      referredUserId: String(targetUserId),
      referredUsername,
      referredFullName,
    });

    if (!result.success) {
      return res.status(400).json({
        success: false,
        error: result.message,
      });
    }

    return res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get("/referrals/stats", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"]) as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId query parameter is required" });
    }
    const overview = getReferralOverviewForUser(userId);
    res.json(overview);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Referral Module (Legacy & Enhanced)
router.get("/referrals", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"]) as string;
    if (!userId) {
      return res.status(400).json({ error: "userId query parameter is required" });
    }
    const legacyData = getReferralsForUser(userId);
    const vrmsOverview = getReferralOverviewForUser(userId);

    res.json({
      ...legacyData,
      referralCode: vrmsOverview.referralCode,
      referralLink: vrmsOverview.referralLink,
      registeredCount: vrmsOverview.registeredCount,
      qualifiedCount: vrmsOverview.qualifiedCount,
      vrmsReferrals: vrmsOverview.referrals,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get("/referrals/list", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"]) as string;
    if (!userId) {
      return res.status(400).json({ error: "userId query parameter is required" });
    }
    const overview = getReferralOverviewForUser(userId);
    res.json(overview);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post("/referrals/claim", requireAuthBearer, (req, res) => {
  const { userId, referralId } = req.body;
  if (!userId || !referralId) {
    return res.status(400).json({ error: "userId and referralId are required" });
  }

  // Concurrency lock on referral reward claim
  if (!acquireClaimLock(userId, referralId)) {
    return res.status(409).json({
      error: "Concurrent referral claim detected. Operation locked.",
      code: "CONCURRENT_CLAIM_LOCKED"
    });
  }

  try {
    const result = claimReferralReward(userId, referralId);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  } finally {
    releaseClaimLock(userId, referralId);
  }
});

// =========================================================================
// VRMS-3 ULTRA (Phase 6): Referral Milestone Reward Engine (RME) Endpoints
// =========================================================================

// GET /api/milestones/status
// Server-authoritative milestone progression status for user
router.get("/milestones/status", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"] || (req as any).auth?.userId || "tg-101") as string;
    const result = evaluateUserMilestones(userId);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/milestones/claim
// Idempotent, budget-guarded milestone claim with financial ledgering
router.post("/milestones/claim", (req, res) => {
  const userId = (req.body.userId || req.body.user_id || req.headers["x-user-id"] || (req as any).auth?.userId || "tg-101") as string;
  const { milestone_id, milestoneId, campaign_id, campaignId } = req.body;
  const targetMilestoneId = milestone_id || milestoneId;
  const targetCampaignId = campaign_id || campaignId;

  if (!targetMilestoneId) {
    return res.status(400).json({
      success: false,
      code: "INVALID_REQUEST",
      message: "milestone_id is required"
    });
  }

  // Concurrency lock on milestone claim per user and milestone
  const lockTarget = `milestone_${targetMilestoneId}`;
  if (!acquireClaimLock(userId, lockTarget)) {
    return res.status(409).json({
      success: false,
      code: "CONCURRENT_CLAIM_LOCKED",
      message: "Concurrent milestone claim in progress. Please wait a moment."
    });
  }

  try {
    const result = claimMilestoneReward(userId, targetMilestoneId, targetCampaignId);
    if (!result.success) {
      const statusCode = result.code === "ALREADY_CLAIMED" ? 409 : 
                         result.code === "USER_RESTRICTED" ? 403 : 
                         result.code === "THRESHOLD_NOT_MET" ? 400 : 400;
      return res.status(statusCode).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, code: "SERVER_ERROR", message: err.message });
  } finally {
    releaseClaimLock(userId, lockTarget);
  }
});

// POST /api/milestones/reverse (Audit & Reversal Compliance)
router.post("/milestones/reverse", (req, res) => {
  const adminUserId = (req.headers["x-user-id"] || (req as any).auth?.userId || "tg-101") as string;
  const { reward_id, rewardId, reason } = req.body;
  const targetRewardId = reward_id || rewardId;

  if (!targetRewardId) {
    return res.status(400).json({ success: false, message: "reward_id is required" });
  }

  try {
    const result = reverseMilestoneReward(targetRewardId, reason || "Administrative compliance adjustment", adminUserId);
    if (!result.success) {
      return res.status(400).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/milestones/configs
router.get("/admin/milestones/configs", (req, res) => {
  try {
    const db = readDB();
    const configs = db.milestone_configs || [];
    const rewards = db.referral_rewards || [];
    return res.json({
      success: true,
      configs,
      total_rewards_issued: rewards.length,
      credited_rewards_count: rewards.filter(r => r.status === 'CREDITED').length,
      total_credited_points: rewards.filter(r => r.status === 'CREDITED').reduce((sum, r) => sum + r.amount, 0)
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/milestones/configs
router.post("/admin/milestones/configs", (req, res) => {
  try {
    const { configs } = req.body;
    if (!Array.isArray(configs)) {
      return res.status(400).json({ success: false, error: "configs must be an array of MilestoneConfig" });
    }
    const db = readDB();
    db.milestone_configs = configs;
    writeDB(db);
    return res.json({ success: true, message: "Milestone configurations updated successfully.", configs: db.milestone_configs });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// VRMS-3 ULTRA (Phase 7): Wallet & Payment Profile Module Endpoints
// =========================================================================

// GET /api/wallet/payment-profile
// Fetch current user's saved payment profiles
router.get("/wallet/payment-profile", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId query parameter is required." });
    }
    const profiles = getUserPaymentProfiles(userId);
    return res.json({
      success: true,
      userId,
      profiles,
      supported_methods: SUPPORTED_PAYMENT_METHODS
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/wallet/payment-profile
// Save or update payment account details
router.post("/wallet/payment-profile", (req, res) => {
  try {
    const { 
      userId, 
      payment_method, 
      account_number_or_wallet_address, 
      account_holder_name 
    } = req.body;

    const effectiveUserId = (userId || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!effectiveUserId) {
      return res.status(400).json({ success: false, error: "userId is required." });
    }

    if (!payment_method || !account_number_or_wallet_address) {
      return res.status(400).json({ 
        success: false, 
        error: "payment_method and account_number_or_wallet_address are required." 
      });
    }

    const result = upsertPaymentProfile(
      effectiveUserId,
      payment_method,
      account_number_or_wallet_address,
      account_holder_name || ""
    );

    if (!result.success) {
      return res.status(400).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/wallet/payment-profile
// Delete or remove saved payment profile vault
router.delete("/wallet/payment-profile", (req, res) => {
  try {
    const userId = (req.body?.userId || req.query?.userId || req.query?.user_id || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    const payment_method = (req.body?.payment_method || req.query?.payment_method) as string;

    if (!userId || !payment_method) {
      return res.status(400).json({ 
        success: false, 
        error: "userId and payment_method are required to delete payment profile." 
      });
    }

    const result = deletePaymentProfile(userId, payment_method);
    if (!result.success) {
      return res.status(400).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/salary/eligibility
// VRMS-3 ULTRA (Phase 8): Monthly Salary Engine Eligibility Evaluation
router.get("/salary/eligibility", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId parameter is required." });
    }
    const evalResult = computeSalaryEligibility(userId);
    return res.json(evalResult);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/salary/generate-snapshot
// VRMS-3 ULTRA (Phase 8): Immutable Cycle Snapshot Generator with strict server-side guardrails
router.post("/salary/generate-snapshot", (req, res) => {
  try {
    const { userId, payment_method } = req.body;
    const effectiveUserId = (userId || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!effectiveUserId) {
      return res.status(400).json({ success: false, error: "userId is required." });
    }
    const result = generateSalarySnapshot(effectiveUserId, payment_method);
    if (!result.success) {
      return res.status(400).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/salary/status
router.get("/salary/status", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId parameter is required." });
    }
    const evalResult = computeSalaryEligibility(userId);
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, ""));
    const requests = (db.salary_requests || []).filter((r: any) => r.user_id === user?.id);
    const snapshots = (db.salary_snapshots || []).filter((s: any) => s.user_id === user?.id);

    // Active cycle request if exists
    const activeCycle = evalResult.active_cycle || getOrCreateActiveSalaryCycle(db);
    const activeCycleRequest = user ? findSalaryRequestByUserAndCycle(user.id, activeCycle.cycle_id, db) : undefined;

    return res.json({
      success: true,
      ...evalResult,
      active_cycle_request: activeCycleRequest || null,
      recent_requests: requests,
      recent_snapshots: snapshots,
      supported_methods: SUPPORTED_PAYMENT_METHODS
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/salary/claim
router.post("/salary/claim", salaryClaimRateLimiter, (req, res) => {
  try {
    const { userId, payment_method, idempotency_key } = req.body;
    const effectiveUserId = (userId || req.headers["x-user-id"] || (req as any).auth?.userId) as string;
    if (!effectiveUserId) {
      return res.status(400).json({ success: false, error: "userId is required." });
    }

    // Process claim via server-authoritative engine (enforces claim != payment, idempotency, unique REQ ID, Telegram payload)
    const result = processSalaryClaim(effectiveUserId, payment_method, idempotency_key);
    if (!result.success) {
      return res.status(400).json(result);
    }
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/salary/request/:requestId
router.get("/salary/request/:requestId", (req, res) => {
  try {
    const { requestId } = req.params;
    if (!requestId) {
      return res.status(400).json({ success: false, error: "requestId is required." });
    }
    const db = readDB();
    const request = findSalaryRequestById(requestId, db);
    if (!request) {
      return res.status(404).json({ success: false, error: "Salary request not found." });
    }
    const snapshot = (db.salary_snapshots || []).find(s => s.snapshot_id === request.snapshot_id);
    return res.json({
      success: true,
      request,
      snapshot
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================================
// VRMS-3 ULTRA (Phase 10): Admin Salary Review & Manual Settlement Layer
// ============================================================================

// GET /api/admin/salary/requests
// Fetch request queue with pagination, status filters, payment method filters, and exact request_id search
router.get("/admin/salary/requests", (req, res) => {
  try {
    const db = readDB();
    const {
      search,
      requestId,
      status = "all",
      payment_method = "all",
      page = "1",
      limit = "20"
    } = req.query;

    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 20));
    const allRequests = Array.isArray(db.salary_requests) ? [...db.salary_requests] : [];

    // Pre-calculate status counts across entire table
    const status_counts = {
      all: allRequests.length,
      under_review: allRequests.filter(r => r.status === 'CLAIMED' || r.status === 'UNDER_REVIEW' || r.status === 'PENDING').length,
      approved: allRequests.filter(r => r.status === 'APPROVED' || r.status === 'AWAITING_MANUAL_PAYMENT').length,
      paid: allRequests.filter(r => r.status === 'PAID' || r.status === 'DISBURSED').length,
      rejected_hold: allRequests.filter(r => r.status === 'HOLD' || r.status === 'REJECTED').length
    };

    // 1. EXACT REQUEST ID INDEXING OPTIMIZATION
    const searchTarget = (requestId || search || "").toString().trim();
    let filteredList = allRequests;

    if (searchTarget) {
      const upperTarget = searchTarget.toUpperCase();
      // If it starts with REQ- or is an exact match query, check the in-memory fast index first
      const exactMatch = findSalaryRequestById(searchTarget, db) || findSalaryRequestById(upperTarget, db);
      if (exactMatch) {
        filteredList = [exactMatch];
      } else {
        // Fallback filter by partial request_id, user_id, transaction_id, or username
        const matchedUsers = (db.users || []).filter((u: any) => 
          (u.username && u.username.toLowerCase().includes(searchTarget.toLowerCase())) ||
          (u.fullName && u.fullName.toLowerCase().includes(searchTarget.toLowerCase())) ||
          (u.email && u.email.toLowerCase().includes(searchTarget.toLowerCase())) ||
          (u.id && u.id.toLowerCase().includes(searchTarget.toLowerCase()))
        );
        const matchedUserIds = new Set(matchedUsers.map(u => u.id));

        filteredList = allRequests.filter(r => 
          r.request_id.toUpperCase().includes(upperTarget) ||
          (r.user_id && r.user_id.toLowerCase().includes(searchTarget.toLowerCase())) ||
          matchedUserIds.has(r.user_id) ||
          (r.transaction_id && r.transaction_id.toUpperCase().includes(upperTarget)) ||
          (r.snapshot_id && r.snapshot_id.toLowerCase().includes(searchTarget.toLowerCase()))
        );
      }
    }

    // 2. Status Filters
    const statusFilter = (status as string).toLowerCase().trim();
    if (statusFilter && statusFilter !== 'all') {
      if (statusFilter === 'under_review') {
        filteredList = filteredList.filter(r => r.status === 'CLAIMED' || r.status === 'UNDER_REVIEW' || r.status === 'PENDING');
      } else if (statusFilter === 'approved') {
        filteredList = filteredList.filter(r => r.status === 'APPROVED' || r.status === 'AWAITING_MANUAL_PAYMENT');
      } else if (statusFilter === 'paid') {
        filteredList = filteredList.filter(r => r.status === 'PAID' || r.status === 'DISBURSED');
      } else if (statusFilter === 'rejected_hold') {
        filteredList = filteredList.filter(r => r.status === 'HOLD' || r.status === 'REJECTED');
      } else {
        filteredList = filteredList.filter(r => r.status.toLowerCase() === statusFilter);
      }
    }

    // 3. Payment Method Filter
    const payFilter = (payment_method as string).trim();
    if (payFilter && payFilter !== 'all') {
      filteredList = filteredList.filter(r => {
        const method = r.payment_profile_snapshot?.payment_method;
        if (!method) {
          const snap = (db.salary_snapshots || []).find(s => s.snapshot_id === r.snapshot_id);
          return snap && snap.payment_method.toLowerCase() === payFilter.toLowerCase();
        }
        return method.toLowerCase() === payFilter.toLowerCase();
      });
    }

    // Sort newest claimed requests first
    filteredList.sort((a, b) => new Date(b.claimed_at || 0).getTime() - new Date(a.claimed_at || 0).getTime());

    // 4. Hydrate requests with User profile & Snapshot details (IMMUTABLE PROTECTION: Snapshot data is cloned, never mutated)
    const snapshotsMap = new Map((db.salary_snapshots || []).map(s => [s.snapshot_id, s]));
    const usersMap = new Map((db.users || []).map(u => [u.id, u]));

    const total = filteredList.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const pageItems = filteredList.slice(startIndex, startIndex + limitNum);

    const hydratedRequests = pageItems.map(reqItem => {
      const user = usersMap.get(reqItem.user_id);
      const snapshot = snapshotsMap.get(reqItem.snapshot_id);

      const paymentMethod = snapshot?.payment_method || reqItem.payment_profile_snapshot?.payment_method || 'bKash';
      const accountNumber = snapshot?.payment_account_snapshot || reqItem.payment_profile_snapshot?.account_number_or_wallet_address || '';
      const accountHolder = snapshot?.account_holder_snapshot || reqItem.payment_profile_snapshot?.account_holder_name || user?.fullName || 'N/A';

      return {
        ...reqItem,
        user_username: user?.username || 'Unknown',
        user_fullname: user?.fullName || '',
        user_email: user?.email || '',
        user_telegram_id: user?.telegramId || '',
        user_is_banned: !!user?.isBanned,
        user_is_suspicious: !!user?.isSuspicious,
        salary_level: snapshot?.salary_level || (reqItem.tier === 'L3' ? 3 : reqItem.tier === 'L2' ? 2 : 1),
        qualified_active_referrals: snapshot?.qualified_active_referrals || 0,
        new_verified_referrals: snapshot?.new_verified_referrals || 0,
        current_eligible_verified_referrals: snapshot?.current_eligible_verified_referrals || 0,
        payment_method: paymentMethod,
        account_number: accountNumber,
        account_holder_name: accountHolder,
        verification_status: snapshot?.verification_status || user?.status || 'VERIFIED',
        risk_status: snapshot?.risk_status || (user?.isSuspicious ? 'HIGH' : 'NOT_RESTRICTED'),
        snapshot: snapshot ? { ...snapshot } : undefined // Read-only immutable clone
      };
    });

    return res.json({
      success: true,
      total,
      page: pageNum,
      limit: limitNum,
      totalPages,
      status_counts,
      requests: hydratedRequests
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/salary/review-action
// Validate admin authorization, execute status transitions (APPROVE, HOLD, REJECT, UNDER_REVIEW),
// enforce mandatory rejection_reason, record immutable audit logs, and maintain Rule 1 (APPROVE != PAYMENT).
router.post("/admin/salary/review-action", (req, res) => {
  try {
    const { requestId, action, reason, note, rejection_reason, adminId } = req.body;

    if (!requestId) {
      return res.status(400).json({ success: false, error: "requestId is required." });
    }
    if (!action) {
      return res.status(400).json({ success: false, error: "action parameter (APPROVE, HOLD, REJECT, UNDER_REVIEW) is required." });
    }

    const normalizedAction = action.toString().toUpperCase().trim();
    const validActions = ['APPROVE', 'HOLD', 'REJECT', 'UNDER_REVIEW', 'AWAIT_PAYMENT'];
    if (!validActions.includes(normalizedAction)) {
      return res.status(400).json({ 
        success: false, 
        error: `Invalid action '${action}'. Allowed: ${validActions.join(', ')}` 
      });
    }

    const db = readDB();
    const request = findSalaryRequestById(requestId, db);
    if (!request) {
      return res.status(404).json({ success: false, error: `Salary request '${requestId}' not found.` });
    }

    const adminUser = (adminId || req.headers["x-admin-id"] || SUPER_ADMIN_USERNAME || "super_admin").toString().trim();
    const oldStatus = request.status;
    let newStatus: any = oldStatus;
    const now = new Date().toISOString();

    // Mandatory rejection reason validation
    const effectiveRejectionReason = (reason || rejection_reason || "").toString().trim();
    if (normalizedAction === 'REJECT') {
      if (!effectiveRejectionReason) {
        return res.status(400).json({
          success: false,
          error: "A valid rejection reason is mandatory when rejecting a salary request."
        });
      }
      newStatus = 'REJECTED';
      request.status = newStatus;
      request.reviewed_at = now;
      request.rejection_reason = effectiveRejectionReason;
      if (note) request.admin_note = note.toString().trim();
    } else if (normalizedAction === 'APPROVE') {
      // RULE 1: APPROVE DOES NOT TRANSFER MONEY. It queues the request for manual disbursement.
      newStatus = 'APPROVED';
      request.status = newStatus;
      request.reviewed_at = now;
      request.approved_at = now;
      if (note) request.admin_note = note.toString().trim();
    } else if (normalizedAction === 'AWAIT_PAYMENT') {
      newStatus = 'AWAITING_MANUAL_PAYMENT';
      request.status = newStatus;
      request.reviewed_at = now;
      if (note) request.admin_note = note.toString().trim();
    } else if (normalizedAction === 'HOLD') {
      newStatus = 'HOLD';
      request.status = newStatus;
      request.reviewed_at = now;
      if (note || reason) request.admin_note = (note || reason).toString().trim();
    } else if (normalizedAction === 'UNDER_REVIEW') {
      newStatus = 'UNDER_REVIEW';
      request.status = newStatus;
      request.reviewed_at = now;
      if (note) request.admin_note = note.toString().trim();
    }

    // RULE 4: AUDIT COMPLIANCE - Record immutable admin audit log
    const auditRecord = recordAdminAuditLog({
      admin_id: adminUser,
      action: `SALARY_${normalizedAction}`,
      target_type: 'salary_request',
      target_id: request.request_id,
      old_value: { status: oldStatus },
      new_value: { 
        status: newStatus, 
        admin_note: request.admin_note, 
        rejection_reason: request.rejection_reason 
      },
      reason: effectiveRejectionReason || note || `Admin transitioned salary request to ${newStatus}`
    }, db);

    // VRMS-3 ULTRA (Phase 12): Phase 9-10 Hook on Salary Request Status Transition
    if (request.user_id) {
      emitSalaryStatusAlert(
        request.user_id,
        request.request_id,
        request.amount,
        newStatus,
        {
          adminNote: request.admin_note,
          rejectionReason: request.rejection_reason
        },
        db
      );
    }

    // Synchronize fast indexes & persist state
    syncSalaryRequestIndexes(db);
    writeDB(db);

    const message = normalizedAction === 'APPROVE'
      ? `Request ${request.request_id} marked as APPROVED. (Reminder: APPROVE does not transfer money; payout must be executed manually).`
      : `Request ${request.request_id} successfully transitioned to ${newStatus}.`;

    return res.json({
      success: true,
      message,
      request,
      old_status: oldStatus,
      new_status: newStatus,
      audit_log: auditRecord
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/salary/mark-paid
// Executed ONLY after physical manual cash transfer. Transitions status to 'PAID',
// records transaction settlement reference, writes financial ledger, sends user notification,
// and updates the audit log.
router.post("/admin/salary/mark-paid", (req, res) => {
  try {
    const { requestId, transactionReference, notes, adminId } = req.body;

    if (!requestId) {
      return res.status(400).json({ success: false, error: "requestId is required." });
    }

    const db = readDB();
    const request = findSalaryRequestById(requestId, db);
    if (!request) {
      return res.status(404).json({ success: false, error: `Salary request '${requestId}' not found.` });
    }

    if (request.status === 'PAID') {
      return res.status(400).json({ 
        success: false, 
        error: `Salary request '${requestId}' is already marked as PAID. Duplicate settlements are rejected.` 
      });
    }

    const adminUser = (adminId || req.headers["x-admin-id"] || SUPER_ADMIN_USERNAME || "super_admin").toString().trim();
    const oldStatus = request.status;
    const now = new Date().toISOString();
    const trxRef = (transactionReference || "").toString().trim() || `MANUAL-PAY-${Date.now()}`;

    // Update salary request record
    request.status = 'PAID';
    request.paid_at = now;
    request.transaction_id = trxRef;
    if (notes) request.admin_note = notes.toString().trim();

    // RULE 4: AUDIT COMPLIANCE - Record manual settlement
    const auditRecord = recordAdminAuditLog({
      admin_id: adminUser,
      action: 'SALARY_MARK_PAID',
      target_type: 'salary_request',
      target_id: request.request_id,
      old_value: { status: oldStatus },
      new_value: { 
        status: 'PAID', 
        transaction_id: trxRef,
        paid_at: now,
        admin_note: request.admin_note
      },
      reason: notes || `Physical manual cash transfer confirmed. External Trx: ${trxRef}`
    }, db);

    // Record in global transaction ledger for financial audit & user history
    if (!db.transactions) db.transactions = [];
    db.transactions.push({
      id: `tx-sal-${Date.now()}`,
      userId: request.user_id,
      amount: request.amount,
      type: "monthly_salary_disbursement",
      status: "completed",
      description: `Monthly Salary Level ${request.tier || 'L1'} Disbursed (Manual Trx Ref: ${trxRef})`,
      timestamp: now
    });

    // Notify claimant of successful payout (VRMS-3 ULTRA Phase 12)
    if (request.user_id) {
      const paymentMethod = request.payment_profile_snapshot?.payment_method || 'bKash/Nagad/USDT';
      emitSalaryStatusAlert(
        request.user_id,
        request.request_id,
        request.amount,
        'PAID',
        {
          paymentMethod,
          transactionReference: trxRef
        },
        db
      );
    }

    // Synchronize fast indexes & persist state
    syncSalaryRequestIndexes(db);
    writeDB(db);

    return res.json({
      success: true,
      message: `Salary request ${request.request_id} marked as PAID. Manual settlement confirmed.`,
      request,
      audit_log: auditRecord
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/salary/audit-logs
// Return compliance audit trail entries for salary requests
router.get("/admin/salary/audit-logs", (req, res) => {
  try {
    const { requestId, limit = "50" } = req.query;
    const limitNum = Math.min(200, Math.max(1, parseInt(limit as string, 10) || 50));
    const logs = getAdminAuditLogs({
      target_type: 'salary_request',
      target_id: requestId ? requestId.toString().trim() : undefined,
      limit: limitNum
    });
    return res.json({
      success: true,
      count: logs.length,
      logs
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});


// Helper to record daily user activity & 30-day cumulative progress
export function recordDailyUserActivity(userId: string) {
  if (!userId || userId === "guest") return;
  const db = readDB();
  const user = db.users.find((u: any) => u.id === userId);
  if (!user) return;

  if (!user.taskStats) {
    user.taskStats = {
      missionsCompleted: 0,
      totalPointsEarned: 0,
      moviesWatched: 0,
      videosWatched: 0
    };
  }

  if (!user.taskStats.activeDaysList) {
    user.taskStats.activeDaysList = [];
  }

  const today = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
  if (!user.taskStats.activeDaysList.includes(today)) {
    user.taskStats.activeDaysList.push(today);
  }

  const activeDaysCount = user.taskStats.activeDaysList.length;
  user.activeDaysCount = activeDaysCount;
  user.taskStats.activeDaysCount = activeDaysCount;

  // 30-Day Cumulative Completion Referral Trigger Logic
  if (activeDaysCount >= 30 && !user.taskStats.thirtyDayBonusClaimed) {
    user.taskStats.thirtyDayBonusClaimed = true;
    user.thirtyDayBonusClaimed = true;

    // Check if user was referred by someone
    const referrerId = user.referredBy;
    if (referrerId) {
      const referrer = db.users.find((u: any) => u.id === referrerId);
      if (referrer) {
        const bonusAmount = 1000;
        referrer.wallet.points = (referrer.wallet.points || 0) + bonusAmount;
        referrer.taskStats.totalPointsEarned = (referrer.taskStats.totalPointsEarned || 0) + bonusAmount;

        if (!db.transactions) db.transactions = [];
        db.transactions.push({
          id: "tx-30day-ref-" + Date.now(),
          userId: referrer.id,
          amount: bonusAmount,
          type: "reward_30day_referral",
          status: "completed",
          description: `30-Day Active Partner Bonus: ${user.fullName} completed 30 cumulative active earning days!`,
          timestamp: new Date().toISOString()
        });

        if (!db.notifications) db.notifications = [];
        db.notifications.push({
          id: "nt-30day-ref-" + Date.now(),
          userId: referrer.id,
          title: "🏆 30-Day Partner Milestone Reached (+1,000)!",
          message: `Your partner ${user.fullName} completed 30 cumulative active earning days! +1,000 credited!`,
          isRead: false,
          timestamp: new Date().toISOString()
        });
      }
    }
  }

  writeDB(db);
}

// Telegram Passive Membership Check Endpoint
router.post("/telegram/check-membership", (req, res) => {
  const { userId } = req.body;
  const db = readDB();
  const user = db.users.find((u: any) => u.id === userId);

  if (user) {
    user.isChannelMember = true;
    writeDB(db);
    return res.json({
      success: true,
      isChannelMember: true,
      message: "Channel membership verified successfully!",
      user
    });
  }

  res.json({
    success: true,
    isChannelMember: true,
    message: "Channel membership verified!"
  });
});

// Gamified Telegram Reaction Bounty Endpoint (+50 & 1.2x Multiplier)
router.post("/telegram/verify-reaction", (req, res) => {
  const { userId } = req.body;
  const db = readDB();
  const user = db.users.find((u: any) => u.id === userId);
  const rewardPts = db.settings.reactionRewardPoints || 50;

  if (user) {
    const alreadyClaimed = user.hasReactedToday;
    
    if (!alreadyClaimed) {
      user.hasReactedToday = true;
      user.telegramReactionVerified = true;
      user.wallet.points = (user.wallet.points || 0) + rewardPts;
      user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + rewardPts;

      if (!db.transactions) db.transactions = [];
      db.transactions.push({
        id: "tx-reaction-" + Date.now(),
        userId: user.id,
        amount: rewardPts,
        type: "reward_telegram_reaction",
        status: "completed",
        description: `Telegram Reaction Bounty (+${rewardPts})`,
        timestamp: new Date().toISOString()
      });

      if (!db.notifications) db.notifications = [];
      db.notifications.push({
        id: "nt-reaction-" + Date.now(),
        userId: user.id,
        title: "⚡ Reaction Bounty Claimed (+50)!",
        message: `You earned +50!`,
        isRead: false,
        timestamp: new Date().toISOString()
      });

      writeDB(db);
      return res.json({
        success: true,
        pointsAwarded: rewardPts,
        hasMultiplier: true,
        message: `Reaction verified! +${rewardPts} added!`,
        user
      });
    } else {
      user.telegramReactionVerified = true;
      writeDB(db);
      return res.json({
        success: true,
        pointsAwarded: 0,
        hasMultiplier: true,
        message: "Reaction Bounty is active for your account!",
        user
      });
    }
  }

  res.json({
    success: true,
    pointsAwarded: rewardPts,
    hasMultiplier: true,
    message: "Reaction verified!"
  });
});

// 7. Notification & Alert Engine (VRMS-3 ULTRA Phase 12)
router.get("/notifications", (req, res) => {
  try {
    const userId = (req.query.userId || req.query.user_id || "").toString();
    const page = req.query.page ? parseInt(req.query.page as string, 10) : 1;
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
    const type = req.query.type as any;
    const unread_only = req.query.unread_only === 'true';

    const result = getUserNotifications(userId, { page, limit, type, unread_only });

    if (req.query.legacy === 'true') {
      return res.json(result.notifications);
    }

    return res.json({
      success: true,
      notifications: result.notifications,
      unread_count: result.unread_count,
      total: result.total,
      page: result.page,
      limit: result.limit,
      totalPages: result.totalPages
    });
  } catch (e: any) {
    return res.status(500).json({ success: false, error: e.message || "Failed to fetch notifications" });
  }
});

router.post("/notifications/mark-read", (req, res) => {
  try {
    const { userId, user_id, notificationIds, id, all } = req.body;
    const effectiveUserId = userId || user_id;
    const ids = Array.isArray(notificationIds) ? notificationIds : (id ? [id] : []);

    const result = markNotificationsAsRead({
      userId: effectiveUserId,
      notificationIds: ids,
      all: Boolean(all)
    });

    return res.json({
      success: true,
      marked_count: result.marked_count,
      unread_count: result.unread_count
    });
  } catch (e: any) {
    return res.status(500).json({ success: false, error: e.message || "Failed to mark notifications as read" });
  }
});

router.post("/notifications/read", (req, res) => {
  try {
    const { id, userId, user_id, all } = req.body;
    const effectiveUserId = userId || user_id || 'all';
    const ids = id ? [id] : [];
    const result = markNotificationsAsRead({
      userId: effectiveUserId,
      notificationIds: ids,
      all: Boolean(all)
    });
    return res.json({ success: true, ...result });
  } catch (e: any) {
    return res.status(500).json({ success: false, error: e.message });
  }
});

router.post("/notifications/broadcast", requireAdminBearer, (req, res) => {
  try {
    const { title, message, type } = req.body;
    if (!title || !message) {
      return res.status(400).json({ success: false, error: "Title and message are required" });
    }
    const notif = createNotification({
      user_id: 'all',
      title: title.trim(),
      message: message.trim(),
      type: type || 'SYSTEM'
    });
    return res.json({ success: true, announcement: notif });
  } catch (e: any) {
    return res.status(500).json({ success: false, error: e.message });
  }
});

// 8. Concierge AI Module
router.post("/search-ai", async (req, res) => {
  const { query, userId, username, notes } = req.body;
  const db = readDB();

  if (!ai) {
    const mockResponses: { [key: string]: string } = {
      "interstellar": "Approved! Christopher Nolan's space-time masterpiece. Fun fact: The black hole Gargantua was rendered using actual relativistic physics equations!",
      "inception": "Approved! A heist film inside dreams. Fun fact: The spinning top at the end was kept ambiguous intentionally to focus on Cobb's emotional choice.",
      "avatar": "Approved! James Cameron's beautiful blue Pandora adventure. Fun fact: James Cameron waited 15 years to make it because visual technology wasn't ready.",
      "gladiator": "Approved! Ridley Scott's classic historical epic. Fun fact: Russell Crowe actually composed many of his character's iconic dialogues!"
    };

    const lowercase = query.toLowerCase();
    let responseText = `Hi ${username || "Explorer"}! Your request for "${query}" is noted. This looks like a great addition to our catalog! An administrator will review this shortly to make it available for our users!`;
    
    for (const key of Object.keys(mockResponses)) {
      if (lowercase.includes(key)) {
        responseText = mockResponses[key];
        break;
      }
    }

    const request = {
      id: "rq-" + Date.now(),
      userId: userId || "tg-101",
      username: username || "mostofa_official",
      title: query,
      notes: notes || "",
      status: "pending",
      aiRecommendation: responseText,
      timestamp: new Date().toISOString()
    };
    db.requests.push(request);
    writeDB(db);

    return res.json({ responseText, request });
  }

  try {
    const prompt = `You are the smart movie concierge for My TeleFlix Platform, a high-quality Telegram Mini App.
A user named "${username || 'Explorer'}" is searching or requesting the movie/video titled: "${query}".
Notes from user: "${notes || 'None'}"

First, check if any of these movies are already available on our platform (match from the following list):
${db.movies.map((m: any) => `- "${m.title}" (${m.genre})`).join("\n")}

Respond in 2-3 concise sentences. If the movie is already available, let them know!
If it's a new movie request, enthusiastically "Approve" the request for review, write a 1-sentence synopsis, and provide an extremely fascinating "Fun Fact" about this movie or its production that will blow their mind. Ensure the response is styled elegantly without raw markdown tables, friendly and premium. Avoid dry wording.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    const responseText = response.text || `Great request for "${query}"! Added to review queue.`;

    const request = {
      id: "rq-" + Date.now(),
      userId: userId || "tg-101",
      username: username || "mostofa_official",
      title: query,
      notes: notes || "",
      status: "pending",
      aiRecommendation: responseText,
      timestamp: new Date().toISOString()
    };
    db.requests.push(request);
    writeDB(db);

    res.json({ responseText, request });
  } catch (err) {
    console.error("Gemini request failed, fallback initiated:", err);
    res.status(500).json({ error: "Gemini server request failed" });
  }
});

router.get("/requests", (req, res) => {
  const db = readDB();
  const list = db.requests.sort((a: any) => new Date(a.timestamp).getTime());
  res.json(list);
});

router.post("/requests/status", (req, res) => {
  const { id, status } = req.body;
  const db = readDB();
  const reqObj = db.requests.find((r: any) => r.id === id);
  if (reqObj) {
    reqObj.status = status;
    writeDB(db);
    return res.json({ success: true, request: reqObj });
  }
  res.status(404).json({ error: "Request not found" });
});

// 9. Admin Operations
router.get("/admin/analytics", (req, res) => {
  try {
    const stats = getAdminAnalytics();
    res.json(stats);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/admin/withdrawals", (req, res) => {
  try {
    const withdrawals = getAllWithdrawals();
    res.json(withdrawals);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/withdrawals/status", (req, res) => {
  try {
    const { id, status } = req.body;
    const result = processWithdrawalStatus(id, status);
    res.json({ success: true, withdrawal: result });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Admin Users & Anti-Fraud Security Management
router.get("/admin/users", (req, res) => {
  try {
    const db = readDB();
    const users = (db.users || []).map((u: any) => {
      const fp = u.device_fingerprint || u.deviceFingerprint;
      const boundCount = fp 
        ? db.users.filter((other: any) => (other.device_fingerprint === fp || other.deviceFingerprint === fp)).length
        : 1;

      return {
        id: u.id,
        telegramId: u.telegramId,
        username: u.username,
        fullName: u.fullName,
        email: u.email,
        role: u.role,
        isPremium: u.isPremium,
        status: u.status || (u.isBanned ? 'banned' : 'active'),
        isBanned: !!u.isBanned || u.status === 'banned',
        banReason: u.banReason || '',
        isSuspicious: !!u.isSuspicious || boundCount > 1,
        suspiciousReason: u.suspiciousReason || (boundCount > 1 ? `High Risk / Multi-Account: ${boundCount} profiles linked to single Hardware ID` : ''),
        device_fingerprint: fp || 'Unbound',
        boundAccountsCount: boundCount,
        points: u.points ?? u.wallet?.points ?? 0,
        createdAt: u.createdAt,
        lastLogin: u.lastLogin,
        last_active_at: u.last_active_at || u.lastActiveAt,
        taskStats: u.taskStats || { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 }
      };
    });
    res.json(users);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/users/ban", (req, res) => {
  try {
    const { userId, isBanned, reason } = req.body;
    if (!userId) {
      return res.status(400).json({ error: "userId is required" });
    }
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Super Admin protection
    if (isSuperAdminEmail(user.email) || user.role === 'admin') {
      return res.status(403).json({ error: "Administrator accounts cannot be restricted." });
    }

    user.isBanned = !!isBanned;
    user.status = isBanned ? 'banned' : 'active';
    user.banReason = isBanned 
      ? (reason || "Account restricted by administrator due to multi-account policy violation.")
      : "";

    // Sync any withdrawals from this user
    if (db.withdrawals) {
      db.withdrawals.forEach((w: any) => {
        if (w.userId === userId) {
          w.isBanned = !!isBanned;
        }
      });
    }

    // Send notification
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: "nt-ban-" + Date.now(),
      userId,
      title: isBanned ? "⚠️ Security Notice: Cashouts Paused" : "✅ Account Restored",
      message: isBanned 
        ? "Your account cashout privileges have been placed on review. Please reach out to support if you believe this was in error."
        : "Your account and cashout privileges have been successfully restored.",
      isRead: false,
      timestamp: new Date().toISOString()
    });

    writeDB(db);
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/users/flag", (req, res) => {
  try {
    const { userId, isSuspicious, reason } = req.body;
    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    user.isSuspicious = !!isSuspicious;
    user.suspiciousReason = isSuspicious ? (reason || "High Risk / Multi-Account flagged by administrator") : "";
    writeDB(db);
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Dedicated Admin Action: Permanently Delete Individual User
router.delete("/admin/users/:userId", (req, res) => {
  try {
    const { userId } = req.params;
    if (!userId) {
      return res.status(400).json({ error: "userId parameter is required" });
    }

    const db = readDB();
    const userIndex = (db.users || []).findIndex((u: any) => u.id === userId);
    if (userIndex === -1) {
      return res.status(404).json({ error: "User not found" });
    }

    const targetUser = db.users[userIndex];
    // Strict Master & Super Admin Protection:
    if (isSuperAdminEmail(targetUser.email) || targetUser.role === 'admin' || (targetUser.email && targetUser.email.toLowerCase().trim() === SUPER_ADMIN_EMAIL.toLowerCase().trim())) {
      return res.status(403).json({ error: "Master Super-Admin account cannot be deleted." });
    }

    // Permanently remove user profile
    db.users.splice(userIndex, 1);

    // Clean up all related user records, tasks, and hardware references
    if (db.taskSessions) {
      db.taskSessions = db.taskSessions.filter((s: any) => s.userId !== userId);
    }
    if (db.missionLogs) {
      db.missionLogs = db.missionLogs.filter((m: any) => m.userId !== userId);
    }
    if (db.referrals) {
      db.referrals = db.referrals.filter((r: any) => r.referrerId !== userId && r.referredUserId !== userId);
    }
    if (db.withdrawals) {
      db.withdrawals = db.withdrawals.filter((w: any) => w.userId !== userId);
    }
    if (db.vipRequests) {
      db.vipRequests = db.vipRequests.filter((v: any) => v.userId !== userId);
    }
    if (db.notifications) {
      db.notifications = db.notifications.filter((n: any) => n.userId !== userId);
    }

    writeDB(db);

    console.log(`[Admin] User ${userId} permanently deleted by administrator.`);
    res.json({
      success: true,
      message: `User ${userId} and all related logs were permanently deleted.`,
      deletedUserId: userId,
      users: db.users
    });
  } catch (err: any) {
    console.error("Failed to delete user:", err);
    res.status(500).json({ error: err.message });
  }
});

// Dedicated Admin Action: Purge Testing Data & Reset Hardware ID Locks
router.post("/admin/users/clear-test-data", (req, res) => {
  try {
    const db = readDB();
    const masterAdminEmail = SUPER_ADMIN_EMAIL.toLowerCase().trim();

    // Preserve master admin user(s)
    let preservedUsers = (db.users || []).filter((u: any) => 
      (u.email && isSuperAdminEmail(u.email)) || u.role === 'admin'
    );

    if (preservedUsers.length === 0) {
      preservedUsers = [{
        id: `tg-${SUPER_ADMIN_TELEGRAM_ID}`,
        telegramId: SUPER_ADMIN_TELEGRAM_ID,
        username: SUPER_ADMIN_USERNAME,
        fullName: "Master Super Admin",
        email: masterAdminEmail,
        role: "admin",
        isPremium: true,
        status: "active",
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        wallet: { points: 10000, walletAddress: "", status: "active", updatedAt: new Date().toISOString() },
        taskStats: { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 }
      }];
    }

    // Reset hardware ID binding registry & unbind locks on preserved admin users
    preservedUsers.forEach((u: any) => {
      delete u.device_fingerprint;
      delete u.deviceFingerprint;
      delete u.hardwareIdHistory;
      delete u.registered_ip;
      u.isSuspicious = false;
      delete u.suspiciousReason;
      u.isBanned = false;
      u.status = "active";
      delete u.banReason;
    });

    const preservedIds = new Set(preservedUsers.map((u: any) => u.id));

    // Clear testing relations for purged users
    if (db.taskSessions) {
      db.taskSessions = db.taskSessions.filter((s: any) => preservedIds.has(s.userId));
    }
    if (db.missionLogs) {
      db.missionLogs = db.missionLogs.filter((m: any) => preservedIds.has(m.userId));
    }
    if (db.referrals) {
      db.referrals = db.referrals.filter((r: any) => preservedIds.has(r.referrerId) || preservedIds.has(r.referredUserId));
    }
    if (db.withdrawals) {
      db.withdrawals = db.withdrawals.filter((w: any) => preservedIds.has(w.userId));
    }
    if (db.vipRequests) {
      db.vipRequests = db.vipRequests.filter((v: any) => preservedIds.has(v.userId));
    }

    db.users = preservedUsers;
    writeDB(db);

    console.log(`[Admin] Testing data purged and hardware locks reset. Active users: ${db.users.length}`);
    res.json({
      success: true,
      message: "Testing data purged and hardware locks successfully reset.",
      users: db.users
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Dynamic Admin List Management (Future-Proofing Zero-Trust Role Isolation)
router.get("/admin/assigned-admins", (req, res) => {
  try {
    const db = readDB();
    const assigned = (db as any).assignedAdmins || (db.settings as any)?.assignedAdmins || [];
    res.json({ success: true, masterAdmin: SUPER_ADMIN_EMAIL, assignedAdmins: assigned });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/assigned-admins", (req, res) => {
  try {
    const { assignedAdmins } = req.body;
    if (!Array.isArray(assignedAdmins)) {
      return res.status(400).json({ error: "assignedAdmins must be an array of email strings" });
    }
    const db = readDB();
    const cleanList = assignedAdmins.map((a: string) => String(a).toLowerCase().trim()).filter(Boolean);
    (db as any).assignedAdmins = cleanList;
    if (db.settings) {
      (db.settings as any).assignedAdmins = cleanList;
    }
    writeDB(db);
    res.json({ success: true, assignedAdmins: cleanList });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.post("/admin/settings", (req, res) => {
  try {
    const settings = updateSystemSettings(req.body);
    res.json({ success: true, settings });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Single-Click Switch for Referral Payout Model (Plan A vs Plan B)
router.post("/admin/referral-plan", (req, res) => {
  try {
    const { plan } = req.body;
    if (plan !== "PLAN_A" && plan !== "PLAN_B") {
      return res.status(400).json({ error: "Invalid referral payout plan. Must be 'PLAN_A' or 'PLAN_B'." });
    }

    const db = readDB();
    if (!db.settings) db.settings = {} as any;
    db.settings.referralPayoutPlan = plan;
    writeDB(db);

    const planConfig = REFERRAL_PAYOUT_PLANS[plan];
    return res.json({
      success: true,
      plan,
      planConfig,
      settings: db.settings,
      message: `Referral payout plan switched to ${planConfig.name} successfully.`
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// System Settings Public Fetch Endpoint
router.get("/system-settings", (req, res) => {
  const db = readDB();
  res.json(db.settings || {});
});

router.get("/settings", (req, res) => {
  const db = readDB();
  res.json(db.settings || {});
});

router.post("/settings", (req, res) => {
  try {
    const settings = updateSystemSettings(req.body);
    res.json({ success: true, settings });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// VIP Membership Upgrade Request Endpoint
router.post("/vip/request", (req, res) => {
  try {
    const { userId, paymentMethod, payment_method, trxId, trx_id, amount } = req.body;
    const db = readDB();

    const effectiveUserId = userId || "tg-101";
    const user = db.users.find((u: any) => u.id === effectiveUserId);

    const pm = paymentMethod || payment_method || "TON Wallet";
    const tx = trxId || trx_id || ("trx-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex"));

    if (!db.vipRequests) db.vipRequests = [];
    if (!db.vip_requests) db.vip_requests = db.vipRequests;

    const newRequest = {
      id: "vip-req-" + Date.now(),
      user_id: effectiveUserId,
      userId: effectiveUserId,
      username: user?.username || "guest",
      fullName: user?.fullName || "Guest User",
      payment_method: pm,
      paymentMethod: pm,
      trx_id: tx,
      trxId: tx,
      amount: Number(amount) || 5,
      status: "PENDING",
      created_at: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    db.vipRequests.unshift(newRequest);
    db.vip_requests = db.vipRequests;
    writeDB(db);

    res.json({ success: true, message: "VIP membership request submitted for review!", request: newRequest });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Admin VIP Requests List
router.get("/admin/vip-requests", (req, res) => {
  const db = readDB();
  const list = db.vipRequests || db.vip_requests || [];
  res.json(list);
});

// Admin Approve VIP Request
router.post("/admin/vip-requests/approve", (req, res) => {
  try {
    const { requestId, id } = req.body;
    const targetId = requestId || id;
    const db = readDB();

    if (!db.vipRequests) db.vipRequests = [];
    const request = db.vipRequests.find((r: any) => r.id === targetId);

    if (!request) {
      return res.status(404).json({ error: "VIP request not found." });
    }

    request.status = "APPROVED";
    
    // Set user VIP flags across both properties for complete coverage
    const targetUserId = request.user_id || request.userId;
    const user = db.users.find((u: any) => u.id === targetUserId);

    if (user) {
      user.is_vip = true;
      user.isPremium = true;

      // Add transaction ledger entry
      db.transactions.push({
        id: "tx-vip-" + Date.now(),
        userId: targetUserId,
        amount: 0,
        type: "deposit",
        status: "completed",
        description: `👑 VIP Membership Approved (${request.payment_method || 'TON Wallet'} - ${request.trx_id || 'Instant'})`,
        timestamp: new Date().toISOString()
      });

      // Notify user
      db.notifications.push({
        id: "nt-vip-" + Date.now(),
        userId: targetUserId,
        title: "👑 VIP Access Granted!",
        message: "Your VIP membership request has been APPROVED by the admin! You now enjoy instant 1-click downloads with zero ads.",
        isRead: false,
        timestamp: new Date().toISOString()
      });
    }

    writeDB(db);
    res.json({ success: true, message: "VIP request APPROVED successfully!", request, user });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Admin Reject VIP Request
router.post("/admin/vip-requests/reject", (req, res) => {
  try {
    const { requestId, id } = req.body;
    const targetId = requestId || id;
    const db = readDB();

    if (!db.vipRequests) db.vipRequests = [];
    const request = db.vipRequests.find((r: any) => r.id === targetId);

    if (!request) {
      return res.status(404).json({ error: "VIP request not found." });
    }

    request.status = "REJECTED";

    const targetUserId = request.user_id || request.userId;
    if (targetUserId) {
      db.notifications.push({
        id: "nt-vip-rej-" + Date.now(),
        userId: targetUserId,
        title: "❌ VIP Membership Request Update",
        message: "Your VIP upgrade request was rejected. Please verify your transaction ID or contact support.",
        isRead: false,
        timestamp: new Date().toISOString()
      });
    }

    writeDB(db);
    res.json({ success: true, message: "VIP request rejected.", request });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -------------------------------------------------------------
// VRMS-3 ULTRA (Phase 5): Server-Authoritative Inactive User Purge Engine Endpoints
// -------------------------------------------------------------

// GET /api/user/inactivity-status
// Returns current authenticated user's inactivity status, days, and warning notice
router.get("/user/inactivity-status", (req, res) => {
  try {
    const userId = (req.query.userId || req.headers["x-user-id"]) as string;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId parameter is required." });
    }

    const db = readDB();
    const user = db.users.find((u: any) => u.id === userId || (userId && (u.guest_device_id === userId || u.device_fingerprint === userId)));

    if (!user) {
      return res.status(404).json({ success: false, error: "User account not found." });
    }

    const trustedAccess = user.last_authenticated_access_at || user.last_active_at || user.lastLogin || user.createdAt;
    const inactivityDays = getInactivityDays(trustedAccess);
    const warningActive = inactivityDays >= 25 && inactivityDays < 30;
    const purgeEligible = inactivityDays >= 30;

    const daysUntilPurge = Math.max(0, 30 - inactivityDays);

    return res.json({
      success: true,
      userId: user.id,
      inactivity_status: user.inactivity_status || (purgeEligible ? "PURGE_ELIGIBLE" : (warningActive ? "INACTIVE_WARNING" : "ACTIVE")),
      inactivity_days: inactivityDays,
      last_authenticated_access_at: user.last_authenticated_access_at || trustedAccess,
      warning_active: warningActive,
      purge_eligible: purgeEligible,
      days_until_purge: daysUntilPurge,
      warning_message: warningActive
        ? "Your account has been inactive for 25+ days. Perform an activity to maintain active status."
        : (purgeEligible ? "Account has exceeded 30 days of continuous inactivity and is eligible for operational purge." : null),
      monthly_salary_eligible: user.monthly_salary_eligible || false,
      monthly_salary_tier: user.monthly_salary_tier || "None",
      qualified_referral_count: user.qualified_referral_count || 0
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/purge/evaluate
// Triggers server-authoritative inactivity evaluation across all users
router.post("/admin/purge/evaluate", (req, res) => {
  try {
    const result = evaluateInactivityAndPurge();
    return res.json({
      success: true,
      ...result,
      message: `Inactivity evaluation completed. Evaluated: ${result.evaluatedCount}, Warned: ${result.warnedCount}, Purged: ${result.purgedCount}.`
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/purge/execute/:userId
// Manually executes a transaction-safe purge on a specific target user
router.post("/admin/purge/execute/:userId", (req, res) => {
  try {
    const { userId } = req.params;
    const reason = req.body?.reason || "admin_manual_purge";

    if (!userId) {
      return res.status(400).json({ success: false, error: "userId parameter is required." });
    }

    const result = executeUserPurge(userId, reason);
    if (!result.success && !result.alreadyPurged) {
      return res.status(400).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/purge/records
// Returns legal/audit purge records with tombstone references and financial retention data
router.get("/admin/purge/records", (req, res) => {
  try {
    const db = readDB();
    const records = db.purge_records || [];
    return res.json({
      success: true,
      count: records.length,
      records
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// VRMS-3 ULTRA (PHASE 11): Risk & Security Engine (RSE)
// ==========================================

// POST /api/security/evaluate-risk
// Evaluates user signals and updates risk assessment server-side
router.post("/security/evaluate-risk", async (req, res) => {
  try {
    const { userId, actionType, device_fingerprint, ip_address, completion_duration_ms, metadata } = req.body;
    if (!userId) {
      return res.status(400).json({ success: false, error: "userId is required" });
    }
    const clientIp = ip_address || req.headers["x-forwarded-for"] || req.socket.remoteAddress;
    const result = await evaluateUserRisk({
      userId,
      actionType,
      device_fingerprint,
      ip_address: typeof clientIp === "string" ? clientIp.split(",")[0].trim() : undefined,
      completion_duration_ms: typeof completion_duration_ms === "number" ? completion_duration_ms : undefined,
      metadata
    });
    return res.json({
      success: true,
      risk_score: result.assessment.risk_score,
      risk_status: result.user.risk_status,
      isRestricted: result.user.risk_status === "RESTRICTED" || result.user.risk_status === "BANNED",
      isBanned: result.user.risk_status === "BANNED" || Boolean(result.user.isBanned),
      detected_signals: result.assessment.detected_signals,
      recommended_action: result.assessment.recommended_action,
      statusChanged: result.statusChanged,
      message: result.message,
      assessment: result.assessment
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/security/flagged-accounts
// Returns accounts flagged for risk or restricted status
router.get(["/security/flagged-accounts", "/admin/security/flagged-accounts"], (req, res) => {
  try {
    const accounts = getFlaggedAccounts();
    return res.json({
      success: true,
      total: accounts.length,
      accounts
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/security/action
// Admin action on flagged/restricted account (UNRESTRICT, CONFIRM_BAN, RESTRICT, FLAG_RISK, CLEAR_RISK)
router.post(["/security/action", "/admin/security/action"], async (req, res) => {
  try {
    const { adminId, targetUserId, action, reason } = req.body;
    if (!targetUserId || !action) {
      return res.status(400).json({ success: false, error: "targetUserId and action are required." });
    }
    const validActions = ["UNRESTRICT", "CONFIRM_BAN", "RESTRICT", "FLAG_RISK", "CLEAR_RISK"];
    if (!validActions.includes(action)) {
      return res.status(400).json({
        success: false,
        error: `Invalid action: ${action}. Allowed: ${validActions.join(", ")}`
      });
    }
    const result = await executeAdminSecurityAction(adminId || "admin", targetUserId, action, reason);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/security/audit-logs
// Returns immutable security audit logs
router.get(["/security/audit-logs", "/admin/security/audit-logs"], (req, res) => {
  try {
    const { user_id, action_taken, enforced_by, limit } = req.query;
    const logs = getSecurityAuditLogs({
      user_id: user_id ? String(user_id) : undefined,
      action_taken: action_taken ? String(action_taken) : undefined,
      enforced_by: enforced_by ? String(enforced_by) : undefined,
      limit: limit ? Number(limit) : 100
    });
    return res.json({
      success: true,
      total: logs.length,
      logs
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// VRMS-3 ULTRA (PHASE 13): Admin System Settings & Dynamic Campaign Engine (DCE)
// =========================================================================

// Helper to construct configMap dictionary for clean frontend consumption
function buildConfigMap(configs: any[]) {
  const map: Record<string, any> = {};
  for (const c of configs) {
    map[c.config_key] = c.config_value;
  }
  return map;
}

// GET /api/system/config
// Public server-authoritative global variables stream (Zero Hardcoded Thresholds)
router.get(["/system/config", "/api/system/config"], (req, res) => {
  try {
    const db = readDB();
    const configs = getSystemConfigs(db);
    const activeCampaign = getActiveCampaign(db);
    const configMap = buildConfigMap(configs);

    return res.json({
      success: true,
      configs,
      configMap,
      activeCampaign,
      maintenance_mode: Boolean(configMap.MAINTENANCE_MODE ?? db.settings?.isMaintenance ?? false),
      timestamp: new Date().toISOString()
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/campaigns/active
// Public endpoint for currently active campaign
router.get(["/campaigns/active", "/api/campaigns/active"], (req, res) => {
  try {
    const db = readDB();
    const activeCampaign = getActiveCampaign(db);
    return res.json({
      success: true,
      activeCampaign,
      hasActiveCampaign: !!activeCampaign
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/config
// Admin endpoint to retrieve all system configurations
router.get(["/admin/config", "/api/admin/config"], (req, res) => {
  try {
    const db = readDB();
    const configs = getSystemConfigs(db);
    return res.json({
      success: true,
      configs,
      configMap: buildConfigMap(configs)
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/config
// Super Admin authoritative system config updater with mandatory audit log
router.post(["/admin/config", "/api/admin/config"], (req, res) => {
  try {
    const { key, config_key, value, config_value, description, admin_id, reason } = req.body;
    const targetKey = key || config_key;
    const targetValue = value !== undefined ? value : config_value;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!targetKey) {
      return res.status(400).json({ success: false, error: "Configuration key (config_key) is required." });
    }

    if (targetValue === undefined) {
      return res.status(400).json({ success: false, error: "Configuration value (config_value) is required." });
    }

    const db = readDB();
    const { config, oldConfig } = setSystemConfig(targetKey, targetValue, description, adminId, db);

    // Record mandatory Admin Audit Log (Phase 10 standard)
    recordAdminAuditLog({
      admin_id: adminId,
      action: "UPDATE_SYSTEM_SETTINGS",
      target_type: "SYSTEM_CONFIG",
      target_id: targetKey,
      old_value: oldConfig?.config_value,
      new_value: targetValue,
      reason: reason || `Updated system configuration parameter '${targetKey}'`
    }, db);

    writeDB(db);

    return res.json({
      success: true,
      message: `System configuration '${targetKey}' successfully updated.`,
      config,
      configs: getSystemConfigs(db),
      configMap: buildConfigMap(getSystemConfigs(db))
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/config/bulk
// Bulk update multiple system configs with atomic audit logging
router.post(["/admin/config/bulk", "/api/admin/config/bulk"], (req, res) => {
  try {
    const { configs, admin_id, reason } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!Array.isArray(configs) || configs.length === 0) {
      return res.status(400).json({ success: false, error: "configs array is required." });
    }

    const db = readDB();
    const updatedKeys: string[] = [];

    for (const item of configs) {
      const k = item.config_key || item.key;
      const v = item.config_value !== undefined ? item.config_value : item.value;
      if (k && v !== undefined) {
        const { oldConfig } = setSystemConfig(k, v, item.description, adminId, db);
        recordAdminAuditLog({
          admin_id: adminId,
          action: "UPDATE_SYSTEM_SETTINGS",
          target_type: "SYSTEM_CONFIG",
          target_id: k,
          old_value: oldConfig?.config_value,
          new_value: v,
          reason: reason || `Bulk update system config '${k}'`
        }, db);
        updatedKeys.push(k);
      }
    }

    writeDB(db);

    return res.json({
      success: true,
      message: `Successfully updated ${updatedKeys.length} system configuration parameters.`,
      updatedKeys,
      configs: getSystemConfigs(db),
      configMap: buildConfigMap(getSystemConfigs(db))
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/campaigns
// Admin endpoint to retrieve all referral campaigns
router.get(["/admin/campaigns", "/api/admin/campaigns"], (req, res) => {
  try {
    const db = readDB();
    const campaigns = getCampaigns(db);
    const activeCampaign = getActiveCampaign(db);

    return res.json({
      success: true,
      total: campaigns.length,
      campaigns,
      activeCampaign
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/campaigns
// Super Admin authoritative campaign manager enforcing ONE ACTIVE CAMPAIGN RULE
router.post(["/admin/campaigns", "/api/admin/campaigns"], (req, res) => {
  try {
    const { campaign_id, title, start_date, end_date, status, target_metrics, admin_id, reason } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!title) {
      return res.status(400).json({ success: false, error: "Campaign title is required." });
    }

    const db = readDB();
    const isNew = !campaign_id || !db.campaigns?.some((c: any) => c.campaign_id === campaign_id);
    const existingCampaign = campaign_id ? db.campaigns?.find((c: any) => c.campaign_id === campaign_id) : undefined;
    const oldStatus = existingCampaign?.status;

    const { campaign, deactivatedPreviousId } = saveCampaign({
      campaign_id,
      title,
      start_date,
      end_date,
      status: status || 'UPCOMING',
      target_metrics: target_metrics || {}
    }, adminId, db);

    // Mandatory Audit Trail logging
    recordAdminAuditLog({
      admin_id: adminId,
      action: isNew ? "CREATE_CAMPAIGN" : "UPDATE_CAMPAIGN",
      target_type: "CAMPAIGN",
      target_id: campaign.campaign_id,
      old_value: isNew ? null : { status: oldStatus, title: existingCampaign?.title },
      new_value: { status: campaign.status, title: campaign.title, metrics: campaign.target_metrics },
      reason: reason || (deactivatedPreviousId 
        ? `Activated campaign '${campaign.title}' and transitioned previous active campaign '${deactivatedPreviousId}' to COMPLETED`
        : `${isNew ? 'Created' : 'Updated'} referral campaign '${campaign.title}'`)
    }, db);

    writeDB(db);

    return res.json({
      success: true,
      message: deactivatedPreviousId 
        ? `Campaign '${campaign.title}' is now ACTIVE. Previous campaign was automatically transitioned to COMPLETED.`
        : `Campaign '${campaign.title}' saved successfully.`,
      campaign,
      deactivatedPreviousId,
      campaigns: getCampaigns(db),
      activeCampaign: getActiveCampaign(db)
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/campaigns/:campaignId/activate
// Dedicated endpoint to immediately activate a campaign enforcing ONE ACTIVE CAMPAIGN RULE
router.post(["/admin/campaigns/:campaignId/activate", "/api/admin/campaigns/:campaignId/activate"], (req, res) => {
  try {
    const { campaignId } = req.params;
    const { admin_id, reason } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!campaignId) {
      return res.status(400).json({ success: false, error: "campaignId is required." });
    }

    const db = readDB();
    const campaign = db.campaigns?.find((c: any) => c.campaign_id === campaignId);
    if (!campaign) {
      return res.status(404).json({ success: false, error: `Campaign '${campaignId}' not found.` });
    }

    const oldStatus = campaign.status;
    const { campaign: activated, deactivatedPreviousId } = saveCampaign({
      ...campaign,
      status: 'ACTIVE'
    }, adminId, db);

    recordAdminAuditLog({
      admin_id: adminId,
      action: "ACTIVATE_CAMPAIGN",
      target_type: "CAMPAIGN",
      target_id: activated.campaign_id,
      old_value: { status: oldStatus },
      new_value: { status: 'ACTIVE' },
      reason: reason || (deactivatedPreviousId 
        ? `Activated campaign '${activated.title}'. Previous campaign '${deactivatedPreviousId}' auto-completed.`
        : `Activated campaign '${activated.title}'`)
    }, db);

    writeDB(db);

    return res.json({
      success: true,
      message: `Campaign '${activated.title}' is now ACTIVE!`,
      campaign: activated,
      deactivatedPreviousId,
      campaigns: getCampaigns(db),
      activeCampaign: activated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ============================================================================
// VRMS-3 ULTRA (Phase 14): Dynamic Task & Content Sync Engine (TCE) Endpoints
// ============================================================================

/**
 * GET /api/tasks or /tasks
 * Returns all active dynamic tasks tagged with user's daily completion status
 */
router.get(["/tasks", "/api/tasks"], (req, res) => {
  try {
    const userId = (req.query.userId as string) || (req as any).auth?.userId;
    const result = TaskContentSyncEngine.getTasksForUser(userId);
    return res.json({
      success: true,
      tasks: result.tasks,
      daily_progress: result.daily_progress,
      server_time: result.server_time
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/tasks/complete or /tasks/complete
 * Server-authoritative task completion and wallet crediting
 */
router.post(["/tasks/complete", "/api/tasks/complete"], taskSubmitRateLimiter, async (req, res) => {
  try {
    const { taskId, userId, idempotencyKey, clientSignature, metadata } = req.body;
    const effectiveUserId = userId || (req as any).auth?.userId;

    if (!taskId || !effectiveUserId) {
      return res.status(400).json({
        success: false,
        code: 'MISSING_PARAMS',
        message: 'taskId and userId are required.'
      });
    }

    const result = await TaskContentSyncEngine.completeTask({
      taskId,
      userId: effectiveUserId,
      idempotencyKey,
      clientSignature,
      metadata
    });

    if (!result.success) {
      const statusCode = result.code === 'TASK_NOT_FOUND' ? 404 :
                         result.code === 'DUPLICATE' ? 409 :
                         result.code === 'DAILY_LIMIT_REACHED' ? 429 : 400;
      return res.status(statusCode).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      code: 'SERVER_ERROR',
      message: err.message || 'Internal task execution error.'
    });
  }
});

/**
 * GET /api/content or /content
 * Returns dynamic content items catalog tagged with user download progress
 */
router.get(["/content", "/api/content"], (req, res) => {
  try {
    const userId = (req.query.userId as string) || (req as any).auth?.userId;
    const result = TaskContentSyncEngine.getContentForUser(userId);
    return res.json({
      success: true,
      content: result.content,
      daily_progress: result.daily_progress,
      server_time: result.server_time
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/content/verify-download or /content/verify-download
 * Intercepts content download/streaming events, logs activity, and updates the 5 required content actions
 */
router.post(["/content/verify-download", "/api/content/verify-download"], taskSubmitRateLimiter, async (req, res) => {
  try {
    const { contentId, userId, idempotencyKey, metadata } = req.body;
    const effectiveUserId = userId || (req as any).auth?.userId;

    if (!contentId || !effectiveUserId) {
      return res.status(400).json({
        success: false,
        code: 'MISSING_PARAMS',
        message: 'contentId and userId are required.'
      });
    }

    const result = await TaskContentSyncEngine.verifyContentDownload({
      contentId,
      userId: effectiveUserId,
      idempotencyKey,
      metadata
    });

    if (!result.success) {
      const statusCode = result.code === 'CONTENT_NOT_FOUND' ? 404 :
                         result.code === 'DUPLICATE' ? 409 : 400;
      return res.status(statusCode).json(result);
    }

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      code: 'SERVER_ERROR',
      message: err.message || 'Content verification failed.'
    });
  }
});

/**
 * GET /api/admin/tasks or /admin/tasks
 * Super Admin endpoint to view all registered dynamic tasks
 */
router.get(["/admin/tasks", "/api/admin/tasks"], (req, res) => {
  try {
    const db = readDB();
    const tasks = getDynamicTasks(db);
    return res.json({
      success: true,
      tasks
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/admin/tasks or /admin/tasks
 * Super Admin endpoint to create or update a dynamic task
 */
router.post(["/admin/tasks", "/api/admin/tasks"], (req, res) => {
  try {
    const { task, admin_id } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!task || !task.title) {
      return res.status(400).json({ success: false, error: "Task data with title is required." });
    }

    const saved = saveDynamicTask(task, adminId);
    return res.json({
      success: true,
      message: `Task "${saved.title}" saved successfully.`,
      task: saved
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/admin/tasks/:taskId/status or /admin/tasks/:taskId/status
 * Super Admin endpoint to toggle task status ('ACTIVE' | 'PAUSED' | 'EXPIRED')
 */
router.post(["/admin/tasks/:taskId/status", "/api/admin/tasks/:taskId/status"], (req, res) => {
  try {
    const { taskId } = req.params;
    const { status, admin_id } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!taskId || !status) {
      return res.status(400).json({ success: false, error: "taskId and status are required." });
    }

    if (!['ACTIVE', 'PAUSED', 'EXPIRED'].includes(status)) {
      return res.status(400).json({ success: false, error: "Invalid status. Must be ACTIVE, PAUSED, or EXPIRED." });
    }

    const updated = setDynamicTaskStatus(taskId, status, adminId);
    if (!updated) {
      return res.status(404).json({ success: false, error: `Task "${taskId}" not found.` });
    }

    return res.json({
      success: true,
      message: `Task "${updated.title}" status updated to ${status}.`,
      task: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/admin/content or /admin/content
 * Super Admin endpoint to view all registered dynamic content
 */
router.get(["/admin/content", "/api/admin/content"], (req, res) => {
  try {
    const db = readDB();
    const content = getDynamicContent(db);
    return res.json({
      success: true,
      content
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/admin/content or /admin/content
 * Super Admin endpoint to create or update dynamic content
 */
router.post(["/admin/content", "/api/admin/content"], (req, res) => {
  try {
    const { content, admin_id } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!content || !content.title) {
      return res.status(400).json({ success: false, error: "Content data with title is required." });
    }

    const saved = saveDynamicContent(content, adminId);
    return res.json({
      success: true,
      message: `Content "${saved.title}" saved successfully.`,
      content: saved
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/admin/content/:contentId/status or /admin/content/:contentId/status
 * Super Admin endpoint to toggle content status ('ACTIVE' | 'PAUSED')
 */
router.post(["/admin/content/:contentId/status", "/api/admin/content/:contentId/status"], (req, res) => {
  try {
    const { contentId } = req.params;
    const { status, admin_id } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!contentId || !status) {
      return res.status(400).json({ success: false, error: "contentId and status are required." });
    }

    if (!['ACTIVE', 'PAUSED'].includes(status)) {
      return res.status(400).json({ success: false, error: "Invalid status. Must be ACTIVE or PAUSED." });
    }

    const updated = setDynamicContentStatus(contentId, status, adminId);
    if (!updated) {
      return res.status(404).json({ success: false, error: `Content "${contentId}" not found.` });
    }

    return res.json({
      success: true,
      message: `Content "${updated.title}" status updated to ${status}.`,
      content: updated
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * ============================================================================
 * VRMS-3 ULTRA (PHASE 15): AUTOMATED AUDIT & RECONCILIATION ENGINE (ARE) ROUTES
 * ============================================================================
 */

/**
 * POST /api/admin/reconcile/run or /admin/reconcile/run
 * Executes an automated system-wide ledger and activity audit run
 */
router.post(["/admin/reconcile/run", "/api/admin/reconcile/run"], async (req, res) => {
  try {
    const { runType, admin_id } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    const result = await AuditReconciliationEngine.runAudit({
      runType: runType === 'SCHEDULED' ? 'SCHEDULED' : 'MANUAL',
      adminId
    });

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/admin/reconcile/health or /admin/reconcile/health
 * Returns summary integrity metrics, current status, and flagged accounts list
 */
router.get(["/admin/reconcile/health", "/api/admin/reconcile/health"], (req, res) => {
  try {
    const health = AuditReconciliationEngine.getHealth();
    return res.json({
      success: true,
      health
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/admin/reconcile/history or /admin/reconcile/history
 * Returns past audit execution logs
 */
router.get(["/admin/reconcile/history", "/api/admin/reconcile/history"], (req, res) => {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 20;
    const history = AuditReconciliationEngine.getHistory(limit);
    return res.json({
      success: true,
      history
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/admin/reconcile/ledger or /admin/reconcile/ledger
 * Returns immutable double-entry ledger records
 */
router.get(["/admin/reconcile/ledger", "/api/admin/reconcile/ledger"], (req, res) => {
  try {
    const userId = req.query.userId as string | undefined;
    const type = req.query.type as any;
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;

    const ledger = AuditReconciliationEngine.getLedger({ userId, type, limit });
    return res.json({
      success: true,
      ledger
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/admin/reconcile/resolve or /admin/reconcile/resolve
 * Resolves a flagged discrepancy through ledger alignment or manual clearance
 */
router.post(["/admin/reconcile/resolve", "/api/admin/reconcile/resolve"], (req, res) => {
  try {
    const { userId, action, admin_id, note } = req.body;
    const adminId = admin_id || (req as any).auth?.userId || "super_admin";

    if (!userId || !action) {
      return res.status(400).json({ success: false, error: "userId and action ('SYNC_LEDGER' | 'CLEAR_FLAG') are required." });
    }

    if (!['SYNC_LEDGER', 'CLEAR_FLAG'].includes(action)) {
      return res.status(400).json({ success: false, error: "Invalid action. Must be SYNC_LEDGER or CLEAR_FLAG." });
    }

    const result = AuditReconciliationEngine.resolveDiscrepancy({
      userId,
      action,
      adminId,
      note
    });

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// PHASE 2: CONTENT MAPPINGS & VERIFICATION HANDSHAKE ENDPOINTS
// ==========================================

/**
 * GET /api/content-mappings/:contentId
 * Retrieves content mapping document for contentId
 */
router.get(["/content-mappings/:contentId", "/api/content-mappings/:contentId"], (req, res) => {
  try {
    const { contentId } = req.params;
    const db = readDB();
    if (!db.content_mappings) db.content_mappings = [];

    let mapping = db.content_mappings.find((m: any) => m.contentId === contentId);
    if (!mapping) {
      // Lookup in movies/videos to auto-seed
      const movie = db.movies.find((m: any) => m.id === contentId) || db.videos.find((v: any) => v.id === contentId);
      if (movie) {
        const universalLink = movie.universalTelegramLink || movie.originalLink || movie.banglaLink || movie.videoUrl || `https://t.me/myteleflix?start=dl_${contentId}`;
        mapping = {
          contentId,
          title: movie.title,
          universalTelegramLink: universalLink,
          category: movie.category || movie.contentType || "movie",
          thumbnailUrl: movie.thumbnailUrl || movie.poster,
          description: movie.description,
          updatedAt: new Date().toISOString()
        };
        db.content_mappings.push(mapping);
        writeDB(db);
      }
    }

    if (!mapping) {
      return res.status(404).json({ success: false, error: `Content mapping not found for ${contentId}` });
    }

    return res.json({ success: true, mapping });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/content-mappings
 * Saves or updates content mapping in DB
 */
router.post(["/content-mappings", "/api/content-mappings"], (req, res) => {
  try {
    const { contentId, title, universalTelegramLink, category, thumbnailUrl, description } = req.body;
    if (!contentId || !title || !universalTelegramLink) {
      return res.status(400).json({ success: false, error: "contentId, title, and universalTelegramLink are required." });
    }

    const db = readDB();
    if (!db.content_mappings) db.content_mappings = [];

    const existingIdx = db.content_mappings.findIndex((m: any) => m.contentId === contentId);
    const updatedMapping = {
      contentId: String(contentId),
      title: String(title),
      universalTelegramLink: String(universalTelegramLink),
      category: category || "movie",
      thumbnailUrl: thumbnailUrl || "",
      description: description || "",
      updatedAt: new Date().toISOString(),
    };

    if (existingIdx >= 0) {
      db.content_mappings[existingIdx] = { ...db.content_mappings[existingIdx], ...updatedMapping };
    } else {
      db.content_mappings.push(updatedMapping);
    }

    writeDB(db);
    return res.json({ success: true, mapping: updatedMapping });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/verification/token
 * Generates a single-use verification token
 */
router.post(["/verification/token", "/api/verification/token"], (req, res) => {
  try {
    const { contentId, telegramId, email } = req.body;
    if (!contentId) {
      return res.status(400).json({ success: false, error: "contentId is required" });
    }

    const randomPart = crypto.randomBytes(8).toString("hex");
    const token = `vtok_${Date.now()}_${randomPart}`;
    const db = readDB();
    if (!db.verification_tokens) db.verification_tokens = [];

    const tokenRecord = {
      token,
      contentId,
      telegramId: telegramId ? String(telegramId) : "",
      userEmail: email || "",
      createdAt: new Date().toISOString(),
      expiresAt: Date.now() + 15 * 60 * 1000,
      isUsed: false,
    };

    db.verification_tokens.push(tokenRecord);
    writeDB(db);

    return res.json({ success: true, token });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/verification/validate
 * Validates and consumes single-use verification token (replay protection)
 */
router.post(["/verification/validate", "/api/verification/validate"], (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ success: false, error: "Token is required" });
    }

    const db = readDB();
    if (!db.verification_tokens) db.verification_tokens = [];

    const tokenIdx = db.verification_tokens.findIndex((t: any) => t.token === token);
    if (tokenIdx === -1) {
      return res.status(404).json({ success: false, error: "Verification token not found or invalid" });
    }

    const tRecord = db.verification_tokens[tokenIdx];
    if (tRecord.isUsed) {
      return res.status(400).json({ success: false, error: "Verification token has already been consumed (single-use protection)" });
    }

    if (tRecord.expiresAt && Date.now() > tRecord.expiresAt) {
      return res.status(400).json({ success: false, error: "Verification token has expired" });
    }

    // Mark as used
    tRecord.isUsed = true;
    tRecord.usedAt = new Date().toISOString();
    writeDB(db);

    return res.json({ success: true, valid: true, tokenData: tRecord });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/verify-signal/:contentId
 * Ties contentId to universalTelegramLink and updates signal status
 */
router.get(["/verify-signal/:contentId", "/api/verify-signal/:contentId"], (req, res) => {
  try {
    const { contentId } = req.params;
    const { telegramId, email, botUsername, userMode, uid } = req.query;

    const db = readDB();
    if (!db.content_mappings) db.content_mappings = [];
    if (!db.download_requests) db.download_requests = [];

    let mapping = db.content_mappings.find((m: any) => m.contentId === contentId);
    if (!mapping) {
      const movie = db.movies.find((m: any) => m.id === contentId) || db.videos.find((v: any) => v.id === contentId);
      const link = movie?.universalTelegramLink || movie?.originalLink || movie?.banglaLink || movie?.videoUrl || `https://t.me/myteleflix?start=dl_${contentId}`;
      mapping = {
        contentId,
        title: movie?.title || `Content #${contentId}`,
        universalTelegramLink: link,
        category: movie?.category || "movie",
        updatedAt: new Date().toISOString()
      };
      db.content_mappings.push(mapping);
    }

    const cleanBot = (botUsername as string || "myteleflix_bot").replace(/^@/, '').replace('https://t.me/', '');
    const deepLink = `https://t.me/${cleanBot}?start=dl_${encodeURIComponent(contentId)}`;

    // Tie signal in download_requests with explicit userMode (GUEST vs VIP)
    const effectiveTgId = telegramId ? String(telegramId) : (uid ? String(uid) : "guest_request");
    const existingReqIdx = db.download_requests.findIndex((r: any) => r.telegramId === effectiveTgId || r.contentId === contentId);
    const resolvedUserMode: "GUEST" | "VIP" = (userMode === "VIP" || Boolean(uid && !String(uid).startsWith('guest_'))) ? "VIP" : "GUEST";
    
    const requestPayload = {
      telegramId: effectiveTgId,
      userEmail: (email as string) || "",
      uid: (uid as string) || null,
      userMode: resolvedUserMode,
      contentId,
      contentTitle: mapping.title,
      universalLink: mapping.universalTelegramLink,
      status: "VERIFIED",
      deepLink,
      verifiedAt: new Date().toISOString(),
    };

    if (existingReqIdx >= 0) {
      db.download_requests[existingReqIdx] = { ...db.download_requests[existingReqIdx], ...requestPayload };
    } else {
      db.download_requests.push(requestPayload);
    }

    writeDB(db);

    return res.json({
      success: true,
      mapping,
      deepLink,
      userMode: resolvedUserMode,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/download/complete
 * Records download completion and allocates rewards for VIP users while strictly blocking earnings for GUEST users.
 */
router.post(["/download/complete", "/api/download/complete"], async (req, res) => {
  try {
    const { docId, contentId, telegramId, uid, userMode } = req.body;
    const effectiveDocId = docId || telegramId || uid || contentId || "guest_request";
    
    const result = await markDownloadRequestCompleted(String(effectiveDocId), {
      forcedUserMode: userMode,
      uid
    });

    return res.json({
      success: true,
      ...result,
      guestPrompt: result.userMode === "GUEST" 
        ? "🌟 Want to EARN from this download? Sign up now to unlock your VIP Wallet!" 
        : null
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/support/chat
 * AI Customer Support Engine endpoint powered by LLM with strict guardrails
 */
router.post(["/support/chat", "/api/support/chat"], async (req, res) => {
  try {
    const { query, message, text, user, history } = req.body;
    const prompt = query || message || text;
    if (!prompt) {
      return res.status(400).json({ success: false, error: "Query or message string is required." });
    }

    const reply = await generateAiSupportResponse({
      userQuery: prompt,
      fromUser: user,
      history: Array.isArray(history) ? history : undefined,
    });

    return res.json({
      success: true,
      reply,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// PHASE 6: SYSTEM CONFIG & REALTIME METRICS
// ==========================================

/**
 * GET /api/system-config
 * Retrieves configuration from Firestore collection 'system_config' (doc 'global_settings')
 */
router.get(["/system-config", "/api/system-config"], async (req, res) => {
  try {
    const dbConfig = await getSystemConfigFromDb();
    const localDb = readDB();

    const mergedConfig = {
      firstVerificationUrl: dbConfig?.firstVerificationUrl || localDb.settings?.firstVerificationUrl || "https://your-1st-website.com/verify/step-1",
      secondVerificationUrl: dbConfig?.secondVerificationUrl || localDb.settings?.secondVerificationUrl || "https://your-2nd-website.com/verify/step-2",
      requiredChannels: dbConfig?.requiredChannels || localDb.settings?.requiredChannels || [
        { id: "@myteleflix", title: "📢 অফিশিয়াল মেইন চ্যানেল", inviteLink: "https://t.me/myteleflix" },
        { id: "@myteleflix_movies", title: "🎬 টেলিফ্লিক্স মুভিজ হাব", inviteLink: "https://t.me/myteleflix" },
        { id: "@myteleflix_backup", title: "⚡ ব্যাকআপ ডিরেক্ট চ্যানেল", inviteLink: "https://t.me/myteleflix" }
      ],
      directAdLink: dbConfig?.directAdLink || localDb.settings?.directAdLink || "",
      vastAdScript: dbConfig?.vastAdScript || localDb.settings?.vastAdScript || "",
      popunderAdScript: dbConfig?.popunderAdScript || localDb.settings?.popunderAdScript || "",
      adCooldownSeconds: dbConfig?.adCooldownSeconds ?? localDb.settings?.adCooldownSeconds ?? 60,
      telegramBotUsername: dbConfig?.telegramBotUsername || localDb.settings?.telegramBotUsername || "myteleflix_bot",
      telegramBotTokenConfigured: Boolean(process.env.TELEGRAM_BOT_TOKEN || localDb.settings?.telegramBotToken),
      adminUids: ["mostofa7077a@gmail.com", ...(process.env.ADMIN_UIDS ? process.env.ADMIN_UIDS.split(",").map(s => s.trim()) : [])],
      updatedAt: dbConfig?.updatedAt || new Date().toISOString()
    };

    return res.json({ success: true, config: mergedConfig });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/system-config
 * Saves and updates all configurations dynamically in Firestore under 'system_config' collection
 */
router.post(["/system-config", "/api/system-config"], async (req, res) => {
  try {
    const updates = req.body || {};
    const localDb = readDB();

    // 1. Update local DB settings
    if (!localDb.settings) localDb.settings = {} as any;
    localDb.settings = {
      ...localDb.settings,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    writeDB(localDb);

    // 2. Save dynamically in Firestore collection 'system_config' (doc 'global_settings')
    await saveSystemConfigToDb({
      ...updates,
      updatedAt: new Date().toISOString()
    });

    return res.json({ success: true, message: "System configuration saved successfully to Firestore", config: localDb.settings });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/admin/realtime-metrics & /api/realtime-metrics
 * Real-time stats display: Total Users, Active Pending Requests, Completed Downloads
 */
router.get(["/admin/realtime-metrics", "/api/admin/realtime-metrics", "/realtime-metrics", "/api/realtime-metrics"], async (req, res) => {
  try {
    const metrics = await getRealtimeMetricsFromDb();
    return res.json({
      success: true,
      metrics: {
        ...metrics,
        serverUptime: Math.floor(process.uptime()),
        uptimeFormatted: `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m ${Math.floor(process.uptime() % 60)}s`,
        memoryMb: {
          rss: Math.round(process.memoryUsage().rss / (1024 * 1024)),
          heapUsed: Math.round(process.memoryUsage().heapUsed / (1024 * 1024))
        }
      }
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

export default router;

