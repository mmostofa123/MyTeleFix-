/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA - PHASE 5: Server-Authoritative Inactive User Purge Engine
 * 
 * NON-NEGOTIABLE SYSTEM RULES:
 * 1. 30-Day Inactivity Rule: Users with no trusted authenticated access for 30 consecutive days
 *    are flagged PURGE_ELIGIBLE and operationally purged.
 * 2. Trusted Access Verification: Only genuine authenticated server transactions update
 *    `last_authenticated_access_at`. Background pings/fake client events do NOT reset the timer.
 * 3. Referral & Salary Recalculation: When a user is purged, detach them from active referral trees
 *    and immediately recalculate the referrer's qualified_referral_count and monthly salary eligibility.
 * 4. Returning Purged User: If a purged user logs back in, treat them as a BRAND NEW USER.
 *    Old verification, streaks, or referral progress MUST NOT be restored.
 * 5. Idempotency & Race Protection: Login events and purge execution are transaction-safe with locks.
 * 6. Audit & Financial Preservation: Mandatory audit records and historical paid ledgers are never destroyed.
 */

import crypto from "crypto";
import { readDB, writeDB, DBState, UserProfile, PurgeRecord, ReferralRecord } from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";
import { 
  SUPER_ADMIN_EMAILS, 
  SUPER_ADMIN_TELEGRAM_ID, 
  SUPER_ADMIN_USERNAME,
  isSuperAdminEmail 
} from "./inactivityPurge.js";
import { invalidateReferralIndexes } from "./referralEngine.js";
import { emitInactivityWarningAlert, createNotification } from "./notificationEngine.js";

// Concurrency locks to protect against simultaneous login/purge races
const userPurgeLocks = new Map<string, number>();
const LOCK_TIMEOUT_MS = 15000;

export function acquireUserPurgeLock(userId: string): boolean {
  const now = Date.now();
  const existingLock = userPurgeLocks.get(userId);
  if (existingLock && now - existingLock < LOCK_TIMEOUT_MS) {
    return false; // Currently locked
  }
  userPurgeLocks.set(userId, now);
  return true;
}

export function releaseUserPurgeLock(userId: string): void {
  userPurgeLocks.delete(userId);
}

/**
 * Calculates whole days of inactivity between the provided timestamp and current time
 */
export function getInactivityDays(lastAccessISO?: string): number {
  if (!lastAccessISO) return 0;
  const lastTime = new Date(lastAccessISO).getTime();
  if (isNaN(lastTime) || lastTime <= 0) return 0;
  const now = Date.now();
  const diffMs = Math.max(0, now - lastTime);
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Check if an account is exempt from auto-purge (e.g., Super Admins)
 */
export function isExemptFromPurge(user: UserProfile): boolean {
  if (!user) return false;
  if (isSuperAdminEmail(user.email)) return true;
  if (user.telegramId && String(user.telegramId) === SUPER_ADMIN_TELEGRAM_ID) return true;
  if (user.username && user.username.toLowerCase() === SUPER_ADMIN_USERNAME.toLowerCase()) return true;
  if (user.role === 'admin') return true;
  return false;
}

/**
 * Recalculates referrer's active qualified referral counts and monthly salary eligibility
 * after referral tree modifications or purge events.
 */
export function recalculateReferralCountsAndSalary(
  referrerId: string,
  providedDb?: DBState
): {
  registeredCount: number;
  qualifiedCount: number;
  salaryEligible: boolean;
  salaryTier: string;
} {
  const db = providedDb || readDB();
  const referrer = db.users.find((u: any) => u.id === referrerId || u.telegramId === referrerId.replace("tg-", ""));
  if (!referrer) {
    return { registeredCount: 0, qualifiedCount: 0, salaryEligible: false, salaryTier: "None" };
  }

  const allReferrals = (db.referrals || []).filter(
    (r: any) => (r.referrerId === referrer.id || r.referrer_id === referrer.id) && r.status !== "PURGED"
  );

  const registeredCount = allReferrals.filter(
    (r: any) => r.status === "REGISTERED" || r.status === "PENDING"
  ).length;

  const qualifiedCount = allReferrals.filter(
    (r: any) => r.status === "QUALIFIED"
  ).length;

  referrer.registered_referral_count = registeredCount;
  referrer.qualified_referral_count = qualifiedCount;

  // Monthly Salary Eligibility Formula:
  // Gold Tier: 50+ Active Qualified Referrals
  // Silver Tier: 25+ Active Qualified Referrals
  // Bronze Tier: 10+ Active Qualified Referrals
  let salaryEligible = false;
  let salaryTier = "None";

  if (qualifiedCount >= 50) {
    salaryEligible = true;
    salaryTier = "Gold (50+ Active Qualified)";
  } else if (qualifiedCount >= 25) {
    salaryEligible = true;
    salaryTier = "Silver (25+ Active Qualified)";
  } else if (qualifiedCount >= 10) {
    salaryEligible = true;
    salaryTier = "Bronze (10+ Active Qualified)";
  }

  referrer.monthly_salary_eligible = salaryEligible;
  referrer.monthly_salary_tier = salaryTier;

  if (!providedDb) {
    writeDB(db);
  }

  return { registeredCount, qualifiedCount, salaryEligible, salaryTier };
}

export interface PurgeExecutionResult {
  success: boolean;
  purged: boolean;
  alreadyPurged?: boolean;
  purgeRecord?: PurgeRecord;
  affectedReferrerIds: string[];
  message: string;
}

/**
 * Purge Execution Transaction (Rule 1, 3, 5, 6):
 * - Locks user record against concurrent access
 * - Detaches user from referral trees (status = 'PURGED')
 * - Immediately triggers recalculation of referrers' qualified counts & salary eligibility
 * - Clears operational user state (active streaks, verification state, pending claims)
 * - Preserves historical paid financial transactions and audit ledgers
 * - Saves tombstoned audit record in purge_records
 */
export function executeUserPurge(
  userId: string,
  purgeReason: string = "30_days_inactivity",
  providedDb?: DBState
): PurgeExecutionResult {
  if (!acquireUserPurgeLock(userId)) {
    return {
      success: false,
      purged: false,
      affectedReferrerIds: [],
      message: `User ${userId} is currently locked by another concurrent transaction.`
    };
  }

  try {
    const db = providedDb || readDB();
    const user = db.users.find((u: any) => u.id === userId);
    if (!user) {
      return {
        success: false,
        purged: false,
        affectedReferrerIds: [],
        message: `User ${userId} not found.`
      };
    }

    if (isExemptFromPurge(user)) {
      return {
        success: false,
        purged: false,
        affectedReferrerIds: [],
        message: `User ${userId} is a protected admin account and cannot be purged.`
      };
    }

    // Idempotency: If already purged, return early without repeating side-effects
    if (user.inactivity_status === "PURGED") {
      return {
        success: true,
        purged: false,
        alreadyPurged: true,
        affectedReferrerIds: [],
        message: `User ${userId} has already been purged.`
      };
    }

    const nowISO = new Date().toISOString();
    const inactivityDays = getInactivityDays(user.last_authenticated_access_at || user.last_active_at || user.lastLogin);

    // 1. Detach user from active referral trees in `referrals`
    if (!db.referrals) db.referrals = [];
    const affectedReferrersSet = new Set<string>();

    for (const ref of db.referrals) {
      const refReferredId = ref.referred_user_id || ref.referredId;
      if (refReferredId === userId) {
        const referrerId = ref.referrer_id || ref.referrerId;
        if (referrerId) {
          affectedReferrersSet.add(referrerId);
        }
        ref.status = "PURGED";
        ref.purged_at = nowISO;
      }
    }

    const affectedReferrerIds = Array.from(affectedReferrersSet);

    // 2. Trigger recalculation hook for all affected referrers
    for (const referrerId of affectedReferrerIds) {
      recalculateReferralCountsAndSalary(referrerId, db);

      // In-app audit notification to referrer (VRMS-3 ULTRA Phase 12)
      createNotification({
        user_id: referrerId,
        title: "⚠️ রেফারেল ডাটা রিক্যালিব্রেশন (Inactive Purge)",
        message: `আপনার রেফারেল নেটওয়ার্কের একজন সদস্য ৩০ দিন কোনো অ্যাক্টিভিটি না থাকায় সিস্টেম কর্তৃক পার্জ করা হয়েছে। আপনার সক্রিয় কোয়ালিফাইড রেফারেল সংখ্যা স্বয়ংক্রিয়ভাবে রিক্যালিব্রেট করা হয়েছে।`,
        type: 'SYSTEM',
        reference_id: `purge_recal_${referrerId}`
      }, db);
    }

    // 3. Preserve Financial Records & Mandatory Audit Ledger (Rule 6)
    const userTransactions = (db.transactions || []).filter((tx: any) => tx.userId === userId);
    const auditLedgerIds = userTransactions.map((tx: any) => tx.id);
    const totalPaidTokens = userTransactions
      .filter((tx: any) => tx.status === "completed" && tx.amount > 0)
      .reduce((sum: number, tx: any) => sum + tx.amount, 0);

    const userHash = crypto.createHash("sha256").update(userId).digest("hex");
    const purgeRecord: PurgeRecord = {
      purge_id: `prg_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`,
      user_id_hash: userHash,
      original_user_id: userId,
      purged_user_id: userId,
      purge_reason: purgeReason,
      inactivity_days: Math.max(30, inactivityDays),
      purged_at: nowISO,
      affected_referrer_ids: affectedReferrerIds,
      financial_retention_reference: {
        transaction_count: userTransactions.length,
        total_paid_tokens: totalPaidTokens,
        wallet_address: user.wallet?.walletAddress || "",
        audit_ledger_ids: auditLedgerIds
      }
    };

    if (!db.purge_records) db.purge_records = [];
    db.purge_records.push(purgeRecord);

    // 4. Clear Operational User State (Streaks, verification, claims)
    user.inactivity_status = "PURGED";
    user.purged_at = nowISO;
    user.purge_eligible_at = nowISO;
    user.active_day_streak = 0;
    user.activeDaysCount = 0;
    user.activeDaysList = [];
    user.valid_action_count = 0;
    user.is_verified = false;
    user.isHumanVerified = false;
    user.isQuizPassed = false;
    user.status = "suspended";
    user.referredBy = undefined;

    // In verification_records, tombstone the record
    if (db.verification_records) {
      const verRecord = db.verification_records.find((v: any) => v.user_id === userId);
      if (verRecord) {
        verRecord.verification_status = "PURGED" as any;
      }
    }

    invalidateReferralIndexes();

    if (!providedDb) {
      writeDB(db);
    }

    // Sync to Firestore if writable
    (async () => {
      try {
        if (await isFirestoreWritable()) {
          await setDoc(
            doc(firestore, "purge_records", purgeRecord.purge_id),
            purgeRecord,
            { merge: true }
          );
          await setDoc(
            doc(firestore, "users", userId),
            {
              inactivity_status: "PURGED",
              purged_at: nowISO,
              is_verified: false,
              active_day_streak: 0,
              valid_action_count: 0
            },
            { merge: true }
          );
        }
      } catch (e) {
        console.warn("[Purge Engine] Non-fatal Firestore sync warning:", e);
      }
    })();

    console.log(`[Purge Engine] User ${userId} successfully purged for ${purgeReason}. Affected referrers: ${affectedReferrerIds.length}`);

    return {
      success: true,
      purged: true,
      purgeRecord,
      affectedReferrerIds,
      message: `User ${userId} successfully purged after ${inactivityDays} days of inactivity.`
    };
  } finally {
    releaseUserPurgeLock(userId);
  }
}

/**
 * Inactivity Evaluator Service (Rule 1 & 2):
 * - Day 25+: Flags user as 'INACTIVE_WARNING' and sends in-app notice.
 * - Day 30+: Flags user as 'PURGE_ELIGIBLE' and executes the operational state purge transaction.
 */
export function evaluateInactivityAndPurge(providedDb?: DBState): {
  evaluatedCount: number;
  warnedCount: number;
  purgedCount: number;
  purgedUserIds: string[];
} {
  const db = providedDb || readDB();
  const now = Date.now();
  let warnedCount = 0;
  let purgedCount = 0;
  const purgedUserIds: string[] = [];

  for (const user of db.users) {
    if (isExemptFromPurge(user)) continue;
    if (user.inactivity_status === "PURGED") continue;

    // Use trusted last_authenticated_access_at
    const trustedAccess = user.last_authenticated_access_at || user.last_active_at || user.lastLogin || user.createdAt;
    const inactivityDays = getInactivityDays(trustedAccess);

    if (inactivityDays >= 30) {
      // Transition to PURGE_ELIGIBLE -> Execute operational state purge
      user.inactivity_status = "PURGE_ELIGIBLE";
      user.purge_eligible_at = new Date().toISOString();

      const purgeRes = executeUserPurge(user.id, "30_days_inactivity", db);
      if (purgeRes.purged) {
        purgedCount++;
        purgedUserIds.push(user.id);
      }
    } else if (inactivityDays >= 25) {
      // Day 25+: Inactivity Warning
      user.inactivity_status = "INACTIVE_WARNING";
      const nowISO = new Date().toISOString();

      // Send warning notification if not already sent in the last 5 days
      const lastWarningTime = user.inactivity_warning_sent_at ? new Date(user.inactivity_warning_sent_at).getTime() : 0;
      if (now - lastWarningTime > 5 * 24 * 60 * 60 * 1000) {
        user.inactivity_warning_sent_at = nowISO;
        emitInactivityWarningAlert(user.id, Math.round(inactivityDays), db);
        warnedCount++;
      }
    } else {
      // Inactivity is under 25 days
      if (user.inactivity_status === "INACTIVE_WARNING" || user.inactivity_status === "PURGE_ELIGIBLE") {
        user.inactivity_status = "ACTIVE";
        user.purge_eligible_at = null;
      }
    }
  }

  if (!providedDb) {
    writeDB(db);
  }

  return {
    evaluatedCount: db.users.length,
    warnedCount,
    purgedCount,
    purgedUserIds
  };
}

/**
 * Trusted Access Verification Hook (Rule 2):
 * Resets the inactivity timer ONLY on genuine authenticated server transactions.
 * Fake client pings or background heartbeat calls MUST NOT call this.
 */
export function touchAuthenticatedAccess(userId: string, providedDb?: DBState): void {
  if (!userId) return;
  const db = providedDb || readDB();
  const user = db.users.find((u: any) => u.id === userId || u.telegramId === userId.replace("tg-", ""));
  if (!user) return;

  const nowISO = new Date().toISOString();
  user.last_authenticated_access_at = nowISO;
  user.last_active_at = nowISO;
  user.lastActiveAt = nowISO;

  // If user was previously warned or marked purge eligible, restore to ACTIVE
  if (user.inactivity_status === "INACTIVE_WARNING" || user.inactivity_status === "PURGE_ELIGIBLE") {
    user.inactivity_status = "ACTIVE";
    user.purge_eligible_at = null;
  }

  if (!providedDb) {
    writeDB(db);
  }
}

/**
 * Re-registration Handler (Rule 4):
 * If a purged user attempts login or registration, they MUST be treated as a NEW USER.
 * Old verification, streaks, or referral progress MUST NOT be restored.
 */
export function handlePurgedUserReRegistration(user: UserProfile, providedDb?: DBState): UserProfile {
  const nowISO = new Date().toISOString();
  const welcomePoints = 100;

  console.log(`[Purge Engine] Handling re-registration for previously purged user ${user.id}. Initializing fresh operational state.`);

  user.inactivity_status = "ACTIVE";
  user.status = "active";
  user.purged_at = null;
  user.purge_eligible_at = null;
  user.last_authenticated_access_at = nowISO;
  user.last_active_at = nowISO;
  user.lastActiveAt = nowISO;
  user.lastLogin = nowISO;

  // Fresh verification & activity defaults (DO NOT RESTORE OLD DATA)
  user.active_day_streak = 0;
  user.activeDaysCount = 0;
  user.activeDaysList = [];
  user.valid_action_count = 0;
  user.is_verified = false;
  user.isHumanVerified = false;
  user.isQuizPassed = false;
  user.referredBy = undefined; // Detached from past referrer

  // Fresh wallet & task stats
  user.wallet = {
    points: welcomePoints,
    walletAddress: "",
    status: "active",
    updatedAt: nowISO
  };
  user.points = welcomePoints;
  user.taskStats = {
    missionsCompleted: 0,
    totalPointsEarned: welcomePoints,
    moviesWatched: 0,
    videosWatched: 0
  };

  const db = providedDb || readDB();

  // Fresh Welcome Ledger
  if (!db.transactions) db.transactions = [];
  db.transactions.push({
    id: "tx-welcome-re-" + Date.now(),
    userId: user.id,
    amount: welcomePoints,
    type: "deposit",
    status: "completed",
    description: "My TeleFlix Telegram Fresh Account Welcome Bonus!",
    timestamp: nowISO
  });

  if (!db.notifications) db.notifications = [];
  db.notifications.push({
    id: "nt-welcome-re-" + Date.now(),
    userId: user.id,
    title: "🎁 Welcome to My TeleFlix!",
    message: `Your new account is ready. We've credited +${welcomePoints} welcome bonus! Complete 10 active days and 100 tasks to verify.`,
    isRead: false,
    timestamp: nowISO
  });

  if (!providedDb) {
    writeDB(db);
  }

  return user;
}
