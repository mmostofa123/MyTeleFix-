/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 16): Distributed Server-Side Rate Limiter
 * 
 * Protects platform infrastructure against DDoS, credential stuffing, automated bots,
 * and high-velocity race-condition exploits on financial and verification endpoints.
 */

import { Request, Response, NextFunction } from "express";

export interface RateLimitConfig {
  windowMs: number;       // Window size in milliseconds
  max: number;            // Maximum number of requests allowed in window
  message?: string;       // User-friendly error message
  statusCode?: number;    // HTTP status code (default 429)
  keyGenerator?: (req: Request) => string; // Custom identifier generator
  skip?: (req: Request) => boolean;        // Optional bypass check
}

interface RateLimitRecord {
  count: number;
  resetAt: number;
  firstRequestAt: number;
}

// In-memory sliding rate limit store
const rateLimitStores = new Map<string, Map<string, RateLimitRecord>>();

// Telemetry counters for health monitoring
let totalThrottledRequests = 0;
const throttledRoutesCount = new Map<string, number>();

/**
 * Periodically clears expired rate-limit records to ensure minimal memory footprint
 */
setInterval(() => {
  const now = Date.now();
  for (const [, store] of rateLimitStores.entries()) {
    for (const [key, record] of store.entries()) {
      if (now > record.resetAt) {
        store.delete(key);
      }
    }
  }
}, 60000);

/**
 * Extracts best-effort client identifier (combining authenticated user ID and client IP)
 */
export function getClientIdentifier(req: Request): string {
  // 1. Authenticated User ID if available
  const authUserId = (req as any).auth?.userId || (req as any).user?.id || req.headers["x-user-id"];
  
  // 2. Client IP Address
  const forwardedFor = req.headers["x-forwarded-for"];
  let clientIp = "";
  if (typeof forwardedFor === "string") {
    clientIp = forwardedFor.split(",")[0].trim();
  } else if (Array.isArray(forwardedFor)) {
    clientIp = forwardedFor[0].trim();
  } else {
    clientIp = req.socket?.remoteAddress || req.ip || "127.0.0.1";
  }

  // Combine authenticated ID with IP if present for granular isolation
  if (authUserId) {
    return `user:${authUserId}:${clientIp}`;
  }
  return `ip:${clientIp}`;
}

/**
 * Creates an Express rate limiting middleware instance
 */
export function createRateLimiter(bucketName: string, config: RateLimitConfig) {
  const {
    windowMs,
    max,
    message = "Too many requests. Please slow down and try again later.",
    statusCode = 429,
    keyGenerator = getClientIdentifier,
    skip
  } = config;

  if (!rateLimitStores.has(bucketName)) {
    rateLimitStores.set(bucketName, new Map<string, RateLimitRecord>());
  }

  const store = rateLimitStores.get(bucketName)!;

  return (req: Request, res: Response, next: NextFunction) => {
    if (skip && skip(req)) {
      return next();
    }

    const key = keyGenerator(req);
    const now = Date.now();
    let record = store.get(key);

    if (!record || now > record.resetAt) {
      record = {
        count: 1,
        resetAt: now + windowMs,
        firstRequestAt: now,
      };
      store.set(key, record);
    } else {
      record.count += 1;
    }

    const remaining = Math.max(0, max - record.count);
    const resetSeconds = Math.ceil((record.resetAt - now) / 1000);

    // Set standard RateLimit headers
    res.setHeader("X-RateLimit-Limit", max);
    res.setHeader("X-RateLimit-Remaining", remaining);
    res.setHeader("X-RateLimit-Reset", resetSeconds);

    if (record.count > max) {
      totalThrottledRequests += 1;
      throttledRoutesCount.set(req.baseUrl + req.path, (throttledRoutesCount.get(req.baseUrl + req.path) || 0) + 1);

      res.setHeader("Retry-After", resetSeconds);
      return res.status(statusCode).json({
        success: false,
        error: "TOO_MANY_REQUESTS",
        message,
        retryAfter: resetSeconds,
        limit: max,
        current: record.count,
        windowMs
      });
    }

    next();
  };
}

/**
 * Pre-configured rate limiters for sensitive VRMS-3 ULTRA endpoints
 */

// 1. Salary Claims: max 10 requests / minute per user/IP
export const salaryClaimRateLimiter = createRateLimiter("salary_claims", {
  windowMs: 60 * 1000,
  max: 10,
  message: "Rate limit exceeded for salary claims (max 10 requests/minute). Please wait before retrying."
});

// 2. Anti-Bot Human Quiz Reset: max 5 resets / hour per user/IP
export const quizResetRateLimiter = createRateLimiter("quiz_reset", {
  windowMs: 60 * 60 * 1000,
  max: 5,
  message: "Verification quiz reset limit exceeded (max 5 resets/hour). Please wait before requesting another reset."
});

// 3. Quiz Answers Submit: max 15 submissions / minute per user/IP
export const quizSubmitRateLimiter = createRateLimiter("quiz_submit", {
  windowMs: 60 * 1000,
  max: 15,
  message: "Quiz verification submission rate limit reached. Please wait 60 seconds before submitting again."
});

// 4. Sensitive Auth Operations (login, token exchange): max 30 requests / minute per IP
export const authRateLimiter = createRateLimiter("auth_gate", {
  windowMs: 60 * 1000,
  max: 30,
  message: "Too many authentication requests from this IP. Please wait 60 seconds before retrying."
});

// 5. Dynamic Task & Content Submissions: max 40 actions / minute per user/IP
export const taskSubmitRateLimiter = createRateLimiter("task_submit", {
  windowMs: 60 * 1000,
  max: 40,
  message: "Task submission velocity exceeds allowed threshold. Please wait before submitting more tasks."
});

// 6. Cashout / Withdrawals: max 5 submissions / minute per user/IP
export const withdrawalRateLimiter = createRateLimiter("withdrawals_create", {
  windowMs: 60 * 1000,
  max: 5,
  message: "Withdrawal submission rate limit reached. Only 5 requests allowed per minute."
});

// 7. Global API Protection: max 300 requests / minute per IP
export const globalApiRateLimiter = createRateLimiter("global_api", {
  windowMs: 60 * 1000,
  max: 300,
  message: "API rate limit reached. Please reduce request frequency."
});

/**
 * Returns telemetry metrics for the rate limiting system
 */
export function getRateLimiterMetrics() {
  let activeTrackedKeys = 0;
  for (const [, store] of rateLimitStores.entries()) {
    activeTrackedKeys += store.size;
  }

  const topThrottledRoutes: Array<{ route: string; count: number }> = [];
  for (const [route, count] of throttledRoutesCount.entries()) {
    topThrottledRoutes.push({ route, count });
  }
  topThrottledRoutes.sort((a, b) => b.count - a.count);

  return {
    totalThrottledRequests,
    activeTrackedKeys,
    activeBucketsCount: rateLimitStores.size,
    topThrottledRoutes: topThrottledRoutes.slice(0, 10)
  };
}
