/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { readDB, writeDB } from "./db.js";
import { processMissionRewards } from "./rewards.js";

// Retrieve the list of active missions
export function getActiveMissions(all: boolean = false) {
  const db = readDB();
  let list = all ? db.missions : db.missions.filter((m: any) => m.isActive);
  // Sort missions by administrative priority order
  return list.sort((a: any, b: any) => a.order - b.order);
}

// Retrieve mission logs for a specific authenticated user
export function getUserMissionLogs(userId: string) {
  const db = readDB();
  return db.missionLogs.filter((l: any) => l.userId === userId);
}

// Verify and process complete mission task
export function verifyAndCompleteMission(userId: string, missionId: string) {
  const db = readDB();

  // REQUIREMENT: Platform controller must always verify the authenticated user before allowing any mission to start/complete.
  const user = db.users.find((u: any) => u.id === userId);
  if (!user) {
    throw new Error("Security verification failed: Authenticated account not found.");
  }

  if (user.status !== "active" || user.isBanned || user.risk_status === 'RESTRICTED' || user.risk_status === 'BANNED') {
    throw new Error("Account restriction: Your account is under security review. Task execution and earnings are temporarily paused.");
  }

  const mission = db.missions.find((m: any) => m.id === missionId);
  if (!mission) {
    throw new Error("Invalid request: Specified task/mission does not exist.");
  }

  // Cooldown validation
  if (mission.cooldownHours) {
    const logs = db.missionLogs
      .filter((l: any) => l.userId === userId && l.missionId === missionId)
      .sort((a: any, b: any) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());

    const lastCompleted = logs[0];
    if (lastCompleted) {
      const hoursSince = (Date.now() - new Date(lastCompleted.completedAt).getTime()) / (3600 * 1000);
      if (hoursSince < mission.cooldownHours) {
        const remainingHours = Math.ceil(mission.cooldownHours - hoursSince);
        throw new Error(`Cooldown active: Please wait ${remainingHours} hours before repeating this task.`);
      }
    }
  } else {
    // One-time mission validation
    const alreadyDone = db.missionLogs.some((l: any) => l.userId === userId && l.missionId === missionId);
    if (alreadyDone) {
      throw new Error("Task completed: This is a one-time reward mission and has already been claimed.");
    }
  }

  // Record mission completion log
  const logId = "ml-" + Date.now();
  const rewardPoints = mission.rewardPoints || mission.pointsReward || 100;

  db.missionLogs.push({
    id: logId,
    userId,
    missionId,
    completedAt: new Date().toISOString(),
    pointsEarned: rewardPoints
  });

  // Increment task stats
  user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + 1;

  writeDB(db);

  // Invoke main platform Reward Controller to process points, referrals commission, and notifications
  const result = processMissionRewards(userId, missionId, rewardPoints, mission.title);

  return {
    success: true,
    pointsEarned: rewardPoints,
    newPointsTotal: result.newPointsTotal
  };
}
