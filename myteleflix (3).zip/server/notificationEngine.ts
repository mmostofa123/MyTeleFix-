/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import { 
  readDB, 
  writeDB, 
  DBState, 
  NotificationRecord, 
  NotificationType 
} from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";

// Allowed Notification Types for VRMS-3 ULTRA Phase 12
export const VALID_NOTIFICATION_TYPES: NotificationType[] = [
  'SYSTEM',
  'VERIFICATION',
  'SALARY',
  'SECURITY',
  'MILESTONE'
];

/**
 * High-performance In-Memory Composite Index:
 * Maps (user_id, is_read, created_at)
 * - userNotificationsMap: user_id -> all NotificationRecords sorted by created_at DESC
 * - userCompositeIndex: `${user_id}::${is_read}` -> NotificationRecords sorted by created_at DESC
 */
const userNotificationsMap = new Map<string, NotificationRecord[]>();
const userCompositeIndex = new Map<string, NotificationRecord[]>();
let indexesInitialized = false;

/**
 * Synchronize and build index on (user_id, is_read, created_at)
 */
export function syncNotificationIndexes(db?: DBState): void {
  const targetDb = db || readDB();
  if (!targetDb.notifications || !Array.isArray(targetDb.notifications)) {
    targetDb.notifications = [];
  }

  userNotificationsMap.clear();
  userCompositeIndex.clear();

  // Normalize notifications to ensure strict schema compliance
  for (const notif of targetDb.notifications) {
    const norm = normalizeNotification(notif);
    
    // Group by user_id
    const userList = userNotificationsMap.get(norm.user_id) || [];
    userList.push(norm);
    userNotificationsMap.set(norm.user_id, userList);

    // Group by composite key (user_id, is_read)
    const compositeKey = `${norm.user_id}::${norm.is_read}`;
    const compositeList = userCompositeIndex.get(compositeKey) || [];
    compositeList.push(norm);
    userCompositeIndex.set(compositeKey, compositeList);
  }

  // Sort each list by created_at DESC
  for (const [, list] of userNotificationsMap.entries()) {
    list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }
  for (const [, list] of userCompositeIndex.entries()) {
    list.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  }

  indexesInitialized = true;
}

/**
 * Normalizes notification object to conform to VRMS-3 Ultra Phase 12 schema
 */
function normalizeNotification(n: any): NotificationRecord {
  const notifId = n.notification_id || n.id || `notif_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const userId = n.user_id || n.userId || 'all';
  const isRead = typeof n.is_read === 'boolean' ? n.is_read : (typeof n.isRead === 'boolean' ? n.isRead : false);
  const createdAt = n.created_at || n.timestamp || new Date().toISOString();

  // Validate or infer type
  let type: NotificationType = 'SYSTEM';
  if (n.type && VALID_NOTIFICATION_TYPES.includes(n.type)) {
    type = n.type;
  } else if (typeof n.type === 'string') {
    const upper = n.type.toUpperCase();
    if (upper.includes('VERIF')) type = 'VERIFICATION';
    else if (upper.includes('SALAR')) type = 'SALARY';
    else if (upper.includes('SECUR') || upper.includes('RISK') || upper.includes('BAN')) type = 'SECURITY';
    else if (upper.includes('MILESTONE')) type = 'MILESTONE';
    else type = 'SYSTEM';
  } else {
    // Check title/message keywords
    const text = `${n.title || ''} ${n.message || ''}`.toLowerCase();
    if (text.includes('verif') || text.includes('quiz') || text.includes('কুইজ')) type = 'VERIFICATION';
    else if (text.includes('salary') || text.includes('স্যালারি') || text.includes('মাসিক বেতন')) type = 'SALARY';
    else if (text.includes('milestone') || text.includes('মাইলস্টোন')) type = 'MILESTONE';
    else if (text.includes('restrict') || text.includes('suspicious') || text.includes('security') || text.includes('নিরাপত্তা')) type = 'SECURITY';
  }

  n.notification_id = notifId;
  n.user_id = userId;
  n.title = n.title || 'System Notification';
  n.message = n.message || '';
  n.type = type;
  n.reference_id = n.reference_id || undefined;
  n.is_read = isRead;
  n.created_at = createdAt;

  // Compatibility fields
  n.id = notifId;
  n.userId = userId;
  n.isRead = isRead;
  n.timestamp = createdAt;

  return n as NotificationRecord;
}

/**
 * Server-authoritative Notification Creation
 * Strictly creates and indexes notifications originating from backend events
 */
export function createNotification(
  params: {
    user_id: string;
    title: string;
    message: string;
    type: NotificationType;
    reference_id?: string;
  },
  db?: DBState
): NotificationRecord {
  const targetDb = db || readDB();
  if (!targetDb.notifications || !Array.isArray(targetDb.notifications)) {
    targetDb.notifications = [];
  }

  const nowISO = new Date().toISOString();
  const notifId = `notif_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;

  const notification: NotificationRecord = {
    notification_id: notifId,
    user_id: params.user_id,
    title: params.title,
    message: params.message,
    type: VALID_NOTIFICATION_TYPES.includes(params.type) ? params.type : 'SYSTEM',
    reference_id: params.reference_id,
    is_read: false,
    created_at: nowISO,
    // Compatibility fields
    id: notifId,
    userId: params.user_id,
    isRead: false,
    timestamp: nowISO
  };

  // Prepend for recent-first order
  targetDb.notifications.unshift(notification);

  // Keep memory index in sync
  syncNotificationIndexes(targetDb);

  // Commit database state atomically
  if (!db) {
    writeDB(targetDb);
  }

  // Sync to Firestore if writable
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        await setDoc(doc(firestore, "notifications", notifId), notification, { merge: true });
      }
    } catch {
      // Non-blocking firestore sync
    }
  })();

  return notification;
}

/**
 * Fetch Paginated User Notifications with Real-Time Total Unread Count
 * Utilizes the composite index (user_id, is_read, created_at)
 */
export function getUserNotifications(
  userId: string,
  options?: {
    page?: number;
    limit?: number;
    type?: NotificationType;
    unread_only?: boolean;
  },
  db?: DBState
): {
  notifications: NotificationRecord[];
  unread_count: number;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
} {
  const targetDb = db || readDB();
  if (!indexesInitialized) {
    syncNotificationIndexes(targetDb);
  }

  const cleanUserId = (userId || "").trim();
  const page = Math.max(1, options?.page || 1);
  const limit = Math.min(100, Math.max(1, options?.limit || 20));

  // Retrieve user direct items + system broadcast items ('all')
  const userItems = userNotificationsMap.get(cleanUserId) || [];
  const broadcastItems = cleanUserId !== 'all' ? (userNotificationsMap.get('all') || []) : [];

  // Combine and deduplicate
  const allMap = new Map<string, NotificationRecord>();
  for (const item of userItems) {
    allMap.set(item.notification_id, item);
  }
  for (const item of broadcastItems) {
    allMap.set(item.notification_id, item);
  }

  let combined = Array.from(allMap.values());
  // Sort by created_at DESC
  combined.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  // Real-time unread count calculated accurately across user's relevant alerts
  const unread_count = combined.filter(n => !n.is_read).length;

  // Filter by type if provided
  if (options?.type) {
    combined = combined.filter(n => n.type === options.type);
  }

  // Filter unread_only if requested
  if (options?.unread_only) {
    combined = combined.filter(n => !n.is_read);
  }

  const total = combined.length;
  const totalPages = Math.ceil(total / limit) || 1;
  const startIndex = (page - 1) * limit;
  const paginatedList = combined.slice(startIndex, startIndex + limit);

  return {
    notifications: paginatedList,
    unread_count,
    total,
    page,
    limit,
    totalPages
  };
}

/**
 * Mark specified notification IDs (or all) as read for a user
 */
export function markNotificationsAsRead(
  params: {
    userId: string;
    notificationIds?: string[];
    all?: boolean;
  },
  db?: DBState
): {
  success: boolean;
  marked_count: number;
  unread_count: number;
} {
  const targetDb = db || readDB();
  if (!targetDb.notifications) targetDb.notifications = [];

  const cleanUserId = (params.userId || "").trim();
  const idSet = new Set<string>(params.notificationIds || []);
  let markedCount = 0;

  for (const notif of targetDb.notifications) {
    const isTargetUser = notif.user_id === cleanUserId || notif.user_id === 'all' || notif.userId === cleanUserId;
    if (!isTargetUser) continue;

    if (params.all) {
      if (!notif.is_read) {
        notif.is_read = true;
        notif.isRead = true;
        markedCount++;
      }
    } else if (idSet.has(notif.notification_id) || (notif.id && idSet.has(notif.id))) {
      if (!notif.is_read) {
        notif.is_read = true;
        notif.isRead = true;
        markedCount++;
      }
    }
  }

  if (markedCount > 0) {
    syncNotificationIndexes(targetDb);
    if (!db) {
      writeDB(targetDb);
    }

    // Sync marked items to Firestore
    (async () => {
      try {
        if (await isFirestoreWritable()) {
          for (const notif of targetDb.notifications) {
            const isTargetUser = notif.user_id === cleanUserId || notif.user_id === 'all';
            if (isTargetUser && notif.is_read) {
              await setDoc(doc(firestore, "notifications", notif.notification_id), { is_read: true, isRead: true }, { merge: true });
            }
          }
        }
      } catch {}
    })();
  }

  const { unread_count } = getUserNotifications(cleanUserId, {}, targetDb);

  return {
    success: true,
    marked_count: markedCount,
    unread_count
  };
}

// ==========================================
// VRMS-3 ULTRA (Phase 12) INTERNAL EVENT HOOKS
// ==========================================

/**
 * Phase 3 Hook: Emit alert on 'VERIFIED' status or Quiz failure
 */
export function emitVerificationAlert(
  userId: string,
  event: 'PASSED' | 'FAILED',
  score?: number,
  referenceId?: string,
  db?: DBState
): NotificationRecord {
  if (event === 'PASSED') {
    return createNotification({
      user_id: userId,
      title: "🎉 অ্যাকাউন্ট ভেরিফিকেশন সফল (Account Verified)!",
      message: "অভিনন্দন! আপনার অ্যাকাউন্ট সফলভাবে ভেরিফাইড হয়েছে। কোয়ালিফাইড রেফারেল ও মাসিক স্যালারি সুবিধা এখন সক্রিয়।",
      type: 'VERIFICATION',
      reference_id: referenceId
    }, db);
  } else {
    return createNotification({
      user_id: userId,
      title: "⚠️ কুইজ ভেরিফিকেশন অসম্পূর্ণ (Quiz Incomplete)",
      message: `হিউম্যান ভেরিফিকেশন কুইজে স্কোর ছিল ${score !== undefined ? score : 0}/৩। সফল হতে ৩/৩ স্কোর প্রয়োজন। একটি নতুন প্রশ্ন সেট তৈরি করা হয়েছে, অনুগ্রহ করে পুনরায় চেষ্টা করুন।`,
      type: 'VERIFICATION',
      reference_id: referenceId
    }, db);
  }
}

/**
 * Phase 5 Hook: Emit alert when user reaches Day 25 inactivity warning
 */
export function emitInactivityWarningAlert(
  userId: string,
  inactivityDays: number,
  db?: DBState
): NotificationRecord {
  return createNotification({
    user_id: userId,
    title: "⚠️ অ্যাকাউন্ট নিষ্ক্রিয়তার সতর্কতা (Inactivity Warning)",
    message: `আপনার অ্যাকাউন্টটি ${inactivityDays} দিন ধরে নিষ্ক্রিয় রয়েছে। অ্যাকাউন্ট সক্রিয় রাখতে এবং ৩০ দিনে স্বয়ংক্রিয় পার্জ এড়াতে এখনই কোনো টাস্ক বা ভিডিও সম্পন্ন করুন।`,
    type: 'SYSTEM',
    reference_id: `inact_warn_${userId}`
  }, db);
}

/**
 * Phase 6 Hook: Emit alert on Milestone reward unlocking or claim
 */
export function emitMilestoneAlert(
  userId: string,
  milestoneId: string,
  threshold: number,
  amount: number,
  title?: string,
  actionType: 'UNLOCKED' | 'CLAIMED' | 'REVERSED' = 'CLAIMED',
  reversalReason?: string,
  db?: DBState
): NotificationRecord {
  if (actionType === 'REVERSED') {
    return createNotification({
      user_id: userId,
      title: "⚠️ রেফারেল মাইলস্টোন রিভার্সাল (Milestone Adjustment)",
      message: `মাইলস্টোন ${milestoneId.toUpperCase()} রিওয়ার্ড অডিট পর্যালোচনায় রিভার্স করা হয়েছে: ${reversalReason || 'Audit compliance'}.`,
      type: 'MILESTONE',
      reference_id: milestoneId
    }, db);
  }

  const isClaimed = actionType === 'CLAIMED';
  return createNotification({
    user_id: userId,
    title: isClaimed 
      ? `🎉 মাইলস্টোন ${milestoneId.toUpperCase()} রিওয়ার্ড দাবি সম্পন্ন!`
      : `🌟 নতুন মাইলস্টোন আনলক হয়েছে: ${title || milestoneId.toUpperCase()}!`,
    message: isClaimed
      ? `অভিনন্দন! আপনি ${threshold} জন কোয়ালিফাইড রেফারেলের মাইলস্টোন সম্পন্ন করেছেন এবং +${amount.toLocaleString()} রিওয়ার্ড পেয়েছেন!`
      : `আপনি ${threshold} জন কোয়ালিফাইড রেফারেলের লক্ষ্য অর্জন করেছেন। অবিলম্বে +${amount.toLocaleString()} রিওয়ার্ডটি ক্লেইম করুন!`,
    type: 'MILESTONE',
    reference_id: milestoneId
  }, db);
}

/**
 * Phase 9-10 Hook: Emit alert on Salary Request approval, hold, rejection, or payment settlement
 */
export function emitSalaryStatusAlert(
  userId: string,
  requestId: string,
  amount: number,
  status: 'APPROVED' | 'HOLD' | 'REJECTED' | 'PAID' | string,
  details?: {
    adminNote?: string;
    rejectionReason?: string;
    paymentMethod?: string;
    transactionReference?: string;
  },
  db?: DBState
): NotificationRecord {
  let title = `Monthly Salary Update: ${status}`;
  let message = `Your monthly salary claim (${requestId}) for ৳${amount} BDT status has transitioned to ${status}.`;

  if (status === 'APPROVED') {
    title = "✅ Monthly Salary Request Approved!";
    message = `Your salary claim (${requestId}) for ৳${amount} BDT has been APPROVED by the admin! Payout is queued for manual transfer via your registered payment profile.`;
  } else if (status === 'HOLD') {
    title = "⏸️ Monthly Salary Request On Hold";
    message = `Your salary claim (${requestId}) is on temporary administrative hold. Note: ${details?.adminNote || 'Administrative verification in progress.'}`;
  } else if (status === 'REJECTED') {
    title = "❌ Monthly Salary Request Rejected";
    message = `Your salary claim (${requestId}) was rejected. Reason: ${details?.rejectionReason || 'Compliance requirements not fulfilled.'}`;
  } else if (status === 'PAID') {
    const pMethod = details?.paymentMethod || 'bKash/Nagad/USDT';
    const trxRef = details?.transactionReference || 'MANUAL-DISPATCH';
    title = "🎉 Monthly Salary Paid!";
    message = `Congratulations! Your monthly salary of ৳${amount} BDT has been successfully paid via ${pMethod} (Ref: ${trxRef}). Please check your payment account.`;
  }

  return createNotification({
    user_id: userId,
    title,
    message,
    type: 'SALARY',
    reference_id: requestId
  }, db);
}

/**
 * Phase 11 Hook: Emit alert if risk status transitions to 'RESTRICTED'
 */
export function emitSecurityRestrictionAlert(
  userId: string,
  reason: string,
  referenceId?: string,
  db?: DBState
): NotificationRecord {
  return createNotification({
    user_id: userId,
    title: "🛡️ অ্যাকাউন্ট নিরাপত্তা সীমাবদ্ধতা (Security Restriction)",
    message: `নিরাপত্তা সতর্কতার কারণে আপনার অ্যাকাউন্টে বিধিনিষেধ আরোপ করা হয়েছে: ${reason || 'Multi-signal risk threshold reached'}. কোনো ভুল মনে হলে সহায়তার সাথে যোগাযোগ করুন।`,
    type: 'SECURITY',
    reference_id: referenceId
  }, db);
}
