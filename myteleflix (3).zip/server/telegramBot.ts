/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Telegram Bot Engine & Webhook Server (Phase 5 Master Architecture)
 * - Multi-Channel Verification Scanner (up to 10 channels in under 1 second)
 * - Dynamic Verification Locking & Once-in-a-Lifetime Unlocking
 * - Message Edit Logic (in-place message update without sending new messages)
 * - Anti-Copyright Redirection (points to Third-Party File Store Bot deep link)
 * - Real-time Signal Handshake Listener with sub-second response
 */

import { Router, Request, Response } from "express";
import { readDB } from "./db.js";
import { 
  lockTelegramUserInDb, 
  getContentMappingFromDb, 
  getDownloadRequestForUser, 
  markDownloadRequestCompleted,
  findPendingDownloadRequest,
  updateDownloadRequestStatus,
  isUserChannelVerified,
  setUserChannelVerified
} from "./firebaseAdmin.js";
import { generateAiSupportResponse } from "./aiSupportAssistant.js";

const router = Router();

// Retrieve Telegram Bot Token from environment or DB settings
export function getBotToken(): string {
  if (process.env.TELEGRAM_BOT_TOKEN) {
    return process.env.TELEGRAM_BOT_TOKEN.trim();
  }
  try {
    const db = readDB();
    if (db.settings?.telegramBotToken) {
      return String(db.settings.telegramBotToken).trim();
    }
    if (db.settings?.telegaBotToken) {
      return String(db.settings.telegaBotToken).trim();
    }
  } catch {}
  return "";
}

// Telegram Bot API URL helper
export function getTelegramApiUrl(endpoint: string, customToken?: string): string {
  const token = customToken || getBotToken();
  return `https://api.telegram.org/bot${token}/${endpoint}`;
}

/**
 * Sends a new message via Telegram Bot API
 */
export async function sendTelegramMessage(
  chatId: number | string,
  text: string,
  extra?: {
    parse_mode?: "HTML" | "Markdown" | "MarkdownV2";
    reply_markup?: any;
    disable_web_page_preview?: boolean;
  }
): Promise<{ ok: boolean; result?: any; description?: string }> {
  const token = getBotToken();
  if (!token) {
    console.warn("[Telegram Bot] Cannot send message: TELEGRAM_BOT_TOKEN not configured.");
    return { ok: false, description: "TELEGRAM_BOT_TOKEN is not configured" };
  }

  try {
    const url = getTelegramApiUrl("sendMessage", token);
    const body: any = {
      chat_id: chatId,
      text,
      parse_mode: extra?.parse_mode || "HTML",
      disable_web_page_preview: extra?.disable_web_page_preview ?? false,
    };

    if (extra?.reply_markup) {
      body.reply_markup = extra.reply_markup;
    }

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    return await response.json();
  } catch (err: any) {
    console.error("[Telegram Bot] Send message network error:", err);
    return { ok: false, description: err.message };
  }
}

/**
 * Sends a chat action (e.g. typing) via Telegram Bot API
 */
export async function sendChatAction(
  chatId: number | string,
  action: "typing" | "upload_document" = "typing"
): Promise<boolean> {
  const token = getBotToken();
  if (!token) return false;
  try {
    const url = getTelegramApiUrl("sendChatAction", token);
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, action }),
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * PHASE 5: MESSAGE EDIT LOGIC
 * Edits an existing message in-place without sending a new message
 */
export async function editTelegramMessage(
  chatId: number | string,
  messageId: number,
  text: string,
  extra?: {
    parse_mode?: "HTML" | "Markdown" | "MarkdownV2";
    reply_markup?: any;
    disable_web_page_preview?: boolean;
  }
): Promise<{ ok: boolean; result?: any; description?: string }> {
  const token = getBotToken();
  if (!token) {
    return { ok: false, description: "TELEGRAM_BOT_TOKEN is not configured" };
  }

  try {
    const url = getTelegramApiUrl("editMessageText", token);
    const body: any = {
      chat_id: chatId,
      message_id: messageId,
      text,
      parse_mode: extra?.parse_mode || "HTML",
      disable_web_page_preview: extra?.disable_web_page_preview ?? false,
    };

    if (extra?.reply_markup) {
      body.reply_markup = extra.reply_markup;
    }

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    return await response.json();
  } catch (err: any) {
    console.error("[Telegram Bot] Edit message error:", err);
    return { ok: false, description: err.message };
  }
}

/**
 * Answers a Telegram callback query with toast or modal alert
 */
export async function answerCallbackQuery(
  callbackQueryId: string,
  text?: string,
  showAlert: boolean = false
): Promise<{ ok: boolean; description?: string }> {
  const token = getBotToken();
  if (!token) return { ok: false, description: "TELEGRAM_BOT_TOKEN not configured" };

  try {
    const url = getTelegramApiUrl("answerCallbackQuery", token);
    const body: any = {
      callback_query_id: callbackQueryId,
      show_alert: showAlert,
    };
    if (text) body.text = text;

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return await response.json();
  } catch (err: any) {
    console.error("[Telegram Bot] answerCallbackQuery error:", err);
    return { ok: false, description: err.message };
  }
}

/**
 * Set or update the Telegram Webhook URL
 */
export async function registerTelegramWebhook(webhookUrl: string): Promise<any> {
  const token = getBotToken();
  if (!token) {
    throw new Error("TELEGRAM_BOT_TOKEN is not configured in server environment.");
  }

  const url = getTelegramApiUrl("setWebhook", token);
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url: webhookUrl,
      allowed_updates: ["message", "callback_query"],
      drop_pending_updates: false,
    }),
  });

  return await response.json();
}

// ==========================================
// PHASE 5: MULTI-CHANNEL VERIFICATION SCANNER
// ==========================================

export interface RequiredChannel {
  id: string; // e.g. "@myteleflix", "-100123456789"
  title: string;
  inviteLink: string;
}

/**
 * Retrieves configured required channels (up to 10 channels)
 */
export function getConfiguredRequiredChannels(): RequiredChannel[] {
  // 1. Environment variable support (JSON array or comma-separated)
  if (process.env.REQUIRED_CHANNELS) {
    try {
      const parsed = JSON.parse(process.env.REQUIRED_CHANNELS);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.slice(0, 10).map((ch, idx) => ({
          id: typeof ch === "string" ? ch : ch.id || ch.channelId || `@channel_${idx + 1}`,
          title: typeof ch === "string" ? `📢 চ্যানেল ${idx + 1}` : ch.title || `📢 চ্যানেল ${idx + 1}`,
          inviteLink: typeof ch === "string" 
            ? (ch.startsWith("http") ? ch : `https://t.me/${ch.replace(/^@/, "")}`) 
            : ch.inviteLink || `https://t.me/${(ch.id || "").replace(/^@/, "")}`,
        }));
      }
    } catch {
      const list = process.env.REQUIRED_CHANNELS.split(",").map((s) => s.trim()).filter(Boolean);
      if (list.length > 0) {
        return list.slice(0, 10).map((ch, idx) => ({
          id: ch,
          title: `📢 চ্যানেল ${idx + 1}`,
          inviteLink: ch.startsWith("http") ? ch : `https://t.me/${ch.replace(/^@/, "")}`,
        }));
      }
    }
  }

  // 2. Database settings
  try {
    const db = readDB();
    if (db.settings?.requiredChannels && Array.isArray(db.settings.requiredChannels) && db.settings.requiredChannels.length > 0) {
      return db.settings.requiredChannels.slice(0, 10);
    }
    if (db.communitySettings?.requiredChannels && Array.isArray(db.communitySettings.requiredChannels)) {
      return db.communitySettings.requiredChannels.slice(0, 10);
    }
  } catch {}

  // 3. Robust default channel configuration (3 channels, expandable up to 10)
  return [
    { id: "@myteleflix", title: "📢 অফিশিয়াল মেইন চ্যানেল", inviteLink: "https://t.me/myteleflix" },
    { id: "@myteleflix_movies", title: "🎬 টেলিফ্লিক্স মুভিজ হাব", inviteLink: "https://t.me/myteleflix" },
    { id: "@myteleflix_backup", title: "⚡ ব্যাকআপ ডিরেক্ট চ্যানেল", inviteLink: "https://t.me/myteleflix" },
  ];
}

/**
 * Checks single user membership in a channel using getChatMember
 */
export async function checkChannelMembership(
  channelIdOrUsername: string,
  userId: number | string
): Promise<boolean> {
  const token = getBotToken();
  if (!token) {
    // If running in development without live token, pass gracefully
    return true;
  }

  try {
    const cleanChat = channelIdOrUsername.trim();
    const url = getTelegramApiUrl(
      `getChatMember?chat_id=${encodeURIComponent(cleanChat)}&user_id=${encodeURIComponent(String(userId))}`,
      token
    );

    // Enforce 850ms timeout per check so 10 parallel checks complete in <1s
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 850);

    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);

    const data = await response.json();
    if (data.ok && data.result) {
      const status = data.result.status;
      // Valid joined membership statuses
      return status === "creator" || status === "administrator" || status === "member" || status === "restricted";
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Multi-Channel Verification Scanner:
 * Checks user membership against up to 10 channels in under 1 second via parallel execution
 */
export async function scanMultiChannelMembership(
  userId: number | string,
  channels: RequiredChannel[]
): Promise<{ allJoined: boolean; missingChannels: RequiredChannel[]; durationMs: number }> {
  const startTime = Date.now();
  const channelsToScan = channels.slice(0, 10);

  // Execute all channel checks simultaneously
  const results = await Promise.all(
    channelsToScan.map(async (ch) => {
      const isMember = await checkChannelMembership(ch.id, userId);
      return { channel: ch, isMember };
    })
  );

  const missingChannels = results.filter((r) => !r.isMember).map((r) => r.channel);
  const durationMs = Date.now() - startTime;
  console.log(`[Multi-Channel Scan] Checked ${channelsToScan.length} channels for user ${userId} in ${durationMs}ms (Missing: ${missingChannels.length})`);

  return {
    allJoined: missingChannels.length === 0,
    missingChannels,
    durationMs,
  };
}

/**
 * Builds the Phase 5 Channel Verification Locked UI message & buttons
 */
export function buildVerificationLockPayload(
  contentId: string,
  missingChannels: RequiredChannel[]
) {
  const text = `
⚠️ <b>আপনার অনুরোধকৃত ফাইলটি লক করা আছে!</b>

নিচের চ্যানেলগুলোতে জয়েন করুন (ভেরিফিকেশন জীবনে মাত্র ১ বার!):
  `.trim();

  // Create inline buttons: each missing channel gets an invite button
  const keyboardRows: any[][] = [];

  missingChannels.forEach((ch, idx) => {
    keyboardRows.push([
      {
        text: `📢 ${ch.title} | জয়েন করুন`,
        url: ch.inviteLink,
      },
    ]);
  });

  // Primary Action Button: [ ✅ Check Verification ]
  keyboardRows.push([
    {
      text: "✅ Check Verification",
      callback_data: `verify_channels:${contentId}`,
    },
  ]);

  return {
    text,
    reply_markup: {
      inline_keyboard: keyboardRows,
    },
  };
}

/**
 * Builds the Phase 5 Verified Unlocked UI message & Anti-Copyright Download Button
 */
export function buildVerifiedDeliveryPayload(
  contentTitle: string,
  contentId: string,
  universalTelegramLink: string,
  userMode: "GUEST" | "VIP" = "GUEST"
) {
  let text = `
🎉 <b>ভেরিফিকেশন সফল হয়েছে!</b>

নিচের বাটন থেকে আপনার কন্টেন্ট গ্রহণ করুন:
  `.trim();

  if (userMode === "GUEST") {
    text += `\n\n🌟 <b>Want to EARN from this download? Sign up now to unlock your VIP Wallet!</b>`;
  } else {
    text += `\n\n💎 <b>VIP Earning Credited:</b> +50 Points added to your VIP Wallet!`;
  }

  // ANTI-COPYRIGHT REDIRECTION (THIRD-PARTY BOT):
  // Main bot never stores or streams media files directly.
  // The button points to the Third-Party File Store Bot deep link containing the universal link hash.
  const inlineKeyboard = {
    inline_keyboard: [
      [
        {
          text: "📥 DOWNLOAD NOW",
          url: universalTelegramLink,
        },
      ],
      ...(userMode === "GUEST"
        ? [
            [
              {
                text: "🌟 Unlock VIP Wallet & Earn",
                url: process.env.APP_URL ? `${process.env.APP_URL}?action=signup` : "https://t.me/myteleflix",
              },
            ],
          ]
        : []),
      [
        {
          text: "🌐 MyTeleFlix Super App",
          url: process.env.APP_URL || "https://t.me/myteleflix",
        },
      ],
    ],
  };

  return {
    text,
    reply_markup: inlineKeyboard,
  };
}

// ==========================================
// COMMAND HANDLERS
// ==========================================

/**
 * PHASE 4 & 5: DYNAMIC SIGNAL HANDSHAKE, MULTI-CHANNEL SCAN & FILE DELIVERY
 * Handles `/start dl_{contentId}` payload in sub-second time.
 */
export async function handleStartPayloadCommand(
  chatId: number | string,
  fromUser: {
    id: number | string;
    username?: string;
    first_name?: string;
    last_name?: string;
  },
  payload: string
): Promise<void> {
  const startTime = Date.now();
  const telegramId = fromUser.id;
  const contentId = payload.replace(/^dl_/, "").trim();

  console.log(`[Handshake Listener] Received /start dl_${contentId} from Telegram user ${telegramId}`);

  // 1. Lock user identity permanently in collection 'users'
  lockTelegramUserInDb(telegramId, {
    username: fromUser.username,
    firstName: fromUser.first_name,
    lastName: fromUser.last_name,
  }).catch((err) => console.warn("[Lock User Notice]:", err));

  // 2. PHASE 4: INSTANT SIGNAL MATCHING ENGINE
  // Instantly query Firestore for pending record where telegramId == user.id AND status == "PENDING" AND contentId == extracted_content_id
  const pendingRequest = await findPendingDownloadRequest(telegramId, contentId);

  // 3. FALLBACK & TIMEOUT HANDLING
  if (!pendingRequest) {
    console.log(`[Handshake Listener] No PENDING request found for user ${telegramId} and content ${contentId}`);

    const fallbackHtml = `⚠️ <b>কোনো সক্রিয় অনুরোধ পাওয়া যায়নি!</b>\nঅনুগ্রহ করে ওয়েবসাইট থেকে ডাউনলোডে ক্লিক করে আবার চেষ্টা করুন।`;
    const appUrl = process.env.APP_URL || "https://t.me/myteleflix";

    await sendTelegramMessage(chatId, fallbackHtml, {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "🎬 ওয়েবসাইট / অ্যাপে যান",
              web_app: { url: appUrl },
            },
          ],
          [
            {
              text: "📢 অফিসিয়াল চ্যানেল",
              url: "https://t.me/myteleflix",
            },
          ],
        ],
      },
    });
    return;
  }

  // 4. Update request status to PROCESSING to prevent double-triggering
  await updateDownloadRequestStatus(pendingRequest.docId, "PROCESSING");

  // 5. Retrieve content details from content_mappings using contentId
  let mapping = await getContentMappingFromDb(contentId);
  if (!mapping) {
    try {
      const db = readDB();
      const movie = db.movies?.find((m: any) => m.id === contentId) || db.videos?.find((v: any) => v.id === contentId);
      if (movie) {
        mapping = {
          contentId,
          title: movie.title,
          universalTelegramLink: movie.universalTelegramLink || movie.originalLink || movie.banglaLink || movie.videoUrl || `https://t.me/myteleflix?start=dl_${contentId}`,
          category: movie.category || movie.contentType || "movie",
        };
      }
    } catch {}
  }

  const contentTitle = mapping?.title || pendingRequest.data?.contentTitle || `Content #${contentId}`;
  const targetDownloadLink = mapping?.universalTelegramLink || 
                             pendingRequest.data?.universalLink || 
                             `https://t.me/myteleflix`;

  // 6. PHASE 5: MULTI-CHANNEL VERIFICATION SCANNER
  // Check if user has already completed the once-in-a-lifetime verification
  const alreadyVerified = await isUserChannelVerified(telegramId);

  if (!alreadyVerified) {
    // Scan up to 10 channels in under 1 second
    const requiredChannels = getConfiguredRequiredChannels();
    const scan = await scanMultiChannelMembership(telegramId, requiredChannels);

    // If missing from ANY channel, send the dynamic verification lock message
    if (!scan.allJoined) {
      console.log(`[Phase 5] User ${telegramId} is missing ${scan.missingChannels.length} channels. Sending lock card.`);
      const lockPayload = buildVerificationLockPayload(contentId, scan.missingChannels);
      await sendTelegramMessage(chatId, lockPayload.text, {
        parse_mode: "HTML",
        reply_markup: lockPayload.reply_markup,
      });
      return;
    }

    // User is in all channels -> Mark verified permanently
    await setUserChannelVerified(telegramId);
  }

  // 7. If verified, send unlocked delivery with Anti-Copyright Third-Party deep link
  const durationMs = Date.now() - startTime;
  console.log(`[Handshake Listener] Delivered in ${durationMs}ms for ${contentTitle}`);

  const userMode: "GUEST" | "VIP" = (pendingRequest as any)?.userMode || ((pendingRequest as any)?.uid ? "VIP" : "GUEST");
  const deliveryPayload = buildVerifiedDeliveryPayload(contentTitle, contentId, targetDownloadLink, userMode);

  await sendTelegramMessage(chatId, deliveryPayload.text, {
    parse_mode: "HTML",
    reply_markup: deliveryPayload.reply_markup,
  });

  // Mark download request as COMPLETED (differentiating Guest vs VIP)
  markDownloadRequestCompleted(pendingRequest.docId, {
    forcedUserMode: userMode,
    uid: (pendingRequest as any)?.uid,
  }).catch(() => {});
}

/**
 * PHASE 5: CALLBACK QUERY HANDLER
 * Handles `[ ✅ Check Verification ]` inline button clicks and performs message editing
 */
export async function handleCallbackQuery(callbackQuery: any): Promise<void> {
  const queryId = callbackQuery.id;
  const data = (callbackQuery.data || "").trim();
  const fromUser = callbackQuery.from;
  const message = callbackQuery.message;

  if (!fromUser || !message) {
    await answerCallbackQuery(queryId);
    return;
  }

  const telegramId = fromUser.id;
  const chatId = message.chat?.id;
  const messageId = message.message_id;

  // Pattern: verify_channels:{contentId}
  if (data.startsWith("verify_channels:")) {
    const contentId = data.replace(/^verify_channels:/, "").trim();

    // 1. Re-scan membership in under 1 second
    const requiredChannels = getConfiguredRequiredChannels();
    const scan = await scanMultiChannelMembership(telegramId, requiredChannels);

    // If STILL missing from channels:
    if (!scan.allJoined) {
      // Alert popup informing user
      await answerCallbackQuery(
        queryId,
        `⚠️ আপনি এখনো ${scan.missingChannels.length}টি চ্যানেলে জয়েন করেননি! সব চ্যানেলে জয়েন করে আবার চেক করুন।`,
        true
      );

      // Refresh existing message with updated remaining channels
      const lockPayload = buildVerificationLockPayload(contentId, scan.missingChannels);
      await editTelegramMessage(chatId, messageId, lockPayload.text, {
        parse_mode: "HTML",
        reply_markup: lockPayload.reply_markup,
      });
      return;
    }

    // 2. VERIFIED: User has joined all channels!
    await answerCallbackQuery(queryId, "🎉 ভেরিফিকেশন সফল হয়েছে!", false);

    // Lock verified state in Firestore permanently
    await setUserChannelVerified(telegramId);

    // 3. Fetch content details
    let mapping = await getContentMappingFromDb(contentId);
    if (!mapping) {
      try {
        const db = readDB();
        const movie = db.movies?.find((m: any) => m.id === contentId) || db.videos?.find((v: any) => v.id === contentId);
        if (movie) {
          mapping = {
            contentId,
            title: movie.title,
            universalTelegramLink: movie.universalTelegramLink || movie.originalLink || movie.banglaLink || movie.videoUrl || `https://t.me/myteleflix?start=dl_${contentId}`,
            category: movie.category || movie.contentType || "movie",
          };
        }
      } catch {}
    }

    const contentTitle = mapping?.title || `Content #${contentId}`;
    const universalLink = mapping?.universalTelegramLink || `https://t.me/myteleflix`;

    // 4. PHASE 5 MESSAGE EDIT LOGIC:
    // EDIT the existing message (do NOT send a new message!)
    const userReq = await getDownloadRequestForUser(telegramId, contentId);
    const userMode: "GUEST" | "VIP" = (userReq as any)?.data?.userMode || ((userReq as any)?.data?.uid ? "VIP" : "GUEST");
    const verifiedPayload = buildVerifiedDeliveryPayload(contentTitle, contentId, universalLink, userMode);

    await editTelegramMessage(chatId, messageId, verifiedPayload.text, {
      parse_mode: "HTML",
      reply_markup: verifiedPayload.reply_markup,
    });

    // 5. Complete download request in Firestore (differentiating Guest vs VIP)
    if (userReq) {
      markDownloadRequestCompleted(userReq.docId, {
        forcedUserMode: userMode,
        uid: (userReq as any)?.data?.uid,
      }).catch(() => {});
    }
    return;
  }

  // Pattern: ai_faq:{topic}
  if (data.startsWith("ai_faq:")) {
    await answerCallbackQuery(queryId, "🤖 TeleFlix AI Support");
    const topic = data.replace(/^ai_faq:/, "").trim();
    let promptQuery = "How to download content on MyTeleFlix?";
    if (topic === "wallet_vip") {
      promptQuery = "Explain the Wallet cashout, bKash & Nagad withdrawal rules, and Guest vs VIP mode.";
    }

    sendChatAction(chatId, "typing").catch(() => {});
    const aiResponse = await generateAiSupportResponse({
      userQuery: promptQuery,
      fromUser,
      chatId,
    });

    const replyMarkup = {
      inline_keyboard: [
        [
          {
            text: "🌐 Launch MyTeleFlix Super App",
            url: process.env.APP_URL || "https://t.me/myteleflix",
          },
        ],
        [
          {
            text: "🎬 How to Download",
            callback_data: "ai_faq:how_to_download",
          },
          {
            text: "💰 Wallet & VIP Rules",
            callback_data: "ai_faq:wallet_vip",
          },
        ],
      ],
    };

    await sendTelegramMessage(chatId, aiResponse, {
      parse_mode: "HTML",
      disable_web_page_preview: true,
      reply_markup: replyMarkup,
    });
    return;
  }

  // Acknowledge any other callback query
  await answerCallbackQuery(queryId);
}

/**
 * Handles regular /start command without payload
 */
export async function handleStandardStartCommand(
  chatId: number | string,
  fromUser: {
    id: number | string;
    username?: string;
    first_name?: string;
    last_name?: string;
  }
): Promise<void> {
  const telegramId = fromUser.id;
  const firstName = fromUser.first_name || "Friend";

  // Lock user in collection 'users'
  lockTelegramUserInDb(telegramId, {
    username: fromUser.username,
    firstName: fromUser.first_name,
    lastName: fromUser.last_name,
  }).catch(() => {});

  const appUrl = process.env.APP_URL || "https://t.me/myteleflix";

  const messageHtml = `
👋 <b>Welcome to MyTeleFlix, ${escapeHtml(firstName)}!</b>

🍿 <b>Your All-In-One Cinema & Entertainment Hub:</b>
• 🎬 10,000+ Movies & Web Series in HD
• 🎧 Dual Audio: Bangla, Hindi, English Dubbed
• ⚡ 24/7 Ultra High-Speed Direct Downloads
• 🎁 Earn points and unlock VIP access

Tap below to browse the catalog and get instant downloads!
  `.trim();

  const inlineKeyboard = {
    inline_keyboard: [
      [
        {
          text: "🎬 Open MyTeleFlix Super App",
          web_app: { url: appUrl },
        },
      ],
      [
        {
          text: "📢 Official Channel",
          url: "https://t.me/myteleflix",
        },
      ],
    ],
  };

  await sendTelegramMessage(chatId, messageHtml, {
    parse_mode: "HTML",
    reply_markup: inlineKeyboard,
  });
}

/**
 * Main Webhook Dispatcher
 */
export async function processTelegramUpdate(update: any): Promise<void> {
  if (!update) return;

  // Handle Callback Queries (e.g. [ ✅ Check Verification ])
  if (update.callback_query) {
    await handleCallbackQuery(update.callback_query);
    return;
  }

  // Handle Standard Messages
  if (update.message) {
    const msg = update.message;
    const chatId = msg.chat?.id;
    const text = (msg.text || "").trim();
    const fromUser = msg.from;

    if (!chatId || !fromUser) return;

    // Command: /start or /start <payload>
    if (text.startsWith("/start")) {
      const parts = text.split(/\s+/);
      const payload = parts[1] || "";

      if (payload.startsWith("dl_")) {
        await handleStartPayloadCommand(chatId, fromUser, payload);
      } else {
        await handleStandardStartCommand(chatId, fromUser);
      }
      return;
    }

    // Command: /ping
    if (text === "/ping") {
      const uptimeSec = Math.floor(process.uptime());
      await sendTelegramMessage(
        chatId,
        `🏓 <b>Pong!</b>\n⏱️ Server Uptime: <code>${uptimeSec}s</code>\n⚡ Engine: <code>MyTeleFlix 24/7 Telegram Engine v3</code>`
      );
      return;
    }

    // Command: /help or /support
    if (text === "/help" || text === "/support") {
      sendChatAction(chatId, "typing").catch(() => {});
      const welcomeSupport = await generateAiSupportResponse({
        userQuery: "Hello, I need help with MyTeleFlix.",
        fromUser,
        chatId,
      });

      const replyMarkup = {
        inline_keyboard: [
          [
            {
              text: "🌐 Launch MyTeleFlix Super App",
              url: process.env.APP_URL || "https://t.me/myteleflix",
            },
          ],
          [
            {
              text: "🎬 How to Download",
              callback_data: "ai_faq:how_to_download",
            },
            {
              text: "💰 Wallet & VIP Rules",
              callback_data: "ai_faq:wallet_vip",
            },
          ],
        ],
      };

      await sendTelegramMessage(chatId, welcomeSupport, {
        parse_mode: "HTML",
        reply_markup: replyMarkup,
        disable_web_page_preview: true,
      });
      return;
    }

    // Default fallback for other unknown slash command texts
    if (text.startsWith("/")) {
      await sendTelegramMessage(
        chatId,
        `❓ Unknown command. Send your question directly, type /help, or launch the Super App to browse movies.`
      );
      return;
    }

    // HUMAN-LIKE AI SUPPORT CONVERSATION:
    // When a user sends general text, question, or inquiry (not a /start dl_ command),
    // route it to the AI Customer Support Engine powered by LLM with strict guardrails!
    sendChatAction(chatId, "typing").catch(() => {});
    const aiResponse = await generateAiSupportResponse({
      userQuery: text,
      fromUser,
      chatId,
    });

    const replyMarkup = {
      inline_keyboard: [
        [
          {
            text: "🌐 Launch MyTeleFlix Super App",
            url: process.env.APP_URL || "https://t.me/myteleflix",
          },
        ],
        [
          {
            text: "🎬 How to Download",
            callback_data: "ai_faq:how_to_download",
          },
          {
            text: "💰 Wallet & VIP Rules",
            callback_data: "ai_faq:wallet_vip",
          },
        ],
      ],
    };

    await sendTelegramMessage(chatId, aiResponse, {
      parse_mode: "HTML",
      reply_markup: replyMarkup,
      disable_web_page_preview: true,
    });
  }
}

function escapeHtml(str: string): string {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ==========================================
// EXPRESS ROUTER ENDPOINTS
// ==========================================

/**
 * POST /api/telegram/webhook
 * Receives live updates from Telegram Bot Webhook
 */
router.post(["/telegram/webhook", "/webhook"], async (req: Request, res: Response) => {
  // Return HTTP 200 immediately to Telegram to prevent retry floods
  res.status(200).json({ ok: true });

  try {
    await processTelegramUpdate(req.body);
  } catch (err) {
    console.error("[Telegram Webhook] Error processing update:", err);
  }
});

/**
 * GET /api/telegram/webhook
 * Diagnostics and Webhook status
 */
router.get(["/telegram/webhook", "/webhook"], async (req: Request, res: Response) => {
  const token = getBotToken();
  if (!token) {
    return res.status(200).json({
      status: "CONFIG_REQUIRED",
      message: "TELEGRAM_BOT_TOKEN is not set yet. Configure TELEGRAM_BOT_TOKEN in .env or settings.",
    });
  }

  try {
    const url = getTelegramApiUrl("getWebhookInfo", token);
    const tgRes = await fetch(url);
    const data = await tgRes.json();
    return res.status(200).json({
      status: "ACTIVE",
      tokenConfigured: true,
      webhookInfo: data.result || data,
    });
  } catch (err: any) {
    return res.status(500).json({ status: "ERROR", error: err.message });
  }
});

/**
 * POST /api/telegram/set-webhook
 * Registers custom webhook URL
 */
router.post("/telegram/set-webhook", async (req: Request, res: Response) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: "url is required" });
    }
    const result = await registerTelegramWebhook(url);
    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

/**
 * GET /api/telegram/me
 * Retrieves bot profile information
 */
router.get("/telegram/me", async (req: Request, res: Response) => {
  const token = getBotToken();
  if (!token) {
    return res.status(400).json({ error: "TELEGRAM_BOT_TOKEN not configured" });
  }

  try {
    const url = getTelegramApiUrl("getMe", token);
    const tgRes = await fetch(url);
    const data = await tgRes.json();
    return res.json(data);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

export default router;
