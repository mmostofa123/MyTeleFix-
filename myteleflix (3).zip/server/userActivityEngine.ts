/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import { readDB, writeDB, DBState } from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";
import { touchAuthenticatedAccess } from "./purgeEngine.js";

export interface UserActivityRecord {
  activity_id: string;
  user_id: string;
  activity_type: 'TASK' | 'CONTENT';
  source_reference: string;
  activity_date: string; // YYYY-MM-DD
  validation_status: 'VALID' | 'INVALID' | 'DUPLICATE';
  idempotency_key: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export interface DailyActivityProgress {
  date: string;
  tasks_completed: number;
  tasks_required: number;
  content_completed: number;
  content_required: number;
  active_day_earned: boolean;
  tasks_remaining: number;
  content_remaining: number;
}

export const SEVENTY_TWO_HOURS_MS = 72 * 60 * 60 * 1000;
export const REQUIRED_DAILY_TASKS = 10;
export const REQUIRED_DAILY_CONTENT = 5;

/**
 * Returns current calendar date string in YYYY-MM-DD format
 */
export function getTodayDateString(): string {
  return new Date().toISOString().split("T")[0];
}

/**
 * 72-Hour Inactivity Rule:
 * Evaluates whether user has had no qualifying activity for > 72 hours.
 * If inactive > 72h: resets active_day_streak = 0.
 * CRITICAL NON-NEGOTIABLE RULE: Cumulative lifetime valid actions (valid_action_count)
 * are NOT deleted or reset.
 */
export function evaluate72HourInactivityForUser(user: any): {
  resetApplied: boolean;
  inactiveHours: number;
} {
  if (!user || user.role === 'admin' || user.role === 'super_admin') {
    return { resetApplied: false, inactiveHours: 0 };
  }

  const lastActiveVal = user.last_activity_at || user.lastActiveAt || user.lastActiveTimestamp || user.lastLogin || user.createdAt;
  const lastActiveTime = typeof lastActiveVal === 'number'
    ? lastActiveVal
    : (lastActiveVal ? new Date(lastActiveVal).getTime() : 0);

  if (lastActiveTime <= 0) {
    return { resetApplied: false, inactiveHours: 0 };
  }

  const diffMs = Date.now() - lastActiveTime;
  const inactiveHours = Math.floor(diffMs / (3600 * 1000));

  if (diffMs > SEVENTY_TWO_HOURS_MS) {
    const currentStreak = user.active_day_streak || user.activeDaysCount || 0;
    if (currentStreak > 0) {
      console.log(`[UAE] 72-Hour Inactivity reset applied to user ${user.id} (${inactiveHours}h inactive). active_day_streak reset to 0. Cumulative valid_action_count (${user.valid_action_count || 0}) preserved.`);
      user.active_day_streak = 0;
      user.activeDaysCount = 0;
      return { resetApplied: true, inactiveHours };
    }
  }

  return { resetApplied: false, inactiveHours };
}

/**
 * Calculates user's daily progress towards the Active Day milestone:
 * EXACTLY 10 valid earning tasks + 5 valid content activities/downloads.
 */
export function getUserDailyActivityProgress(userId: string, db: DBState, targetDate?: string): DailyActivityProgress {
  const date = targetDate || getTodayDateString();
  const activities = (db.user_activity || []).filter(
    (a) => a.user_id === userId && a.activity_date === date && a.validation_status === 'VALID'
  );

  const tasksCount = activities.filter((a) => a.activity_type === 'TASK').length;
  const contentCount = activities.filter((a) => a.activity_type === 'CONTENT').length;

  const user = db.users.find((u: any) => u.id === userId);
  const activeDayEarned = Boolean(
    user?.last_active_day_date === date || 
    (tasksCount >= REQUIRED_DAILY_TASKS && contentCount >= REQUIRED_DAILY_CONTENT)
  );

  return {
    date,
    tasks_completed: tasksCount,
    tasks_required: REQUIRED_DAILY_TASKS,
    content_completed: contentCount,
    content_required: REQUIRED_DAILY_CONTENT,
    active_day_earned: activeDayEarned,
    tasks_remaining: Math.max(0, REQUIRED_DAILY_TASKS - tasksCount),
    content_remaining: Math.max(0, REQUIRED_DAILY_CONTENT - contentCount),
  };
}

/**
 * Retrieves server-authoritative activity statistics for an authenticated user,
 * automatically applying the 72-hour inactivity check on-access.
 */
export function getUserActivityStats(userId: string): {
  success: boolean;
  user_id: string;
  active_day_streak: number;
  valid_action_count: number;
  last_activity_at: string;
  inactivity_reset_applied: boolean;
  today: DailyActivityProgress;
} {
  const db = readDB();
  const user = db.users.find((u: any) => u.id === userId || (userId && (u.guest_device_id === userId || u.device_fingerprint === userId)));

  if (!user) {
    return {
      success: false,
      user_id: userId,
      active_day_streak: 0,
      valid_action_count: 0,
      last_activity_at: new Date().toISOString(),
      inactivity_reset_applied: false,
      today: {
        date: getTodayDateString(),
        tasks_completed: 0,
        tasks_required: REQUIRED_DAILY_TASKS,
        content_completed: 0,
        content_required: REQUIRED_DAILY_CONTENT,
        active_day_earned: false,
        tasks_remaining: REQUIRED_DAILY_TASKS,
        content_remaining: REQUIRED_DAILY_CONTENT
      }
    };
  }

  // 72-hour inactivity check on-access
  const { resetApplied } = evaluate72HourInactivityForUser(user);
  if (resetApplied) {
    writeDB(db);
  }

  const today = getUserDailyActivityProgress(user.id, db);

  return {
    success: true,
    user_id: user.id,
    active_day_streak: user.active_day_streak || 0,
    valid_action_count: user.valid_action_count || 0,
    last_activity_at: user.last_activity_at || new Date().toISOString(),
    inactivity_reset_applied: resetApplied,
    today
  };
}

/**
 * Server-Authoritative User Activity Engine (UAE):
 * Validates, deduplicates, and logs user activity events.
 * 
 * Rules:
 * 1. Backend/database is ultimate source of truth.
 * 2. 1 Active Day requires EXACTLY 10 valid tasks + 5 valid content activities. Max 1 Active Day per day.
 * 3. 72-Hour Inactivity Rule: resets active_day_streak = 0 if inactive > 72 hours.
 * 4. Cumulative lifetime valid actions (valid_action_count) are strictly preserved and never decremented.
 * 5. Unique constraint on idempotency_key prevents duplicate task claims.
 */
export async function recordAndValidateActivity(params: {
  userId: string;
  activityType: 'TASK' | 'CONTENT';
  sourceReference: string;
  idempotencyKey?: string;
  metadata?: Record<string, any>;
}): Promise<{
  success: boolean;
  code: 'VALID' | 'DUPLICATE' | 'INVALID' | 'ACCOUNT_RESTRICTED';
  message: string;
  activity?: UserActivityRecord;
  stats: {
    active_day_streak: number;
    valid_action_count: number;
    last_activity_at: string;
    today: DailyActivityProgress;
  };
  activeDayNewlyAwarded: boolean;
}> {
  const db = readDB();
  if (!db.user_activity) db.user_activity = [];
  if (!db.verification_records) db.verification_records = [];

  const { userId, activityType, sourceReference, metadata } = params;

  // 1. Resolve User
  const user = db.users.find(
    (u: any) => u.id === userId || (userId && (u.guest_device_id === userId || u.device_fingerprint === userId))
  );

  if (!user) {
    return {
      success: false,
      code: 'INVALID',
      message: 'Authenticated account not found.',
      stats: {
        active_day_streak: 0,
        valid_action_count: 0,
        last_activity_at: new Date().toISOString(),
        today: {
          date: getTodayDateString(),
          tasks_completed: 0,
          tasks_required: REQUIRED_DAILY_TASKS,
          content_completed: 0,
          content_required: REQUIRED_DAILY_CONTENT,
          active_day_earned: false,
          tasks_remaining: REQUIRED_DAILY_TASKS,
          content_remaining: REQUIRED_DAILY_CONTENT
        }
      },
      activeDayNewlyAwarded: false
    };
  }

  if (user.isBanned || user.status === 'banned' || user.status === 'suspended' || user.risk_status === 'RESTRICTED' || user.risk_status === 'BANNED') {
    return {
      success: false,
      code: 'ACCOUNT_RESTRICTED',
      message: 'Account under security review. Activity recording and earnings are paused.',
      stats: {
        active_day_streak: user.active_day_streak || 0,
        valid_action_count: user.valid_action_count || 0,
        last_activity_at: user.last_activity_at || new Date().toISOString(),
        today: getUserDailyActivityProgress(user.id, db)
      },
      activeDayNewlyAwarded: false
    };
  }

  // 2. Perform 72h Inactivity Check on access
  evaluate72HourInactivityForUser(user);

  // 3. Validate source reference
  if (!sourceReference || sourceReference.trim() === '') {
    return {
      success: false,
      code: 'INVALID',
      message: 'Invalid activity: Source reference is required.',
      stats: {
        active_day_streak: user.active_day_streak || 0,
        valid_action_count: user.valid_action_count || 0,
        last_activity_at: user.last_activity_at || new Date().toISOString(),
        today: getUserDailyActivityProgress(user.id, db)
      },
      activeDayNewlyAwarded: false
    };
  }

  const todayDate = getTodayDateString();

  // 4. Construct unique idempotency key
  const uniqueKey = params.idempotencyKey || 
    `${user.id}_${activityType}_${sourceReference}_${metadata?.impressionId || metadata?.sessionToken || (activityType === 'CONTENT' ? `c_${Date.now()}` : todayDate)}`;

  // 5. Unique constraint check on idempotency key
  const existingRecord = db.user_activity.find(
    (a) => a.idempotency_key === uniqueKey && a.validation_status === 'VALID'
  );

  if (existingRecord) {
    return {
      success: false,
      code: 'DUPLICATE',
      message: 'এই অ্যাক্টিভিটি/টাস্ক ইতিমধ্যে সফলভাবে ভেরিফাই ও রেকর্ড করা হয়েছে (Already Claimed)।',
      activity: existingRecord,
      stats: {
        active_day_streak: user.active_day_streak || 0,
        valid_action_count: user.valid_action_count || 0,
        last_activity_at: user.last_activity_at || new Date().toISOString(),
        today: getUserDailyActivityProgress(user.id, db, todayDate)
      },
      activeDayNewlyAwarded: false
    };
  }

  // 6. Record New Valid Activity
  const nowISO = new Date().toISOString();
  const activityRecord: UserActivityRecord = {
    activity_id: `act_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
    user_id: user.id,
    activity_type: activityType,
    source_reference: sourceReference,
    activity_date: todayDate,
    validation_status: 'VALID',
    idempotency_key: uniqueKey,
    created_at: nowISO,
    metadata: metadata || {}
  };

  db.user_activity.push(activityRecord);

  // 7. Update User Timestamps & Lifetime Cumulative Action Count
  user.last_activity_at = nowISO;
  user.lastActiveAt = nowISO;
  user.lastActiveTimestamp = Date.now();
  user.valid_action_count = (user.valid_action_count || 0) + 1;
  touchAuthenticatedAccess(user.id, db);

  // 8. Calculate Active Day Increment
  // 1 Active Day requires EXACTLY 10 valid tasks + 5 valid content activities within the calendar day.
  const todayProgress = getUserDailyActivityProgress(user.id, db, todayDate);
  let activeDayNewlyAwarded = false;

  if (
    todayProgress.tasks_completed >= REQUIRED_DAILY_TASKS &&
    todayProgress.content_completed >= REQUIRED_DAILY_CONTENT
  ) {
    if (user.last_active_day_date !== todayDate) {
      user.active_day_streak = (user.active_day_streak || 0) + 1;
      user.last_active_day_date = todayDate;
      user.activeDaysCount = user.active_day_streak;
      if (!user.activeDaysList) user.activeDaysList = [];
      if (!user.activeDaysList.includes(todayDate)) {
        user.activeDaysList.push(todayDate);
      }
      activeDayNewlyAwarded = true;
      todayProgress.active_day_earned = true;
      console.log(`[UAE] User ${user.id} achieved Active Day milestone! Streak: ${user.active_day_streak} days.`);
    }
  }

  // 9. Update verification_records table
  if (!db.verification_records) db.verification_records = [];
  const verRecIndex = db.verification_records.findIndex((r: any) => r.user_id === user.id);
  const existingVer = verRecIndex >= 0 ? db.verification_records[verRecIndex] : null;

  const verificationRecord = {
    verification_id: existingVer?.verification_id || `ver_${user.id}`,
    user_id: user.id,
    active_days: user.active_day_streak || 0,
    valid_actions: user.valid_action_count || 0,
    quiz_status: existingVer?.quiz_status || (user.isQuizPassed ? 'PASSED' : 'PENDING'),
    verification_status: existingVer?.verification_status || 'UNVERIFIED',
    rule_version: 'VRMS-3-ULTRA',
    verified_at: existingVer?.verified_at || null,
    active_day_streak: user.active_day_streak || 0,
    valid_action_count: user.valid_action_count || 0,
    last_activity_at: user.last_activity_at,
    last_active_day_date: user.last_active_day_date || null,
    today_tasks: todayProgress.tasks_completed,
    today_content: todayProgress.content_completed,
    today_active_day_earned: todayProgress.active_day_earned,
    updated_at: nowISO
  };

  if (verRecIndex >= 0) {
    db.verification_records[verRecIndex] = verificationRecord;
  } else {
    db.verification_records.push(verificationRecord);
  }

  // 10. Persist to Local DB
  writeDB(db);

  // 11. Async Cloud Firestore Sync (without blocking response)
  (async () => {
    try {
      const writable = await isFirestoreWritable();
      if (writable) {
        // Sync activity record
        const actRef = doc(firestore, "user_activity", activityRecord.activity_id);
        await setDoc(actRef, activityRecord, { merge: true });

        // Sync verification record
        const verRef = doc(firestore, "verification_records", user.id);
        await setDoc(verRef, verificationRecord, { merge: true });

        // Sync user stats
        const userRef = doc(firestore, "users", user.id);
        await setDoc(userRef, {
          active_day_streak: user.active_day_streak,
          activeDaysCount: user.active_day_streak,
          valid_action_count: user.valid_action_count,
          last_activity_at: user.last_activity_at,
          last_active_day_date: user.last_active_day_date
        }, { merge: true });
      }
    } catch (syncErr) {
      console.warn("[UAE] Firestore background sync notice:", syncErr);
    }
  })();

  const successMessage = activeDayNewlyAwarded
    ? `অভিনন্দন! আজকের লক্ষ্য (১০ টাস্ক + ৫ কনটেন্ট) সম্পন্ন হয়েছে! অ্যাক্টিভ ডে স্ট্রিক +১ বৃদ্ধি পেয়েছে (মোট: ${user.active_day_streak} দিন)।`
    : activityType === 'TASK'
    ? `ভ্যালিড টাস্ক সফলভাবে সম্পন্ন ও ভেরিফাই হয়েছে! (আজকের টাস্ক: ${todayProgress.tasks_completed}/${REQUIRED_DAILY_TASKS})`
    : `ভ্যালিড কনটেন্ট অ্যাক্টিভিটি সফলভাবে ভেরিফাই হয়েছে! (আজকের কনটেন্ট: ${todayProgress.content_completed}/${REQUIRED_DAILY_CONTENT})`;

  return {
    success: true,
    code: 'VALID',
    message: successMessage,
    activity: activityRecord,
    stats: {
      active_day_streak: user.active_day_streak || 0,
      valid_action_count: user.valid_action_count || 0,
      last_activity_at: user.last_activity_at,
      today: todayProgress
    },
    activeDayNewlyAwarded
  };
}
