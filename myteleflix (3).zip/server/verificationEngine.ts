/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import { readDB, writeDB, DBState, QuizAttemptRecord, VerificationRecord } from "./db.js";
import { evaluate72HourInactivityForUser } from "./userActivityEngine.js";
import { onUserVerifiedReferralTrigger } from "./referralEngine.js";
import { emitVerificationAlert } from "./notificationEngine.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";

export const RULE_VERSION = "VRMS-3-ULTRA";
export const REQUIRED_ACTIVE_DAYS = 10;
export const REQUIRED_VALID_ACTIONS = 100;
export const REQUIRED_QUIZ_SCORE = 3;
export const MAX_RESETS_PER_HOUR = 5;
export const RESET_WINDOW_MS = 60 * 60 * 1000;

interface InternalQuizQuestion {
  id: number;
  questionBn: string;
  questionEn: string;
  options: Array<{ id: string; textBn: string; textEn: string }>;
  correctOptionId: string; // STRICTLY SERVER-SIDE - NEVER EXPOSED IN CLIENT PAYLOAD
}

export interface PublicQuizQuestion {
  id: number;
  questionBn: string;
  questionEn: string;
  options: Array<{ id: string; textBn: string; textEn: string }>;
}

// 1. Math Generator supporting +, -, *, /
function generateMathQuestion(variant: number): InternalQuizQuestion {
  const mathTypes = [
    {
      qBn: (a: number, b: number) => `${a} + ${b} = কত?`,
      qEn: (a: number, b: number) => `What is ${a} + ${b}?`,
      gen: () => {
        const a = Math.floor(Math.random() * 15) + 5;
        const b = Math.floor(Math.random() * 14) + 4;
        return { a, b, ans: a + b };
      },
    },
    {
      qBn: (a: number, b: number) => `${a} × ${b} = কত?`,
      qEn: (a: number, b: number) => `What is ${a} × ${b}?`,
      gen: () => {
        const a = Math.floor(Math.random() * 8) + 3;
        const b = Math.floor(Math.random() * 7) + 3;
        return { a, b, ans: a * b };
      },
    },
    {
      qBn: (a: number, b: number) => `${a} - ${b} = কত?`,
      qEn: (a: number, b: number) => `What is ${a} - ${b}?`,
      gen: () => {
        const a = Math.floor(Math.random() * 20) + 20;
        const b = Math.floor(Math.random() * 12) + 5;
        return { a, b, ans: a - b };
      },
    },
    {
      qBn: (a: number, b: number) => `${a} ÷ ${b} = কত?`,
      qEn: (a: number, b: number) => `What is ${a} ÷ ${b}?`,
      gen: () => {
        const b = Math.floor(Math.random() * 6) + 2;
        const multiplier = Math.floor(Math.random() * 7) + 2;
        const a = b * multiplier;
        return { a, b, ans: multiplier };
      },
    },
  ];

  const type = mathTypes[Math.abs(variant) % mathTypes.length];
  const { a, b, ans } = type.gen();

  const wrongAnswers = new Set<number>();
  let delta = 1;
  while (wrongAnswers.size < 3) {
    const candidate = ans + (wrongAnswers.size % 2 === 0 ? delta : -delta);
    if (candidate !== ans && candidate >= 0) {
      wrongAnswers.add(candidate);
    }
    delta++;
  }

  const allNumbers = [ans, ...Array.from(wrongAnswers)].sort(() => Math.random() - 0.5);
  const keys = ["a", "b", "c", "d"];
  const correctIdx = allNumbers.indexOf(ans);
  const correctKey = keys[correctIdx];

  const options = allNumbers.map((num, i) => ({
    id: keys[i],
    textBn: `${num}`,
    textEn: `${num}`,
  }));

  return {
    id: 1,
    questionBn: type.qBn(a, b),
    questionEn: type.qEn(a, b),
    options,
    correctOptionId: correctKey,
  };
}

// 2. Logic Question Bank (Server-Side Storage)
const LOGIC_QUESTIONS_BANK = [
  {
    questionBn: "নিচের কোনটি একটি ফল?",
    questionEn: "Which of the following is a fruit?",
    correct: { bn: "আম (Mango)", en: "Mango" },
    wrong: [
      { bn: "আলু (Potato)", en: "Potato" },
      { bn: "পেঁয়াজ (Onion)", en: "Onion" },
      { bn: "গাজর (Carrot)", en: "Carrot" },
    ],
  },
  {
    questionBn: "নিচের কোনটি রাস্তা দিয়ে চলার স্থলযান?",
    questionEn: "Which of the following is a road vehicle?",
    correct: { bn: "বাস (Bus)", en: "Bus" },
    wrong: [
      { bn: "নৌকা (Boat)", en: "Boat" },
      { bn: "উড়োজাহাজ (Airplane)", en: "Airplane" },
      { bn: "সাবমেরিন (Submarine)", en: "Submarine" },
    ],
  },
  {
    questionBn: "সূর্য কোন দিকে উদিত হয়?",
    questionEn: "In which direction does the sun rise?",
    correct: { bn: "পূর্ব দিক (East)", en: "East" },
    wrong: [
      { bn: "পশ্চিম দিক (West)", en: "West" },
      { bn: "উত্তর দিক (North)", en: "North" },
      { bn: "দক্ষিণ দিক (South)", en: "South" },
    ],
  },
  {
    questionBn: "এক সপ্তাহে মোট কত দিন থাকে?",
    questionEn: "How many days are in a week?",
    correct: { bn: "৭ দিন (7 Days)", en: "7 Days" },
    wrong: [
      { bn: "৫ দিন (5 Days)", en: "5 Days" },
      { bn: "১০ দিন (10 Days)", en: "10 Days" },
      { bn: "৮ দিন (8 Days)", en: "8 Days" },
    ],
  },
  {
    questionBn: "কোন প্রাণীটি দুধ দেয় এবং তৃণভোজী?",
    questionEn: "Which animal is a herbivore and gives milk?",
    correct: { bn: "গরু (Cow)", en: "Cow" },
    wrong: [
      { bn: "বাঘ (Tiger)", en: "Tiger" },
      { bn: "কুমির (Crocodile)", en: "Crocodile" },
      { bn: "শকুন (Vulture)", en: "Vulture" },
    ],
  },
];

// 3. Science / General Knowledge Question Bank (Server-Side Storage)
const SCIENCE_QUESTIONS_BANK = [
  {
    questionBn: "মানুষ শ্বাস নেওয়ার সময় মূলত কোন গ্যাস গ্রহণ করে?",
    questionEn: "Which gas do humans primarily inhale?",
    correct: { bn: "অক্সিজেন (Oxygen)", en: "Oxygen" },
    wrong: [
      { bn: "নাইট্রোজেন (Nitrogen)", en: "Nitrogen" },
      { bn: "কার্বন ডাই অক্সাইড (CO2)", en: "Carbon Dioxide" },
      { bn: "হিলিয়াম (Helium)", en: "Helium" },
    ],
  },
  {
    questionBn: "পানি শূন্য ডিগ্রির নিচে জমে কীসে পরিণত হয়?",
    questionEn: "What does water turn into when frozen below zero degrees?",
    correct: { bn: "বরফ (Ice)", en: "Ice" },
    wrong: [
      { bn: "বাষ্প (Steam)", en: "Steam" },
      { bn: "ধোঁয়া (Smoke)", en: "Smoke" },
      { bn: "তেল (Oil)", en: "Oil" },
    ],
  },
  {
    questionBn: "উদ্ভিদ নিজের খাদ্য তৈরির জন্য কোন গ্যাস গ্রহণ করে?",
    questionEn: "Which gas do plants absorb to produce their food?",
    correct: { bn: "কার্বন ডাই অক্সাইড (CO2)", en: "Carbon Dioxide" },
    wrong: [
      { bn: "অক্সিজেন (Oxygen)", en: "Oxygen" },
      { bn: "মিথেন (Methane)", en: "Methane" },
      { bn: "হিলিয়াম (Helium)", en: "Helium" },
    ],
  },
  {
    questionBn: "এক মিনিটে মোট কত সেকেন্ড থাকে?",
    questionEn: "How many seconds are in one minute?",
    correct: { bn: "৬০ সেকেন্ড (60s)", en: "60 seconds" },
    wrong: [
      { bn: "৪৫ সেকেন্ড (45s)", en: "45 seconds" },
      { bn: "৩০ সেকেন্ড (30s)", en: "30 seconds" },
      { bn: "১০০ সেকেন্ড (100s)", en: "100 seconds" },
    ],
  },
  {
    questionBn: "পৃথিবীর সবচেয়ে দ্রুতগামী পাখি কোনটি?",
    questionEn: "What is the fastest diving bird on Earth?",
    correct: { bn: "পেরেগ্রিন ফ্যালকন (Falcon)", en: "Peregrine Falcon" },
    wrong: [
      { bn: "পেঙ্গুইন (Penguin)", en: "Penguin" },
      { bn: "উটপাখি (Ostrich)", en: "Ostrich" },
      { bn: "ময়ূর (Peacock)", en: "Peacock" },
    ],
  },
];

function buildBankQuestion(
  id: number,
  item: (typeof LOGIC_QUESTIONS_BANK)[0]
): InternalQuizQuestion {
  const allItems = [
    { isCorrect: true, ...item.correct },
    ...item.wrong.map((w) => ({ isCorrect: false, ...w })),
  ].sort(() => Math.random() - 0.5);

  const keys = ["a", "b", "c", "d"];
  let correctKey = "a";
  const options = allItems.map((opt, i) => {
    if (opt.isCorrect) correctKey = keys[i];
    return {
      id: keys[i],
      textBn: opt.bn,
      textEn: opt.en,
    };
  });

  return {
    id,
    questionBn: item.questionBn,
    questionEn: item.questionEn,
    options,
    correctOptionId: correctKey,
  };
}

/**
 * Generates a fresh randomized 3-question set
 * - Question 1: Math with randomized operators and numbers
 * - Question 2: Randomized logic question with shuffled choices
 * - Question 3: Randomized science question with shuffled choices
 */
export function generateFreshQuizSet(): {
  questionSetVersion: string;
  serverQuestions: InternalQuizQuestion[];
  clientQuestions: PublicQuizQuestion[];
} {
  const version = `set_v${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  const randomMathVariant = Math.floor(Math.random() * 100);
  const randomLogicIndex = Math.floor(Math.random() * LOGIC_QUESTIONS_BANK.length);
  const randomScienceIndex = Math.floor(Math.random() * SCIENCE_QUESTIONS_BANK.length);

  const q1 = generateMathQuestion(randomMathVariant);
  const q2 = buildBankQuestion(2, LOGIC_QUESTIONS_BANK[randomLogicIndex]);
  const q3 = buildBankQuestion(3, SCIENCE_QUESTIONS_BANK[randomScienceIndex]);

  const serverQuestions = [q1, q2, q3];

  // Strip correctOptionId completely before transmitting to client
  const clientQuestions: PublicQuizQuestion[] = serverQuestions.map((q) => ({
    id: q.id,
    questionBn: q.questionBn,
    questionEn: q.questionEn,
    options: q.options,
  }));

  return {
    questionSetVersion: version,
    serverQuestions,
    clientQuestions,
  };
}

/**
 * Rate Limit Checker for Quiz Resets
 * Max 5 resets per 60 minutes per user
 */
export function checkResetRateLimit(
  userId: string,
  db: DBState
): { allowed: boolean; resetsRemaining: number; resetCount: number; message?: string } {
  const now = Date.now();
  const attempts = (db.quiz_attempts || []).filter((a) => a.user_id === userId);

  // Filter resets in the last 1 hour
  const recentResets = attempts.filter((a) => {
    const lastReset = a.last_reset_at ? new Date(a.last_reset_at).getTime() : 0;
    return now - lastReset < RESET_WINDOW_MS && (a.attempt_status === "RESET" || a.reset_count > 0);
  });

  const totalResetsInWindow = recentResets.reduce((acc, curr) => acc + (curr.reset_count || 1), 0);

  if (totalResetsInWindow >= MAX_RESETS_PER_HOUR) {
    return {
      allowed: false,
      resetsRemaining: 0,
      resetCount: totalResetsInWindow,
      message: `খুব বেশি রিসেট অনুরোধ করা হয়েছে (সর্বোচ্চ প্রতি ঘণ্টায় ${MAX_RESETS_PER_HOUR} বার)। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।`,
    };
  }

  return {
    allowed: true,
    resetsRemaining: Math.max(0, MAX_RESETS_PER_HOUR - totalResetsInWindow),
    resetCount: totalResetsInWindow,
  };
}

/**
 * GET /api/quiz/get-questions
 * Retrieves or initializes an active quiz set for the user without exposing answers
 */
export function getOrCreateUserQuiz(userId: string): {
  success: boolean;
  attempt_id: string;
  question_set_version: string;
  questions: PublicQuizQuestion[];
  reset_count: number;
  max_resets: number;
  resets_remaining: number;
} {
  const db = readDB();
  if (!db.quiz_attempts) db.quiz_attempts = [];

  const existingAttempt = db.quiz_attempts
    .slice()
    .reverse()
    .find((a) => a.user_id === userId && a.attempt_status === "IN_PROGRESS");

  if (existingAttempt && existingAttempt.questions && existingAttempt.questions.length === 3) {
    const clientQuestions: PublicQuizQuestion[] = existingAttempt.questions.map((q) => ({
      id: q.id,
      questionBn: q.questionBn,
      questionEn: q.questionEn,
      options: q.options,
    }));

    const rateCheck = checkResetRateLimit(userId, db);

    return {
      success: true,
      attempt_id: existingAttempt.attempt_id,
      question_set_version: existingAttempt.question_set_version,
      questions: clientQuestions,
      reset_count: existingAttempt.reset_count || 0,
      max_resets: MAX_RESETS_PER_HOUR,
      resets_remaining: rateCheck.resetsRemaining,
    };
  }

  // Create fresh attempt
  const fresh = generateFreshQuizSet();
  const nowISO = new Date().toISOString();
  const attemptId = `att_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;

  const newAttempt: QuizAttemptRecord = {
    attempt_id: attemptId,
    user_id: userId,
    question_set_version: fresh.questionSetVersion,
    score: 0,
    attempt_status: "IN_PROGRESS",
    reset_count: 0,
    last_reset_at: nowISO,
    created_at: nowISO,
    questions: fresh.serverQuestions,
  };

  db.quiz_attempts.push(newAttempt);
  writeDB(db);

  // Async sync to Firestore
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        const ref = doc(firestore, "quiz_attempts", attemptId);
        await setDoc(
          ref,
          {
            attempt_id: newAttempt.attempt_id,
            user_id: newAttempt.user_id,
            question_set_version: newAttempt.question_set_version,
            score: newAttempt.score,
            attempt_status: newAttempt.attempt_status,
            reset_count: newAttempt.reset_count,
            last_reset_at: newAttempt.last_reset_at,
            created_at: newAttempt.created_at,
          },
          { merge: true }
        );
      }
    } catch {}
  })();

  const rateCheck = checkResetRateLimit(userId, db);

  return {
    success: true,
    attempt_id: attemptId,
    question_set_version: fresh.questionSetVersion,
    questions: fresh.clientQuestions,
    reset_count: 0,
    max_resets: MAX_RESETS_PER_HOUR,
    resets_remaining: rateCheck.resetsRemaining,
  };
}

/**
 * POST /api/quiz/submit-answers
 * Server-authoritatively evaluates answers.
 * If 3/3: sets quiz_status = 'PASSED'.
 * If < 3/3: sets quiz_status = 'FAILED', shuffles a new question set, and requires reset.
 */
export function submitUserQuizAnswers(
  userId: string,
  attemptId: string,
  submittedAnswers: Record<string | number, string>
): {
  success: boolean;
  score: number;
  quiz_status: "PASSED" | "FAILED";
  message: string;
  error?: string;
  requireReset?: boolean;
  newAttempt?: {
    attempt_id: string;
    question_set_version: string;
    questions: PublicQuizQuestion[];
    resets_remaining: number;
  };
} {
  const db = readDB();
  if (!db.quiz_attempts) db.quiz_attempts = [];
  if (!db.verification_records) db.verification_records = [];

  const targetUser = db.users.find((u: any) => u.id === userId);
  if (targetUser && (targetUser.risk_status === 'RESTRICTED' || targetUser.risk_status === 'BANNED' || targetUser.isBanned || targetUser.status === 'suspended' || targetUser.status === 'banned')) {
    return {
      success: false,
      score: 0,
      quiz_status: "FAILED",
      message: "নিরাপত্তা পর্যালোচনার কারণে আপনার অ্যাকাউন্ট স্থগিত রয়েছে। কুইজ দেওয়া সম্ভব নয়।",
      error: "SECURITY_RESTRICTION: Account under security review. Verification quiz blocked.",
      requireReset: false,
    };
  }

  const attemptIndex = db.quiz_attempts.findIndex(
    (a) => a.attempt_id === attemptId && a.user_id === userId
  );

  let attempt = attemptIndex >= 0 ? db.quiz_attempts[attemptIndex] : null;

  // Fallback to latest attempt if ID mismatch
  if (!attempt) {
    attempt = db.quiz_attempts
      .slice()
      .reverse()
      .find((a) => a.user_id === userId && a.attempt_status === "IN_PROGRESS") || null;
  }

  if (!attempt || !attempt.questions || attempt.questions.length === 0) {
    return {
      success: false,
      score: 0,
      quiz_status: "FAILED",
      message: "কুইজ সেশন পাওয়া যায়নি। দয়া করে নতুন করে শুরু করুন।",
      error: "কুইজ সেশন পাওয়া যায়নি।",
      requireReset: true,
    };
  }

  // Evaluate answers server-side
  let score = 0;
  for (const q of attempt.questions) {
    const userChoice = submittedAnswers[q.id] || submittedAnswers[String(q.id)];
    if (userChoice && userChoice === q.correctOptionId) {
      score += 1;
    }
  }

  const nowISO = new Date().toISOString();
  const user = db.users.find((u: any) => u.id === userId);

  // Update verification record
  let verRec = db.verification_records.find((r) => r.user_id === userId);
  if (!verRec) {
    verRec = {
      verification_id: `ver_${userId}`,
      user_id: userId,
      active_days: user?.active_day_streak || 0,
      valid_actions: user?.valid_action_count || 0,
      quiz_status: "PENDING",
      verification_status: "UNVERIFIED",
      rule_version: RULE_VERSION,
      verified_at: null,
      updated_at: nowISO,
    };
    db.verification_records.push(verRec);
  }

  if (score === 3) {
    // 3/3: PASSED
    attempt.score = 3;
    attempt.attempt_status = "PASSED";

    if (user) {
      user.isQuizPassed = true;
      user.isHumanVerified = true;
    }

    verRec.quiz_status = "PASSED";
    verRec.updated_at = nowISO;

    writeDB(db);

    // Sync to Firestore
    (async () => {
      try {
        if (await isFirestoreWritable()) {
          await setDoc(
            doc(firestore, "quiz_attempts", attempt.attempt_id),
            {
              score: 3,
              attempt_status: "PASSED",
              updated_at: nowISO,
            },
            { merge: true }
          );

          await setDoc(
            doc(firestore, "verification_records", userId),
            {
              quiz_status: "PASSED",
              updated_at: nowISO,
            },
            { merge: true }
          );

          if (user) {
            await setDoc(
              doc(firestore, "users", userId),
              {
                isQuizPassed: true,
                isHumanVerified: true,
              },
              { merge: true }
            );
          }
        }
      } catch {}
    })();

    return {
      success: true,
      score: 3,
      quiz_status: "PASSED",
      message: "অভিনন্দন! হিউম্যান ভেরিফিকেশন কুইজ সফলভাবে সম্পন্ন হয়েছে (৩/৩)।",
    };
  } else {
    // < 3: FAILED
    attempt.score = score;
    attempt.attempt_status = "FAILED";

    if (user) {
      user.isQuizPassed = false;
      user.isHumanVerified = false;
    }

    verRec.quiz_status = "FAILED";
    verRec.updated_at = nowISO;

    // VRMS-3 ULTRA (Phase 12): Phase 3 Hook on Quiz Failure
    emitVerificationAlert(userId, 'FAILED', score, attempt.attempt_id, db);

    // Immediately generate a new shuffled question set so client can retry seamlessly
    const fresh = generateFreshQuizSet();
    const newAttemptId = `att_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
    const newAttempt: QuizAttemptRecord = {
      attempt_id: newAttemptId,
      user_id: userId,
      question_set_version: fresh.questionSetVersion,
      score: 0,
      attempt_status: "IN_PROGRESS",
      reset_count: (attempt.reset_count || 0) + 1,
      last_reset_at: nowISO,
      created_at: nowISO,
      questions: fresh.serverQuestions,
    };

    db.quiz_attempts.push(newAttempt);
    writeDB(db);

    // Sync to Firestore
    (async () => {
      try {
        if (await isFirestoreWritable()) {
          await setDoc(
            doc(firestore, "quiz_attempts", attempt.attempt_id),
            {
              score,
              attempt_status: "FAILED",
              updated_at: nowISO,
            },
            { merge: true }
          );

          await setDoc(
            doc(firestore, "quiz_attempts", newAttemptId),
            {
              attempt_id: newAttempt.attempt_id,
              user_id: newAttempt.user_id,
              question_set_version: newAttempt.question_set_version,
              score: 0,
              attempt_status: "IN_PROGRESS",
              reset_count: newAttempt.reset_count,
              last_reset_at: newAttempt.last_reset_at,
              created_at: newAttempt.created_at,
            },
            { merge: true }
          );

          await setDoc(
            doc(firestore, "verification_records", userId),
            {
              quiz_status: "FAILED",
              updated_at: nowISO,
            },
            { merge: true }
          );
        }
      } catch {}
    })();

    const rateCheck = checkResetRateLimit(userId, db);

    return {
      success: false,
      score,
      quiz_status: "FAILED",
      message: "ভেরিফিকেশন ভুল হয়েছে! আবার চেষ্টা করুন।",
      error: "ভেরিফিকেশন ভুল হয়েছে! আবার চেষ্টা করুন।",
      requireReset: true,
      newAttempt: {
        attempt_id: newAttemptId,
        question_set_version: fresh.questionSetVersion,
        questions: fresh.clientQuestions,
        resets_remaining: rateCheck.resetsRemaining,
      },
    };
  }
}

/**
 * POST /api/quiz/reset
 * Rate-limited question set reset and shuffling
 */
export function resetUserQuiz(userId: string): {
  success: boolean;
  attempt_id?: string;
  question_set_version?: string;
  questions?: PublicQuizQuestion[];
  resets_remaining?: number;
  error?: string;
} {
  const db = readDB();
  if (!db.quiz_attempts) db.quiz_attempts = [];

  const rateCheck = checkResetRateLimit(userId, db);
  if (!rateCheck.allowed) {
    return {
      success: false,
      error: rateCheck.message || "খুব বেশি রিসেট অনুরোধ করা হয়েছে। পরে চেষ্টা করুন।",
    };
  }

  // Mark all previous in-progress attempts as RESET
  const nowISO = new Date().toISOString();
  db.quiz_attempts.forEach((a) => {
    if (a.user_id === userId && a.attempt_status === "IN_PROGRESS") {
      a.attempt_status = "RESET";
      a.last_reset_at = nowISO;
    }
  });

  // Generate fresh set
  const fresh = generateFreshQuizSet();
  const attemptId = `att_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
  const newAttempt: QuizAttemptRecord = {
    attempt_id: attemptId,
    user_id: userId,
    question_set_version: fresh.questionSetVersion,
    score: 0,
    attempt_status: "IN_PROGRESS",
    reset_count: rateCheck.resetCount + 1,
    last_reset_at: nowISO,
    created_at: nowISO,
    questions: fresh.serverQuestions,
  };

  db.quiz_attempts.push(newAttempt);
  writeDB(db);

  // Sync to Firestore
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        await setDoc(
          doc(firestore, "quiz_attempts", attemptId),
          {
            attempt_id: newAttempt.attempt_id,
            user_id: newAttempt.user_id,
            question_set_version: newAttempt.question_set_version,
            score: 0,
            attempt_status: "IN_PROGRESS",
            reset_count: newAttempt.reset_count,
            last_reset_at: newAttempt.last_reset_at,
            created_at: newAttempt.created_at,
          },
          { merge: true }
        );
      }
    } catch {}
  })();

  const newRemaining = Math.max(0, MAX_RESETS_PER_HOUR - (rateCheck.resetCount + 1));

  return {
    success: true,
    attempt_id: attemptId,
    question_set_version: fresh.questionSetVersion,
    questions: fresh.clientQuestions,
    resets_remaining: newRemaining,
  };
}

/**
 * POST /api/verification/check-status
 * Server-authoritative evaluation of all 4 verification prerequisites:
 * Formula: VERIFIED = ACCOUNT_VALID AND active_day_streak >= 10 AND valid_action_count >= 100 AND quiz_score >= 3/3 AND NOT_RESTRICTED.
 */
export function checkAccountVerificationStatus(userId: string): {
  success: boolean;
  verified: boolean;
  status: "UNVERIFIED" | "VERIFIED" | "PENDING" | "REJECTED";
  message: string;
  verificationRecord: VerificationRecord;
  prerequisites: {
    accountValid: { passed: boolean; label: string };
    activeDays: { current: number; required: number; passed: boolean; label: string };
    validActions: { current: number; required: number; passed: boolean; label: string };
    quizPassed: { passed: boolean; score?: number; label: string };
    notRestricted: { passed: boolean; label: string };
  };
} {
  const db = readDB();
  if (!db.verification_records) db.verification_records = [];

  const user = db.users.find((u: any) => u.id === userId);
  if (!user) {
    const dummyRecord: VerificationRecord = {
      verification_id: `ver_${userId}`,
      user_id: userId,
      active_days: 0,
      valid_actions: 0,
      quiz_status: "PENDING",
      verification_status: "UNVERIFIED",
      rule_version: RULE_VERSION,
      verified_at: null,
      updated_at: new Date().toISOString(),
    };
    return {
      success: false,
      verified: false,
      status: "UNVERIFIED",
      message: "ব্যবহারকারী অ্যাকাউন্ট পাওয়া যায়নি।",
      verificationRecord: dummyRecord,
      prerequisites: {
        accountValid: { passed: false, label: "অ্যাকাউন্ট ভ্যালিডেশন ব্যর্থ" },
        activeDays: { current: 0, required: REQUIRED_ACTIVE_DAYS, passed: false, label: "১০টি সক্রিয় দিন প্রয়োজন" },
        validActions: { current: 0, required: REQUIRED_VALID_ACTIONS, passed: false, label: "১০০টি অ্যাক্টিভিটি প্রয়োজন" },
        quizPassed: { passed: false, label: "হিউম্যান কুইজ প্রয়োজন" },
        notRestricted: { passed: false, label: "অ্যাকাউন্ট নিষিদ্ধ বা স্থগিত নয়" },
      },
    };
  }

  // 1. Evaluate 72-Hour Inactivity Rule before checking status
  evaluate72HourInactivityForUser(user);

  const activeDays = user.active_day_streak || user.activeDaysCount || 0;
  const validActions = user.valid_action_count || 0;

  // Retrieve quiz status
  let verRec = db.verification_records.find((r) => r.user_id === userId);
  const nowISO = new Date().toISOString();

  if (!verRec) {
    verRec = {
      verification_id: `ver_${userId}`,
      user_id: userId,
      active_days: activeDays,
      valid_actions: validActions,
      quiz_status: user.isQuizPassed ? "PASSED" : "PENDING",
      verification_status: "UNVERIFIED",
      rule_version: RULE_VERSION,
      verified_at: null,
      updated_at: nowISO,
      active_day_streak: activeDays,
      valid_action_count: validActions,
      last_activity_at: user.last_activity_at,
    };
    db.verification_records.push(verRec);
  }

  // Evaluate latest quiz attempt
  const latestPassedAttempt = (db.quiz_attempts || [])
    .slice()
    .reverse()
    .find((a) => a.user_id === userId && a.attempt_status === "PASSED" && a.score >= 3);

  const isQuizPassed = Boolean(latestPassedAttempt || user.isQuizPassed || verRec.quiz_status === "PASSED");

  // Rule 2: VERIFIED = ACCOUNT_VALID AND active_day_streak >= 10 AND valid_action_count >= 100 AND quiz_score >= 3/3 AND NOT_RESTRICTED
  const accountValid = Boolean(user.id && user.createdAt);
  const activeDaysPassed = activeDays >= REQUIRED_ACTIVE_DAYS;
  const validActionsPassed = validActions >= REQUIRED_VALID_ACTIONS;
  const quizPassed = isQuizPassed;
  const notRestricted = user.status !== "suspended" && user.status !== "banned" && !user.isBanned && user.risk_status !== 'RESTRICTED' && user.risk_status !== 'BANNED';

  const allPassed = accountValid && activeDaysPassed && validActionsPassed && quizPassed && notRestricted;

  // Update DB states
  const previousStatus = verRec.verification_status;
  const newStatus = allPassed ? "VERIFIED" : "UNVERIFIED";

  verRec.active_days = activeDays;
  verRec.valid_actions = validActions;
  verRec.quiz_status = quizPassed ? "PASSED" : verRec.quiz_status === "FAILED" ? "FAILED" : "PENDING";
  verRec.verification_status = newStatus;
  verRec.rule_version = RULE_VERSION;
  verRec.updated_at = nowISO;
  verRec.active_day_streak = activeDays;
  verRec.valid_action_count = validActions;
  verRec.last_activity_at = user.last_activity_at;

  if (allPassed && !verRec.verified_at) {
    verRec.verified_at = nowISO;
  }

  if (allPassed) {
    user.is_verified = true;
    user.isHumanVerified = true;
    user.isQuizPassed = true;

    // VRMS-3 ULTRA Phase 4: Trigger/Hook on Verification Event
    // Converts referral from REGISTERED to QUALIFIED and increments direct referrer's qualified_referral_count
    onUserVerifiedReferralTrigger(userId, db);

    // VRMS-3 ULTRA Phase 12: Internal Hook on Verification Event
    if (previousStatus !== "VERIFIED") {
      emitVerificationAlert(userId, 'PASSED', 3, verRec.verification_id, db);
    }
  }

  writeDB(db);

  // Sync to Firestore
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        await setDoc(
          doc(firestore, "verification_records", userId),
          {
            verification_id: verRec.verification_id,
            user_id: verRec.user_id,
            active_days: verRec.active_days,
            valid_actions: verRec.valid_actions,
            quiz_status: verRec.quiz_status,
            verification_status: verRec.verification_status,
            rule_version: verRec.rule_version,
            verified_at: verRec.verified_at,
            updated_at: verRec.updated_at,
          },
          { merge: true }
        );

        if (allPassed) {
          await setDoc(
            doc(firestore, "users", userId),
            {
              is_verified: true,
              isHumanVerified: true,
              isQuizPassed: true,
            },
            { merge: true }
          );
        }
      }
    } catch {}
  })();

  const message = allPassed
    ? "অভিনন্দন! আপনার অ্যাকাউন্ট সম্পূর্ণ ভেরিফাইড (VERIFIED)। সব শর্ত পূরণ হয়েছে।"
    : "অ্যাকাউন্ট এখনও ভেরিফাই হয়নি। সব শর্ত পূরণ করে পুনরায় চেষ্টা করুন।";

  return {
    success: true,
    verified: allPassed,
    status: newStatus,
    message,
    verificationRecord: verRec,
    prerequisites: {
      accountValid: {
        passed: accountValid,
        label: accountValid ? "অ্যাকাউন্ট ভ্যালিড" : "অবৈধ অ্যাকাউন্ট",
      },
      activeDays: {
        current: activeDays,
        required: REQUIRED_ACTIVE_DAYS,
        passed: activeDaysPassed,
        label: `সক্রিয় দিন: ${activeDays}/${REQUIRED_ACTIVE_DAYS}`,
      },
      validActions: {
        current: validActions,
        required: REQUIRED_VALID_ACTIONS,
        passed: validActionsPassed,
        label: `ভ্যালিড অ্যাক্টিভিটি: ${validActions}/${REQUIRED_VALID_ACTIONS}`,
      },
      quizPassed: {
        passed: quizPassed,
        score: isQuizPassed ? 3 : 0,
        label: quizPassed ? "হিউম্যান কুইজ সম্পন্ন (৩/৩)" : "হিউম্যান কুইজ বাকি (৩/৩ প্রয়োজন)",
      },
      notRestricted: {
        passed: notRestricted,
        label: notRestricted ? "অ্যাকাউন্ট সক্রিয় ও সীমাবদ্ধতামুক্ত" : "অ্যাকাউন্ট স্থগিত বা নিষিদ্ধ",
      },
    },
  };
}
