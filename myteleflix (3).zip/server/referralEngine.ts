/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA - PHASE 4: Server-Authoritative Referral Engine (RE)
 * 
 * NON-NEGOTIABLE SYSTEM RULES:
 * 1. Signup is NOT a Qualified Referral. Signup creates status 'REGISTERED'.
 * 2. Verification triggers qualification: Referred user becoming 'VERIFIED' converts status from 'REGISTERED' to 'QUALIFIED'.
 * 3. Referral relationship is IMMUTABLE after creation, MUST be unique, and CIRCULAR REFERRALS ARE STRICTLY BLOCKED (e.g., A -> B -> A is forbidden).
 * 4. Direct Referral Isolation: Only DIRECT referrers get referral credit. Multi-level tree logic must not grant direct salary referral credits to upper-tier referrers.
 * 5. Re-verification rule: A user CANNOT generate a second qualification for the same referral relationship after already qualifying.
 * 6. Backend is the ultimate source of truth; no mock/demo data.
 */

import { readDB, writeDB, DBState, ReferralRecord, UserProfile } from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";

export const RULE_VERSION = "VRMS-3-ULTRA";

// In-memory lookup index cache for high-performance retrieval
interface ReferralIndexes {
  byReferrerId: Map<string, ReferralRecord[]>;
  byReferredUserId: Map<string, ReferralRecord>;
  byPair: Map<string, ReferralRecord>; // key: `${referrerId}::${referredUserId}`
}

let cachedIndexes: ReferralIndexes | null = null;
let lastIndexedLength = -1;

/**
 * Rebuilds high-performance in-memory indexes on the referrals collection
 */
export function getReferralIndexes(db: DBState): ReferralIndexes {
  const referrals = db.referrals || [];
  if (cachedIndexes && referrals.length === lastIndexedLength) {
    return cachedIndexes;
  }

  const byReferrerId = new Map<string, ReferralRecord[]>();
  const byReferredUserId = new Map<string, ReferralRecord>();
  const byPair = new Map<string, ReferralRecord>();

  for (const ref of referrals) {
    const referrerId = ref.referrer_id || ref.referrerId || "";
    const referredUserId = ref.referred_user_id || ref.referredId || "";

    if (!referrerId || !referredUserId) continue;

    // Index by referrer
    const list = byReferrerId.get(referrerId) || [];
    list.push(ref);
    byReferrerId.set(referrerId, list);

    // Index by referred user (Unique direct referrer constraint)
    if (!byReferredUserId.has(referredUserId) || ref.status !== "PURGED") {
      byReferredUserId.set(referredUserId, ref);
    }

    // Index by pair for UNIQUE constraint (referrer_id, referred_user_id)
    const pairKey = `${referrerId}::${referredUserId}`;
    byPair.set(pairKey, ref);
  }

  cachedIndexes = { byReferrerId, byReferredUserId, byPair };
  lastIndexedLength = referrals.length;
  return cachedIndexes;
}

export function invalidateReferralIndexes(): void {
  cachedIndexes = null;
  lastIndexedLength = -1;
}

/**
 * Cycle Detection: Checks if adding (referrerId -> referredUserId) would form a circular referral loop.
 * Traverses ancestors of referrerId upwards. If referredUserId is encountered, a cycle is guaranteed.
 */
export function wouldFormCircularReferral(
  referrerId: string,
  referredUserId: string,
  db: DBState
): boolean {
  if (!referrerId || !referredUserId) return true;
  if (referrerId === referredUserId) return true; // Direct self-referral

  const referrals = db.referrals || [];
  const visited = new Set<string>();
  let currentId: string | null = referrerId;

  while (currentId && !visited.has(currentId)) {
    visited.add(currentId);
    if (currentId === referredUserId) {
      return true; // Cycle detected: referredUserId is an ancestor of referrerId!
    }

    // Find who invited currentId
    const parentRef = referrals.find((r) => {
      const refId = r.referred_user_id || r.referredId;
      return refId === currentId && r.status !== "PURGED";
    });

    if (parentRef) {
      currentId = parentRef.referrer_id || parentRef.referrerId || null;
    } else {
      // Check user record's referredBy or invitedBy fallback
      const currentUser = db.users.find((u: any) => u.id === currentId);
      currentId = currentUser?.referredBy || currentUser?.invitedBy || null;
    }
  }

  return false;
}

/**
 * Normalizes user ID or referral code to locate existing user profile
 */
export function resolveReferrerUser(identifier: string, db: DBState): UserProfile | null {
  if (!identifier) return null;
  const clean = identifier.trim().replace(/^REF_/i, "").replace(/^ref_/i, "");

  return (
    db.users.find(
      (u: any) =>
        u.id === clean ||
        u.id === identifier ||
        u.id === `tg-${clean}` ||
        u.telegramId === clean ||
        u.username?.toLowerCase() === clean.toLowerCase()
    ) || null
  );
}

/**
 * POST /api/referrals/register
 * 
 * Registers a new direct referral relationship.
 * - Enforces UNIQUE constraint on (referrer_id, referred_user_id)
 * - Strict circular referral blocking
 * - Immutability: A user can only be referred once
 * - Initial status: strictly 'REGISTERED' (never 'QUALIFIED')
 */
export function registerDirectReferral(params: {
  referrerIdentifier: string;
  referredUserId: string;
  referredUsername?: string;
  referredFullName?: string;
}): {
  success: boolean;
  message: string;
  status?: "REGISTERED" | "QUALIFIED" | "PURGED";
  referral?: ReferralRecord;
  isExisting?: boolean;
} {
  const { referrerIdentifier, referredUserId } = params;
  if (!referrerIdentifier || !referredUserId) {
    return { success: false, message: "রেফারার আইডি এবং ব্যবহারকারী আইডি আবশ্যক।" };
  }

  const db = readDB();
  if (!db.referrals) db.referrals = [];

  const referrer = resolveReferrerUser(referrerIdentifier, db);
  if (!referrer) {
    return { success: false, message: "অবৈধ রেফারার কোড বা ব্যবহারকারী পাওয়া যায়নি।" };
  }

  const referrerId = referrer.id;

  // 1. Self-referral check
  if (referrerId === referredUserId) {
    return { success: false, message: "সরাসরি নিজের রেফারেল কোড ব্যবহার করা নিষিদ্ধ।" };
  }

  // 2. Hardware ID / Anti-sybil check
  const referredUser = db.users.find((u: any) => u.id === referredUserId);
  if (
    referrer.risk_status === 'RESTRICTED' ||
    referrer.risk_status === 'BANNED' ||
    referrer.isBanned ||
    referredUser?.risk_status === 'RESTRICTED' ||
    referredUser?.risk_status === 'BANNED' ||
    referredUser?.isBanned
  ) {
    return {
      success: false,
      message: "নিরাপত্তা স্থগিতাদেশের কারণে রেফারেল নিবন্ধন সম্ভব নয় (Account under security review).",
    };
  }
  const referrerHwid = referrer.device_fingerprint || referrer.deviceFingerprint;
  const referredHwid = referredUser?.device_fingerprint || referredUser?.deviceFingerprint;
  if (referrerHwid && referredHwid && referrerHwid === referredHwid) {
    referrer.isSuspicious = true;
    referrer.suspiciousReason = `Self-referral farm attempt on identical hardware ID (${referrerHwid.slice(0, 10)}...)`;
    if (referredUser) {
      referredUser.isSuspicious = true;
      referredUser.suspiciousReason = `Self-referral farm attempt on identical hardware ID (${referredHwid.slice(0, 10)}...)`;
    }
    writeDB(db);
    return { success: false, message: "একই ডিভাইসে একাধিক রেফারেল তৈরি করা নিষিদ্ধ।" };
  }

  // 3. Circular referral check (A -> B -> A or multi-hop loops)
  if (wouldFormCircularReferral(referrerId, referredUserId, db)) {
    return { success: false, message: "সার্কুলার রেফারেল নিষিদ্ধ (Circular referral loop detected and blocked)!" };
  }

  const indexes = getReferralIndexes(db);
  const pairKey = `${referrerId}::${referredUserId}`;

  // 4. Check if exact pair already exists (UNIQUE constraint idempotency)
  const existingPair = indexes.byPair.get(pairKey);
  if (existingPair) {
    return {
      success: true,
      message: "রেফারেল সম্পর্ক ইতিমধ্যে বিদ্যমান।",
      status: existingPair.status,
      referral: existingPair,
      isExisting: true,
    };
  }

  // 5. Immutability check: Has referred_user_id already been referred by someone else?
  const existingReferred = indexes.byReferredUserId.get(referredUserId);
  if (existingReferred && existingReferred.status !== "PURGED") {
    return {
      success: false,
      message: "এই ব্যবহারকারী ইতিমধ্যে অন্য একটি অপরিবর্তনীয় রেফারেল লিংকের সাথে যুক্ত।",
    };
  }

  const nowISO = new Date().toISOString();
  const referralId = `ref_${referrerId}_${referredUserId}`;

  const newReferral: ReferralRecord = {
    referral_id: referralId,
    referrer_id: referrerId,
    referred_user_id: referredUserId,
    status: "REGISTERED", // Non-negotiable rule 1: Signup is strictly REGISTERED
    registered_at: nowISO,
    qualified_at: null,
    purged_at: null,
    rule_version: RULE_VERSION,
    bonus_amount: 0,
    referred_username: params.referredUsername || referredUser?.username || "user",
    referred_fullname: params.referredFullName || referredUser?.fullName || "Member",

    // Compatibility fields
    id: referralId,
    referrerId: referrerId,
    referredId: referredUserId,
    referredUsername: params.referredUsername || referredUser?.username || "user",
    referredFullName: params.referredFullName || referredUser?.fullName || "Member",
    pointsEarned: 0,
    timestamp: nowISO,
  };

  db.referrals.push(newReferral);

  // Update referrer's registered_referral_count
  referrer.registered_referral_count = (referrer.registered_referral_count || 0) + 1;

  if (referredUser) {
    referredUser.referredBy = referrerId;
  }

  invalidateReferralIndexes();
  writeDB(db);

  // Sync to Firestore
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        await setDoc(
          doc(firestore, "referrals", referralId),
          {
            referral_id: newReferral.referral_id,
            referrer_id: newReferral.referrer_id,
            referred_user_id: newReferral.referred_user_id,
            status: "REGISTERED",
            registered_at: newReferral.registered_at,
            qualified_at: null,
            purged_at: null,
            rule_version: RULE_VERSION,
            referred_username: newReferral.referred_username,
            referred_fullname: newReferral.referred_fullname,
          },
          { merge: true }
        );

        await setDoc(
          doc(firestore, "users", referrerId),
          {
            registered_referral_count: referrer.registered_referral_count,
            referredBy: referrer.referredBy,
          },
          { merge: true }
        );
      }
    } catch (e) {
      console.warn("Firestore sync warning on referral registration:", e);
    }
  })();

  return {
    success: true,
    message: "রেফারেল সফলভাবে নিবন্ধিত হয়েছে (REGISTERED)। ব্যবহারকারী ভেরিফাইড হলে কোয়ালিফাই হবে।",
    status: "REGISTERED",
    referral: newReferral,
  };
}

/**
 * Trigger/Hook on Verification Event:
 * Whenever Phase 3 logic confirms a user is 'VERIFIED', this hook is invoked.
 * 
 * Rules Enforced:
 * 1. Queries referrals for referred_user_id = verifiedUserId WHERE status = 'REGISTERED'.
 * 2. Updates referral status to 'QUALIFIED', sets qualified_at = now().
 * 3. Increments direct referrer's qualified_referral_count by 1 server-side.
 * 4. Direct Referral Isolation: Only DIRECT referrer receives credit.
 * 5. Re-verification rule & Idempotency: Already QUALIFIED referrals are skipped.
 */
export function onUserVerifiedReferralTrigger(
  verifiedUserId: string,
  providedDb?: DBState
): {
  success: boolean;
  qualified: boolean;
  referralId?: string;
  referrerId?: string;
  rewardPoints?: number;
  message: string;
} {
  const db = providedDb || readDB();
  if (!db.referrals) db.referrals = [];

  // Query referrals table for referred_user_id = verifiedUserId
  const referral = db.referrals.find((r) => {
    const rId = r.referred_user_id || r.referredId;
    return rId === verifiedUserId;
  });

  if (!referral) {
    return {
      success: true,
      qualified: false,
      message: "এই ব্যবহারকারীর কোনো রেফারেল রেকর্ড নেই।",
    };
  }

  // Duplicate Guard & Re-verification Rule (Rule 5):
  // A user CANNOT generate a second qualification for the same referral relationship after already qualifying.
  if (referral.status === "QUALIFIED" || referral.qualified_at) {
    return {
      success: true,
      qualified: false,
      referralId: referral.referral_id || referral.id,
      message: "রেফারেলটি ইতিমধ্যে কোয়ালিফাইড। ডুপ্লিকেট ক্রেডিট রোধ করা হয়েছে।",
    };
  }

  // Only convert if status is REGISTERED (or PENDING from legacy)
  if (referral.status !== "REGISTERED" && referral.status !== "PENDING") {
    return {
      success: true,
      qualified: false,
      message: `রেফারেলের বর্তমান স্ট্যাটাস (${referral.status}) কোয়ালিফিকেশন সমর্থন করে না।`,
    };
  }

  const referrerId = referral.referrer_id || referral.referrerId;
  if (!referrerId) {
    return {
      success: false,
      qualified: false,
      message: "রেফারারের আইডি পাওয়া যায়নি।",
    };
  }

  const referrer = db.users.find((u: any) => u.id === referrerId);
  const referredUser = db.users.find((u: any) => u.id === verifiedUserId);

  // Prevent qualification on banned or restricted accounts
  if (
    referrer?.isBanned ||
    referrer?.status === "banned" ||
    referrer?.status === "suspended" ||
    referrer?.risk_status === "RESTRICTED" ||
    referrer?.risk_status === "BANNED" ||
    referredUser?.isBanned ||
    referredUser?.status === "banned" ||
    referredUser?.status === "suspended" ||
    referredUser?.risk_status === "RESTRICTED" ||
    referredUser?.risk_status === "BANNED"
  ) {
    return {
      success: false,
      qualified: false,
      message: "অ্যাকাউন্ট নিরাপত্তা স্থগিতাদেশ বা নিষেধাজ্ঞায় থাকায় রেফারেল কোয়ালিফাই বাতিল করা হয়েছে।",
    };
  }

  const nowISO = new Date().toISOString();
  const rewardPoints = db.settings?.referralReward || 300;

  // 1. Update referral status to QUALIFIED
  referral.status = "QUALIFIED";
  referral.qualified_at = nowISO;
  referral.rule_version = RULE_VERSION;
  referral.bonus_amount = rewardPoints;
  referral.pointsEarned = rewardPoints;
  referral.isVerified = true;

  // 2. Direct Referral Isolation: ONLY direct referrer gets qualified_referral_count + 1
  if (referrer) {
    referrer.qualified_referral_count = (referrer.qualified_referral_count || 0) + 1;
    if (!referrer.wallet) {
      referrer.wallet = {
        points: 0,
        walletAddress: "",
        status: "active",
        updatedAt: nowISO,
      };
    }
    referrer.wallet.points = (referrer.wallet.points || 0) + rewardPoints;
    referrer.wallet.updatedAt = nowISO;

    if (!referrer.taskStats) {
      referrer.taskStats = {
        missionsCompleted: 0,
        totalPointsEarned: 0,
        moviesWatched: 0,
        videosWatched: 0,
      };
    }
    referrer.taskStats.totalPointsEarned = (referrer.taskStats.totalPointsEarned || 0) + rewardPoints;

    // Record wallet ledger transaction
    if (!db.transactions) db.transactions = [];
    const txId = `tx_${Date.now()}_ref_qual_${referral.referral_id || referral.id}`;
    db.transactions.push({
      id: txId,
      userId: referrer.id,
      amount: rewardPoints,
      type: "reward_referral",
      status: "completed",
      description: `VRMS-3 Direct Referral Qualified (+${rewardPoints}) for ${referredUser ? referredUser.fullName : "Referred Member"}`,
      timestamp: nowISO,
    });

    // In-app notification for referrer
    if (!db.notifications) db.notifications = [];
    db.notifications.push({
      id: `nt_ref_qual_${Date.now()}`,
      userId: referrer.id,
      title: `🎉 রেফারেল কোয়ালিফাইড (+${rewardPoints})!`,
      message: `আপনার রেফারেল ${referredUser ? referredUser.fullName : "মেম্বার"} ভেরিফিকেশন সফলভাবে সম্পন্ন করেছে! আপনি +${rewardPoints} বোনাস পেয়েছেন।`,
      isRead: false,
      timestamp: nowISO,
    });
  }

  invalidateReferralIndexes();
  if (!providedDb) {
    writeDB(db);
  }

  // Sync to Firestore
  (async () => {
    try {
      if (await isFirestoreWritable()) {
        const refDocId = referral.referral_id || referral.id || `ref_${referrerId}_${verifiedUserId}`;
        await setDoc(
          doc(firestore, "referrals", refDocId),
          {
            status: "QUALIFIED",
            qualified_at: nowISO,
            bonus_amount: rewardPoints,
            rule_version: RULE_VERSION,
          },
          { merge: true }
        );

        if (referrer) {
          await setDoc(
            doc(firestore, "users", referrer.id),
            {
              qualified_referral_count: referrer.qualified_referral_count,
              points: referrer.wallet.points,
              "wallet.points": referrer.wallet.points,
              "wallet.updatedAt": nowISO,
            },
            { merge: true }
          );
        }
      }
    } catch (err) {
      console.warn("Firestore sync warning on referral qualification:", err);
    }
  })();

  return {
    success: true,
    qualified: true,
    referralId: referral.referral_id || referral.id,
    referrerId,
    rewardPoints,
    message: "রেফারেল সফলভাবে কোয়ালিফাই হয়েছে এবং ডিরেক্ট রেফারারের পয়েন্ট যুক্ত হয়েছে।",
  };
}

/**
 * Returns referral overview, counts, and breakdown for a user
 */
export function getReferralOverviewForUser(userId: string): {
  success: boolean;
  userId: string;
  referralCode: string;
  referralLink: string;
  registeredCount: number;
  qualifiedCount: number;
  totalInvited: number;
  totalEarnedPoints: number;
  referrals: Array<{
    referral_id: string;
    referred_user_id: string;
    referred_username: string;
    referred_fullname: string;
    status: "REGISTERED" | "QUALIFIED" | "PURGED";
    status_label: string;
    registered_at: string;
    qualified_at: string | null;
    bonus_amount: number;
    active_days: number;
    valid_actions: number;
    quiz_status: string;
    is_verified: boolean;
  }>;
} {
  const db = readDB();
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );

  const effectiveId = user ? user.id : userId;
  const telegramId = user?.telegramId || effectiveId.replace(/^tg-/, "") || "101";
  const referralCode = `REF_${telegramId}`;
  const referralLink = `https://t.me/MyTeleFlixBot/app?startapp=${referralCode}`;

  const indexes = getReferralIndexes(db);
  const userReferrals = indexes.byReferrerId.get(effectiveId) || [];

  let registeredCount = 0;
  let qualifiedCount = 0;
  let totalEarnedPoints = 0;

  const referralList = userReferrals.map((ref) => {
    const refUserId = ref.referred_user_id || ref.referredId || "";
    const referredUser = db.users.find((u: any) => u.id === refUserId);
    const verRec = (db.verification_records || []).find((v) => v.user_id === refUserId);

    const isQualified = ref.status === "QUALIFIED";
    const isPurged = ref.status === "PURGED";

    if (isQualified) {
      qualifiedCount += 1;
      totalEarnedPoints += ref.bonus_amount || ref.pointsEarned || 300;
    } else if (!isPurged) {
      registeredCount += 1;
    }

    const activeDays = isPurged ? 0 : (referredUser?.active_day_streak || verRec?.active_days || 0);
    const validActions = isPurged ? 0 : (referredUser?.valid_action_count || verRec?.valid_actions || 0);
    const isQuizPassed = isPurged ? false : Boolean(referredUser?.isQuizPassed || verRec?.quiz_status === "PASSED");
    const isVerified = isPurged ? false : Boolean(
      referredUser?.is_verified || verRec?.verification_status === "VERIFIED" || isQualified
    );

    const statusLabel = isPurged ? "Purged (30d Inactive)" : (isQualified ? "Qualified" : "Pending Verification");

    return {
      referral_id: ref.referral_id || ref.id || `ref_${effectiveId}_${refUserId}`,
      referred_user_id: refUserId,
      referred_username: ref.referred_username || ref.referredUsername || referredUser?.username || "user",
      referred_fullname: ref.referred_fullname || ref.referredFullName || referredUser?.fullName || "Member",
      status: ref.status,
      status_label: statusLabel,
      registered_at: ref.registered_at || ref.timestamp || new Date().toISOString(),
      qualified_at: ref.qualified_at || null,
      bonus_amount: ref.bonus_amount || ref.pointsEarned || 0,
      active_days: activeDays,
      valid_actions: validActions,
      quiz_status: isQuizPassed ? "PASSED" : "PENDING",
      is_verified: isVerified,
    };
  });

  return {
    success: true,
    userId: effectiveId,
    referralCode,
    referralLink,
    registeredCount,
    qualifiedCount,
    totalInvited: userReferrals.length,
    totalEarnedPoints,
    referrals: referralList,
  };
}
