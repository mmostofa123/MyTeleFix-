/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import { readDB, writeDB, UserProfile } from "./db.js";
import { recordPendingReferral } from "./referrals.js";
import { SUPER_ADMIN_EMAIL, SUPER_ADMIN_TELEGRAM_ID, SUPER_ADMIN_USERNAME, isSuperAdminEmail } from "./inactivityPurge.js";
import { 
  acquireUserPurgeLock, 
  releaseUserPurgeLock, 
  touchAuthenticatedAccess, 
  handlePurgedUserReRegistration 
} from "./purgeEngine.js";
import { findDeviceLockMatch, normalizeGpuChipset, normalizePhysicalScreen } from "./deviceSecurity.js";

/**
 * Validates Telegram Mini App initData using HMAC SHA-256 signatures.
 */
export function verifyTelegramInitData(initDataRaw: string, botToken: string = process.env.BOT_TOKEN || "DEFAULT_TELEGRAM_BOT_TOKEN"): { isValid: boolean; user?: any; startParam?: string } {
  if (!initDataRaw) return { isValid: false };

  try {
    const urlParams = new URLSearchParams(initDataRaw);
    const hash = urlParams.get("hash");

    if (!hash) {
      // Development / Testing fallback for JSON simulation payloads
      try {
        const parsed = JSON.parse(initDataRaw);
        if (parsed.id || parsed.telegramId) {
          return { isValid: true, user: parsed, startParam: parsed.startParam || parsed.start_param };
        }
      } catch (e) {
        // ignore
      }
      return { isValid: false };
    }

    urlParams.delete("hash");

    const params: string[] = [];
    urlParams.forEach((val, key) => {
      params.push(`${key}=${val}`);
    });
    params.sort();
    const dataCheckString = params.join("\n");

    const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest();
    const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

    const isValid = calculatedHash === hash || botToken === "DEFAULT_TELEGRAM_BOT_TOKEN";

    let user: any = null;
    const userStr = urlParams.get("user");
    if (userStr) {
      try {
        user = JSON.parse(userStr);
      } catch (e) {
        // ignore
      }
    }

    const startParam = urlParams.get("start_param") || urlParams.get("startParam");

    return { isValid, user, startParam: startParam || undefined };
  } catch (err) {
    return { isValid: false };
  }
}

export interface TelegramAuthPayload {
  telegramId?: string | number;
  username?: string;
  firstName?: string;
  lastName?: string;
  photoUrl?: string;
  startParam?: string;
  initData?: string;
  device_fingerprint?: string;
  guest_device_id?: string;
}

export function handleTelegramAuth(payload: TelegramAuthPayload, headerInitData?: string): { user: UserProfile; settings: any; isNew?: boolean; isLockedToExisting?: boolean } {
  let { telegramId, username, firstName, lastName, photoUrl, startParam, initData, device_fingerprint, guest_device_id } = payload;
  const rawInitData = initData || headerInitData;

  if (rawInitData) {
    const verified = verifyTelegramInitData(rawInitData);
    if (verified.isValid && verified.user) {
      telegramId = verified.user.id || verified.user.telegramId || telegramId;
      username = verified.user.username || username;
      firstName = verified.user.first_name || verified.user.firstName || firstName;
      lastName = verified.user.last_name || verified.user.lastName || lastName;
      photoUrl = verified.user.photo_url || verified.user.photoUrl || photoUrl;
      if (verified.startParam) {
        startParam = verified.startParam;
      }
    }
  }

  const db = readDB();

  if (!telegramId) {
    throw new Error("Missing telegramId or valid initData parameter.");
  }

  const tgIdStr = String(telegramId);
  const uid = `tg-${tgIdStr}`;
  const fullNameCalculated = ([firstName, lastName].filter(Boolean).join(" ") || username || `User ${tgIdStr}`).trim();

  // Check if user already exists by telegramId or uid
  let user = db.users.find((u: any) => String(u.telegramId) === tgIdStr || u.id === uid);

  // Default admin Telegram ID or Super Admin email
  const isTargetAdmin = (username && username.toLowerCase() === SUPER_ADMIN_USERNAME.toLowerCase()) || 
    tgIdStr === SUPER_ADMIN_TELEGRAM_ID;
  const targetRole = isTargetAdmin ? "admin" : "user";

  if (!user) {
    const welcomePoints = 100; // Welcome Bonus requirement
    
    user = {
      id: uid,
      telegramId: tgIdStr,
      username: username || `tg_${tgIdStr}`,
      fullName: fullNameCalculated,
      email: `${username || tgIdStr}@telegram.org`,
      photoUrl: photoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
      role: targetRole,
      isPremium: false,
      status: "active",
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      last_active_at: new Date().toISOString(),
      last_authenticated_access_at: new Date().toISOString(),
      inactivity_status: "ACTIVE",
      device_fingerprint: device_fingerprint,
      authProvider: "telegram",
      wallet: {
        points: welcomePoints,
        walletAddress: "",
        status: "active",
        updatedAt: new Date().toISOString()
      },
      taskStats: {
        missionsCompleted: 0,
        totalPointsEarned: welcomePoints,
        moviesWatched: 0,
        videosWatched: 0
      },
      points: welcomePoints
    };

    // Ledger Entry for Welcome Bonus
    db.transactions.push({
      id: "tx-welcome-" + Date.now(),
      userId: uid,
      amount: welcomePoints,
      type: "deposit",
      status: "completed",
      description: "My TeleFlix Telegram Welcome Bonus!",
      timestamp: new Date().toISOString()
    });

    // Welcome Notification
    db.notifications.push({
      id: "nt-welcome-" + Date.now(),
      userId: uid,
      title: "🎁 Welcome Bonus Credited!",
      message: `Welcome to My TeleFlix! We've credited +${welcomePoints} welcome bonus to your account!`,
      isRead: false,
      timestamp: new Date().toISOString()
    });

    // Check Referral Start Param (e.g. REF_703119315615 or REF_101 or 703119315615)
    if (startParam) {
      recordPendingReferral(startParam, user);
    }

    if (guest_device_id) {
      user.guest_device_id = guest_device_id;
      const guestIdx = db.users.findIndex((u: any) => u.id === guest_device_id);
      if (guestIdx !== -1) {
        const guestUser = db.users[guestIdx];
        if (guestUser.taskStats) {
          user.taskStats.moviesWatched = (user.taskStats.moviesWatched || 0) + (guestUser.taskStats.moviesWatched || 0);
          user.taskStats.videosWatched = (user.taskStats.videosWatched || 0) + (guestUser.taskStats.videosWatched || 0);
          user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + (guestUser.taskStats.missionsCompleted || 0);
        }
        db.users.splice(guestIdx, 1);
      }
    }

    db.users.push(user);
    writeDB(db);
    return { user, settings: db.settings, isNew: true };
  } else {
    acquireUserPurgeLock(user.id);
    try {
      if (user.inactivity_status === "PURGED") {
        user = handlePurgedUserReRegistration(user, db);
        return { user, settings: db.settings, isNew: true };
      }

      touchAuthenticatedAccess(user.id, db);
      user.lastLogin = new Date().toISOString();
      user.last_active_at = new Date().toISOString();
      if (device_fingerprint && !user.device_fingerprint) {
        user.device_fingerprint = device_fingerprint;
      }
      if (guest_device_id && !user.guest_device_id) {
        user.guest_device_id = guest_device_id;
      }
      if (username) user.username = username;
      if (fullNameCalculated) user.fullName = fullNameCalculated;
      if (photoUrl) user.photoUrl = photoUrl;
      if (isTargetAdmin) user.role = "admin";
      user.points = user.wallet?.points ?? user.points ?? 100;

      writeDB(db);
      return { user, settings: db.settings, isNew: false };
    } finally {
      releaseUserPurgeLock(user.id);
    }
  }
}

export interface GoogleAuthPayload {
  googleId?: string;
  email: string;
  fullName?: string;
  photoUrl?: string;
  device_fingerprint?: string;
  hwid?: string;
  cross_browser_hwid?: string;
  hardware_uuid?: string;
  gpu_renderer?: string;
  gpu_chipset?: string;
  screen_resolution?: string;
  physical_screen?: string;
  hardware_concurrency?: number;
  cpu_cores?: number;
  timezone?: string;
  platform?: string;
  platform_family?: string;
  guest_device_id?: string;
  startParam?: string;
  adminPasskey?: string;
  credential?: string;
  gender?: 'male' | 'female' | 'other';
  ip_address?: string;
}

export function handleGoogleAuth(payload: GoogleAuthPayload): { user: UserProfile; settings: any; isNew?: boolean; isLockedToExisting?: boolean } {
  const db = readDB();
  const { 
    email, 
    googleId, 
    fullName, 
    photoUrl, 
    device_fingerprint, 
    hwid,
    cross_browser_hwid,
    hardware_uuid,
    gpu_renderer,
    gpu_chipset,
    screen_resolution,
    physical_screen,
    hardware_concurrency,
    cpu_cores,
    timezone,
    platform,
    platform_family,
    guest_device_id, 
    startParam, 
    adminPasskey, 
    gender, 
    ip_address 
  } = payload;

  if (!email) {
    throw new Error("Missing email in Google authentication payload.");
  }

  const cleanEmail = email.toLowerCase().trim();
  const isTargetAdmin = isSuperAdminEmail(cleanEmail) || cleanEmail === "mostofa7077a@gmail.com";
  const targetRole = isTargetAdmin ? "admin" : "user";

  const normGpu = gpu_chipset || (gpu_renderer ? normalizeGpuChipset(gpu_renderer) : undefined);
  const normScreen = physical_screen || (screen_resolution ? normalizePhysicalScreen(screen_resolution) : undefined);
  const cores = cpu_cores || hardware_concurrency || undefined;

  // STRICT CROSS-BROWSER 1-DEVICE = 1-ACCOUNT ANTI-FRAUD ENFORCEMENT:
  // Non-admin accounts cannot register or log in on a device that already has a different account bound to it.
  if (!isTargetAdmin) {
    const match = findDeviceLockMatch(db, {
      hwid,
      cross_browser_hwid,
      hardware_uuid,
      device_fingerprint,
      gpu_renderer,
      gpu_chipset: normGpu,
      screen_resolution,
      physical_screen: normScreen,
      hardware_concurrency: cores,
      cpu_cores: cores,
      timezone,
      ip_address,
      platform,
      platform_family
    });

    if (match.isLocked && match.primaryEmail && cleanEmail !== match.primaryEmail) {
      const boundPrimaryEmail = match.primaryEmail;
      const boundUser = match.user || db.users.find((u: any) => u.email && u.email.toLowerCase().trim() === boundPrimaryEmail);
      const err: any = new Error("আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য");
      err.blocked = true;
      err.statusCode = 403;
      err.primaryEmail = boundPrimaryEmail;
      err.existingAccount = {
        id: boundUser?.id || match.lock?.user_id || `u_${boundPrimaryEmail.replace(/[^a-zA-Z0-9]/g, '_')}`,
        email: boundPrimaryEmail,
        username: boundUser?.username || boundPrimaryEmail.split("@")[0],
        fullName: boundUser?.fullName || boundUser?.displayName || boundPrimaryEmail.split("@")[0],
        photoUrl: boundUser?.photoUrl
      };
      err.deviceFingerprint = device_fingerprint || hwid || cross_browser_hwid;
      err.hwid = hwid || match.lock?.hwid;
      err.ipAddress = ip_address;
      throw err;
    }
  }

  // Check if account already exists for this email
  let existingUserByEmail = db.users.find(
    (u: any) =>
      (u.email && u.email.toLowerCase().trim() === cleanEmail) ||
      (googleId && (u.googleId === googleId || u.id === googleId || u.id === `g-${googleId}`))
  );

  if (existingUserByEmail) {
    acquireUserPurgeLock(existingUserByEmail.id);
    try {
      if (existingUserByEmail.inactivity_status === "PURGED") {
        const newUser = handlePurgedUserReRegistration(existingUserByEmail, db);
        return { user: newUser, settings: db.settings, isNew: true, isLockedToExisting: false };
      }

      touchAuthenticatedAccess(existingUserByEmail.id, db);
      existingUserByEmail.lastLogin = new Date().toISOString();
      existingUserByEmail.last_active_at = new Date().toISOString();
      if (device_fingerprint) existingUserByEmail.device_fingerprint = device_fingerprint;
      if (ip_address) (existingUserByEmail as any).registered_ip = ip_address;
      if (gender) (existingUserByEmail as any).gender = gender;
      if (fullName && !existingUserByEmail.fullName) existingUserByEmail.fullName = fullName;
      if (photoUrl && !existingUserByEmail.photoUrl) existingUserByEmail.photoUrl = photoUrl;
      
      if (isTargetAdmin) {
        existingUserByEmail.role = "admin";
      } else {
        existingUserByEmail.role = "user";
      }

      // Update/bind device lock in db.device_locks for this user
      if (hwid || cross_browser_hwid || device_fingerprint) {
        if (!(db as any).device_locks) (db as any).device_locks = [];
        const lockKey = cross_browser_hwid || hwid || device_fingerprint;
        const existingLockIdx = (db as any).device_locks.findIndex((l: any) => 
          (hwid && l.hwid === hwid) || 
          (cross_browser_hwid && l.cross_browser_hwid === cross_browser_hwid) || 
          (l.primary_email === cleanEmail)
        );
        const lockRecord = {
          hwid: hwid || lockKey,
          cross_browser_hwid: cross_browser_hwid || hwid || lockKey,
          device_fingerprint: device_fingerprint || hwid,
          hardware_uuid: hardware_uuid,
          gpu_renderer: gpu_renderer,
          gpu_chipset: normGpu,
          screen_resolution: screen_resolution,
          physical_screen: normScreen,
          hardware_concurrency: cores,
          cpu_cores: cores,
          timezone: timezone,
          platform_family: platform_family || platform,
          ip_address: ip_address,
          primary_email: cleanEmail,
          user_id: existingUserByEmail.id,
          updated_at: new Date().toISOString()
        };
        if (existingLockIdx >= 0) {
          (db as any).device_locks[existingLockIdx] = { ...(db as any).device_locks[existingLockIdx], ...lockRecord };
        } else {
          (db as any).device_locks.push({ ...lockRecord, created_at: new Date().toISOString() });
        }
      }
      
      writeDB(db);
      return { user: existingUserByEmail, settings: db.settings, isNew: false, isLockedToExisting: false };
    } finally {
      releaseUserPurgeLock(existingUserByEmail.id);
    }
  }

  // User does not exist yet: create a brand new account for this email
  let user: UserProfile | undefined = undefined;

  if (!user) {
    const welcomePoints = 100;
    const gId = googleId || cleanEmail.replace(/[^a-zA-Z0-9]/g, '_');
    const uid = googleId && (googleId.startsWith('g-') || googleId.length >= 20) ? googleId : `g-${gId}`;
    const calculatedName = fullName || cleanEmail.split("@")[0] || "Google Explorer";

    user = {
      id: uid,
      telegramId: "",
      googleId: gId,
      username: cleanEmail.split("@")[0],
      fullName: calculatedName,
      email: cleanEmail,
      photoUrl: photoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
      role: targetRole,
      isPremium: false,
      status: "active",
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      last_active_at: new Date().toISOString(),
      last_authenticated_access_at: new Date().toISOString(),
      inactivity_status: "ACTIVE",
      device_fingerprint: device_fingerprint,
      authProvider: "google",
      gender: gender,
      wallet: {
        points: welcomePoints,
        walletAddress: "",
        status: "active",
        updatedAt: new Date().toISOString()
      },
      taskStats: {
        missionsCompleted: 0,
        totalPointsEarned: welcomePoints,
        moviesWatched: 0,
        videosWatched: 0
      },
      points: welcomePoints
    };

    // Ledger Entry for Welcome Bonus
    db.transactions.push({
      id: "tx-welcome-" + Date.now(),
      userId: uid,
      amount: welcomePoints,
      type: "deposit",
      status: "completed",
      description: "My TeleFlix Google Welcome Bonus!",
      timestamp: new Date().toISOString()
    });

    // Welcome Notification
    db.notifications.push({
      id: "nt-welcome-" + Date.now(),
      userId: uid,
      title: "🎁 Welcome Bonus Credited!",
      message: `Welcome to My TeleFlix! We've credited +${welcomePoints} welcome bonus to your account!`,
      isRead: false,
      timestamp: new Date().toISOString()
    });

    if (startParam) {
      recordPendingReferral(startParam, user);
    }

    if (guest_device_id) {
      user.guest_device_id = guest_device_id;
      const guestIdx = db.users.findIndex((u: any) => u.id === guest_device_id);
      if (guestIdx !== -1) {
        const guestUser = db.users[guestIdx];
        if (guestUser.taskStats) {
          user.taskStats.moviesWatched = (user.taskStats.moviesWatched || 0) + (guestUser.taskStats.moviesWatched || 0);
          user.taskStats.videosWatched = (user.taskStats.videosWatched || 0) + (guestUser.taskStats.videosWatched || 0);
          user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + (guestUser.taskStats.missionsCompleted || 0);
        }
        db.users.splice(guestIdx, 1);
      }
    }

    // Bind hardware device lock to this primary account across browsers
    if (hwid || cross_browser_hwid || device_fingerprint) {
      if (!(db as any).device_locks) (db as any).device_locks = [];
      const primaryLockId = cross_browser_hwid || hwid || device_fingerprint;
      const existingLockIdx = (db as any).device_locks.findIndex((l: any) => 
        (hwid && l.hwid === hwid) || (cross_browser_hwid && l.cross_browser_hwid === cross_browser_hwid) || (primaryLockId && l.hwid === primaryLockId)
      );
      const lockData = {
        hwid: hwid || primaryLockId,
        cross_browser_hwid: cross_browser_hwid || hwid || primaryLockId,
        device_fingerprint: device_fingerprint || hwid,
        hardware_uuid: hardware_uuid,
        gpu_renderer: gpu_renderer,
        gpu_chipset: normGpu,
        screen_resolution: screen_resolution,
        physical_screen: normScreen,
        hardware_concurrency: cores,
        cpu_cores: cores,
        timezone: timezone,
        platform_family: platform_family || platform,
        ip_address: ip_address,
        primary_email: cleanEmail,
        user_id: user.id,
        created_at: existingLockIdx >= 0 ? (db as any).device_locks[existingLockIdx].created_at : new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      if (existingLockIdx >= 0) {
        (db as any).device_locks[existingLockIdx] = { ...(db as any).device_locks[existingLockIdx], ...lockData };
      } else {
        (db as any).device_locks.push(lockData);
      }
    }

    db.users.push(user);
    writeDB(db);
    return { user, settings: db.settings, isNew: true };
  } else {
    user.lastLogin = new Date().toISOString();
    user.last_active_at = new Date().toISOString();
    if (device_fingerprint && !user.device_fingerprint) {
      user.device_fingerprint = device_fingerprint;
    }
    if (guest_device_id && !user.guest_device_id) {
      user.guest_device_id = guest_device_id;
    }
    if (fullName) user.fullName = fullName;
    if (photoUrl) user.photoUrl = photoUrl;
    if (gender) user.gender = gender;
    user.role = isTargetAdmin ? "admin" : "user";
    user.points = user.wallet?.points ?? user.points ?? 100;

    writeDB(db);
    return { user, settings: db.settings, isNew: false };
  }
}

export function handleAuthSwitch(payload: { userId: string; username?: string; fullName?: string; isPremium?: boolean; referrerId?: string }): { user: UserProfile; settings: any } {
  const { userId, username, fullName, isPremium, referrerId } = payload;
  const db = readDB();
  
  let user = db.users.find((u: any) => u.id === userId);
  const targetRole = (userId === "admin-demo-id") ? "admin" : "user";

  if (!user) {
    user = {
      id: userId,
      telegramId: Math.floor(100000000 + Math.random() * 900000000).toString(),
      username: username || "user_" + userId,
      fullName: fullName || "User " + userId,
      email: `${username || userId}@demo-myteleflix.com`,
      photoUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80`,
      role: targetRole,
      isPremium: !!isPremium,
      status: "active",
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      wallet: {
        points: 1000,
        walletAddress: "",
        status: "active",
        updatedAt: new Date().toISOString()
      },
      taskStats: {
        missionsCompleted: 0,
        totalPointsEarned: 1000,
        moviesWatched: 0,
        videosWatched: 0
      }
    };

    if (referrerId) {
      recordPendingReferral(referrerId, user);
    }

    db.users.push(user);
    writeDB(db);
  } else {
    user.lastLogin = new Date().toISOString();
    if (username) user.username = username;
    if (fullName) user.fullName = fullName;
    if (isPremium !== undefined) user.isPremium = isPremium;
    writeDB(db);
  }

  return { user, settings: db.settings };
}
