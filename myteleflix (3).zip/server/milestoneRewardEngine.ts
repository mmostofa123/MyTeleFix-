/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 6): Referral Milestone Reward Engine (RME)
 * 
 * NON-NEGOTIABLE SYSTEM RULES:
 * 1. SEPARATE SYSTEM: Milestone rewards are completely separate from Monthly Salary.
 * 2. CURRENT QUALIFIED COUNT ONLY: Milestone eligibility MUST exclude purged, banned, or restricted users.
 * 3. REWARD STATE MACHINE: Strictly enforce transitions:
 *    LOCKED -> PENDING -> CLAIMABLE -> CREDITED.
 *    Reversal path: CREDITED -> REVIEW -> REVERSED.
 * 4. IDEMPOTENT CREDITING: A milestone can be credited ONLY ONCE per user + milestone + campaign + rule version.
 *    Duplicate claims MUST be rejected server-side.
 * 5. FINANCIAL INTEGRITY: Never delete a settled financial record. Reversals must create a new ledger entry referencing the original.
 * 6. FRONTEND AUTHORITY RESTRICTION: Reward amounts and thresholds MUST NOT be hardcoded on the client.
 *    All figures must be fetched from backend config.
 */

import { 
  readDB, 
  writeDB, 
  DBState, 
  MilestoneConfig, 
  ReferralRewardRecord, 
  UserProfile,
  DEFAULT_MILESTONE_CONFIGS,
  getActiveCampaign,
  recordLedgerEntry
} from "./db.js";
import { touchAuthenticatedAccess } from "./purgeEngine.js";
import { emitMilestoneAlert } from "./notificationEngine.js";
import crypto from "crypto";

export interface MilestoneEvaluationItem {
  milestone_id: string;
  campaign_id: string;
  threshold: number;
  amount: number;
  title: string;
  description: string;
  status: 'LOCKED' | 'PENDING' | 'CLAIMABLE' | 'CREDITED' | 'REVIEW' | 'REVERSED';
  current_count: number;
  progress_percent: number;
  max_per_user: number;
  rule_version: number;
  claimed_at: string | null;
  reward_id?: string;
  is_claimable: boolean;
  is_claimed: boolean;
}

export interface UserMilestoneStatusResponse {
  success: boolean;
  userId: string;
  qualifiedCount: number;
  totalMilestones: number;
  claimedCount: number;
  claimableCount: number;
  totalClaimedRewardPoints: number;
  campaign: {
    campaign_id: string;
    rule_version: number;
    budget: number;
    total_claimed_amount: number;
  };
  milestones: MilestoneEvaluationItem[];
}

export interface ClaimMilestoneResult {
  success: boolean;
  code?: 'USER_NOT_FOUND' | 'USER_RESTRICTED' | 'CONFIG_NOT_FOUND' | 'CONFIG_INACTIVE' | 'CAMPAIGN_EXPIRED' | 'THRESHOLD_NOT_MET' | 'BUDGET_EXHAUSTED' | 'ALREADY_CLAIMED' | 'MAX_LIMIT_REACHED' | 'SERVER_ERROR';
  message: string;
  reward?: ReferralRewardRecord;
  claimedAmount?: number;
  newPointsTotal?: number;
}

/**
 * RULE 2: Calculate server-authoritative CURRENT QUALIFIED referrals for milestone eligibility.
 * MUST exclude:
 * - Purged referrals (ref.status === 'PURGED')
 * - Purged referred users (user.inactivity_status === 'PURGED')
 * - Banned or restricted referred users (user.isBanned, user.status === 'banned' | 'restricted')
 * - Unverified referred users (referee must be is_verified || isHumanVerified)
 */
export function calculateCurrentQualifiedReferrals(
  referrerId: string, 
  db: DBState
): { count: number; qualifiedReferralIds: string[] } {
  if (!referrerId) return { count: 0, qualifiedReferralIds: [] };

  const referrals = db.referrals || [];
  const users = db.users || [];
  const verificationRecords = db.verification_records || [];

  // Match referrer by either user ID or telegramId
  const referrer = users.find((u: any) => u.id === referrerId || u.telegramId === referrerId.replace(/^tg-/, ""));
  const effectiveReferrerId = referrer ? referrer.id : referrerId;

  const userMap = new Map<string, UserProfile>();
  users.forEach((u: any) => userMap.set(u.id, u));

  const verMap = new Map<string, any>();
  verificationRecords.forEach((v) => verMap.set(v.user_id, v));

  let qualifiedCount = 0;
  const qualifiedReferralIds: string[] = [];

  for (const ref of referrals) {
    const rReferrerId = ref.referrer_id || ref.referrerId;
    if (rReferrerId !== effectiveReferrerId) continue;

    // Check referral record status
    if (ref.status !== "QUALIFIED") continue;

    const refUserId = ref.referred_user_id || ref.referredId;
    if (!refUserId) continue;

    const referredUser = userMap.get(refUserId);
    // If referred user is deleted or purged, skip
    if (!referredUser) continue;
    if (referredUser.inactivity_status === "PURGED") continue;
    if (referredUser.isBanned || referredUser.status === "banned" || referredUser.status === "suspended" || referredUser.risk_status === "RESTRICTED" || referredUser.risk_status === "BANNED") continue;

    // Check verification status
    const verRec = verMap.get(refUserId);
    const isVerified = Boolean(
      referredUser.is_verified || 
      referredUser.isHumanVerified || 
      (verRec && verRec.status === "VERIFIED")
    );

    if (!isVerified) continue;

    qualifiedCount += 1;
    qualifiedReferralIds.push(ref.referral_id || ref.id || `${rReferrerId}_${refUserId}`);
  }

  return { count: qualifiedCount, qualifiedReferralIds };
}

/**
 * Evaluates full milestone status for a given user against all active milestone configurations.
 */
export function evaluateUserMilestones(
  userId: string, 
  providedDb?: DBState
): UserMilestoneStatusResponse {
  const db = providedDb || readDB();

  // Find user
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  const effectiveUserId = user ? user.id : userId;

  // Calculate current verified, non-purged qualified referrals
  const { count: qualifiedCount } = calculateCurrentQualifiedReferrals(effectiveUserId, db);

  // Active milestone configurations sorted by threshold ascending
  const configs = (db.milestone_configs && db.milestone_configs.length > 0 
    ? db.milestone_configs 
    : DEFAULT_MILESTONE_CONFIGS
  ).slice().sort((a, b) => a.threshold - b.threshold);

  const rewards = db.referral_rewards || [];
  const now = new Date();

  let claimedCount = 0;
  let claimableCount = 0;
  let totalClaimedRewardPoints = 0;

  const milestoneItems: MilestoneEvaluationItem[] = configs.map((cfg) => {
    // Find existing rewards for this user and milestone
    const userRewards = rewards.filter(
      (r) => 
        r.user_id === effectiveUserId && 
        r.milestone_id === cfg.milestone_id &&
        r.campaign_id === cfg.campaign_id &&
        r.rule_version === cfg.rule_version
    );

    const creditedReward = userRewards.find((r) => r.status === "CREDITED");
    const reviewReward = userRewards.find((r) => r.status === "REVIEW");
    const reversedReward = userRewards.find((r) => r.status === "REVERSED");

    const isClaimed = !!creditedReward;
    if (isClaimed) {
      claimedCount += 1;
      totalClaimedRewardPoints += creditedReward.amount;
    }

    // Determine state based on State Machine:
    // LOCKED -> PENDING -> CLAIMABLE -> CREDITED (Reversal path: CREDITED -> REVIEW -> REVERSED)
    let status: 'LOCKED' | 'PENDING' | 'CLAIMABLE' | 'CREDITED' | 'REVIEW' | 'REVERSED' = 'LOCKED';
    let claimed_at: string | null = null;
    let reward_id: string | undefined = undefined;

    if (creditedReward) {
      status = 'CREDITED';
      claimed_at = creditedReward.claimed_at;
      reward_id = creditedReward.reward_id;
    } else if (reviewReward) {
      status = 'REVIEW';
      reward_id = reviewReward.reward_id;
    } else if (reversedReward) {
      status = 'REVERSED';
      reward_id = reversedReward.reward_id;
    } else {
      // Not yet claimed: evaluate threshold, campaign status and budget
      const meetsThreshold = qualifiedCount >= cfg.threshold;
      const isCampaignActive = cfg.status === "ACTIVE";
      const isStarted = !cfg.active_from || new Date(cfg.active_from) <= now;
      const notExpired = !cfg.active_to || new Date(cfg.active_to) >= now;
      const hasBudget = (cfg.total_claimed_amount || 0) + cfg.amount <= cfg.budget;
      const isUserEligible = !user?.isBanned && user?.status !== "banned" && user?.status !== "suspended";

      if (meetsThreshold && isCampaignActive && isStarted && notExpired && hasBudget && isUserEligible) {
        status = 'CLAIMABLE';
        claimableCount += 1;
      } else if (meetsThreshold && (!isCampaignActive || !hasBudget || !notExpired)) {
        // Condition met but campaign paused, over-budget, or under review
        status = 'PENDING';
      } else {
        status = 'LOCKED';
      }
    }

    const current_count = Math.min(qualifiedCount, cfg.threshold);
    const progress_percent = Math.min(100, Math.round((qualifiedCount / cfg.threshold) * 100));

    return {
      milestone_id: cfg.milestone_id,
      campaign_id: cfg.campaign_id,
      threshold: cfg.threshold,
      amount: cfg.amount,
      title: cfg.title || `Milestone ${cfg.threshold}`,
      description: cfg.description || `Reach ${cfg.threshold} qualified referrals`,
      status,
      current_count,
      progress_percent,
      max_per_user: cfg.max_per_user || 1,
      rule_version: cfg.rule_version || 1,
      claimed_at,
      reward_id,
      is_claimable: status === 'CLAIMABLE',
      is_claimed: status === 'CREDITED'
    };
  });

  const dynamicActiveCampaign = getActiveCampaign(db);
  const activeCampaign = dynamicActiveCampaign || configs[0] || {
    campaign_id: "default_campaign",
    rule_version: 1,
    budget: 50000000,
    total_claimed_amount: 0
  };

  return {
    success: true,
    userId: effectiveUserId,
    qualifiedCount,
    totalMilestones: configs.length,
    claimedCount,
    claimableCount,
    totalClaimedRewardPoints,
    campaign: {
      campaign_id: activeCampaign.campaign_id,
      title: (activeCampaign as any).title || "VRMS-3 Ultra Active Campaign",
      rule_version: (activeCampaign as any).rule_version || 1,
      budget: (activeCampaign as any).target_metrics?.budget || (activeCampaign as any).budget || 50000000,
      total_claimed_amount: (activeCampaign as any).total_claimed_amount || 0
    },
    milestones: milestoneItems
  };
}

/**
 * Claims a referral milestone reward with atomic validation, idempotency guard,
 * budget enforcement, ledger creation, and wallet crediting.
 */
export function claimMilestoneReward(
  userId: string,
  milestoneId: string,
  campaignId?: string
): ClaimMilestoneResult {
  const db = readDB();

  // 1. Verify User
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  if (!user) {
    return {
      success: false,
      code: "USER_NOT_FOUND",
      message: "Authentication error: User profile not found."
    };
  }

  if (user.isBanned || user.status === "banned" || user.status === "suspended" || user.risk_status === "RESTRICTED" || user.risk_status === "BANNED") {
    return {
      success: false,
      code: "USER_RESTRICTED",
      message: "Your account is under security review. Earning and milestone rewards are temporarily paused."
    };
  }

  // Update authenticated activity timestamp (Rule 30-day reset)
  touchAuthenticatedAccess(user.id, db);

  // 2. Locate Milestone Config
  const configs = db.milestone_configs && db.milestone_configs.length > 0
    ? db.milestone_configs
    : DEFAULT_MILESTONE_CONFIGS;

  const activeCamp = getActiveCampaign(db);
  const effectiveCampaignId = campaignId || (activeCamp ? activeCamp.campaign_id : "default_campaign");
  const config = configs.find(
    (c) => c.milestone_id.toLowerCase() === milestoneId.toLowerCase() && 
           (!campaignId || c.campaign_id === effectiveCampaignId || c.campaign_id === "default_campaign")
  );

  if (!config) {
    return {
      success: false,
      code: "CONFIG_NOT_FOUND",
      message: `Milestone configuration '${milestoneId}' not found.`
    };
  }

  if (config.status !== "ACTIVE") {
    return {
      success: false,
      code: "CONFIG_INACTIVE",
      message: "This milestone campaign is currently paused by administration."
    };
  }

  const now = new Date();
  if (config.active_from && new Date(config.active_from) > now) {
    return {
      success: false,
      code: "CAMPAIGN_EXPIRED",
      message: "This milestone campaign has not started yet."
    };
  }
  if (config.active_to && new Date(config.active_to) < now) {
    return {
      success: false,
      code: "CAMPAIGN_EXPIRED",
      message: "This milestone campaign has concluded."
    };
  }

  // 3. RULE 4: IDEMPOTENT CREDITING GUARD
  // Check if reward record already exists with status 'CREDITED'
  db.referral_rewards = db.referral_rewards || [];
  const existingRewards = db.referral_rewards.filter(
    (r) => 
      r.user_id === user.id &&
      r.milestone_id === config.milestone_id &&
      r.campaign_id === config.campaign_id &&
      r.rule_version === config.rule_version
  );

  const alreadyCredited = existingRewards.find((r) => r.status === "CREDITED");
  if (alreadyCredited) {
    return {
      success: false,
      code: "ALREADY_CLAIMED",
      message: "This milestone reward has already been claimed and credited to your account."
    };
  }

  const claimedCountForUser = existingRewards.filter((r) => r.status === "CREDITED").length;
  if (claimedCountForUser >= (config.max_per_user || 1)) {
    return {
      success: false,
      code: "MAX_LIMIT_REACHED",
      message: "You have already reached the maximum claim limit for this milestone."
    };
  }

  // 4. RULE 2: Re-check current QUALIFIED referral count server-side
  const { count: currentQualifiedCount } = calculateCurrentQualifiedReferrals(user.id, db);
  if (currentQualifiedCount < config.threshold) {
    return {
      success: false,
      code: "THRESHOLD_NOT_MET",
      message: `Threshold not reached. You have ${currentQualifiedCount} of ${config.threshold} required qualified referrals.`
    };
  }

  // 5. Campaign Budget Guard
  const currentTotalClaimed = config.total_claimed_amount || 0;
  if (currentTotalClaimed + config.amount > config.budget) {
    return {
      success: false,
      code: "BUDGET_EXHAUSTED",
      message: "Campaign allocated reward budget has been exhausted. Please contact support."
    };
  }

  // 6. ATOMIC TRANSACTION EXECUTION:
  // Transition status: CLAIMABLE -> CREDITED
  const nowISO = new Date().toISOString();
  const rewardId = `rw_milestone_${config.milestone_id}_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const txId = `tx-milestone-${config.milestone_id}-${Date.now()}`;

  const newRewardRecord: ReferralRewardRecord = {
    reward_id: rewardId,
    user_id: user.id,
    milestone_id: config.milestone_id,
    campaign_id: config.campaign_id,
    amount: config.amount,
    status: "CREDITED",
    rule_version: config.rule_version,
    created_at: nowISO,
    claimed_at: nowISO,
    transaction_id: txId
  };

  db.referral_rewards.push(newRewardRecord);

  // Update config budget usage
  config.total_claimed_amount = currentTotalClaimed + config.amount;

  // Credit user wallet and synchronized top-level points
  if (!user.wallet) {
    user.wallet = {
      points: user.points || 0,
      walletAddress: "",
      status: "active",
      updatedAt: nowISO
    };
  }
  user.wallet.points = (user.wallet.points || 0) + config.amount;
  user.wallet.updatedAt = nowISO;
  user.points = user.wallet.points;

  // Increment taskStats total points
  if (user.taskStats) {
    user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + config.amount;
  }

  // RULE 5: FINANCIAL INTEGRITY LEDGER ENTRY
  db.transactions = db.transactions || [];
  db.transactions.push({
    id: txId,
    userId: user.id,
    amount: config.amount,
    type: "referral_milestone",
    status: "completed",
    description: `Referral Milestone ${config.milestone_id.toUpperCase()} unlocked: ${config.threshold} Qualified Referrals (+${config.amount})`,
    timestamp: nowISO,
    metadata: {
      milestone_id: config.milestone_id,
      campaign_id: config.campaign_id,
      rule_version: config.rule_version,
      reward_id: rewardId,
      threshold: config.threshold
    }
  });

  // Immutable Financial Ledger Entry (Phase 15 ARE)
  recordLedgerEntry({
    user_id: user.id,
    transaction_type: 'MILESTONE_BONUS',
    amount: config.amount,
    reference_type: 'MILESTONE',
    reference_id: rewardId,
    metadata: {
      milestone_id: config.milestone_id,
      campaign_id: config.campaign_id,
      threshold: config.threshold
    }
  }, db);

  // In-app Notification (VRMS-3 ULTRA Phase 12)
  emitMilestoneAlert(user.id, config.milestone_id, config.threshold, config.amount, config.title, 'CLAIMED', undefined, db);

  // Commit changes atomically to disk
  writeDB(db);

  return {
    success: true,
    message: "Milestone unlocked and credited successfully!",
    reward: newRewardRecord,
    claimedAmount: config.amount,
    newPointsTotal: user.wallet.points
  };
}

/**
 * RULE 5: Financial Reversal Execution (Reversal path: CREDITED -> REVIEW -> REVERSED)
 * Never deletes the original transaction. Creates a dedicated reversal ledger record.
 */
export function reverseMilestoneReward(
  rewardId: string,
  reversalReason: string,
  adminUserId?: string
): { success: boolean; message: string; reversedReward?: ReferralRewardRecord } {
  const db = readDB();

  db.referral_rewards = db.referral_rewards || [];
  const reward = db.referral_rewards.find((r) => r.reward_id === rewardId);
  if (!reward) {
    return { success: false, message: "Reward record not found." };
  }

  if (reward.status === "REVERSED") {
    return { success: false, message: "Reward has already been reversed." };
  }

  const user = db.users.find((u: any) => u.id === reward.user_id);
  if (!user) {
    return { success: false, message: "Associated user profile not found." };
  }

  const nowISO = new Date().toISOString();
  const reversalTxId = `tx-rev-milestone-${Date.now()}`;

  // 1. Transition state: CREDITED -> REVIEW -> REVERSED
  reward.status = "REVERSED";
  reward.reversed_at = nowISO;
  reward.reversal_reason = reversalReason;
  reward.reversal_tx_id = reversalTxId;

  // 2. Adjust budget consumption
  const config = (db.milestone_configs || []).find(
    (c) => c.milestone_id === reward.milestone_id && c.campaign_id === reward.campaign_id
  );
  if (config && typeof config.total_claimed_amount === "number") {
    config.total_claimed_amount = Math.max(0, config.total_claimed_amount - reward.amount);
  }

  // 3. Deduct points safely (floor at 0)
  if (user.wallet) {
    user.wallet.points = Math.max(0, (user.wallet.points || 0) - reward.amount);
    user.wallet.updatedAt = nowISO;
    user.points = user.wallet.points;
  }

  // 4. RULE 5: Append new reversal transaction ledger referencing the original
  db.transactions = db.transactions || [];
  db.transactions.push({
    id: reversalTxId,
    userId: user.id,
    amount: -reward.amount,
    type: "referral_milestone_reversal",
    status: "completed",
    description: `Reversal of Referral Milestone ${reward.milestone_id.toUpperCase()} reward. Reason: ${reversalReason}`,
    timestamp: nowISO,
    metadata: {
      original_transaction_id: reward.transaction_id,
      original_reward_id: reward.reward_id,
      reversal_reason: reversalReason,
      reversed_by_admin: adminUserId || "SYSTEM_AUDIT"
    }
  });

  // Immutable Financial Ledger Entry (Phase 15 ARE)
  recordLedgerEntry({
    user_id: user.id,
    transaction_type: 'REVERSAL',
    amount: -reward.amount,
    reference_type: 'MILESTONE',
    reference_id: reversalTxId,
    metadata: {
      original_reward_id: reward.reward_id,
      reversal_reason: reversalReason,
      reversed_by_admin: adminUserId || "SYSTEM_AUDIT"
    }
  }, db);

  // 5. In-app Notification for Audit Compliance (VRMS-3 ULTRA Phase 12)
  emitMilestoneAlert(user.id, reward.milestone_id, 0, reward.amount, undefined, 'REVERSED', reversalReason, db);

  writeDB(db);

  return {
    success: true,
    message: `Milestone reward ${rewardId} reversed successfully.`,
    reversedReward: reward
  };
}
