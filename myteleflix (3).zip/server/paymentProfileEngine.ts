/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 7): Wallet & Payment Profile Module
 * 
 * NON-NEGOTIABLE SYSTEM RULES:
 * 1. EXACTLY THREE PAYMENT METHODS: Supported methods are ONLY 'bKash', 'Nagad', and 'TRC20_USDT'.
 *    Do NOT add Bank or any 4th payment method.
 * 2. SERVER-SIDE VALIDATION: Account numbers and wallet addresses MUST be strictly validated server-side.
 *    - bKash/Nagad: Valid 11-digit Bangladeshi mobile numbers.
 *    - TRC20 USDT: Valid TRON address format (starts with 'T', 34 characters).
 * 3. SNAPSHOT INTEGRITY: When created/updated, future salary requests take a snapshot of the payment profile at claim time.
 *    Updating the payment profile later MUST NOT retroactively alter already created salary request snapshots.
 * 4. UNIQUE CONSTRAINT: Enforces one active wallet profile per (user_id, payment_method).
 */

import crypto from "crypto";
import { 
  readDB, 
  writeDB, 
  DBState, 
  WalletPaymentProfile, 
  PaymentMethodType, 
  PaymentProfileSnapshot,
  SalaryRequestRecord
} from "./db.js";
import { touchAuthenticatedAccess } from "./purgeEngine.js";

// STRICT RULE 1: EXACTLY THREE PAYMENT METHODS
export const SUPPORTED_PAYMENT_METHODS: readonly PaymentMethodType[] = [
  "bKash",
  "Nagad",
  "TRC20_USDT"
] as const;

export function isSupportedPaymentMethod(method: string): method is PaymentMethodType {
  return SUPPORTED_PAYMENT_METHODS.includes(method as PaymentMethodType);
}

/**
 * Sanitizes input strings to prevent XSS and injection attacks.
 */
export function sanitizePaymentInput(val: string): string {
  if (!val) return "";
  return val
    .trim()
    .replace(/[<>'"`;\(\)\{\}\[\]\\]/g, "")
    .slice(0, 100);
}

/**
 * STRICT RULE 2: Server-side validation of account numbers and wallet addresses.
 */
export function validatePaymentAccountFormat(
  method: string, 
  accountOrAddress: string
): { isValid: boolean; error?: string; cleanValue: string } {
  const cleanValue = accountOrAddress ? accountOrAddress.trim() : "";

  if (!cleanValue) {
    return {
      isValid: false,
      error: "Account number or wallet address is required.",
      cleanValue: ""
    };
  }

  // Enforce Rule 1
  if (!isSupportedPaymentMethod(method)) {
    return {
      isValid: false,
      error: `Unsupported payment method '${method}'. Allowed methods are strictly: ${SUPPORTED_PAYMENT_METHODS.join(", ")}.`,
      cleanValue
    };
  }

  // Enforce Rule 2
  if (method === "bKash" || method === "Nagad") {
    // Valid 11-digit Bangladeshi mobile number starting with 013-019
    const bdMobileRegex = /^01[3-9]\d{8}$/;
    if (!bdMobileRegex.test(cleanValue)) {
      return {
        isValid: false,
        error: `Invalid ${method} account number. Must be a valid 11-digit Bangladeshi mobile number (e.g., 017XXXXXXXX).`,
        cleanValue
      };
    }
  } else if (method === "TRC20_USDT") {
    // Valid TRON address: Starts with 'T', exactly 34 characters, base58 character set
    const tronRegex = /^T[1-9A-HJ-NP-za-km-z]{33}$/;
    if (!tronRegex.test(cleanValue)) {
      return {
        isValid: false,
        error: "Invalid TRC20 USDT address. Must start with 'T' and be exactly 34 base58 characters.",
        cleanValue
      };
    }
  }

  return { isValid: true, cleanValue };
}

/**
 * Fetches all saved payment profiles for a given user.
 */
export function getUserPaymentProfiles(
  userId: string, 
  providedDb?: DBState
): WalletPaymentProfile[] {
  if (!userId) return [];
  const db = providedDb || readDB();
  const profiles = db.wallet_payment_profiles || [];

  // Match by user id or telegram id
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  const effectiveUserId = user ? user.id : userId;

  return profiles.filter(
    (p) => p.user_id === effectiveUserId && isSupportedPaymentMethod(p.payment_method)
  );
}

/**
 * Upserts a payment profile enforcing:
 * - Method validation (Rule 1)
 * - Format validation (Rule 2)
 * - Unique constraint on (user_id, payment_method) (Step 1)
 */
export function upsertPaymentProfile(
  userId: string,
  paymentMethod: string,
  accountOrAddress: string,
  accountHolderName: string,
  providedDb?: DBState
): { 
  success: boolean; 
  profile?: WalletPaymentProfile; 
  message: string; 
  error?: string;
  code?: string;
} {
  const db = providedDb || readDB();

  // Verify User
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  if (!user) {
    return {
      success: false,
      code: "USER_NOT_FOUND",
      error: "User profile not found.",
      message: "Authentication error: User profile not found."
    };
  }

  // Validate method and account format
  const validation = validatePaymentAccountFormat(paymentMethod, accountOrAddress);
  if (!validation.isValid) {
    return {
      success: false,
      code: "INVALID_FORMAT",
      error: validation.error,
      message: validation.error || "Invalid account format."
    };
  }

  const cleanMethod = paymentMethod as PaymentMethodType;
  const cleanAddress = validation.cleanValue;
  const cleanHolderName = sanitizePaymentInput(accountHolderName || user.fullName || user.username || "Account Holder");

  db.wallet_payment_profiles = db.wallet_payment_profiles || [];

  // Enforce UNIQUE constraint on (user_id, payment_method)
  const nowISO = new Date().toISOString();
  const existingIdx = db.wallet_payment_profiles.findIndex(
    (p) => p.user_id === user.id && p.payment_method === cleanMethod
  );

  let targetProfile: WalletPaymentProfile;

  if (existingIdx !== -1) {
    // Update existing record
    targetProfile = {
      ...db.wallet_payment_profiles[existingIdx],
      account_number_or_wallet_address: cleanAddress,
      account_holder_name: cleanHolderName,
      updated_at: nowISO,
      verified_status: "VERIFIED"
    };
    db.wallet_payment_profiles[existingIdx] = targetProfile;
  } else {
    // Insert new record
    const profileId = `prof_${cleanMethod.toLowerCase()}_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
    targetProfile = {
      profile_id: profileId,
      user_id: user.id,
      payment_method: cleanMethod,
      account_number_or_wallet_address: cleanAddress,
      account_holder_name: cleanHolderName,
      verified_status: "VERIFIED",
      updated_at: nowISO,
      created_at: nowISO
    };
    db.wallet_payment_profiles.push(targetProfile);
  }

  // Update last cached wallet address if applicable
  if (user.wallet) {
    user.wallet.walletAddress = cleanAddress;
    user.wallet.updatedAt = nowISO;
  }

  // Update activity timestamp
  touchAuthenticatedAccess(user.id, db);

  writeDB(db);

  return {
    success: true,
    message: "Payment account saved successfully.",
    profile: targetProfile
  };
}

/**
 * STRICT RULE 3: SNAPSHOT INTEGRITY
 * Creates an immutable snapshot of the user's payment profile at claim time.
 * Updating the payment profile later will NEVER retroactively alter this snapshot.
 */
export function createPaymentProfileSnapshot(
  userId: string,
  paymentMethod: PaymentMethodType,
  providedDb?: DBState
): PaymentProfileSnapshot {
  const db = providedDb || readDB();
  const profiles = db.wallet_payment_profiles || [];

  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  const effectiveUserId = user ? user.id : userId;

  const profile = profiles.find(
    (p) => p.user_id === effectiveUserId && p.payment_method === paymentMethod
  );

  if (!profile) {
    throw new Error(
      `No saved payment profile found for '${paymentMethod}'. Please configure your payment account in Profile Settings before submitting.`
    );
  }

  return {
    snapshot_id: `snp_${profile.profile_id}_${Date.now()}_${crypto.randomBytes(2).toString("hex")}`,
    profile_id: profile.profile_id,
    payment_method: profile.payment_method,
    account_number_or_wallet_address: profile.account_number_or_wallet_address,
    account_holder_name: profile.account_holder_name,
    verified_status: profile.verified_status,
    snapshotted_at: new Date().toISOString()
  };
}

/**
 * Submits a monthly salary claim with immutable payment profile snapshot linkage.
 */
export function claimMonthlySalaryWithSnapshot(
  userId: string,
  paymentMethod: string
): { 
  success: boolean; 
  code?: string; 
  message: string; 
  request?: SalaryRequestRecord;
} {
  const db = readDB();

  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  if (!user) {
    return { success: false, code: "USER_NOT_FOUND", message: "User profile not found." };
  }

  if (user.isBanned || user.status === "banned" || user.status === "suspended") {
    return {
      success: false,
      code: "USER_RESTRICTED",
      message: "Your account is restricted from claiming salary payouts."
    };
  }

  if (!user.monthly_salary_eligible) {
    return {
      success: false,
      code: "NOT_ELIGIBLE",
      message: "You are not currently eligible for monthly salary. Maintain at least 10 active qualified referrals."
    };
  }

  if (!isSupportedPaymentMethod(paymentMethod)) {
    return {
      success: false,
      code: "INVALID_METHOD",
      message: `Invalid payment method '${paymentMethod}'. Must be one of: ${SUPPORTED_PAYMENT_METHODS.join(", ")}.`
    };
  }

  // Check 1 claim per calendar month
  const now = new Date();
  const currentMonthPrefix = now.toISOString().slice(0, 7); // e.g. "2026-09"

  db.salary_requests = db.salary_requests || [];
  const existingClaimThisMonth = db.salary_requests.find(
    (r) => r.user_id === user.id && r.claimed_at.startsWith(currentMonthPrefix) && r.status !== "REJECTED"
  );

  if (existingClaimThisMonth) {
    return {
      success: false,
      code: "ALREADY_CLAIMED_THIS_MONTH",
      message: `You have already submitted a salary request for this month (${currentMonthPrefix}).`
    };
  }

  // Create immutable payment profile snapshot (Rule 3)
  let snapshot: PaymentProfileSnapshot;
  try {
    snapshot = createPaymentProfileSnapshot(user.id, paymentMethod, db);
  } catch (err: any) {
    return {
      success: false,
      code: "PROFILE_NOT_CONFIGURED",
      message: err.message
    };
  }

  // Determine salary amount based on tier
  const tier = user.monthly_salary_tier || "Bronze";
  let salaryAmount = 3000;
  if (tier.includes("Gold")) {
    salaryAmount = 20000;
  } else if (tier.includes("Silver")) {
    salaryAmount = 8000;
  }

  const requestId = `sal_req_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
  const nowISO = now.toISOString();

  const newSalaryRequest: SalaryRequestRecord = {
    request_id: requestId,
    user_id: user.id,
    tier,
    amount: salaryAmount,
    status: "PENDING",
    claimed_at: nowISO,
    payment_profile_snapshot: snapshot,
    transaction_id: `tx-salary-${Date.now()}`
  };

  db.salary_requests.push(newSalaryRequest);

  // Financial ledger transaction
  db.transactions = db.transactions || [];
  db.transactions.push({
    id: newSalaryRequest.transaction_id!,
    userId: user.id,
    amount: salaryAmount,
    type: "monthly_salary_payout",
    status: "pending",
    description: `Monthly Salary Request (${tier}) via ${snapshot.payment_method} to ${snapshot.account_number_or_wallet_address}`,
    timestamp: nowISO,
    metadata: {
      salary_request_id: requestId,
      payment_profile_snapshot_id: snapshot.snapshot_id,
      payment_method: snapshot.payment_method,
      destination: snapshot.account_number_or_wallet_address
    }
  });

  // Notification
  db.notifications = db.notifications || [];
  db.notifications.push({
    id: `nt-salary-${Date.now()}`,
    userId: user.id,
    title: "💵 Monthly Salary Request Submitted",
    message: `Your ${tier} salary request of ${salaryAmount.toLocaleString()} BDT has been received with snapshot payment to ${snapshot.payment_method} (${snapshot.account_number_or_wallet_address}).`,
    isRead: false,
    timestamp: nowISO
  });

  touchAuthenticatedAccess(user.id, db);
  writeDB(db);

  return {
    success: true,
    message: "Monthly salary request submitted successfully with immutable payment snapshot.",
    request: newSalaryRequest
  };
}

/**
 * Deletes a payment profile from the user's saved vault
 */
export function deletePaymentProfile(
  userId: string,
  paymentMethod: string,
  providedDb?: DBState
): { success: boolean; message: string; error?: string } {
  const db = providedDb || readDB();
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );
  if (!user) {
    return { success: false, error: "User profile not found.", message: "User not found." };
  }
  const cleanMethod = paymentMethod as PaymentMethodType;
  db.wallet_payment_profiles = db.wallet_payment_profiles || [];
  const initialLen = db.wallet_payment_profiles.length;
  db.wallet_payment_profiles = db.wallet_payment_profiles.filter(
    (p) => !(p.user_id === user.id && p.payment_method === cleanMethod)
  );
  if (db.wallet_payment_profiles.length === initialLen) {
    return { success: false, message: "Profile not found or already removed." };
  }
  writeDB(db);
  return { success: true, message: `Payout vault for ${cleanMethod} removed successfully.` };
}
