/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import {
  readDB,
  writeDB,
  DBState,
  DynamicTaskRecord,
  DynamicContentRecord,
  getDynamicTasks,
  getDynamicContent,
  TaskStatus,
  ContentStatus,
  recordLedgerEntry
} from "./db.js";
import {
  recordAndValidateActivity,
  getUserDailyActivityProgress,
  getTodayDateString,
  REQUIRED_DAILY_TASKS,
  REQUIRED_DAILY_CONTENT,
  DailyActivityProgress
} from "./userActivityEngine.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";

export interface TaskUserView extends DynamicTaskRecord {
  completions_today: number;
  is_completed_today: boolean;
  can_complete: boolean;
  remaining_today: number;
}

export interface ContentUserView extends DynamicContentRecord {
  is_downloaded_today: boolean;
  downloads_today: number;
}

export interface TaskCompletionResult {
  success: boolean;
  code: 'SUCCESS' | 'DUPLICATE' | 'TASK_INACTIVE' | 'TASK_NOT_FOUND' | 'DAILY_LIMIT_REACHED' | 'USER_NOT_FOUND' | 'ACCOUNT_RESTRICTED' | 'INVALID_SIGNATURE';
  message: string;
  points_awarded?: number;
  new_balance?: number;
  task_id?: string;
  idempotency_key?: string;
  daily_progress?: DailyActivityProgress;
  active_day_newly_awarded?: boolean;
}

export interface ContentVerificationResult {
  success: boolean;
  code: 'SUCCESS' | 'DUPLICATE' | 'CONTENT_INACTIVE' | 'CONTENT_NOT_FOUND' | 'USER_NOT_FOUND' | 'ACCOUNT_RESTRICTED';
  message: string;
  content_id?: string;
  points_awarded?: number;
  new_balance?: number;
  daily_progress?: DailyActivityProgress;
  active_day_newly_awarded?: boolean;
}

/**
 * VRMS-3 ULTRA (Phase 14): Server-Authoritative Task & Content Sync Engine (TCE)
 */
export class TaskContentSyncEngine {
  /**
   * Retrieves active dynamic tasks tagged with user-specific daily completion status
   */
  public static getTasksForUser(userId?: string): {
    tasks: TaskUserView[];
    daily_progress?: DailyActivityProgress;
    server_time: string;
  } {
    const db = readDB();
    const tasks = getDynamicTasks(db);
    const today = getTodayDateString();
    const activities = (db.user_activity || []).filter(
      (a) => a.activity_date === today && a.validation_status === 'VALID' && a.activity_type === 'TASK'
    );

    const userActivities = userId ? activities.filter(a => a.user_id === userId) : [];

    const decoratedTasks: TaskUserView[] = tasks.map((task) => {
      const completionsToday = userActivities.filter(a => a.source_reference === task.task_id).length;
      const dailyLimit = task.daily_limit_per_user || 1;
      const isCompletedToday = completionsToday >= dailyLimit;
      const canComplete = task.status === 'ACTIVE' && !isCompletedToday;
      const remainingToday = Math.max(0, dailyLimit - completionsToday);

      return {
        ...task,
        completions_today: completionsToday,
        is_completed_today: isCompletedToday,
        can_complete: canComplete,
        remaining_today: remainingToday
      };
    });

    const dailyProgress = userId ? getUserDailyActivityProgress(userId, db, today) : undefined;

    return {
      tasks: decoratedTasks,
      daily_progress: dailyProgress,
      server_time: new Date().toISOString()
    };
  }

  /**
   * Retrieves dynamic content tagged with user download status
   */
  public static getContentForUser(userId?: string): {
    content: ContentUserView[];
    daily_progress?: DailyActivityProgress;
    server_time: string;
  } {
    const db = readDB();
    const contentList = getDynamicContent(db);
    const today = getTodayDateString();
    const activities = (db.user_activity || []).filter(
      (a) => a.activity_date === today && a.validation_status === 'VALID' && a.activity_type === 'CONTENT'
    );

    const userActivities = userId ? activities.filter(a => a.user_id === userId) : [];

    const decoratedContent: ContentUserView[] = contentList.map((item) => {
      const downloadsToday = userActivities.filter(a => a.source_reference === item.content_id).length;
      return {
        ...item,
        is_downloaded_today: downloadsToday > 0,
        downloads_today: downloadsToday
      };
    });

    const dailyProgress = userId ? getUserDailyActivityProgress(userId, db, today) : undefined;

    return {
      content: decoratedContent,
      daily_progress: dailyProgress,
      server_time: new Date().toISOString()
    };
  }

  /**
   * Server-authoritative task execution validation and reward distribution.
   * 
   * NON-NEGOTIABLE SYSTEM RULES ENFORCED:
   * 1. SERVER-VALIDATED TASK COMPLETION: Client cannot directly increment task counts.
   * 2. IDEMPOTENT TASK CLAIMS: Unique idempotency_key prevents duplicate claims.
   * 3. DAILY TASK COUNTS SYNC: Automatically logs into user_activity (10 Tasks required for Active Day).
   * 4. DYNAMIC LIFECYCLE: Checks ACTIVE status and daily limits.
   */
  public static async completeTask(params: {
    taskId: string;
    userId: string;
    idempotencyKey?: string;
    clientSignature?: string;
    metadata?: Record<string, any>;
  }): Promise<TaskCompletionResult> {
    const { taskId, userId, clientSignature, metadata } = params;
    const db = readDB();

    if (!taskId || !userId) {
      return {
        success: false,
        code: 'TASK_NOT_FOUND',
        message: 'Invalid task parameters: Task ID and User ID are required.'
      };
    }

    // 1. Resolve User
    const user = db.users.find(
      (u: any) => u.id === userId || (u.guest_device_id === userId || u.device_fingerprint === userId)
    );

    if (!user) {
      return {
        success: false,
        code: 'USER_NOT_FOUND',
        message: 'Authenticated account not found.'
      };
    }

    // Check account restriction / ban
    if (user.isBanned || user.status === 'banned' || user.status === 'suspended' || user.risk_status === 'RESTRICTED' || user.risk_status === 'BANNED') {
      return {
        success: false,
        code: 'ACCOUNT_RESTRICTED',
        message: 'Account under security review. Task execution and earnings are restricted.'
      };
    }

    // 2. Resolve Dynamic Task
    const tasks = getDynamicTasks(db);
    const task = tasks.find(t => t.task_id === taskId);

    if (!task) {
      return {
        success: false,
        code: 'TASK_NOT_FOUND',
        message: `Task with ID "${taskId}" does not exist in the active registry.`
      };
    }

    // 3. Dynamic Lifecycle State Machine Check
    if (task.status === 'PAUSED') {
      return {
        success: false,
        code: 'TASK_INACTIVE',
        message: 'This task is currently paused by administrators. Please try again later.'
      };
    }

    if (task.status === 'EXPIRED') {
      return {
        success: false,
        code: 'TASK_INACTIVE',
        message: 'This campaign task has expired.'
      };
    }

    if (task.status !== 'ACTIVE') {
      return {
        success: false,
        code: 'TASK_INACTIVE',
        message: 'This task is not in an ACTIVE status.'
      };
    }

    const todayDate = getTodayDateString();

    // 4. Daily Limit Check
    const existingCompletionsToday = (db.user_activity || []).filter(
      (a) => a.user_id === user.id &&
             a.activity_date === todayDate &&
             a.source_reference === task.task_id &&
             a.validation_status === 'VALID' &&
             a.activity_type === 'TASK'
    ).length;

    const dailyLimit = task.daily_limit_per_user || 1;
    if (existingCompletionsToday >= dailyLimit) {
      return {
        success: false,
        code: 'DAILY_LIMIT_REACHED',
        message: `Daily limit reached (${dailyLimit}/${dailyLimit}). You can complete this task again tomorrow.`
      };
    }

    // 5. Anti-Spam Idempotency Verification
    // Canonical idempotency key format: tce_task_{taskId}_{userId}_{todayDate}_{idempotencyKey}
    const clientKey = params.idempotencyKey || `auto_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const canonicalIdempotencyKey = `tce_task_${task.task_id}_${user.id}_${todayDate}_${clientKey}`;

    const duplicateClaim = (db.user_activity || []).find(
      (a) => (a.idempotency_key === canonicalIdempotencyKey || (params.idempotencyKey && a.idempotency_key === params.idempotencyKey)) &&
             a.validation_status === 'VALID'
    );

    if (duplicateClaim) {
      return {
        success: false,
        code: 'DUPLICATE',
        message: 'Duplicate task claim detected. This execution instance was already verified and rewarded today.',
        task_id: task.task_id,
        idempotency_key: canonicalIdempotencyKey
      };
    }

    // 6. Record in User Activity Engine (UAE)
    const uaeResult = await recordAndValidateActivity({
      userId: user.id,
      activityType: 'TASK',
      sourceReference: task.task_id,
      idempotencyKey: canonicalIdempotencyKey,
      metadata: {
        task_title: task.title,
        reward_points: task.reward_points,
        task_type: task.task_type,
        client_signature: clientSignature || null,
        ...metadata
      }
    });

    if (!uaeResult.success) {
      return {
        success: false,
        code: uaeResult.code === 'DUPLICATE' ? 'DUPLICATE' : 'ACCOUNT_RESTRICTED',
        message: uaeResult.message,
        task_id: task.task_id
      };
    }

    // 7. Award Wallet Points & Record Ledger
    const rewardPoints = Number(task.reward_points) || 0;
    if (!user.wallet) {
      user.wallet = {
        points: user.points || 0,
        walletAddress: user.id,
        status: 'active',
        updatedAt: new Date().toISOString()
      };
    }

    user.wallet.points = (user.wallet.points || 0) + rewardPoints;
    user.points = user.wallet.points;
    user.lifetimeRewards = (user.lifetimeRewards || 0) + rewardPoints;

    if (!user.taskStats) {
      user.taskStats = { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 };
    }
    user.taskStats.missionsCompleted = (user.taskStats.missionsCompleted || 0) + 1;
    user.taskStats.totalPointsEarned = (user.taskStats.totalPointsEarned || 0) + rewardPoints;
    if (task.task_type === 'VIDEO') {
      user.taskStats.videosWatched = (user.taskStats.videosWatched || 0) + 1;
    }

    // Double-entry Wallet Transaction
    if (!db.transactions) db.transactions = [];
    const txId = `tx_tce_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
    db.transactions.push({
      id: txId,
      userId: user.id,
      amount: rewardPoints,
      type: 'reward_mission',
      status: 'completed',
      description: `Completed dynamic task: ${task.title}`,
      timestamp: new Date().toISOString()
    });

    // Immutable Financial Ledger Entry (Phase 15 ARE)
    recordLedgerEntry({
      user_id: user.id,
      transaction_type: 'TASK_REWARD',
      amount: rewardPoints,
      reference_type: 'TASK',
      reference_id: task.task_id,
      metadata: {
        task_title: task.title,
        idempotency_key: canonicalIdempotencyKey
      }
    }, db);

    // Increment task aggregate completed count
    task.completed_count = (task.completed_count || 0) + 1;
    task.updated_at = new Date().toISOString();

    // In-App Notification
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift({
      id: `nt_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
      userId: user.id,
      title: 'Task Reward Received! 💰',
      message: `You earned +${rewardPoints} points for completing "${task.title}". Keep going towards your Daily Active milestone!`,
      isRead: false,
      timestamp: new Date().toISOString()
    });

    // Write database
    writeDB(db);

    // Sync to Firestore if configured
    if (isFirestoreWritable() && firestore) {
      try {
        setDoc(doc(firestore, "users", user.id), {
          points: user.points,
          wallet: user.wallet,
          valid_action_count: user.valid_action_count,
          last_activity_at: user.last_activity_at,
          updatedAt: new Date().toISOString()
        }, { merge: true }).catch(() => {});

        setDoc(doc(firestore, "tasks", task.task_id), {
          completed_count: task.completed_count,
          updated_at: task.updated_at
        }, { merge: true }).catch(() => {});
      } catch (fErr) {
        console.warn("[TCE] Firestore mirror non-blocking error:", fErr);
      }
    }

    const updatedProgress = getUserDailyActivityProgress(user.id, db, todayDate);

    return {
      success: true,
      code: 'SUCCESS',
      message: `Task completed successfully! +${rewardPoints} points credited to your wallet.`,
      points_awarded: rewardPoints,
      new_balance: user.wallet.points,
      task_id: task.task_id,
      idempotency_key: canonicalIdempotencyKey,
      daily_progress: updatedProgress,
      active_day_newly_awarded: uaeResult.activeDayNewlyAwarded
    };
  }

  /**
   * Server-authoritative Content Download & Stream Verification.
   * Updates the 5 required content downloads/views for Active Day tracking.
   */
  public static async verifyContentDownload(params: {
    contentId: string;
    userId: string;
    idempotencyKey?: string;
    metadata?: Record<string, any>;
  }): Promise<ContentVerificationResult> {
    const { contentId, userId, metadata } = params;
    const db = readDB();

    if (!contentId || !userId) {
      return {
        success: false,
        code: 'CONTENT_NOT_FOUND',
        message: 'Invalid parameters: Content ID and User ID are required.'
      };
    }

    // 1. Resolve User
    const user = db.users.find(
      (u: any) => u.id === userId || (u.guest_device_id === userId || u.device_fingerprint === userId)
    );

    if (!user) {
      return {
        success: false,
        code: 'USER_NOT_FOUND',
        message: 'Authenticated account not found.'
      };
    }

    if (user.isBanned || user.status === 'banned' || user.status === 'suspended' || user.risk_status === 'RESTRICTED' || user.risk_status === 'BANNED') {
      return {
        success: false,
        code: 'ACCOUNT_RESTRICTED',
        message: 'Account under security review. Content activity recording is restricted.'
      };
    }

    // 2. Resolve Dynamic Content Item
    const contentList = getDynamicContent(db);
    const content = contentList.find(c => c.content_id === contentId);

    if (!content) {
      return {
        success: false,
        code: 'CONTENT_NOT_FOUND',
        message: `Content item "${contentId}" does not exist.`
      };
    }

    if (content.status !== 'ACTIVE') {
      return {
        success: false,
        code: 'CONTENT_INACTIVE',
        message: 'This content item is currently paused or unavailable.'
      };
    }

    const todayDate = getTodayDateString();
    const clientKey = params.idempotencyKey || `dl_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const canonicalIdempotencyKey = `tce_cnt_${content.content_id}_${user.id}_${clientKey}`;

    // 3. Record in User Activity Engine (UAE)
    const uaeResult = await recordAndValidateActivity({
      userId: user.id,
      activityType: 'CONTENT',
      sourceReference: content.content_id,
      idempotencyKey: canonicalIdempotencyKey,
      metadata: {
        content_title: content.title,
        category: content.category,
        download_url: content.download_url,
        ...metadata
      }
    });

    if (!uaeResult.success) {
      return {
        success: false,
        code: uaeResult.code === 'DUPLICATE' ? 'DUPLICATE' : 'ACCOUNT_RESTRICTED',
        message: uaeResult.message,
        content_id: content.content_id
      };
    }

    // 4. Optional Reward Points
    let pointsAwarded = 0;
    if (content.reward_points && content.reward_points > 0) {
      pointsAwarded = Number(content.reward_points);
      if (!user.wallet) {
        user.wallet = { points: user.points || 0, walletAddress: user.id, status: 'active', updatedAt: new Date().toISOString() };
      }
      user.wallet.points = (user.wallet.points || 0) + pointsAwarded;
      user.points = user.wallet.points;
      user.lifetimeRewards = (user.lifetimeRewards || 0) + pointsAwarded;

      if (!db.transactions) db.transactions = [];
      db.transactions.push({
        id: `tx_cnt_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
        userId: user.id,
        amount: pointsAwarded,
        type: content.category === 'MOVIE' ? 'reward_movie' : 'reward_video',
        status: 'completed',
        description: `Downloaded/Streamed content: ${content.title}`,
        timestamp: new Date().toISOString()
      });

      // Immutable Financial Ledger Entry (Phase 15 ARE)
      recordLedgerEntry({
        user_id: user.id,
        transaction_type: 'CONTENT_REWARD',
        amount: pointsAwarded,
        reference_type: 'CONTENT',
        reference_id: content.content_id,
        metadata: {
          content_title: content.title,
          category: content.category,
          idempotency_key: canonicalIdempotencyKey
        }
      }, db);
    }

    // Increment content download count
    content.download_count = (content.download_count || 0) + 1;
    content.updated_at = new Date().toISOString();

    // Increment user downloads count
    user.downloadsCount = (user.downloadsCount || 0) + 1;

    writeDB(db);

    const updatedProgress = getUserDailyActivityProgress(user.id, db, todayDate);

    return {
      success: true,
      code: 'SUCCESS',
      message: pointsAwarded > 0
        ? `Content verified! +${pointsAwarded} points credited and recorded towards your daily active goal.`
        : `Content action verified and recorded towards your daily active goal (${updatedProgress.content_completed}/${REQUIRED_DAILY_CONTENT}).`,
      content_id: content.content_id,
      points_awarded: pointsAwarded,
      new_balance: user.wallet?.points || user.points,
      daily_progress: updatedProgress,
      active_day_newly_awarded: uaeResult.activeDayNewlyAwarded
    };
  }
}
