/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Firebase Admin SDK Integration (Phase 3 Backend Engine)
 * Connects securely with Firestore collections:
 * - 'users' (Document ID: telegramId numeric)
 * - 'content_mappings' (Document ID: contentId)
 * - 'download_requests' (Document ID: telegramId or uid)
 */

import { initializeApp, getApps, cert, type App } from "firebase-admin/app";
import { getFirestore, FieldValue, type Firestore } from "firebase-admin/firestore";
import { firestore as fallbackFirestore } from "./firebase.js";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { readDB, writeDB } from "./db.js";

let adminApp: App | null = null;
let adminDb: Firestore | null = null;
let useAdminSdk = false;

try {
  const existingApps = getApps();
  if (existingApps.length > 0) {
    adminApp = existingApps[0]!;
    adminDb = getFirestore(adminApp);
    useAdminSdk = true;
  } else {
    // Check for Service Account in environment
    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT || process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
    if (serviceAccountJson) {
      try {
        const credentials = JSON.parse(serviceAccountJson);
        adminApp = initializeApp({
          credential: cert(credentials),
          projectId: credentials.project_id || "playmint-2f3b1",
        });
        adminDb = getFirestore(adminApp);
        useAdminSdk = true;
        console.log("[Firebase Admin] Initialized with Service Account.");
      } catch (e) {
        console.warn("[Firebase Admin] Service Account parse notice:", e);
      }
    }

    if (!adminApp) {
      // Initialize with Project ID
      adminApp = initializeApp({
        projectId: process.env.FIREBASE_PROJECT_ID || "playmint-2f3b1",
      });
      adminDb = getFirestore(adminApp);
      useAdminSdk = true;
      console.log("[Firebase Admin] Initialized with Project ID: playmint-2f3b1");
    }
  }
} catch (err) {
  console.warn("[Firebase Admin] Fallback to client Firestore instance:", err);
  useAdminSdk = false;
}

export { adminDb, useAdminSdk };

// ==========================================
// SECURE DATABASE REPOSITORY HELPERS
// ==========================================

export interface LockedUserRecord {
  telegramId: number | string;
  email?: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  joinedAt: any;
  isVerified: boolean;
  lastActive?: any;
}

export interface ContentMappingRecord {
  contentId: string;
  title: string;
  universalTelegramLink: string;
  category: string;
  updatedAt?: any;
}

export interface DownloadRequestRecord {
  telegramId: number | string;
  userEmail?: string;
  uid?: string;
  userMode?: "GUEST" | "VIP";
  contentId: string;
  contentTitle: string;
  universalLink: string;
  status: "PENDING" | "VERIFIED" | "COMPLETED" | "DELIVERED";
  createdAt?: any;
  verifiedAt?: any;
  deliveredAt?: any;
  earnedPoints?: number;
  pointsAllocated?: boolean;
}

/**
 * Permanently locks or updates user in collection 'users'
 * Document ID: telegramId (Numeric ID locked permanently)
 */
export async function lockTelegramUserInDb(
  telegramId: number | string,
  extraData?: Partial<LockedUserRecord>
): Promise<void> {
  const tgIdStr = String(telegramId).trim();
  if (!tgIdStr) return;
  const numericId = /^\d+$/.test(tgIdStr) ? Number(tgIdStr) : tgIdStr;

  try {
    if (useAdminSdk && adminDb) {
      const userRef = adminDb.collection("users").doc(tgIdStr);
      await userRef.set(
        {
          telegramId: numericId,
          isVerified: true,
          updatedAt: FieldValue.serverTimestamp(),
          lastActive: FieldValue.serverTimestamp(),
          ...(extraData?.email ? { email: extraData.email } : {}),
          ...(extraData?.username ? { username: extraData.username } : {}),
          ...(extraData?.firstName ? { firstName: extraData.firstName } : {}),
          ...(extraData?.lastName ? { lastName: extraData.lastName } : {}),
          joinedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      const userRef = doc(fallbackFirestore, "users", tgIdStr);
      await setDoc(
        userRef,
        {
          telegramId: numericId,
          isVerified: true,
          updatedAt: new Date().toISOString(),
          lastActive: new Date().toISOString(),
          ...(extraData?.email ? { email: extraData.email } : {}),
          ...(extraData?.username ? { username: extraData.username } : {}),
          ...(extraData?.firstName ? { firstName: extraData.firstName } : {}),
          ...(extraData?.lastName ? { lastName: extraData.lastName } : {}),
          joinedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }
  } catch (err) {
    console.warn(`[Db Lock] Warning writing user ${tgIdStr}:`, err);
  }
}

/**
 * Checks if user has already completed the once-in-a-lifetime channel verification
 */
export async function isUserChannelVerified(telegramId: number | string): Promise<boolean> {
  const tgIdStr = String(telegramId).trim();
  if (!tgIdStr) return false;

  try {
    if (useAdminSdk && adminDb) {
      const snap = await adminDb.collection("users").doc(tgIdStr).get();
      if (snap.exists) {
        const data = snap.data();
        if (data?.channelVerified === true || data?.channelsJoined === true) {
          return true;
        }
      }
    } else {
      const snap = await getDoc(doc(fallbackFirestore, "users", tgIdStr));
      if (snap.exists()) {
        const data = snap.data();
        if (data?.channelVerified === true || data?.channelsJoined === true) {
          return true;
        }
      }
    }
  } catch (err) {
    console.warn(`[User Channel Verify] Error checking ${tgIdStr}:`, err);
  }
  return false;
}

/**
 * Marks user as channel verified in Firestore
 */
export async function setUserChannelVerified(telegramId: number | string): Promise<void> {
  const tgIdStr = String(telegramId).trim();
  if (!tgIdStr) return;

  try {
    if (useAdminSdk && adminDb) {
      await adminDb.collection("users").doc(tgIdStr).set(
        {
          channelVerified: true,
          channelVerifiedAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      await setDoc(
        doc(fallbackFirestore, "users", tgIdStr),
        {
          channelVerified: true,
          channelVerifiedAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }
  } catch (err) {
    console.warn(`[User Channel Verify] Error setting ${tgIdStr}:`, err);
  }
}

/**
 * Retrieves content mapping from collection 'content_mappings'
 */
export async function getContentMappingFromDb(contentId: string): Promise<ContentMappingRecord | null> {
  const cleanId = String(contentId).trim();
  if (!cleanId) return null;

  try {
    if (useAdminSdk && adminDb) {
      const snap = await adminDb.collection("content_mappings").doc(cleanId).get();
      if (snap.exists) {
        return snap.data() as ContentMappingRecord;
      }
    } else {
      const snap = await getDoc(doc(fallbackFirestore, "content_mappings", cleanId));
      if (snap.exists()) {
        return snap.data() as ContentMappingRecord;
      }
    }
  } catch (err) {
    console.warn(`[Content Mapping] Warning reading ${cleanId}:`, err);
  }

  return null;
}

/**
 * Retrieves pending/verified download request for user from collection 'download_requests'
 * Searches by Document ID (telegramId) or query (telegramId == numericId).
 */
export async function getDownloadRequestForUser(
  telegramId: number | string,
  contentId?: string
): Promise<{ docId: string; data: DownloadRequestRecord } | null> {
  const tgIdStr = String(telegramId).trim();
  if (!tgIdStr) return null;
  const numId = /^\d+$/.test(tgIdStr) ? Number(tgIdStr) : tgIdStr;

  try {
    if (useAdminSdk && adminDb) {
      // 1. Check direct doc by telegramId
      const directDoc = await adminDb.collection("download_requests").doc(tgIdStr).get();
      if (directDoc.exists) {
        const data = directDoc.data() as DownloadRequestRecord;
        if (!contentId || data.contentId === contentId) {
          return { docId: directDoc.id, data };
        }
      }

      // 2. Query download_requests where telegramId matches
      const querySnap = await adminDb
        .collection("download_requests")
        .where("telegramId", "in", [tgIdStr, numId])
        .limit(3)
        .get();

      if (!querySnap.empty) {
        if (contentId) {
          const matched = querySnap.docs.find((d) => (d.data() as any).contentId === contentId);
          if (matched) return { docId: matched.id, data: matched.data() as DownloadRequestRecord };
        }
        const first = querySnap.docs[0]!;
        return { docId: first.id, data: first.data() as DownloadRequestRecord };
      }
    } else {
      // Fallback Firestore Client
      const directSnap = await getDoc(doc(fallbackFirestore, "download_requests", tgIdStr));
      if (directSnap.exists()) {
        const data = directSnap.data() as DownloadRequestRecord;
        if (!contentId || data.contentId === contentId) {
          return { docId: directSnap.id, data };
        }
      }
    }
  } catch (err) {
    console.warn(`[Download Requests] Warning retrieving request for ${tgIdStr}:`, err);
  }

  return null;
}

/**
 * Marks download request as COMPLETED / DELIVERED
 * Strictly blocks earnings for GUEST users.
 * Allocates reward points to users/{uid}/wallet for registered VIP users.
 */
export async function markDownloadRequestCompleted(
  docId: string,
  options?: {
    forcedUserMode?: "GUEST" | "VIP";
    uid?: string;
  }
): Promise<{ success: boolean; userMode: "GUEST" | "VIP"; earnedPoints: number }> {
  try {
    let reqData: DownloadRequestRecord | null = null;
    let targetDocId = docId;

    if (useAdminSdk && adminDb) {
      const snap = await adminDb.collection("download_requests").doc(docId).get();
      if (snap.exists) {
        reqData = snap.data() as DownloadRequestRecord;
      } else {
        const qSnap = await adminDb.collection("download_requests")
          .where("telegramId", "==", /^\d+$/.test(docId) ? Number(docId) : docId)
          .limit(1)
          .get();
        if (!qSnap.empty) {
          targetDocId = qSnap.docs[0].id;
          reqData = qSnap.docs[0].data() as DownloadRequestRecord;
        }
      }
    } else {
      const snap = await getDoc(doc(fallbackFirestore, "download_requests", docId));
      if (snap.exists()) {
        reqData = snap.data() as DownloadRequestRecord;
      }
    }

    // Determine userMode: strictly prioritize explicit GUEST or check if authenticated UID exists
    const userMode: "GUEST" | "VIP" = options?.forcedUserMode || reqData?.userMode || (reqData?.uid ? "VIP" : "GUEST");
    const uid = options?.uid || reqData?.uid;

    // 1. STRICT BACKEND BLOCK FOR GUEST USERS:
    // Guest users can download without limits, but CANNOT accumulate earnings, referral rewards, or wallet points.
    if (userMode === "GUEST") {
      console.log(`[Backend Security] Download ${targetDocId} completed in GUEST mode. Strictly BLOCKING earning calculations.`);
      
      const guestUpdate = {
        status: "COMPLETED",
        userMode: "GUEST",
        earnedPoints: 0,
        pointsAllocated: false,
        deliveredAt: useAdminSdk ? FieldValue.serverTimestamp() : new Date().toISOString(),
        updatedAt: useAdminSdk ? FieldValue.serverTimestamp() : new Date().toISOString(),
      };

      if (useAdminSdk && adminDb) {
        await adminDb.collection("download_requests").doc(targetDocId).set(guestUpdate, { merge: true });
      } else {
        await setDoc(doc(fallbackFirestore, "download_requests", targetDocId), guestUpdate, { merge: true });
      }

      // Sync local db if present
      const localDb = readDB();
      if (localDb.download_requests) {
        const itemIdx = localDb.download_requests.findIndex((r: any) => 
          r.telegramId === targetDocId || r.contentId === targetDocId || r.id === targetDocId
        );
        if (itemIdx >= 0) {
          localDb.download_requests[itemIdx] = { 
            ...localDb.download_requests[itemIdx], 
            status: "COMPLETED", 
            userMode: "GUEST", 
            earnedPoints: 0, 
            pointsAllocated: false 
          };
          writeDB(localDb);
        }
      }

      return { success: true, userMode: "GUEST", earnedPoints: 0 };
    }

    // 2. REGISTERED / VIP MODE: Allocate rewards to users/{uid}/wallet balance
    const REWARD_POINTS = 50; // VIP download completion reward
    let targetUid = uid;

    if (!targetUid && reqData?.telegramId) {
      const localDb = readDB();
      const matched = localDb.users?.find((u: any) => String(u.telegramId) === String(reqData!.telegramId));
      if (matched && matched.role !== 'guest') {
        targetUid = matched.id;
      }
    }

    console.log(`[Backend Security] Download ${targetDocId} completed in VIP mode. Allocating ${REWARD_POINTS} points to user ${targetUid || 'VIP user'}.`);

    const vipUpdate = {
      status: "COMPLETED",
      userMode: "VIP",
      earnedPoints: REWARD_POINTS,
      pointsAllocated: true,
      deliveredAt: useAdminSdk ? FieldValue.serverTimestamp() : new Date().toISOString(),
      updatedAt: useAdminSdk ? FieldValue.serverTimestamp() : new Date().toISOString(),
    };

    if (useAdminSdk && adminDb) {
      await adminDb.collection("download_requests").doc(targetDocId).set(vipUpdate, { merge: true });

      if (targetUid) {
        // Update user record in Firestore
        await adminDb.collection("users").doc(targetUid).set({
          points: FieldValue.increment(REWARD_POINTS),
          wallet: {
            points: FieldValue.increment(REWARD_POINTS),
            updatedAt: FieldValue.serverTimestamp(),
          },
          updatedAt: FieldValue.serverTimestamp(),
        }, { merge: true });

        // Update modular subcollection users/{uid}/wallet/balance
        await adminDb.collection("users").doc(targetUid).collection("wallet").doc("balance").set({
          points: FieldValue.increment(REWARD_POINTS),
          lastRewardAmount: REWARD_POINTS,
          lastRewardType: "DOWNLOAD_COMPLETED",
          updatedAt: FieldValue.serverTimestamp(),
        }, { merge: true });

        // Financial Ledger entry
        const txId = `tx_dl_${Date.now()}_${targetDocId.slice(0, 8)}`;
        await adminDb.collection("wallet_transactions").doc(txId).set({
          id: txId,
          userId: targetUid,
          amount: REWARD_POINTS,
          type: "download_reward",
          status: "completed",
          description: `VIP Download Reward: ${reqData?.contentTitle || 'Media File'}`,
          createdAt: FieldValue.serverTimestamp(),
          downloadRequestId: targetDocId
        });
      }
    } else {
      await setDoc(doc(fallbackFirestore, "download_requests", targetDocId), vipUpdate, { merge: true });
    }

    // Sync in-memory DB
    const localDb = readDB();
    if (localDb.download_requests) {
      const itemIdx = localDb.download_requests.findIndex((r: any) => 
        r.telegramId === targetDocId || r.contentId === targetDocId || r.id === targetDocId
      );
      if (itemIdx >= 0) {
        localDb.download_requests[itemIdx] = { 
          ...localDb.download_requests[itemIdx], 
          status: "COMPLETED", 
          userMode: "VIP", 
          earnedPoints: REWARD_POINTS, 
          pointsAllocated: true 
        };
      }
    }
    if (targetUid && localDb.users) {
      const u = localDb.users.find((user: any) => user.id === targetUid);
      if (u) {
        if (!u.wallet) u.wallet = { points: u.points || 0, walletAddress: u.id, status: 'active', updatedAt: new Date().toISOString() };
        u.wallet.points = (u.wallet.points || 0) + REWARD_POINTS;
        u.points = u.wallet.points;
        if (!localDb.transactions) localDb.transactions = [];
        localDb.transactions.push({
          id: `tx_dl_${Date.now()}`,
          userId: targetUid,
          amount: REWARD_POINTS,
          type: "download_reward",
          status: "completed",
          description: `VIP Download Reward: ${reqData?.contentTitle || 'Media File'}`,
          timestamp: new Date().toISOString()
        });
      }
    }
    writeDB(localDb);

    return { success: true, userMode: "VIP", earnedPoints: REWARD_POINTS };
  } catch (err) {
    console.warn(`[Download Requests] Warning completing doc ${docId}:`, err);
    return { success: false, userMode: "GUEST", earnedPoints: 0 };
  }
}

/**
 * PHASE 4: INSTANT SIGNAL MATCHING ENGINE
 * Sub-second query in Firestore download_requests collection where:
 * telegramId == user.id AND status == "PENDING" (or active) AND contentId == extracted_content_id
 */
export async function findPendingDownloadRequest(
  telegramId: number | string,
  contentId: string
): Promise<{ docId: string; data: DownloadRequestRecord } | null> {
  const tgIdStr = String(telegramId).trim();
  if (!tgIdStr || !contentId) return null;
  const numId = /^\d+$/.test(tgIdStr) ? Number(tgIdStr) : tgIdStr;

  try {
    if (useAdminSdk && adminDb) {
      // 1. O(1) Instant Direct Document lookup by Document ID (telegramId)
      const directDoc = await adminDb.collection("download_requests").doc(tgIdStr).get();
      if (directDoc.exists) {
        const data = directDoc.data() as DownloadRequestRecord;
        const matchesContent = String(data.contentId).trim() === String(contentId).trim();
        const isPending = data.status === "PENDING" || (data as any).status === "VERIFIED";
        if (matchesContent && isPending) {
          return { docId: directDoc.id, data };
        }
      }

      // 2. Query where telegramId == user.id AND contentId == extracted_content_id
      const querySnap = await adminDb
        .collection("download_requests")
        .where("telegramId", "in", [tgIdStr, numId])
        .where("contentId", "==", String(contentId).trim())
        .limit(3)
        .get();

      if (!querySnap.empty) {
        for (const docSnap of querySnap.docs) {
          const data = docSnap.data() as DownloadRequestRecord;
          if (data.status === "PENDING" || (data as any).status === "VERIFIED") {
            return { docId: docSnap.id, data };
          }
        }
      }
    } else {
      // Fallback Client Firestore
      const directSnap = await getDoc(doc(fallbackFirestore, "download_requests", tgIdStr));
      if (directSnap.exists()) {
        const data = directSnap.data() as DownloadRequestRecord;
        const matchesContent = String(data.contentId).trim() === String(contentId).trim();
        const isPending = data.status === "PENDING" || (data as any).status === "VERIFIED";
        if (matchesContent && isPending) {
          return { docId: directSnap.id, data };
        }
      }
    }
  } catch (err) {
    console.warn(`[Find Pending Signal] Error checking request for ${tgIdStr}:`, err);
  }

  return null;
}

/**
 * PHASE 4: Update status in download_requests from PENDING to PROCESSING to prevent double-triggering
 */
export async function updateDownloadRequestStatus(
  docId: string,
  newStatus: "PENDING" | "PROCESSING" | "VERIFIED" | "COMPLETED" | "DELIVERED"
): Promise<void> {
  try {
    if (useAdminSdk && adminDb) {
      await adminDb.collection("download_requests").doc(docId).set(
        {
          status: newStatus,
          updatedAt: FieldValue.serverTimestamp(),
          ...(newStatus === "PROCESSING" ? { processingAt: FieldValue.serverTimestamp() } : {}),
          ...(newStatus === "COMPLETED" ? { deliveredAt: FieldValue.serverTimestamp() } : {}),
        },
        { merge: true }
      );
    } else {
      await setDoc(
        doc(fallbackFirestore, "download_requests", docId),
        {
          status: newStatus,
          updatedAt: new Date().toISOString(),
          ...(newStatus === "PROCESSING" ? { processingAt: new Date().toISOString() } : {}),
          ...(newStatus === "COMPLETED" ? { deliveredAt: new Date().toISOString() } : {}),
        },
        { merge: true }
      );
    }
  } catch (err) {
    console.warn(`[Update Request Status] Warning for doc ${docId}:`, err);
  }
}

/**
 * PHASE 6: Retrieve dynamic system configuration from Firestore collection 'system_config'
 * Document ID: 'global_settings'
 */
export async function getSystemConfigFromDb(): Promise<any> {
  try {
    if (useAdminSdk && adminDb) {
      const snap = await adminDb.collection("system_config").doc("global_settings").get();
      if (snap.exists) {
        return snap.data();
      }
    } else {
      const snap = await getDoc(doc(fallbackFirestore, "system_config", "global_settings"));
      if (snap.exists()) {
        return snap.data();
      }
    }
  } catch (err) {
    console.warn("[System Config] Warning reading system_config/global_settings:", err);
  }
  return null;
}

/**
 * PHASE 6: Save or update dynamic system configuration in Firestore collection 'system_config'
 * Document ID: 'global_settings'
 */
export async function saveSystemConfigToDb(configData: Record<string, any>): Promise<void> {
  const cleanData = { ...configData };
  try {
    if (useAdminSdk && adminDb) {
      await adminDb.collection("system_config").doc("global_settings").set(
        {
          ...cleanData,
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } else {
      await setDoc(
        doc(fallbackFirestore, "system_config", "global_settings"),
        {
          ...cleanData,
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
    }
  } catch (err) {
    console.warn("[System Config] Warning saving system_config/global_settings:", err);
  }
}

/**
 * PHASE 6: Real-time Stats & Metrics Display (Sub-second query)
 * Counts:
 * - Total Users ('users' count)
 * - Active Pending Requests ('download_requests' with status 'PENDING')
 * - Completed Downloads ('download_requests' with status 'COMPLETED')
 */
export async function getRealtimeMetricsFromDb(): Promise<{
  totalUsers: number;
  activePending: number;
  completedDownloads: number;
  timestamp: string;
}> {
  let totalUsers = 0;
  let activePending = 0;
  let completedDownloads = 0;

  try {
    if (useAdminSdk && adminDb) {
      // Users count
      const usersSnap = await adminDb.collection("users").count().get();
      totalUsers = usersSnap.data().count;

      // Pending requests count
      const pendingSnap = await adminDb
        .collection("download_requests")
        .where("status", "==", "PENDING")
        .count()
        .get();
      activePending = pendingSnap.data().count;

      // Completed downloads count
      const completedSnap = await adminDb
        .collection("download_requests")
        .where("status", "==", "COMPLETED")
        .count()
        .get();
      completedDownloads = completedSnap.data().count;
    } else {
      // Fallback: estimate from local DB
      const db = readDB();
      totalUsers = db.users?.length || 0;
      activePending = db.download_requests?.filter((r: any) => r.status === "PENDING").length || 0;
      completedDownloads = db.download_requests?.filter((r: any) => r.status === "COMPLETED").length || 0;
    }
  } catch (err) {
    console.warn("[Realtime Metrics] Query error, falling back to local DB counts:", err);
    try {
      const db = readDB();
      totalUsers = db.users?.length || 0;
      activePending = db.download_requests?.filter((r: any) => r.status === "PENDING").length || 0;
      completedDownloads = db.download_requests?.filter((r: any) => r.status === "COMPLETED").length || 0;
    } catch {}
  }

  return {
    totalUsers,
    activePending,
    completedDownloads,
    timestamp: new Date().toISOString(),
  };
}

