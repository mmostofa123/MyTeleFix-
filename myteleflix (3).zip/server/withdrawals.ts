/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { readDB, writeDB, recordLedgerEntry } from "./db.js";

// Fetch transactions history for the user
export function getTransactionHistory(userId: string) {
  const db = readDB();
  return db.transactions
    .filter((tx: any) => tx.userId === userId)
    .sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

// Request points withdrawal
export function requestWithdrawal(
  userId: string, 
  amount: number, 
  walletAddress: string,
  paymentMethod?: string,
  email?: string,
  accountNumber?: string,
  securityDetails?: {
    riskScore?: number;
    riskReasons?: string[];
    isHighRisk?: boolean;
    device_fingerprint?: string;
    hardwareMetrics?: any;
    ip_address?: string;
    userAgent?: string;
  }
) {
  const db = readDB();

  // 1. Verify User exists and is verified
  const user = db.users.find((u: any) => u.id === userId);
  if (!user) {
    throw new Error("Security verification failed: Authenticated account not found.");
  }

  if (user.isBanned || user.status === "banned") {
    throw new Error(user.banReason || "Cashout temporarily unavailable: Account has been restricted by an administrator.");
  }

  if (user.status !== "active") {
    throw new Error("Withdrawal rejected: Account is currently restricted or suspended.");
  }

  if (user.wallet.status === "frozen") {
    throw new Error("Withdrawal rejected: Wallet is frozen due to administrative hold.");
  }

  // 2. Validate withdrawal constraints
  const minWithdrawal = db.settings.minimumWithdrawal || 1000;
  if (amount < minWithdrawal) {
    throw new Error(`Limit check failed: Minimum withdrawal threshold is ${minWithdrawal} points.`);
  }

  if (user.wallet.points < amount) {
    throw new Error("Balance check failed: Insufficient points in your cinematic wallet.");
  }

  const effectivePaymentMethod = paymentMethod || "Crypto (TON)";
  const effectiveDestination = accountNumber || walletAddress || "";
  const applicantEmail = email || user.email || (user.username ? `${user.username}@t.me` : "applicant@myteleflix.com");

  // 3. Deduct points instantly from wallet
  user.wallet.points -= amount;
  user.wallet.walletAddress = effectiveDestination; // Cache last used address
  user.wallet.updatedAt = new Date().toISOString();

  // Look up or generate immutable payment profile snapshot if profile exists
  let paymentSnapshot = null;
  if (db.wallet_payment_profiles && Array.isArray(db.wallet_payment_profiles)) {
    const matchedProfile = db.wallet_payment_profiles.find(
      (p: any) => p.user_id === userId && (p.payment_method === effectivePaymentMethod || p.account_number_or_wallet_address === effectiveDestination)
    );
    if (matchedProfile) {
      paymentSnapshot = {
        snapshot_id: `snp_w_${matchedProfile.profile_id}_${Date.now()}`,
        profile_id: matchedProfile.profile_id,
        payment_method: matchedProfile.payment_method,
        account_number_or_wallet_address: matchedProfile.account_number_or_wallet_address,
        account_holder_name: matchedProfile.account_holder_name,
        verified_status: matchedProfile.verified_status,
        snapshotted_at: new Date().toISOString()
      };
    }
  }

  // 4. Create pending withdrawal record (linked to the authenticated user)
  const withdrawalId = "wt-" + Date.now();
  const withdrawalObj = {
    id: withdrawalId,
    userId,
    username: user.username || user.fullName || "Member",
    email: applicantEmail,
    userEmail: applicantEmail,
    amount,
    paymentMethod: effectivePaymentMethod,
    walletAddress: effectiveDestination,
    accountNumber: effectiveDestination,
    payment_profile_snapshot: paymentSnapshot,
    status: "pending",
    isSuspicious: !!user.isSuspicious,
    suspiciousReason: user.suspiciousReason || "",
    isBanned: !!user.isBanned,
    device_fingerprint: securityDetails?.device_fingerprint || user.device_fingerprint || user.deviceFingerprint || "",
    hardwareMetrics: securityDetails?.hardwareMetrics || null,
    riskScore: securityDetails?.riskScore || 0,
    riskReasons: securityDetails?.riskReasons || [],
    isHighRisk: !!securityDetails?.isHighRisk,
    ip_address: securityDetails?.ip_address || "",
    userAgent: securityDetails?.userAgent || "",
    timestamp: new Date().toISOString()
  };

  db.withdrawals.push(withdrawalObj);

  // 5. Add negative ledger transaction for reward history accountability
  db.transactions.push({
    id: "tx-draw-" + Date.now(),
    userId,
    amount: -amount,
    type: "withdrawal",
    status: "pending",
    description: `Withdrawal (${effectivePaymentMethod}): ${effectiveDestination}`,
    timestamp: new Date().toISOString()
  });

  // Immutable Financial Ledger Entry (Phase 15 ARE)
  recordLedgerEntry({
    user_id: userId,
    transaction_type: 'WITHDRAWAL',
    amount: -amount,
    reference_type: 'WITHDRAWAL',
    reference_id: withdrawalId,
    metadata: {
      payment_method: effectivePaymentMethod,
      destination: effectiveDestination
    }
  }, db);

  writeDB(db);

  return {
    success: true,
    newPointsTotal: user.wallet.points,
    withdrawal: withdrawalObj
  };
}
