/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import crypto from "crypto";
import {
  readDB,
  writeDB,
  DBState,
  UserProfile,
  LedgerEntry,
  LedgerTransactionType,
  AuditReconciliation,
  AuditReconciliationSummary,
  DiscrepancyDetail,
  ReconciliationRunType,
  ReconciliationStatus,
  recordLedgerEntry,
  saveAuditReconciliation,
  getAuditReconciliations,
  getLedgerEntries
} from "./db.js";
import { firestore, isFirestoreWritable } from "./firebase.js";
import { doc, setDoc } from "firebase/firestore";
import { recordEngineRun } from "./health.js";
import { calculateMonthlySalary } from "./monthlySalaryEngine.js";

export interface AuditRunResult {
  success: boolean;
  message: string;
  reconciliation: AuditReconciliation;
  health: {
    status: ReconciliationStatus;
    total_audited_users: number;
    flagged_users_count: number;
    integrity_score_percent: number;
  };
}

/**
 * VRMS-3 ULTRA (Phase 15): Automated Audit & Reconciliation Engine (ARE)
 */
export class AuditReconciliationEngine {
  /**
   * Executes a comprehensive, automated system integrity audit comparing:
   * 1. User wallet points vs. Sum of double-entry ledger entries (Balance Integrity)
   * 2. Qualified referral counts vs. Actual verified referral relationships (Referral Integrity)
   * 3. Salary snapshots vs. Strict tier verification rules (Salary Integrity)
   */
  public static async runAudit(params: {
    runType?: ReconciliationRunType;
    adminId?: string;
  } = {}): Promise<AuditRunResult> {
    const startTime = Date.now();
    const db = readDB();
    const runType: ReconciliationRunType = params.runType || 'MANUAL';
    const adminId: string = params.adminId || 'system_are';

    // Ensure collections exist
    if (!db.ledger_entries) db.ledger_entries = [];
    if (!db.audit_reconciliations) db.audit_reconciliations = [];
    if (!db.users) db.users = [];
    if (!db.referrals) db.referrals = [];
    if (!db.salary_snapshots) db.salary_snapshots = [];

    const discrepancies: DiscrepancyDetail[] = [];
    let balancedUsersCount = 0;
    const nowIso = new Date().toISOString();

    // Map of users for fast lookup
    const userMap = new Map<string, UserProfile>();
    db.users.forEach(u => userMap.set(u.id, u));

    // ==========================================
    // CHECK 1: LEDGER DOUBLE-ENTRY BALANCE INTEGRITY
    // ==========================================
    // Pre-aggregate ledger amounts per user
    const ledgerUserSums = new Map<string, number>();
    for (const entry of db.ledger_entries) {
      const current = ledgerUserSums.get(entry.user_id) || 0;
      ledgerUserSums.set(entry.user_id, current + entry.amount);
    }

    // Pre-aggregate legacy transactions if user has legacy transactions not yet in ledger
    const txUserSums = new Map<string, number>();
    for (const tx of (db.transactions || [])) {
      if (tx.status === 'completed' || tx.status === 'approved') {
        const current = txUserSums.get(tx.userId) || 0;
        txUserSums.set(tx.userId, current + (typeof tx.amount === 'number' ? tx.amount : 0));
      }
    }

    for (const user of db.users) {
      const actualBalance = user.wallet ? user.wallet.points : (user.points || 0);
      let expectedBalance = ledgerUserSums.get(user.id);

      // If user has no ledger entries yet, fallback to legacy transactions sum or self-reconcile
      if (expectedBalance === undefined) {
        expectedBalance = txUserSums.get(user.id);
      }

      // If user has neither (e.g. freshly created user with 0 points)
      if (expectedBalance === undefined) {
        expectedBalance = 0;
      }

      // Compare actual vs expected
      const delta = actualBalance - expectedBalance;
      if (Math.abs(delta) > 0.001) {
        // Discrepancy detected
        const disc: DiscrepancyDetail = {
          record_id: user.id,
          category: 'BALANCE_MISMATCH',
          user_id: user.id,
          username: user.username || user.fullName || user.id,
          expected_value: expectedBalance,
          actual_value: actualBalance,
          discrepancy_delta: delta,
          reason: `Wallet balance (${actualBalance.toLocaleString()}) does not match immutable ledger sum (${expectedBalance.toLocaleString()}). Delta: ${delta > 0 ? '+' : ''}${delta.toLocaleString()}.`,
          timestamp: nowIso
        };
        discrepancies.push(disc);

        // Flag user without corrupting rows
        user.is_reconciled = false;
        user.discrepancy_flag = true;
        user.discrepancy_details = disc;
      } else {
        balancedUsersCount++;
        user.is_reconciled = true;
        user.discrepancy_flag = false;
        user.discrepancy_details = null;
      }
    }

    // ==========================================
    // CHECK 2: QUALIFIED REFERRALS RECONCILIATION
    // ==========================================
    // Count actual qualified referrals from referrals table
    const qualifiedRefCounts = new Map<string, number>();
    for (const ref of db.referrals) {
      if (ref.status === 'QUALIFIED') {
        const current = qualifiedRefCounts.get(ref.referrer_id) || 0;
        qualifiedRefCounts.set(ref.referrer_id, current + 1);
      }
    }

    for (const user of db.users) {
      const actualCount = user.qualified_referral_count || 0;
      const expectedCount = qualifiedRefCounts.get(user.id) || 0;

      if (actualCount !== expectedCount) {
        const delta = actualCount - expectedCount;
        const disc: DiscrepancyDetail = {
          record_id: `ref_${user.id}`,
          category: 'REFERRAL_MISMATCH',
          user_id: user.id,
          username: user.username || user.fullName || user.id,
          expected_value: expectedCount,
          actual_value: actualCount,
          discrepancy_delta: delta,
          reason: `User recorded ${actualCount} qualified referrals, but ledger activity shows ${expectedCount} verified referrals.`,
          timestamp: nowIso
        };
        discrepancies.push(disc);

        // Mark user with discrepancy
        user.is_reconciled = false;
        user.discrepancy_flag = true;
        user.discrepancy_details = disc;
      }
    }

    // ==========================================
    // CHECK 3: SALARY SNAPSHOTS & TIER INTEGRITY
    // ==========================================
    for (const snapshot of db.salary_snapshots) {
      const claimant = userMap.get(snapshot.user_id);
      const activeRefs = snapshot.qualified_active_referrals || snapshot.current_eligible_verified_referrals || 0;
      const expectedSalary = calculateMonthlySalary(snapshot.salary_level as any, activeRefs);

      // Check salary amount calculation
      if (expectedSalary > 0 && snapshot.calculated_salary !== expectedSalary) {
        const delta = snapshot.calculated_salary - expectedSalary;
        discrepancies.push({
          record_id: snapshot.snapshot_id,
          category: 'SALARY_MISMATCH',
          user_id: snapshot.user_id,
          username: claimant?.username || snapshot.user_id,
          expected_value: expectedSalary,
          actual_value: snapshot.calculated_salary,
          discrepancy_delta: delta,
          reason: `Salary Level ${snapshot.salary_level} snapshot has invalid payout ৳${snapshot.calculated_salary} (expected ৳${expectedSalary}).`,
          timestamp: nowIso
        });

        if (claimant) {
          claimant.is_reconciled = false;
          claimant.discrepancy_flag = true;
        }
      }

      // Check threshold qualification consistency
      if (snapshot.current_eligible_verified_referrals < minRefs) {
        discrepancies.push({
          record_id: snapshot.snapshot_id,
          category: 'SALARY_MISMATCH',
          user_id: snapshot.user_id,
          username: claimant?.username || snapshot.user_id,
          expected_value: minRefs,
          actual_value: snapshot.current_eligible_verified_referrals,
          discrepancy_delta: snapshot.current_eligible_verified_referrals - minRefs,
          reason: `Salary Level ${snapshot.salary_level} snapshot requires >= ${minRefs} verified referrals, but was approved with ${snapshot.current_eligible_verified_referrals}.`,
          timestamp: nowIso
        });

        if (claimant) {
          claimant.is_reconciled = false;
          claimant.discrepancy_flag = true;
        }
      }
    }

    const durationMs = Date.now() - startTime;
    const flaggedUsersCount = db.users.filter(u => u.discrepancy_flag).length;
    const status: ReconciliationStatus = discrepancies.length === 0 ? 'PASSED' : 'DISCREPANCY_FOUND';

    const reconciliationId = `rec_${Date.now()}_${crypto.randomBytes(3).toString("hex")}`;
    const summaryLog: AuditReconciliationSummary = {
      audited_users_count: db.users.length,
      audited_ledger_entries_count: db.ledger_entries.length,
      audited_referrals_count: db.referrals.length,
      audited_salaries_count: db.salary_snapshots.length,
      balanced_users_count: balancedUsersCount,
      flagged_users_count: flaggedUsersCount,
      discrepancies,
      execution_duration_ms: durationMs,
      run_by: adminId,
      notes: status === 'PASSED'
        ? 'All mathematical checks and double-entry ledgers reconciled with 100% integrity.'
        : `Detected ${discrepancies.length} discrepancy record(s) across balance, referral, or salary snapshots.`
    };

    const reconciliationRecord: AuditReconciliation = {
      reconciliation_id: reconciliationId,
      run_type: runType,
      status,
      mismatched_records_count: discrepancies.length,
      summary_log: summaryLog,
      executed_at: nowIso
    };

    // Save audit record to memory and Firestore
    db.audit_reconciliations.unshift(reconciliationRecord);

    // If discrepancies were found, log to security_audit_logs and create notifications
    if (discrepancies.length > 0) {
      if (!db.security_audit_logs) db.security_audit_logs = [];
      db.security_audit_logs.push({
        log_id: `sec_rec_${Date.now()}`,
        user_id: discrepancies[0].user_id,
        action_taken: 'FLAGGED',
        reason: `ARE detected ${discrepancies.length} financial or referral discrepancies in audit run ${reconciliationId}.`,
        enforced_by: 'SYSTEM',
        created_at: nowIso,
        metadata: {
          reconciliation_id: reconciliationId,
          discrepancies_count: discrepancies.length
        }
      });

      // Notify Super Admins
      if (!db.notifications) db.notifications = [];
      db.notifications.unshift({
        notification_id: `nt_are_${Date.now()}`,
        user_id: 'all',
        title: 'System Integrity Alert (ARE)',
        message: `Automated Audit Engine detected ${discrepancies.length} discrepancy record(s). Discrepancy flags applied for review.`,
        type: 'SECURITY',
        is_read: false,
        created_at: nowIso
      });
    }

    // Persist all updates atomically
    writeDB(db);

    // Cloud firestore non-blocking sync
    isFirestoreWritable().then(writable => {
      if (writable) {
        setDoc(doc(firestore, "audit_reconciliations", reconciliationId), reconciliationRecord, { merge: true }).catch(() => {});
      }
    }).catch(() => {});

    const totalAudited = Math.max(1, db.users.length);
    const integrityScore = Math.round(((totalAudited - flaggedUsersCount) / totalAudited) * 100);

    // Record health telemetry for background engine monitoring
    recordEngineRun("audit_reconciliation_engine", {
      status: "ACTIVE",
      durationMs,
      message: `Audit completed: ${discrepancies.length} discrepancies found. Integrity: ${integrityScore}%.`
    });

    return {
      success: true,
      message: status === 'PASSED'
        ? `Audit completed successfully. All ${db.users.length} accounts passed ledger integrity verification.`
        : `Audit finished with ${discrepancies.length} discrepancy flag(s) isolated for review.`,
      reconciliation: reconciliationRecord,
      health: {
        status,
        total_audited_users: db.users.length,
        flagged_users_count: flaggedUsersCount,
        integrity_score_percent: integrityScore
      }
    };
  }

  /**
   * Resolves a flagged discrepancy on a user account
   */
  public static resolveDiscrepancy(params: {
    userId: string;
    action: 'SYNC_LEDGER' | 'CLEAR_FLAG';
    adminId: string;
    note?: string;
  }): { success: boolean; message: string; user?: UserProfile } {
    const db = readDB();
    const user = db.users.find(u => u.id === params.userId);
    if (!user) {
      return { success: false, message: "User account not found." };
    }

    const nowIso = new Date().toISOString();

    if (params.action === 'SYNC_LEDGER') {
      // Calculate current ledger sum
      const ledgerSum = (db.ledger_entries || [])
        .filter(e => e.user_id === user.id)
        .reduce((sum, e) => sum + e.amount, 0);

      const actualBalance = user.wallet ? user.wallet.points : (user.points || 0);
      const delta = actualBalance - ledgerSum;

      if (delta !== 0) {
        // Create an adjusting entry in the ledger to balance it
        recordLedgerEntry({
          user_id: user.id,
          transaction_type: 'SYSTEM_ADJUSTMENT',
          amount: delta,
          reference_type: 'SYSTEM',
          reference_id: `adj_${Date.now()}`,
          metadata: {
            reason: `Admin ledger re-alignment: ${params.note || 'Resolved mathematical discrepancy'}`,
            admin_id: params.adminId
          }
        }, db);
      }

      user.is_reconciled = true;
      user.discrepancy_flag = false;
      user.discrepancy_details = null;
    } else if (params.action === 'CLEAR_FLAG') {
      user.is_reconciled = true;
      user.discrepancy_flag = false;
      user.discrepancy_details = null;
    }

    // Admin audit trail
    if (!db.admin_audit_logs) db.admin_audit_logs = [];
    db.admin_audit_logs.push({
      log_id: `aud_resolve_${Date.now()}`,
      admin_id: params.adminId,
      action_type: 'RECONCILIATION_RESOLVE',
      target_resource: `users/${user.id}`,
      details: { action: params.action, note: params.note || 'Discrepancy resolved' },
      timestamp: nowIso
    });

    writeDB(db);
    return {
      success: true,
      message: `Discrepancy on account ${user.username || user.id} was successfully resolved.`,
      user
    };
  }

  /**
   * Retrieves current ARE health status and summary statistics
   */
  public static getHealth(): {
    status: ReconciliationStatus;
    last_run_at: string | null;
    last_reconciliation_id: string | null;
    total_audited_runs: number;
    total_flagged_users: number;
    total_ledger_entries: number;
    integrity_score_percent: number;
    passing_rate_percent: number;
    flagged_users: Array<{
      id: string;
      username: string;
      discrepancy_details: DiscrepancyDetail | null;
      wallet_points: number;
    }>;
  } {
    const db = readDB();
    const runs = db.audit_reconciliations || [];
    const lastRun = runs.length > 0 ? runs[0] : null;
    const flaggedUsers = (db.users || []).filter(u => u.discrepancy_flag);

    const totalAudited = Math.max(1, (db.users || []).length);
    const integrityScore = Math.round(((totalAudited - flaggedUsers.length) / totalAudited) * 100);

    const passedRuns = runs.filter(r => r.status === 'PASSED').length;
    const passingRate = runs.length > 0 ? Math.round((passedRuns / runs.length) * 100) : 100;

    return {
      status: flaggedUsers.length > 0 ? 'DISCREPANCY_FOUND' : (lastRun ? lastRun.status : 'PASSED'),
      last_run_at: lastRun ? lastRun.executed_at : null,
      last_reconciliation_id: lastRun ? lastRun.reconciliation_id : null,
      total_audited_runs: runs.length,
      total_flagged_users: flaggedUsers.length,
      total_ledger_entries: (db.ledger_entries || []).length,
      integrity_score_percent: integrityScore,
      passing_rate_percent: passingRate,
      flagged_users: flaggedUsers.map(u => ({
        id: u.id,
        username: u.username || u.fullName || u.id,
        discrepancy_details: u.discrepancy_details || null,
        wallet_points: u.wallet ? u.wallet.points : (u.points || 0)
      }))
    };
  }

  /**
   * Retrieves audit runs history
   */
  public static getHistory(limit: number = 20): AuditReconciliation[] {
    return getAuditReconciliations(limit);
  }

  /**
   * Retrieves ledger entries
   */
  public static getLedger(options: { userId?: string; limit?: number; type?: LedgerTransactionType } = {}): LedgerEntry[] {
    return getLedgerEntries(options);
  }
}
