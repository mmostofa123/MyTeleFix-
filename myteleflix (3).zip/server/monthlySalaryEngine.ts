/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA (Phase 8): Monthly Salary Engine (MSE)
 * 
 * Server-authoritative, fraud-proof engine enforcing:
 * 1. HARD CEILING (MAX_SALARY_LEVEL = 3 FOREVER):
 *    Level 4+ MUST NOT exist in logic, database, configuration, API, or UI.
 *    Level caps: L1 (50 Direct Verified), L2 (100 Direct Verified), L3 (150 Direct Verified).
 * 2. CURRENT ELIGIBLE COUNT RULE: Exclude purged, restricted, or unverified users.
 * 3. MANDATORY ELIGIBILITY CONDITIONS:
 *    - >= 5 NEW VERIFIED direct referrals in current cycle.
 *    - Qualified Active Referrals: >= 10 Active Days in the last 30 days.
 *    - Claimant MUST be VERIFIED and NOT_RESTRICTED.
 *    - Valid saved payment profile (bKash, Nagad, TRC20_USDT) MUST exist.
 * 4. SALARY TIERS & CAPS:
 *    - L1: 10 Active = ৳200 | 20 Active = ৳400 | 30+ Active = ৳600 MAX
 *    - L2: 10 Active = ৳300 | 20 Active = ৳600 | 30+ Active = ৳900 MAX
 *    - L3: 10 Active = ৳400 | 20 Active = ৳800 | 30+ Active = ৳1,200 MAX
 * 5. IMMUTABLE CYCLE SNAPSHOT:
 *    Upon cycle calculation, generates an immutable snapshot record.
 */

import { 
  DBState, 
  readDB, 
  writeDB, 
  UserProfile, 
  PaymentMethodType, 
  SalaryCycle, 
  SalarySnapshot, 
  SalaryLevel,
  WalletPaymentProfile,
  SalaryRequestRecord,
  SalaryRequestStatus,
  findSalaryRequestById,
  findSalaryRequestByUserAndCycle,
  syncSalaryRequestIndexes,
  getActiveCampaign,
  getUserActiveDatesInWindow
} from "./db.js";
import { getUserPaymentProfiles } from "./paymentProfileEngine.js";

// HARD CEILING: Maximum Salary Level is 3 FOREVER. Level 4+ is strictly forbidden.
export const MAX_SALARY_LEVEL = 3 as const;
export const RULE_VERSION = "VRMS-3-ULTRA-MSE-V1" as const;

export interface SalaryTierDef {
  level: SalaryLevel;
  tierLabel: "L1" | "L2" | "L3";
  verifiedThreshold: number; // 50, 100, 150
  cap: number;
  payouts: {
    min10: number;
    min20: number;
    min30Max: number;
  };
}

export const SALARY_TIERS: Record<SalaryLevel, SalaryTierDef> = {
  1: {
    level: 1,
    tierLabel: "L1",
    verifiedThreshold: 50,
    cap: 50,
    payouts: {
      min10: 200,
      min20: 400,
      min30Max: 600
    }
  },
  2: {
    level: 2,
    tierLabel: "L2",
    verifiedThreshold: 100,
    cap: 100,
    payouts: {
      min10: 300,
      min20: 600,
      min30Max: 900
    }
  },
  3: {
    level: 3,
    tierLabel: "L3",
    verifiedThreshold: 150,
    cap: 150,
    payouts: {
      min10: 400,
      min20: 800,
      min30Max: 1200
    }
  }
};

/**
 * Calculates monthly salary based on Level (1, 2, or 3) and Qualified Active Referrals count.
 */
export function calculateMonthlySalary(level: SalaryLevel | 0, qualifiedActive: number): number {
  if (level === 1) {
    if (qualifiedActive >= 30) return 600;
    if (qualifiedActive >= 20) return 400;
    if (qualifiedActive >= 10) return 200;
    return 0;
  }
  if (level === 2) {
    if (qualifiedActive >= 30) return 900;
    if (qualifiedActive >= 20) return 600;
    if (qualifiedActive >= 10) return 300;
    return 0;
  }
  if (level === 3) {
    if (qualifiedActive >= 30) return 1200;
    if (qualifiedActive >= 20) return 800;
    if (qualifiedActive >= 10) return 400;
    return 0;
  }
  return 0;
}

/**
 * Server-authoritative level determination enforcing HARD CEILING (MAX_SALARY_LEVEL = 3).
 */
export function determineSalaryLevel(eligibleVerifiedCount: number): {
  level: SalaryLevel | 0;
  tierLabel: 'L1' | 'L2' | 'L3' | 'None';
  levelCapTarget: number;
} {
  // Enforce Level Caps: L3 (150), L2 (100), L1 (50). Level 4+ MUST NOT exist.
  if (eligibleVerifiedCount >= 150) {
    return { level: 3, tierLabel: 'L3', levelCapTarget: 150 };
  }
  if (eligibleVerifiedCount >= 100) {
    return { level: 2, tierLabel: 'L2', levelCapTarget: 100 };
  }
  if (eligibleVerifiedCount >= 50) {
    return { level: 1, tierLabel: 'L1', levelCapTarget: 50 };
  }
  return { level: 0, tierLabel: 'None', levelCapTarget: 50 };
}

/**
 * Ensures or creates the current active monthly salary cycle.
 */
export function getOrCreateActiveSalaryCycle(db: DBState): SalaryCycle {
  if (!db.salary_cycles) {
    db.salary_cycles = [];
  }

  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, "0");
  const expectedCycleId = `cycle_${year}_${month}`;

  let activeCycle = db.salary_cycles.find(c => c.status === "ACTIVE");

  if (!activeCycle) {
    // Generate dates for the current calendar month
    const startAt = new Date(Date.UTC(year, now.getUTCMonth(), 1, 0, 0, 0, 0)).toISOString();
    // End of month
    const endAt = new Date(Date.UTC(year, now.getUTCMonth() + 1, 0, 23, 59, 59, 999)).toISOString();
    // Distribution on 1st of next month
    const distAt = new Date(Date.UTC(year, now.getUTCMonth() + 1, 1, 0, 0, 0, 0)).toISOString();

    activeCycle = {
      cycle_id: expectedCycleId,
      start_at: startAt,
      end_at: endAt,
      distribution_at: distAt,
      rule_version: RULE_VERSION,
      status: "ACTIVE"
    };

    db.salary_cycles.push(activeCycle);
    writeDB(db);
  }

  return activeCycle;
}

export interface SalaryEligibilityEvaluation {
  success: boolean;
  eligible: boolean;
  salary_level: SalaryLevel | 0;
  salary_tier_label: 'L1' | 'L2' | 'L3' | 'None';
  current_eligible_verified_referrals: number;
  level_cap_target: number;
  new_verified_referrals: number;
  new_verified_target: number;
  has_met_new_verified: boolean;
  qualified_active_referrals: number;
  active_referrals_target: number;
  has_met_active_referrals: boolean;
  claimant_verified: boolean;
  claimant_not_restricted: boolean;
  has_payment_profile: boolean;
  payment_profiles: WalletPaymentProfile[];
  calculated_salary: number;
  active_cycle: SalaryCycle | null;
  already_claimed_in_cycle: boolean;
  reasons_ineligible: string[];
  max_salary_level: 3;
  active_campaign_id?: string;
  active_campaign_title?: string;
}

/**
 * Computes server-authoritative Monthly Salary Engine eligibility for a user.
 */
export function computeSalaryEligibility(
  userId: string, 
  providedDb?: DBState
): SalaryEligibilityEvaluation {
  const db = providedDb || readDB();

  // Find claimant user
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );

  if (!user) {
    return {
      success: false,
      eligible: false,
      salary_level: 0,
      salary_tier_label: "None",
      current_eligible_verified_referrals: 0,
      level_cap_target: 50,
      new_verified_referrals: 0,
      new_verified_target: 5,
      has_met_new_verified: false,
      qualified_active_referrals: 0,
      active_referrals_target: 10,
      has_met_active_referrals: false,
      claimant_verified: false,
      claimant_not_restricted: false,
      has_payment_profile: false,
      payment_profiles: [],
      calculated_salary: 0,
      active_cycle: null,
      already_claimed_in_cycle: false,
      reasons_ineligible: ["User not found"],
      max_salary_level: 3
    };
  }

  const effectiveUserId = user.id;
  const activeCycle = getOrCreateActiveSalaryCycle(db);

  // 1. Claimant Verification & Restriction Checks
  const verRec = (db.verification_records || []).find((v) => v.user_id === effectiveUserId);
  const claimant_verified = Boolean(
    user.is_verified || 
    user.isHumanVerified || 
    (verRec && verRec.status === "VERIFIED")
  );

  const claimant_not_restricted = Boolean(
    !user.isBanned &&
    user.status !== "banned" &&
    user.status !== "suspended" &&
    user.inactivity_status !== "PURGED" &&
    user.risk_status !== "RESTRICTED" &&
    user.risk_status !== "BANNED"
  );

  // 2. Check if already claimed/snapshotted in this cycle
  const existingSnapshot = (db.salary_snapshots || []).find(
    (s) => s.user_id === effectiveUserId && s.cycle_id === activeCycle.cycle_id
  );
  const already_claimed_in_cycle = Boolean(existingSnapshot);

  // 3. User Map & Verification Map for Direct Referrals
  const userMap = new Map<string, UserProfile>();
  db.users.forEach((u: any) => userMap.set(u.id, u));

  const verMap = new Map<string, any>();
  (db.verification_records || []).forEach((v) => verMap.set(v.user_id, v));

  const referrals = db.referrals || [];
  const cycleStartMs = new Date(activeCycle.start_at).getTime();
  const thirtyDaysAgoMs = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const thirtyDaysAgoDateStr = new Date(thirtyDaysAgoMs).toISOString().split("T")[0];

  let eligibleVerifiedCount = 0;
  let newVerifiedCount = 0;
  let qualifiedActiveCount = 0;

  for (const ref of referrals) {
    const rReferrerId = ref.referrer_id || (ref as any).referrerId;
    if (rReferrerId !== effectiveUserId && rReferrerId !== user.telegramId) {
      continue;
    }

    const refUserId = ref.referred_user_id || (ref as any).referredId;
    if (!refUserId) continue;

    const referredUser = userMap.get(refUserId);
    if (!referredUser) continue;

    // RULE 2: Exclude purged, restricted, or unverified users from direct referral counts
    if (referredUser.inactivity_status === "PURGED") continue;
    if (referredUser.isBanned || referredUser.status === "banned" || referredUser.status === "suspended") continue;

    const refVerRec = verMap.get(refUserId);
    const isRefVerified = Boolean(
      referredUser.is_verified ||
      referredUser.isHumanVerified ||
      (refVerRec && refVerRec.status === "VERIFIED")
    );

    if (!isRefVerified) continue;

    // This is an eligible direct verified referral
    eligibleVerifiedCount += 1;

    // Check if NEW VERIFIED in current cycle (created or verified >= cycle.start_at)
    const refCreatedAt = ref.created_at || (ref as any).createdAt;
    const refVerifiedAt = (ref as any).verified_at || referredUser.verified_at || (refVerRec ? refVerRec.verified_at : null);
    const userCreatedAt = referredUser.createdAt;

    const isNewInCycle = 
      (refCreatedAt && new Date(refCreatedAt).getTime() >= cycleStartMs) ||
      (refVerifiedAt && new Date(refVerifiedAt).getTime() >= cycleStartMs) ||
      (userCreatedAt && new Date(userCreatedAt).getTime() >= cycleStartMs);

    if (isNewInCycle) {
      newVerifiedCount += 1;
    }

    // Check Qualified Active Referrals: >= 10 Active Days within the last 30 days
    const activeDates = new Set<string>();
    if (referredUser.taskStats?.activeDaysList) {
      referredUser.taskStats.activeDaysList.forEach((d: string) => activeDates.add(d));
    }
    if ((referredUser as any).activeDaysList) {
      (referredUser as any).activeDaysList.forEach((d: string) => activeDates.add(d));
    }

    // Check user_activity records in last 30 days (Phase 16: O(1) indexed lookup)
    const indexedRecentDates = getUserActiveDatesInWindow(refUserId, thirtyDaysAgoDateStr, db);
    indexedRecentDates.forEach((dateStr) => activeDates.add(dateStr));

    let totalRecentActiveDays = 0;
    activeDates.forEach((dateStr) => {
      if (dateStr >= thirtyDaysAgoDateStr) {
        totalRecentActiveDays += 1;
      }
    });

    // Fallback if active_day_streak or activeDaysCount indicates active engagement
    const streak = referredUser.active_day_streak || (referredUser as any).activeDaysCount || 0;
    const effectiveActiveDays = Math.max(totalRecentActiveDays, streak);

    if (effectiveActiveDays >= 10) {
      qualifiedActiveCount += 1;
    }
  }

  // Determine Salary Level (Enforces MAX_SALARY_LEVEL = 3 FOREVER)
  const { level, tierLabel, levelCapTarget } = determineSalaryLevel(eligibleVerifiedCount);

  // Check saved payment profiles
  const paymentProfiles = getUserPaymentProfiles(effectiveUserId, db);
  const has_payment_profile = paymentProfiles.length > 0 && paymentProfiles.some(
    p => Boolean(p.account_number_or_wallet_address && p.account_number_or_wallet_address.trim())
  );

  // Eligibility conditions
  const has_met_new_verified = newVerifiedCount >= 5;
  const has_met_active_referrals = qualifiedActiveCount >= 10;
  const has_met_level = level >= 1;

  // Calculate salary amount
  let calculated_salary = 0;
  if (has_met_level && has_met_new_verified && has_met_active_referrals && claimant_verified && claimant_not_restricted) {
    calculated_salary = calculateMonthlySalary(level, qualifiedActiveCount);
  }

  const eligible = Boolean(
    has_met_level &&
    has_met_new_verified &&
    has_met_active_referrals &&
    claimant_verified &&
    claimant_not_restricted &&
    has_payment_profile &&
    !already_claimed_in_cycle
  );

  const reasons_ineligible: string[] = [];
  if (!claimant_verified) reasons_ineligible.push("Claimant must be identity-verified.");
  if (!claimant_not_restricted) reasons_ineligible.push("Claimant account is restricted or purged.");
  if (!has_met_level) reasons_ineligible.push(`Requires at least 50 direct verified referrals for Level 1 (current: ${eligibleVerifiedCount}).`);
  if (!has_met_new_verified) reasons_ineligible.push(`Requires at least 5 new verified direct referrals in current cycle (current: ${newVerifiedCount}/5).`);
  if (!has_met_active_referrals) reasons_ineligible.push(`Requires at least 10 qualified active referrals with >=10 active days (current: ${qualifiedActiveCount}/10).`);
  if (!has_payment_profile) reasons_ineligible.push("No valid saved payout profile (bKash, Nagad, or TRC20 USDT) found.");
  if (already_claimed_in_cycle) reasons_ineligible.push("Salary snapshot has already been claimed for the current cycle.");

  return {
    success: true,
    eligible,
    salary_level: level,
    salary_tier_label: tierLabel,
    current_eligible_verified_referrals: eligibleVerifiedCount,
    level_cap_target: levelCapTarget,
    new_verified_referrals: newVerifiedCount,
    new_verified_target: 5,
    has_met_new_verified,
    qualified_active_referrals: qualifiedActiveCount,
    active_referrals_target: 10,
    has_met_active_referrals,
    claimant_verified,
    claimant_not_restricted,
    has_payment_profile,
    payment_profiles: paymentProfiles,
    calculated_salary,
    active_cycle: activeCycle,
    already_claimed_in_cycle,
    reasons_ineligible,
    max_salary_level: MAX_SALARY_LEVEL,
    active_campaign_id: getActiveCampaign(db)?.campaign_id || "default_campaign",
    active_campaign_title: getActiveCampaign(db)?.title || "VRMS-3 Ultra Pioneer Campaign"
  };
}

/**
 * Generates an immutable cycle snapshot for an eligible user.
 */
export function generateSalarySnapshot(
  userId: string,
  preferredMethod?: PaymentMethodType,
  providedDb?: DBState
): {
  success: boolean;
  message: string;
  snapshot?: SalarySnapshot;
  error?: string;
} {
  const db = providedDb || readDB();

  // Find user
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );

  if (!user) {
    return { success: false, message: "User not found.", error: "USER_NOT_FOUND" };
  }

  // Compute full server-side eligibility
  const evalResult = computeSalaryEligibility(user.id, db);

  // STRICT GUARDRAILS
  if (!evalResult.claimant_verified) {
    return {
      success: false,
      message: "Claim blocked: Claimant must be verified.",
      error: "CLAIMANT_UNVERIFIED"
    };
  }

  if (!evalResult.claimant_not_restricted) {
    return {
      success: false,
      message: "Claim blocked: Claimant account is restricted or suspended.",
      error: "CLAIMANT_RESTRICTED"
    };
  }

  if (evalResult.salary_level < 1) {
    return {
      success: false,
      message: `Claim blocked: Minimum 50 eligible verified referrals required for Level 1 (current: ${evalResult.current_eligible_verified_referrals}).`,
      error: "LEVEL_THRESHOLD_NOT_MET"
    };
  }

  if (evalResult.new_verified_referrals < 5) {
    return {
      success: false,
      message: `Claim blocked: Minimum 5 new verified direct referrals required in current cycle (current: ${evalResult.new_verified_referrals}/5).`,
      error: "NEW_VERIFIED_THRESHOLD_NOT_MET"
    };
  }

  if (evalResult.qualified_active_referrals < 10) {
    return {
      success: false,
      message: `Claim blocked: Minimum 10 qualified active referrals with >=10 active days required (current: ${evalResult.qualified_active_referrals}/10).`,
      error: "ACTIVE_REFERRALS_THRESHOLD_NOT_MET"
    };
  }

  if (evalResult.already_claimed_in_cycle) {
    return {
      success: false,
      message: "Claim blocked: Salary snapshot already generated for the current cycle.",
      error: "ALREADY_CLAIMED_IN_CYCLE"
    };
  }

  if (!evalResult.has_payment_profile || evalResult.payment_profiles.length === 0) {
    return {
      success: false,
      message: "Claim blocked: No valid saved payment profile found.",
      error: "PAYMENT_PROFILE_MISSING"
    };
  }

  // Select profile
  let targetProfile: WalletPaymentProfile | undefined;
  if (preferredMethod) {
    targetProfile = evalResult.payment_profiles.find(p => p.payment_method === preferredMethod);
  }
  if (!targetProfile) {
    targetProfile = evalResult.payment_profiles[0];
  }

  if (!targetProfile || !targetProfile.account_number_or_wallet_address) {
    return {
      success: false,
      message: "Claim blocked: Selected payment profile is invalid or has no address.",
      error: "INVALID_PAYMENT_PROFILE"
    };
  }

  const activeCycle = evalResult.active_cycle || getOrCreateActiveSalaryCycle(db);
  const nowStr = new Date().toISOString();
  const snapshotId = `mss_${activeCycle.cycle_id}_${user.id}_${Date.now()}`;

  // IMMUTABLE CYCLE SNAPSHOT
  const snapshot: SalarySnapshot = {
    snapshot_id: snapshotId,
    cycle_id: activeCycle.cycle_id,
    user_id: user.id,
    salary_level: evalResult.salary_level as SalaryLevel,
    current_eligible_verified_referrals: evalResult.current_eligible_verified_referrals,
    new_verified_referrals: evalResult.new_verified_referrals,
    qualified_active_referrals: evalResult.qualified_active_referrals,
    calculated_salary: evalResult.calculated_salary,
    payment_method: targetProfile.payment_method,
    payment_account_snapshot: targetProfile.account_number_or_wallet_address,
    account_holder_snapshot: targetProfile.account_holder_name || user.fullName || user.username || "Account Holder",
    verification_status: "VERIFIED",
    risk_status: "NOT_RESTRICTED",
    created_at: nowStr
  };

  if (!db.salary_snapshots) {
    db.salary_snapshots = [];
  }
  db.salary_snapshots.push(snapshot);

  // Link to salary_requests as well for unified audit trails (VRMS-3 ULTRA Phase 9)
  if (!db.salary_requests) {
    db.salary_requests = [];
  }

  // Check if salary request already exists for this user and cycle
  let salaryReq = findSalaryRequestByUserAndCycle(user.id, activeCycle.cycle_id, db);
  let requestId = salaryReq?.request_id;

  if (!salaryReq) {
    requestId = generateSalaryRequestId();
    while (findSalaryRequestById(requestId, db)) {
      requestId = generateSalaryRequestId();
    }

    const telegramText = formatTelegramSalaryRequest({
      user,
      snapshot,
      requestId
    });
    const telegramDeepLink = generateTelegramShareUrl(telegramText);

    // NON-NEGOTIABLE RULE 1: CLAIM IS NOT PAYMENT. State is strictly 'CLAIMED'
    salaryReq = {
      request_id: requestId,
      snapshot_id: snapshotId,
      cycle_id: activeCycle.cycle_id,
      user_id: user.id,
      amount: evalResult.calculated_salary,
      status: "CLAIMED",
      claim_idempotency_key: `claim_${activeCycle.cycle_id}_${user.id}`,
      claimed_at: nowStr,
      tier: `L${evalResult.salary_level}`,
      payment_profile_snapshot: {
        snapshot_id: `snap_${Date.now()}`,
        profile_id: targetProfile.profile_id,
        payment_method: targetProfile.payment_method,
        account_number_or_wallet_address: targetProfile.account_number_or_wallet_address,
        account_holder_name: targetProfile.account_holder_name,
        verified_status: targetProfile.verified_status,
        snapshotted_at: nowStr
      },
      telegram_message_text: telegramText,
      telegram_deep_link: telegramDeepLink
    };
    db.salary_requests.push(salaryReq);
  }

  // Update user cached status
  user.monthly_salary_eligible = true;
  user.monthly_salary_tier = `L${evalResult.salary_level}`;

  writeDB(db);
  syncSalaryRequestIndexes(db);

  return {
    success: true,
    message: `Salary snapshot generated successfully for Level ${evalResult.salary_level} (৳${evalResult.calculated_salary}).`,
    snapshot
  };
}

/**
 * VRMS-3 ULTRA (Phase 9): Unique Request ID Generator
 * Format: REQ-YYYYMMDD-XXXXXX (e.g., REQ-20260917-8F3K2A)
 */
export function generateSalaryRequestId(date = new Date()): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, "0");
  const dd = String(date.getDate()).padStart(2, "0");
  const chars = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ";
  let random = "";
  for (let i = 0; i < 6; i++) {
    random += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `REQ-${yyyy}${mm}${dd}-${random}`;
}

/**
 * VRMS-3 ULTRA (Phase 9): Telegram Request Template Generator
 * Strict blueprint template without internal sensitive metrics or keys.
 */
export function formatTelegramSalaryRequest(params: {
  user: UserProfile;
  snapshot: SalarySnapshot;
  requestId: string;
}): string {
  const { user, snapshot, requestId } = params;
  const username = user.username
    ? (user.username.startsWith("@") ? user.username : `@${user.username}`)
    : (user.fullName || "N/A");

  return [
    `💼 MONTHLY SALARY REQUEST`,
    `User ID: ${user.id}`,
    `Username: ${username}`,
    `Salary Level: L${snapshot.salary_level}`,
    `Eligible VERIFIED Direct Referrals: ${snapshot.current_eligible_verified_referrals}`,
    `New VERIFIED Direct Referrals This Cycle: ${snapshot.new_verified_referrals}`,
    `Qualified Active Referrals: ${snapshot.qualified_active_referrals}`,
    `Calculated Salary: ৳${snapshot.calculated_salary.toLocaleString()}`,
    `Payment Method: ${snapshot.payment_method}`,
    `Payment Account: ${snapshot.payment_account_snapshot}`,
    `Verification: VERIFIED`,
    `Request ID: ${requestId}`
  ].join("\n");
}

/**
 * VRMS-3 ULTRA (Phase 9): Telegram Deep-Link Generator
 * Encodes formatted message for instant Telegram share prefill
 */
export function generateTelegramShareUrl(text: string): string {
  return `https://t.me/share/url?text=${encodeURIComponent(text)}`;
}

/**
 * VRMS-3 ULTRA (Phase 9): Primary Server-Authoritative Salary Claim Engine
 * Enforces:
 * 1. CLAIM IS NOT PAYMENT (status = 'CLAIMED')
 * 2. ONE CLAIM PER CYCLE (strict uniqueness & idempotency)
 * 3. UNIQUE REQUEST ID FORMAT (REQ-YYYYMMDD-XXXXXX)
 * 4. TELEGRAM FLOW INTEGRATION & Universal Copy Fallback
 * 5. NO INTERNAL SENSITIVE DATA EXPOSURE
 */
export function processSalaryClaim(
  userId: string,
  preferredMethod?: PaymentMethodType,
  idempotencyKey?: string,
  providedDb?: DBState
): {
  success: boolean;
  message: string;
  request_id?: string;
  status?: SalaryRequestStatus;
  request?: SalaryRequestRecord;
  snapshot?: SalarySnapshot;
  telegram_message_text?: string;
  telegram_deep_link?: string;
  is_existing?: boolean;
  error?: string;
  code?: string;
} {
  const db = providedDb || readDB();

  // Find user
  const user = db.users.find(
    (u: any) => u.id === userId || u.telegramId === userId.replace(/^tg-/, "")
  );

  if (!user) {
    return {
      success: false,
      message: "User not found.",
      error: "USER_NOT_FOUND",
      code: "USER_NOT_FOUND"
    };
  }

  const activeCycle = getOrCreateActiveSalaryCycle(db);

  // STEP 1 & NON-NEGOTIABLE RULE 2: STRICT IDEMPOTENCY & UNIQUENESS PER CYCLE
  // Check if a salary request already exists for (user_id, cycle_id)
  const existingReq = findSalaryRequestByUserAndCycle(user.id, activeCycle.cycle_id, db);
  if (existingReq) {
    let matchingSnapshot = (db.salary_snapshots || []).find(
      s => s.snapshot_id === existingReq.snapshot_id || (s.user_id === user.id && s.cycle_id === activeCycle.cycle_id)
    );

    // If telegram text or deep link was not populated previously, populate it now
    if (!existingReq.telegram_message_text && matchingSnapshot) {
      existingReq.telegram_message_text = formatTelegramSalaryRequest({
        user,
        snapshot: matchingSnapshot,
        requestId: existingReq.request_id
      });
      existingReq.telegram_deep_link = generateTelegramShareUrl(existingReq.telegram_message_text);
      writeDB(db);
      syncSalaryRequestIndexes(db);
    }

    return {
      success: true,
      message: `Salary request already exists for this cycle. Request ID: ${existingReq.request_id}`,
      request_id: existingReq.request_id,
      status: existingReq.status,
      request: existingReq,
      snapshot: matchingSnapshot,
      telegram_message_text: existingReq.telegram_message_text,
      telegram_deep_link: existingReq.telegram_deep_link,
      is_existing: true
    };
  }

  // STEP 2: VERIFY OR GENERATE SALARY SNAPSHOT FOR CURRENT CYCLE
  let snapshot = (db.salary_snapshots || []).find(
    s => s.user_id === user.id && s.cycle_id === activeCycle.cycle_id
  );

  if (!snapshot) {
    const snapResult = generateSalarySnapshot(user.id, preferredMethod, db);
    if (!snapResult.success || !snapResult.snapshot) {
      return {
        success: false,
        message: snapResult.message || "Failed to generate salary snapshot.",
        error: snapResult.error || "SNAPSHOT_FAILED",
        code: snapResult.error || "SNAPSHOT_FAILED"
      };
    }
    snapshot = snapResult.snapshot;
  }

  // Double check if request was created by snapshot generator
  const postSnapReq = findSalaryRequestByUserAndCycle(user.id, activeCycle.cycle_id, db);
  if (postSnapReq) {
    if (!postSnapReq.telegram_message_text && snapshot) {
      postSnapReq.telegram_message_text = formatTelegramSalaryRequest({
        user,
        snapshot,
        requestId: postSnapReq.request_id
      });
      postSnapReq.telegram_deep_link = generateTelegramShareUrl(postSnapReq.telegram_message_text);
      writeDB(db);
      syncSalaryRequestIndexes(db);
    }

    return {
      success: true,
      message: `Salary request created successfully. Request ID: ${postSnapReq.request_id}`,
      request_id: postSnapReq.request_id,
      status: postSnapReq.status,
      request: postSnapReq,
      snapshot,
      telegram_message_text: postSnapReq.telegram_message_text,
      telegram_deep_link: postSnapReq.telegram_deep_link,
      is_existing: false
    };
  }

  // STEP 3: ATOMIC INSERT INTO salary_requests
  let newRequestId = generateSalaryRequestId();
  while (findSalaryRequestById(newRequestId, db)) {
    newRequestId = generateSalaryRequestId();
  }

  const telegramText = formatTelegramSalaryRequest({
    user,
    snapshot,
    requestId: newRequestId
  });
  const telegramDeepLink = generateTelegramShareUrl(telegramText);

  // NON-NEGOTIABLE RULE 1: CLAIM IS NOT PAYMENT. State is strictly 'CLAIMED'.
  const newSalaryRequest: SalaryRequestRecord = {
    request_id: newRequestId,
    snapshot_id: snapshot.snapshot_id,
    cycle_id: activeCycle.cycle_id,
    user_id: user.id,
    amount: snapshot.calculated_salary,
    status: "CLAIMED",
    claim_idempotency_key: idempotencyKey || `claim_${activeCycle.cycle_id}_${user.id}`,
    claimed_at: new Date().toISOString(),
    tier: `L${snapshot.salary_level}`,
    payment_profile_snapshot: {
      snapshot_id: `snap_${Date.now()}`,
      profile_id: snapshot.snapshot_id,
      payment_method: snapshot.payment_method,
      account_number_or_wallet_address: snapshot.payment_account_snapshot,
      account_holder_name: snapshot.account_holder_snapshot,
      verified_status: snapshot.verification_status,
      snapshotted_at: new Date().toISOString()
    },
    telegram_message_text: telegramText,
    telegram_deep_link: telegramDeepLink
  };

  if (!db.salary_requests) {
    db.salary_requests = [];
  }
  db.salary_requests.push(newSalaryRequest);

  // Update user cached status
  user.monthly_salary_eligible = true;
  user.monthly_salary_tier = `L${snapshot.salary_level}`;

  writeDB(db);
  syncSalaryRequestIndexes(db);

  return {
    success: true,
    message: `Salary request created successfully. Request ID: ${newRequestId}`,
    request_id: newRequestId,
    status: newSalaryRequest.status,
    request: newSalaryRequest,
    snapshot,
    telegram_message_text: telegramText,
    telegram_deep_link: telegramDeepLink,
    is_existing: false
  };
}

