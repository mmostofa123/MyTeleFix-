export interface User {
  id: string;
  uid?: string;
  telegramId: string;
  username: string;
  fullName: string;
  displayName?: string;
  photoUrl?: string;
  photoURL?: string;
  points: number;
  createdAt: string;
  isPremium: boolean;
  is_vip?: boolean;
  role?: 'user' | 'guest' | 'admin' | 'super_admin' | 'ADMIN' | 'USER' | 'VIP USER';
  assignedAdmins?: string[];
  email?: string;
  gender?: 'male' | 'female' | 'other' | 'Male' | 'Female' | 'Other';
  telegramReactionVerified?: boolean;
  isChannelMember?: boolean;
  hasReactedToday?: boolean;
  activeDaysCount?: number;
  activeDaysList?: string[];
  thirtyDayBonusClaimed?: boolean;
  device_fingerprint?: string;
  deviceFingerprint?: string;
  device_hardware_uuid?: string;
  registered_ip?: string;
  isOnboarded?: boolean;
  onboardingCompleted?: boolean;
  profileInitialized?: boolean;
  isProfileCompleted?: boolean;
  profileStatus?: 'completed' | 'pending' | string;
  telegramUsername?: string;
  vip_level?: string;
  last_active_at?: string;
  lastActiveAt?: string;
  updatedAt?: string;
  authProvider?: 'telegram' | 'google' | 'guest';
  googleId?: string;
  guest_device_id?: string;
  totalWatchTimeSeconds?: number;
  status?: 'active' | 'suspended' | 'banned' | 'pending_verification';
  isBanned?: boolean;
  banReason?: string;
  isSuspicious?: boolean;
  suspiciousReason?: string;
  hardwareIdHistory?: string[];
  boundAccountsCount?: number;
  isQuizPassed?: boolean;
  isHumanVerified?: boolean;
  downloadsCount?: number;
  lastActiveTimestamp?: number;
  // VRMS-3 ULTRA Phase 11: Risk & Security Engine (RSE)
  risk_score?: number;
  risk_status?: 'LOW' | 'MEDIUM' | 'HIGH' | 'RESTRICTED' | 'BANNED';
  restriction_reason?: string;
  restricted_at?: string | null;
  last_ip?: string;
  taskStats?: {
    moviesWatched?: number;
    videosWatched?: number;
    missionsCompleted?: number;
    totalPointsEarned?: number;
  };
  active_day_streak?: number;
  valid_action_count?: number;
  last_active_day_date?: string;
  today_activity?: {
    date: string;
    tasksCompleted: number;
    tasksRequired: number;
    contentCompleted: number;
    contentRequired: number;
    activeDayEarned: boolean;
    tasksRemaining: number;
    contentRemaining: number;
  };
  // VRMS-3 ULTRA Phase 15: Automated Audit & Reconciliation Engine (ARE)
  is_reconciled?: boolean;
  discrepancy_flag?: boolean;
  discrepancy_details?: DiscrepancyDetail | null;
  qualified_referral_count?: number;
}

export interface UserDailyActivityStats {
  date: string;
  tasksCompleted: number;
  tasksRequired: number;
  contentCompleted: number;
  contentRequired: number;
  activeDayEarned: boolean;
  tasksRemaining: number;
  contentRemaining: number;
}

export interface UserActivityEngineStats {
  userId: string;
  active_day_streak: number;
  valid_action_count: number;
  last_activity_at: string;
  today: UserDailyActivityStats;
  inactivityResetApplied: boolean;
  hoursUntilInactivityReset?: number;
}

export interface VerificationRecord {
  verification_id: string;
  user_id: string;
  active_days: number;
  valid_actions: number;
  quiz_status: 'PENDING' | 'PASSED' | 'FAILED';
  verification_status: 'UNVERIFIED' | 'VERIFIED' | 'PENDING' | 'REJECTED';
  rule_version: string;
  verified_at: string | null;
  updated_at: string;
  active_day_streak?: number;
  valid_action_count?: number;
  last_activity_at?: string;
  last_active_day_date?: string | null;
  today_tasks?: number;
  today_content?: number;
  today_active_day_earned?: boolean;
}

export interface QuizQuestionOption {
  id: string;
  textBn: string;
  textEn: string;
}

export interface PublicQuizQuestion {
  id: number;
  questionBn: string;
  questionEn: string;
  options: QuizQuestionOption[];
}

export interface QuizAttemptResponse {
  attempt_id: string;
  question_set_version: string;
  questions: PublicQuizQuestion[];
  reset_count: number;
  max_resets: number;
  resets_remaining: number;
}

export interface VerificationStatusResponse {
  success: boolean;
  verified: boolean;
  status: 'UNVERIFIED' | 'VERIFIED' | 'PENDING' | 'REJECTED';
  message: string;
  verificationRecord: VerificationRecord;
  prerequisites: {
    accountValid: { passed: boolean; label: string };
    activeDays: { current: number; required: number; passed: boolean; label: string };
    validActions: { current: number; required: number; passed: boolean; label: string };
    quizPassed: { passed: boolean; score?: number; label: string };
    notRestricted: { passed: boolean; label: string };
  };
}

export interface Movie {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  genre: string;
  duration: string;
  pointsReward: number;
  requiredMissionId?: string;
  isPremiumOnly: boolean;
  rating: number;
  releaseYear: number;
  isActive: boolean;
  views: number;
  createdAt?: string;
  languages?: string[];
  tutorialVideoUrl?: string;
  audioUrl?: string;
  banglaLink?: string;
  hindiLink?: string;
  englishLink?: string;
  originalLink?: string;
  hindiDubbedUrl?: string;
  banglaDubbedUrl?: string;
  englishDubbedUrl?: string;
  originalLanguageUrl?: string;
  contentType?: 'movie' | 'drama' | 'series' | 'video' | 'adult_movie';
  category?: string;
  seasonCount?: number;
  episodeCount?: number;
  totalEpisodes?: string; // e.g. "Season 1 • Ep 12"
  groupTitle?: string;
  series_group_title?: string;
  season?: string | number;
  season_number?: string | number;
  episode?: string | number;
  episode_number?: string | number;
  dubbingLabels?: string[];
  dubbing_labels?: string[];
  languageOriginLabels?: string[];
  language_origin_labels?: string[];
  dramaClassificationLabels?: string[];
  drama_classification_labels?: string[];
}

export interface SeriesGroupPack {
  groupTitle: string;
  masterItem: Movie;
  episodes: Movie[];
  totalEpisodesCount: number;
  seasons: string[];
  latestEpisode?: string | number;
}

export interface Video {
  id: string;
  title: string;
  description?: string;
  thumbnailUrl: string;
  videoUrl: string;
  pointsReward: number;
  isActive: boolean;
  views: number;
  duration?: string;
  category?: string; // 'Deshi' | 'Indian' | 'Russian' | 'Pakistani' | 'English' | 'All'
  requiredMissionId?: string;
  isPremiumOnly?: boolean;
  genre?: string;
  rating?: number;
  createdAt?: string;
  languages?: string[];
  tutorialVideoUrl?: string;
  audioUrl?: string;
  banglaLink?: string;
  hindiLink?: string;
  englishLink?: string;
  originalLink?: string;
  contentType?: 'movie' | 'drama' | 'series' | 'video' | 'adult_movie';
  seasonCount?: number;
  episodeCount?: number;
  totalEpisodes?: string;
  groupTitle?: string;
  series_group_title?: string;
  season?: string | number;
  season_number?: string | number;
  episode?: string | number;
  episode_number?: string | number;
  dubbingLabels?: string[];
  dubbing_labels?: string[];
  languageOriginLabels?: string[];
  language_origin_labels?: string[];
  dramaClassificationLabels?: string[];
  drama_classification_labels?: string[];
}

export type MissionCategory = 'daily_reward' | 'video_ads' | 'social_tasks' | 'telegram';

export interface Mission {
  id: string;
  title: string;
  description: string;
  thumbnailUrl?: string;
  pointsReward?: number;
  rewardPoints?: number;
  type: string;
  category?: MissionCategory | string;
  platform?: 'telegram' | 'youtube' | 'facebook' | 'twitter' | 'instagram' | 'ads' | 'website' | 'daily';
  url?: string;
  durationSeconds?: number;
  isActive: boolean;
  order: number;
  cooldownHours?: number;
  guideVideoUrl?: string;
  totalSlots?: number;
  createdAt?: string;
}

export interface MissionLog {
  id: string;
  userId: string;
  missionId: string;
  status?: 'completed' | 'pending';
  timestamp?: string;
  completedAt: string;
  pointsEarned?: number;
}

export interface Transaction {
  id: string;
  userId: string;
  type: string;
  amount: number;
  description: string;
  timestamp: string;
  status: string;
}

export interface ReferralVerification {
  activeDays: number;            // Counter e.g. 0 to 5 (Requirement: 5 Days active streak)
  requiredActiveDays: number;    // 5
  tasksCompleted: number;        // Counter e.g. 0 to 50 (Requirement: 50 Valid Tasks completed)
  requiredTasks: number;         // 50
  humanQuizCompleted: boolean;   // Dynamic Human Quiz status
  subReferralsCount: number;     // e.g. 0 to 2 (Requirement: User B invites sub-referrals)
  requiredSubReferrals: number;  // 2
  isVerified: boolean;           // true when all 4 conditions are met
  verificationPercent: number;   // 0 - 100%
  claimableReward: number;       // High-value reward (e.g. 1,000 Tokens)
  isClaimed: boolean;            // Claim status by User A
  lifetimeCommissionEarned: number; // 10% lifetime task earnings credited to User A
}

export interface ChainedReferralUserB {
  id: string;
  referrerId?: string;
  referredId: string;
  username: string;
  fullName: string;
  photoUrl?: string;
  timestamp: string;
  status: 'PENDING' | 'VERIFIED' | 'CLAIMED';
  verification: ReferralVerification;
}

export interface Referral {
  id: string;
  referral_id?: string;
  referrer_id?: string;
  referred_user_id?: string;
  referrerId?: string;
  referredId?: string;
  userId?: string;
  referredUserId?: string;
  referredUsername: string;
  referredFullName?: string;
  referred_username?: string;
  referred_fullname?: string;
  status: 'REGISTERED' | 'QUALIFIED' | 'PURGED' | 'PENDING' | 'VERIFIED' | 'CLAIMED' | 'pending' | 'qualified';
  status_label?: string;
  registered_at?: string;
  qualified_at?: string | null;
  purged_at?: string | null;
  rule_version?: string;
  pointsAwarded?: number;
  pointsEarned: number;
  bonus_amount?: number;
  timestamp: string;
  qualifiedAt?: string;
  // VRMS-3 ULTRA Phase 4 fields
  active_days?: number;
  valid_actions?: number;
  quiz_status?: string;
  is_verified?: boolean;
  // Chained Viral Referral Loop fields
  verification?: ReferralVerification;
  activeDays?: number;
  tasksCompleted?: number;
  humanQuizCompleted?: boolean;
  subReferralsCount?: number;
  isVerified?: boolean;
  isClaimed?: boolean;
  claimableReward?: number;
  lifetimeCommission?: number;
}

export interface VRMSReferralItem {
  referral_id: string;
  referred_user_id: string;
  referred_username: string;
  referred_fullname: string;
  status: 'REGISTERED' | 'QUALIFIED' | 'PURGED';
  status_label: string;
  registered_at: string;
  qualified_at: string | null;
  bonus_amount: number;
  active_days: number;
  valid_actions: number;
  quiz_status: string;
  is_verified: boolean;
}

export interface VRMSReferralStats {
  success: boolean;
  userId: string;
  referralCode: string;
  referralLink: string;
  registeredCount: number;
  qualifiedCount: number;
  totalInvited: number;
  totalEarnedPoints: number;
  referrals: VRMSReferralItem[];
}

export type NotificationType = 'SYSTEM' | 'VERIFICATION' | 'SALARY' | 'SECURITY' | 'MILESTONE';

export interface Notification {
  notification_id: string;
  user_id: string;
  title: string;
  message: string;
  type: NotificationType;
  category?: string;
  content?: string;
  reference_id?: string;
  is_read: boolean;
  created_at: string;
  // Backward compatibility fields
  id: string;
  userId: string;
  isRead: boolean;
  timestamp: string;
}

export interface NotificationListResponse {
  success: boolean;
  notifications: Notification[];
  unread_count: number;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  error?: string;
}

export interface MovieRequest {
  id: string;
  userId: string;
  username: string;
  title: string;
  notes?: string;
  status: 'pending' | 'approved' | 'rejected';
  aiRecommendation?: string;
  timestamp: string;
}

export interface CommunitySettings {
  telegramChannelLink?: string;
  telegramSupportGroupLink?: string;
  whatsappSupportLink?: string;
  youtubeChannelLink?: string;
  facebookLink?: string;
  promotionEmail?: string;
  supportOperatingHours?: string;
  supportGuidelines?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface VerificationSettings {
  // Daily Active Requirements
  dailyRequiredEarnTasks: number; // Default: 10
  dailyRequiredDownloads: number; // Default: 5

  // Total Verification Targets
  requiredActiveDays: number; // Default: 10
  requiredTasks: number; // Default: 100
  requiredRefers: number; // Default: 20

  // Notice Timer Manager
  noticeCountdownSeconds: number; // Default: 15
  noticeFrequencyHours: number; // Default: 72

  updatedAt?: string;
  updatedBy?: string;
}

export interface ContentMapping {
  contentId: string;
  title: string;
  universalTelegramLink: string; // Third-party store link / file hash
  category: string;
  updatedAt?: any;
  thumbnailUrl?: string;
  description?: string;
}

export interface VerificationToken {
  token: string;
  contentId: string;
  telegramId?: string | number;
  userEmail?: string;
  createdAt: any;
  expiresAt: any;
  isUsed: boolean;
  usedAt?: any;
}

export const DEFAULT_VERIFICATION_SETTINGS: VerificationSettings = {
  dailyRequiredEarnTasks: 10,
  dailyRequiredDownloads: 5,
  requiredActiveDays: 10,
  requiredTasks: 100,
  requiredRefers: 20,
  noticeCountdownSeconds: 15,
  noticeFrequencyHours: 72,
};

export interface SystemSettings {
  domain: string;
  referralReward: number;
  referralCommissionPercent: number;
  minimumWithdrawal: number;
  isMaintenance: boolean;
  telegramBotLink: string;
  tokenRateBdt?: number; // Rate e.g. 1000 Tokens = X BDT (e.g. 100)
  tokenRateUsd?: number; // Rate e.g. 1000 Tokens = $Y USD (e.g. 0.85)
  default_reward_pts?: number;
  guide_video_url?: string;
  guideVideoUrl?: string;
  guide_audio_url?: string;
  guideAudioUrl?: string;
  guideVideoLogoUrl?: string;
  activeMagazines?: number;
  battery_site_urls?: string[];
  batterySites?: string[];
  telegramChannelUrl?: string;
  telegramPostId?: string;
  reactionRewardPoints?: number;
  referralPayoutPlan?: 'PLAN_A' | 'PLAN_B';
  // Real Ad Network Integration (Adsterra, Monetag, Google AdSense, Direct Impressions)
  adNetworkType?: 'adsterra' | 'monetag' | 'adsense' | 'direct' | 'adsgram';
  adNetworkEnabled?: boolean;
  adsterraDirectLink?: string;
  adsterraScriptTag?: string;
  monetagDirectTag?: string;
  monetagScriptCode?: string;
  monetagKey?: string;
  adsgramZone?: string;
  telegaId?: string;
  adsenseClient?: string;
  adsenseSlot?: string;
  directImpressionUrl?: string;
  adRewardPoints?: number;
  adCooldownSeconds?: number;
  videoPreRollAd?: boolean;
  videoMidRollAd?: boolean;
  firstVerificationUrl?: string;
  secondVerificationUrl?: string;
  telegramBotUsername?: string;
  verificationSettings?: VerificationSettings;
}

export interface AdImpressionRecord {
  id: string;
  userId: string;
  network: 'adsterra' | 'monetag' | 'adsense' | 'direct' | 'adsgram';
  type: 'task' | 'video_preroll' | 'video_reward';
  rewardPoints: number;
  impressionUrl?: string;
  timestamp: string;
}

export interface HighRiskWithdrawalLog {
  id: string;
  withdrawalId: string;
  userId: string;
  username: string;
  email?: string;
  amount: number;
  riskScore: number;
  riskReasons: string[];
  device_fingerprint?: string;
  ip_address?: string;
  userAgent?: string;
  hardwareMetrics?: {
    screenResolution?: string;
    colorDepth?: number;
    hardwareConcurrency?: number;
    deviceMemory?: number;
    timezone?: string;
    platform?: string;
  };
  status?: 'pending' | 'flagged' | 'cleared' | 'rejected';
  timestamp: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  username: string;
  email?: string;
  userEmail?: string;
  amount: number;
  paymentMethod?: 'bKash' | 'Nagad' | 'Crypto' | 'TON' | 'USDT' | string;
  walletAddress: string;
  accountNumber?: string;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  timestamp: string;
}

export interface VipRequest {
  id: string;
  user_id: string;
  userId?: string;
  username: string;
  fullName?: string;
  payment_method: string;
  paymentMethod?: string;
  trx_id: string;
  trxId?: string;
  amount?: number;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  created_at: string;
  createdAt?: string;
}

export interface AdminAnalytics {
  totalUsers: number;
  totalPointsAwarded: number;
  totalWithdrawals: number;
  pendingWithdrawals: number;
  activeMissionsCount: number;
  pointsDistribution: Array<{ type: string; total: number }>;
}

// VRMS-3 ULTRA (Phase 6): Referral Milestone Reward Engine (RME) Types
export interface MilestoneItem {
  milestone_id: string;
  campaign_id: string;
  threshold: number;
  amount: number;
  title: string;
  description: string;
  status: 'LOCKED' | 'PENDING' | 'CLAIMABLE' | 'CREDITED' | 'REVIEW' | 'REVERSED';
  current_count: number;
  progress_percent: number;
  max_per_user: number;
  rule_version: number;
  claimed_at: string | null;
  reward_id?: string;
  is_claimable: boolean;
  is_claimed: boolean;
}

export interface MilestoneStatusData {
  success: boolean;
  userId: string;
  qualifiedCount: number;
  totalMilestones: number;
  claimedCount: number;
  claimableCount: number;
  totalClaimedRewardPoints: number;
  campaign: {
    campaign_id: string;
    rule_version: number;
    budget: number;
    total_claimed_amount: number;
  };
  milestones: MilestoneItem[];
}

// VRMS-3 ULTRA (Phase 7): Wallet & Payment Profile Types
export type PaymentMethodType = 'bKash' | 'Nagad' | 'TRC20_USDT';

export interface WalletPaymentProfile {
  profile_id: string;
  user_id: string;
  payment_method: PaymentMethodType;
  account_number_or_wallet_address: string;
  account_holder_name: string;
  verified_status: 'UNVERIFIED' | 'VERIFIED' | 'REJECTED';
  updated_at: string;
  created_at?: string;
}

export interface PaymentProfileSnapshot {
  snapshot_id: string;
  profile_id: string;
  payment_method: PaymentMethodType;
  account_number_or_wallet_address: string;
  account_holder_name: string;
  verified_status: string;
  snapshotted_at: string;
}

// VRMS-3 ULTRA (Phase 9): Salary Request Types & Status
export type SalaryRequestStatus = 
  | 'CLAIMED' 
  | 'UNDER_REVIEW' 
  | 'APPROVED' 
  | 'AWAITING_MANUAL_PAYMENT' 
  | 'PAID' 
  | 'HOLD' 
  | 'REJECTED'
  | 'PENDING'
  | 'DISBURSED';

export interface SalaryRequestRecord {
  request_id: string;
  snapshot_id: string;
  cycle_id: string;
  user_id: string;
  amount: number;
  status: SalaryRequestStatus;
  claim_idempotency_key: string;
  claimed_at: string;
  reviewed_at?: string;
  approved_at?: string;
  paid_at?: string;
  rejection_reason?: string;
  admin_note?: string;
  // Contextual and backward-compatibility fields
  tier?: string;
  payment_profile_snapshot?: PaymentProfileSnapshot;
  transaction_id?: string;
  telegram_message_text?: string;
  telegram_deep_link?: string;
}

export interface SalaryClaimResponse {
  success: boolean;
  message: string;
  request_id?: string;
  status?: SalaryRequestStatus;
  request?: SalaryRequestRecord;
  snapshot?: SalarySnapshot;
  telegram_message_text?: string;
  telegram_deep_link?: string;
  is_existing?: boolean;
  error?: string;
  code?: string;
}

export interface PaymentProfileResponse {
  success: boolean;
  userId?: string;
  profiles: WalletPaymentProfile[];
  supported_methods: PaymentMethodType[];
}

// VRMS-3 ULTRA (Phase 8): Monthly Salary Engine Types
export type SalaryLevel = 1 | 2 | 3;

export interface SalaryCycle {
  cycle_id: string;
  start_at: string;
  end_at: string;
  distribution_at: string;
  rule_version: string;
  status: 'ACTIVE' | 'CLOSED';
}

export interface SalarySnapshot {
  snapshot_id: string;
  cycle_id: string;
  user_id: string;
  salary_level: SalaryLevel;
  current_eligible_verified_referrals: number;
  new_verified_referrals: number;
  qualified_active_referrals: number;
  calculated_salary: number;
  payment_method: PaymentMethodType;
  payment_account_snapshot: string;
  account_holder_snapshot: string;
  verification_status: string;
  risk_status: 'LOW' | 'MEDIUM' | 'HIGH' | 'CLEARED' | 'NOT_RESTRICTED';
  created_at: string;
}

export interface SalaryEligibilityResponse {
  success: boolean;
  eligible: boolean;
  salary_level: SalaryLevel | 0;
  salary_tier_label: 'L1' | 'L2' | 'L3' | 'None';
  current_eligible_verified_referrals: number;
  level_cap_target: number;
  new_verified_referrals: number;
  new_verified_target: number;
  has_met_new_verified: boolean;
  qualified_active_referrals: number;
  active_referrals_target: number;
  has_met_active_referrals: boolean;
  claimant_verified: boolean;
  claimant_not_restricted: boolean;
  has_payment_profile: boolean;
  payment_profiles: WalletPaymentProfile[];
  calculated_salary: number;
  active_cycle: SalaryCycle | null;
  already_claimed_in_cycle: boolean;
  reasons_ineligible: string[];
  max_salary_level: 3;
}

export interface SalarySnapshotGenerateResponse {
  success: boolean;
  message: string;
  snapshot?: SalarySnapshot;
  error?: string;
}

// VRMS-3 ULTRA (Phase 10): Admin Audit Logs & Salary Review Types
export interface AdminAuditLogRecord {
  log_id: string;
  admin_id: string;
  action: string;
  target_type: string;
  target_id: string;
  old_value: any;
  new_value: any;
  reason?: string;
  created_at: string;
}

export type AdminSalaryActionType = 'APPROVE' | 'HOLD' | 'REJECT' | 'UNDER_REVIEW' | 'AWAIT_PAYMENT';

export interface AdminSalaryRequestItem extends SalaryRequestRecord {
  user_username?: string;
  user_fullname?: string;
  user_email?: string;
  user_telegram_id?: string;
  user_is_banned?: boolean;
  user_is_suspicious?: boolean;
  salary_level?: SalaryLevel;
  qualified_active_referrals?: number;
  new_verified_referrals?: number;
  current_eligible_verified_referrals?: number;
  payment_method?: PaymentMethodType;
  account_number?: string;
  account_holder_name?: string;
  verification_status?: string;
  risk_status?: string;
  snapshot?: SalarySnapshot;
}

export interface AdminSalaryRequestsResponse {
  success: boolean;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  status_counts: {
    all: number;
    under_review: number;
    approved: number;
    paid: number;
    rejected_hold: number;
  };
  requests: AdminSalaryRequestItem[];
  error?: string;
}

export interface AdminSalaryReviewActionResponse {
  success: boolean;
  message: string;
  request?: SalaryRequestRecord;
  old_status?: SalaryRequestStatus;
  new_status?: SalaryRequestStatus;
  audit_log?: AdminAuditLogRecord;
  error?: string;
}

export interface AdminSalaryMarkPaidResponse {
  success: boolean;
  message: string;
  request?: SalaryRequestRecord;
  audit_log?: AdminAuditLogRecord;
  error?: string;
}

export type RiskStatus = 'LOW' | 'MEDIUM' | 'HIGH' | 'RESTRICTED' | 'BANNED';

export interface DetectedSignals {
  device_hash_overlap?: {
    overlap_count: number;
    matched_user_ids: string[];
    device_fingerprint?: string;
  };
  ip_anomalies?: {
    ip_reuse_count: number;
    matched_user_ids: string[];
    ip_address?: string;
  };
  fast_completion?: {
    duration_ms?: number;
    threshold_ms?: number;
    velocity_anomaly?: boolean;
    consecutive_rapid_completions?: number;
  };
  details?: string[];
}

export interface RiskAssessmentRecord {
  assessment_id: string;
  user_id: string;
  risk_score: number;
  detected_signals: DetectedSignals;
  recommended_action: 'NONE' | 'MONITOR' | 'RESTRICT' | 'BAN';
  created_at: string;
}

export interface SecurityAuditLogRecord {
  log_id: string;
  user_id: string;
  action_taken: 'FLAGGED' | 'RESTRICTED' | 'BANNED' | 'UNRESTRICTED' | 'CLEARED' | 'MONITORED';
  reason: string;
  enforced_by: 'SYSTEM' | 'ADMIN';
  created_at: string;
  metadata?: Record<string, any>;
}

// =========================================================================
// VRMS-3 ULTRA (PHASE 13): Dynamic Campaign Engine & System Settings Types
// =========================================================================

export type CampaignStatus = 'UPCOMING' | 'ACTIVE' | 'PAUSED' | 'COMPLETED';

export interface CampaignRecord {
  campaign_id: string;
  title: string;
  start_date: string;
  end_date: string;
  status: CampaignStatus;
  target_metrics?: {
    referral_target?: number;
    budget?: number;
    level_1_cap?: number;
    level_2_cap?: number;
    level_3_cap?: number;
    bonus_multiplier?: number;
    description?: string;
  };
  created_at?: string;
  updated_at?: string;
}

export interface SystemConfigRecord {
  config_key: string;
  config_value: any;
  description?: string;
  last_updated_by?: string;
  updated_at?: string;
}

export interface GlobalConfigMap {
  MIN_WITHDRAWAL_POINTS: number;
  MAX_DAILY_WITHDRAWAL_POINTS: number;
  SALARY_LEVEL_1_TARGET: number;
  SALARY_LEVEL_2_TARGET: number;
  SALARY_LEVEL_3_TARGET: number;
  SALARY_LEVEL_1_AMOUNT_BDT: number;
  SALARY_LEVEL_2_AMOUNT_BDT: number;
  SALARY_LEVEL_3_AMOUNT_BDT: number;
  SALARY_NEW_VERIFIED_TARGET: number;
  SALARY_ACTIVE_DAYS_TARGET: number;
  MAINTENANCE_MODE: boolean;
  MAINTENANCE_MESSAGE: string;
  TASK_BASE_REWARD_POINTS: number;
  TELEGRAM_REACTION_REWARD_POINTS: number;
  DAILY_STREAK_BONUS_POINTS: number;
  PURGE_INACTIVE_DAYS: number;
  INACTIVITY_WARNING_HOURS: number;
  [key: string]: any;
}

export interface SystemConfigResponse {
  success: boolean;
  configs: SystemConfigRecord[];
  configMap: GlobalConfigMap;
  activeCampaign: CampaignRecord | null;
  maintenance_mode: boolean;
  timestamp: string;
}

// ==========================================
// VRMS-3 ULTRA (Phase 15): Automated Audit & Reconciliation Engine (ARE)
// ==========================================
export type LedgerTransactionType = 
  | 'TASK_REWARD' 
  | 'MILESTONE_BONUS' 
  | 'SALARY_PAYOUT' 
  | 'REVERSAL'
  | 'WITHDRAWAL'
  | 'CONTENT_REWARD'
  | 'REFUND'
  | 'INITIAL_BALANCE'
  | 'SYSTEM_ADJUSTMENT';

export interface LedgerEntry {
  ledger_id: string;
  user_id: string;
  transaction_type: LedgerTransactionType;
  amount: number;
  reference_type: 'TASK' | 'MILESTONE' | 'SALARY' | 'WITHDRAWAL' | 'CONTENT' | 'PURGE' | 'SYSTEM' | 'REFERRAL';
  reference_id: string;
  created_at: string;
  metadata?: Record<string, any>;
}

export type ReconciliationRunType = 'SCHEDULED' | 'MANUAL';
export type ReconciliationStatus = 'PASSED' | 'DISCREPANCY_FOUND';
export type DiscrepancyCategory = 'BALANCE_MISMATCH' | 'REFERRAL_MISMATCH' | 'SALARY_MISMATCH';

export interface DiscrepancyDetail {
  record_id: string;
  category: DiscrepancyCategory;
  user_id: string;
  username?: string;
  expected_value: number;
  actual_value: number;
  discrepancy_delta: number;
  reason: string;
  timestamp: string;
}

export interface AuditReconciliationSummary {
  audited_users_count: number;
  audited_ledger_entries_count: number;
  audited_referrals_count: number;
  audited_salaries_count: number;
  balanced_users_count: number;
  flagged_users_count: number;
  discrepancies: DiscrepancyDetail[];
  execution_duration_ms: number;
  run_by: string;
  notes?: string;
}

export interface AuditReconciliation {
  reconciliation_id: string;
  run_type: ReconciliationRunType;
  status: ReconciliationStatus;
  mismatched_records_count: number;
  summary_log: AuditReconciliationSummary;
  executed_at: string;
}

export interface ReconciliationHealthSummary {
  status: ReconciliationStatus;
  last_run_at: string | null;
  last_reconciliation_id: string | null;
  total_audited_runs: number;
  total_flagged_users: number;
  total_ledger_entries: number;
  integrity_score_percent: number;
  passing_rate_percent: number;
}

export type AppLanguage = 'English' | 'বাংলা' | 'हिंदी';

export interface LanguageOption {
  code: AppLanguage;
  label: string;
  native: string;
  flag: string;
}

export type UserMode = "GUEST" | "VIP";

export interface DownloadRequest {
  id?: string;
  telegramId?: number | string;
  userEmail?: string;
  uid?: string;
  userMode: UserMode;
  contentId: string;
  contentTitle: string;
  universalLink: string;
  status: "PENDING" | "VERIFIED" | "COMPLETED" | "DELIVERED";
  deepLink?: string;
  createdAt?: any;
  verifiedAt?: any;
  deliveredAt?: any;
  rewardEarned?: number;
  pointsAllocated?: boolean;
}
