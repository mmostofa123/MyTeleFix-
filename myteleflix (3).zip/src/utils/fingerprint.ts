/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Device Fingerprinting Engine for My TeleFlix
// Generates a deterministic, resilient client device fingerprint based on canvas rendering,
// hardware capabilities, display specs, and browser platform attributes.

const STORAGE_KEY = "myteleflix_device_fingerprint";
const GUEST_ID_KEY = "myteleflix_guest_device_id";

/**
 * Generates or retrieves a persistent guest_device_id bound to device fingerprint.
 */
export function getGuestDeviceId(existingFp?: string): string {
  if (typeof window === "undefined") return "guest_ssr";
  try {
    const cached = localStorage.getItem(GUEST_ID_KEY);
    if (cached && cached.startsWith("guest_")) {
      return cached;
    }
    const fp = existingFp || getCachedDeviceFingerprint();
    const hash = fp ? fp.replace(/^fp_/, "").slice(0, 16) : Math.random().toString(36).substring(2, 10);
    const newGuestId = `guest_${hash}`;
    localStorage.setItem(GUEST_ID_KEY, newGuestId);
    return newGuestId;
  } catch (e) {
    return `guest_device_${Date.now()}`;
  }
}

/**
 * Fast synchronous retrieval of previously generated fingerprint (if cached),
 * or generates a quick fallback while full asynchronous calculation proceeds.
 */
export function getCachedDeviceFingerprint(): string {
  if (typeof window === "undefined") return "fp_ssr_server_fallback";
  try {
    const cached = localStorage.getItem(STORAGE_KEY);
    if (cached && cached.startsWith("fp_")) {
      return cached;
    }
  } catch (e) {
    // Ignore storage issues
  }
  return "";
}

/**
 * Generates an FNV-1a 32-bit hash of a string, represented as hex.
 */
function fnv1a(str: string): string {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

/**
 * Canvas 2D geometry, gradient, and font metric rendering fingerprint.
 */
function getCanvasFingerprint(): string {
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 240;
    canvas.height = 60;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "no-canvas-2d";

    // Text with complex typography and emojis
    ctx.textBaseline = "top";
    ctx.font = "14px 'Arial', 'Helvetica', sans-serif";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#f60";
    ctx.fillRect(125, 1, 62, 20);

    ctx.fillStyle = "#069";
    ctx.fillText("MyTeleFlix 🎬 100% ⚡", 2, 15);
    ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
    ctx.fillText("Cinema & Vault Auth", 4, 35);

    // Multi-color radial and linear gradients
    const grad = ctx.createLinearGradient(0, 0, 200, 0);
    grad.addColorStop(0, "#ff007a");
    grad.addColorStop(0.5, "#7928ca");
    grad.addColorStop(1, "#4338ca");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 45, 240, 15);

    return canvas.toDataURL();
  } catch (e) {
    return "canvas-failed";
  }
}

/**
 * WebGL hardware renderer and vendor query.
 */
function getWebGLFingerprint(): string {
  try {
    const canvas = document.createElement("canvas");
    const gl = (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (!gl) return "no-webgl";

    const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
    const vendor = debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
    const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);

    return `${vendor}~${renderer}`;
  } catch (e) {
    return "webgl-failed";
  }
}

/**
 * Computes the unique client device fingerprint.
 */
export async function getDeviceFingerprint(): Promise<string> {
  if (typeof window === "undefined") {
    return "fp_ssr_server_environment";
  }

  // Check if valid fingerprint already stored
  const cached = getCachedDeviceFingerprint();
  if (cached) {
    return cached;
  }

  try {
    const canvasHash = fnv1a(getCanvasFingerprint());
    const webglHash = fnv1a(getWebGLFingerprint());

    const screenData = [
      window.screen.width,
      window.screen.height,
      window.screen.colorDepth,
      window.devicePixelRatio || 1
    ].join("x");

    const hardwareData = [
      navigator.hardwareConcurrency || "unknown",
      (navigator as any).deviceMemory || "unknown",
      navigator.maxTouchPoints || 0,
      navigator.language || "en",
      Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"
    ].join("|");

    const rawSignature = `${canvasHash}:${webglHash}:${screenData}:${hardwareData}:${navigator.platform || "web"}`;

    let finalHash: string;

    // Use Web Crypto SHA-256 if supported
    if (window.crypto && window.crypto.subtle) {
      const msgUint8 = new TextEncoder().encode(rawSignature);
      const hashBuffer = await window.crypto.subtle.digest("SHA-256", msgUint8);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      finalHash = hashArray.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 24);
    } else {
      // Fallback combined double fnv1a
      const h1 = fnv1a(rawSignature);
      const h2 = fnv1a(rawSignature + "_salt");
      const h3 = fnv1a(rawSignature + "_pepper");
      finalHash = (h1 + h2 + h3).slice(0, 24);
    }

    const fingerprint = `fp_${finalHash}`;

    try {
      localStorage.setItem(STORAGE_KEY, fingerprint);
    } catch (e) {
      // ignore
    }

    return fingerprint;
  } catch (err) {
    // Graceful fallback
    const fallback = `fp_${fnv1a((navigator.platform || "web") + screen.width + screen.height + (navigator.hardwareConcurrency || 4))}`;
    try {
      localStorage.setItem(STORAGE_KEY, fallback);
    } catch (e) {}
    return fallback;
  }
}

/**
 * Returns structured client hardware specifications for anti-fraud analysis and Firestore logging.
 */
export function getHardwareMetrics(): {
  screenResolution: string;
  colorDepth: number;
  hardwareConcurrency: number;
  deviceMemory: number;
  timezone: string;
  platform: string;
} {
  if (typeof window === "undefined") {
    return {
      screenResolution: "unknown",
      colorDepth: 24,
      hardwareConcurrency: 4,
      deviceMemory: 8,
      timezone: "UTC",
      platform: "server"
    };
  }
  return {
    screenResolution: `${window.screen?.width || 0}x${window.screen?.height || 0}`,
    colorDepth: window.screen?.colorDepth || 24,
    hardwareConcurrency: navigator?.hardwareConcurrency || 4,
    deviceMemory: (navigator as any)?.deviceMemory || 4,
    timezone: Intl?.DateTimeFormat()?.resolvedOptions()?.timeZone || "UTC",
    platform: navigator?.platform || "web"
  };
}

