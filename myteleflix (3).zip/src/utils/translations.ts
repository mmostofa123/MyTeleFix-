/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Lightweight, zero-dependency 3-Language Multi-Language Engine
 * Supported Languages: English (Default), বাংলা (Bangla), हिंदी (Hindi)
 */

import { AppLanguage, LanguageOption } from "../types";

export const STORAGE_KEY_LANGUAGE = "user_app_language";
export const LANGUAGE_CHANGE_EVENT = "user_app_language_changed";

export const LANGUAGE_OPTIONS: LanguageOption[] = [
  {
    code: "English",
    label: "English (Default)",
    native: "English",
    flag: "🇬🇧"
  },
  {
    code: "বাংলা",
    label: "বাংলা (Bangla)",
    native: "বাংলা",
    flag: "🇧🇩"
  },
  {
    code: "हिंदी",
    label: "हिंदी (Hindi)",
    native: "हिंदी",
    flag: "🇮🇳"
  }
];

export function getStoredLanguage(): AppLanguage {
  if (typeof window === "undefined") return "English";
  try {
    const saved = localStorage.getItem(STORAGE_KEY_LANGUAGE) || localStorage.getItem("myteleflix_language");
    if (saved === "বাংলা" || saved === "bn" || saved === "Bangla" || saved === "Bengali") return "বাংলা";
    if (saved === "हिंदी" || saved === "hi" || saved === "Hindi") return "हिंदी";
    return "English";
  } catch {
    return "English";
  }
}

export function setStoredLanguage(lang: AppLanguage): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY_LANGUAGE, lang);
    const code = lang === "বাংলা" ? "bn" : (lang === "हिंदी" ? "hi" : "en");
    localStorage.setItem("myteleflix_language", code);
    window.dispatchEvent(new CustomEvent(LANGUAGE_CHANGE_EVENT, { detail: lang }));
  } catch (e) {
    console.warn("Error saving user_app_language:", e);
  }
}

/**
 * 3-Language Dictionary for UI Strings & Sub-Filter Labels
 */
export const DICTIONARY: Record<string, Record<AppLanguage, string>> = {
  // Navigation
  "nav.home": {
    English: "Home",
    "বাংলা": "হোম",
    "हिंदी": "होम"
  },
  "nav.movies": {
    English: "Movies",
    "বাংলা": "মুভিজ",
    "हिंदी": "फ़िल्में"
  },
  "nav.videos": {
    English: "Videos",
    "বাংলা": "ভিডিও",
    "हिंदी": "वीडियो"
  },
  "nav.earn": {
    English: "Earn",
    "বাংলা": "ইনকাম সাইট",
    "हिंदी": "कमाई"
  },
  "tabs.earn": {
    English: "Earn",
    "বাংলা": "ইনকাম সাইট",
    "हिंदी": "कमाई"
  },
  "earn": {
    English: "Earn",
    "বাংলা": "ইনকাম সাইট",
    "हिंदी": "कमाई"
  },
  "ইনকাম সাইট": {
    English: "Earn",
    "বাংলা": "ইনকাম সাইট",
    "हिंदी": "कमाई"
  },
  "আর্ন": {
    English: "Earn",
    "বাংলা": "ইনকাম সাইট",
    "हिंदी": "कमाई"
  },
  "nav.profile": {
    English: "Profile",
    "বাংলা": "প্রোফাইল",
    "हिंदी": "प्रोफ़ाइल"
  },
  "nav.wallet": {
    English: "Wallet",
    "বাংলা": "ওয়ালেট",
    "हिंदी": "वॉलेट"
  },

  // Actions
  "download": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "DOWNLOAD": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "action.download": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "GET LINK": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "গেট লিংক": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "action.get_link": {
    English: "DOWNLOAD",
    "বাংলা": "ডাউনলোড",
    "हिंदी": "डाउनलोड"
  },
  "OPENING...": {
    English: "OPENING...",
    "বাংলা": "লোড হচ্ছে...",
    "हिंदी": "खुल रहा है..."
  },
  "opening": {
    English: "OPENING...",
    "বাংলা": "লোড হচ্ছে...",
    "हिंदी": "खুল रहा है..."
  },
  "action.opening": {
    English: "OPENING...",
    "বাংলা": "লোড হচ্ছে...",
    "हिंदी": "खुल रहा है..."
  },
  "back": {
    English: "Back",
    "বাংলা": "ফিরে যান",
    "हिंदी": "वापस जाएं"
  },
  "action.back": {
    English: "Back",
    "বাংলা": "ফিরে যান",
    "हिंदी": "वापस जाएं"
  },
  "all_episodes": {
    English: "ALL EPISODES",
    "বাংলা": "সকল পর্ব ও লিংক",
    "हिंदी": "सभी एपिसोड"
  },
  "back_to_all": {
    English: "Back to All",
    "বাংলা": "সবগুলোতে ফিরে যান",
    "हिंदी": "सभी पर वापस जाएं"
  },
  "popular": {
    English: "POPULAR",
    "বাংলা": "জনপ্রিয়",
    "हिंदी": "लोकप्रिय"
  },
  // Top Categories
  "All": {
    English: "All",
    "বাংলা": "সব",
    "हिंदी": "सभी"
  },
  "Movies": {
    English: "Movies",
    "বাংলা": "মুভি",
    "हिंदी": "फिल्में"
  },
  "Adult Movies": {
    English: "Adult Movies",
    "বাংলা": "অ্যাডাল্ট মুভি",
    "हिंदी": "एडल्ट फिल्में"
  },
  "AdultMovies": {
    English: "Adult Movies",
    "বাংলা": "অ্যাডাল্ট মুভি",
    "हिंदी": "एडल्ट फिल्में"
  },
  "Drama / Natok": {
    English: "Drama / Natok",
    "বাংলা": "নাটক",
    "हिंदी": "नाटक"
  },
  "Drama": {
    English: "Drama / Natok",
    "বাংলা": "নাটক",
    "हिंदी": "नाटक"
  },
  "Web Series": {
    English: "Web Series",
    "বাংলা": "ওয়েব সিরিজ",
    "हिंदी": "वेब सीरीज"
  },
  "Series": {
    English: "Web Series",
    "বাংলা": "ওয়েব সিরিজ",
    "हिंदी": "वेब सीरीज"
  },
  "Videos": {
    English: "Videos",
    "বাংলা": "ভিডিও",
    "हिंदी": "वीडियो"
  },

  // Movies Screen Sub-Filters
  "ALL": {
    English: "ALL",
    "বাংলা": "সব",
    "हिंदी": "सभी"
  },
  "বাংলা ডাবড": {
    English: "Bangla Dubbed",
    "বাংলা": "বাংলা ডাবড",
    "हिंदी": "बांग्ला डब"
  },
  "হিন্দি ডাবড": {
    English: "Hindi Dubbed",
    "বাংলা": "হিন্দি ডাবড",
    "हिंदी": "हिंदी डब"
  },
  "ইংলিশ ডাবড": {
    English: "English Dubbed",
    "বাংলা": "ইংলিশ ডাবড",
    "हिंदी": "इंग्लिश डब"
  },

  // Series Screen Sub-Filters
  "বাংলা সিরিজ": {
    English: "Bangla Series",
    "বাংলা": "বাংলা সিরিজ",
    "हिंदी": "बांग्ला सीरीज"
  },
  "হিন্দি সিরিজ": {
    English: "Hindi Series",
    "বাংলা": "হিন্দি সিরিজ",
    "हिंदी": "हिंदी सीरीज"
  },
  "ফরেন / ইংলিশ": {
    English: "Foreign / English",
    "বাংলা": "ফরেন / ইংলিশ",
    "हिंदी": "फॉरेन / इंग्लिश"
  },
  "কে-ড্রামা & অ্যানিমে": {
    English: "K-Drama & Anime",
    "বাংলা": "কে-ড্রামা & অ্যানিমে",
    "हिंदी": "के-ड्रामा और एनीमे"
  },

  // Drama Screen Sub-Filters
  "বাংলা নাটক": {
    English: "Bangla Natok",
    "বাংলা": "বাংলা নাটক",
    "हिंदी": "बांग्ला नाटक"
  },
  "হিন্দি ড্রামা": {
    English: "Hindi Drama",
    "বাংলা": "হিন্দি ড্রামা",
    "हिंदी": "हिंदी ड्रामा"
  },
  "মেগা সিরিয়াল": {
    English: "Mega Serial",
    "বাংলা": "মেগা সিরিয়াল",
    "हिंदी": "मेगा सीरियल"
  },
  "টেলিফিল্ম": {
    English: "Telefilm",
    "বাংলা": "টেলিফিল্ম",
    "हिंदी": "टेलीफिल्म"
  },

  // Video Country / Sub-category Filters
  "Deshi": {
    English: "Deshi",
    "বাংলা": "দেশি",
    "हिंदी": "देसी"
  },
  "দেশি": {
    English: "Deshi",
    "বাংলা": "দেশি",
    "हिंदी": "देसी"
  },
  "Indian": {
    English: "Indian",
    "বাংলা": "ইন্ডিয়ান",
    "हिंदी": "इंडियन"
  },
  "ইন্ডিয়ান": {
    English: "Indian",
    "বাংলা": "ইন্ডিয়ান",
    "हिंदी": "इंडियन"
  },
  "Russian": {
    English: "Russian",
    "বাংলা": "রাশিয়ান",
    "हिंदी": "रूसी"
  },
  "রাশিয়ান": {
    English: "Russian",
    "বাংলা": "রাশিয়ান",
    "हिंदी": "रूसी"
  },
  "Pakistani": {
    English: "Pakistani",
    "বাংলা": "পাকিস্তানি",
    "हिंदी": "पाकिस्तानी"
  },
  "পাকিস্তানি": {
    English: "Pakistani",
    "বাংলা": "পাকিস্তানি",
    "हिंदी": "पाकिस्तानी"
  },
  "English": {
    English: "English",
    "বাংলা": "ইংলিশ",
    "हिंदी": "इंग्लिश"
  },
  "ইংলিশ": {
    English: "English",
    "বাংলা": "ইংলিশ",
    "हिंदी": "इंग्लिश"
  },

  // Section Headers & Titles
  "trending_movies": {
    English: "Trending Movies",
    "বাংলা": "জনপ্রিয় মুভি",
    "हिंदी": "ट्रेंडिंग फिल्में"
  },
  "adult_movies_title": {
    English: "Adult Movies (18+)",
    "বাংলা": "অ্যাডাল্ট মুভি (১৮+)",
    "हिंदी": "एडल्ट फिल्में (18+)"
  },
  "trending_series": {
    English: "Trending Web Series",
    "বাংলা": "জনপ্রিয় ওয়েব সিরিজ",
    "हिंदी": "ट्रेंडिंग वेब सीरीज"
  },
  "trending_drama": {
    English: "Drama & Bangla Natok",
    "বাংলা": "নাটক ও বাংলা নাটক",
    "हिंदी": "ड्रामा और बांग्ला नाटक"
  },
  "viral_videos_title": {
    English: "Viral Videos",
    "বাংলা": "ভাইরাল ভিডিও",
    "हिंदी": "वायरल वीडियो"
  },
  "cinema_movies_title": {
    English: "Cinema Movies",
    "বাংলা": "সিনেমা মুভি",
    "हिंदी": "सिनेमा फिल्में"
  },
  "web_series_title": {
    English: "Web Series",
    "বাংলা": "ওয়েব সিরিজ",
    "हिंदी": "वेब सीरीज"
  },
  "drama_natok_title": {
    English: "Drama & Bangla Natok",
    "বাংলা": "নাটক ও বাংলা নাটক",
    "हिंदी": "ड्रामा और बांग्ला नाटक"
  },
  "search_results_title": {
    English: "Search Results",
    "বাংলা": "সার্চ রেজাল্ট",
    "हिंदी": "खोज परिणाम"
  },

  // Search Bar Placeholders
  "search_global_placeholder": {
    English: "Search movies, natok, web series & videos...",
    "বাংলা": "মুভি, নাটক, ওয়েব সিরিজ ও ভিডিও সার্চ করুন...",
    "हिंदी": "फिल्में, नाटक, वेब सीरीज और वीडियो खोजें..."
  },
  "search_movies_placeholder": {
    English: "Search movies by title, genre...",
    "বাংলা": "টাইটেল অথবা জনরা দিয়ে মুভি খুঁজুন...",
    "हिंदी": "शीर्षक या शैली से फिल्में खोजें..."
  },
  "search_series_placeholder": {
    English: "Search web series by title, season, episodes...",
    "বাংলা": "ওয়েব সিরিজ, সিজন বা পর্ব সার্চ করুন...",
    "हिंदी": "वेब सीरीज, सीजन या एपिसोड खोजें..."
  },
  "search_drama_placeholder": {
    English: "Filter drama & natok by title, actors, genre...",
    "বাংলা": "নাটক, অভিনেতা বা জনরা দিয়ে খুঁজুন...",
    "हिंदी": "शीर्षक, कलाकार या शैली से नाटक खोजें..."
  },
  "search_videos_placeholder": {
    English: "Search videos...",
    "বাংলা": "ভিডিও ক্লিপ সার্চ করুন...",
    "हिंदी": "वीडियो क्लिप्स खोजें..."
  },

  // Empty State Headings & Messages
  "no_content_found": {
    English: "No Content Found",
    "বাংলা": "কোন কনটেন্ট পাওয়া যায়নি",
    "हिंदी": "कोई सामग्री नहीं मिली"
  },
  "no_movies_found": {
    English: "No Movies Found",
    "বাংলা": "কোন মুভি পাওয়া যায়নি",
    "हिंदी": "कोई फिल्म नहीं मिली"
  },
  "no_series_found": {
    English: "No Web Series Found",
    "বাংলা": "কোন ওয়েব সিরিজ পাওয়া যায়নি",
    "हिंदी": "कोई वेब सीरीज नहीं मिली"
  },
  "no_drama_found": {
    English: "No Drama Found",
    "বাংলা": "কোন নাটক পাওয়া যায়নি",
    "हिंदी": "कोई नाटक नहीं मिला"
  },
  "no_videos_found": {
    English: "No Videos Found",
    "বাংলা": "কোন ভিডিও পাওয়া যায়নি",
    "हिंदी": "कोई वीडियो नहीं मिला"
  },
  "see_all_movies": {
    English: "View All Movies",
    "বাংলা": "সব মুভি দেখুন",
    "हिंदी": "सभी फिल्में देखें"
  },
  "see_all_series": {
    English: "View All Series",
    "বাংলা": "সব সিরিজ দেখুন",
    "हिंदी": "सभी सीरीज देखें"
  },
  "see_all_drama": {
    English: "View All Drama",
    "বাংলা": "সব নাটক দেখুন",
    "हिंदी": "सभी नाटक देखें"
  },
  "view_all_content": {
    English: "View All Content",
    "বাংলা": "সব কনটেন্ট দেখুন",
    "हिंदी": "सभी सामग्री देखें"
  },

  // Action Buttons & Labels
  "sign_in_now": {
    English: "Sign In Now",
    "বাংলা": "এখন সাইন ইন করুন",
    "हिंदी": "अभी साइन इन करें"
  },
  "app_settings": {
    English: "App Settings",
    "বাংলা": "অ্যাপ সেটিংস",
    "हिंदी": "ऐप सेटिंग्स"
  },
  "language_setting": {
    English: "Language / ভাষা",
    "বাংলা": "Language / ভাষা",
    "हिंदी": "Language / भाषा"
  },
  "language_description": {
    English: "Select app language (English, বাংলা, हिंदी)",
    "বাংলা": "অ্যাপের ভাষা নির্বাচন করুন (English, বাংলা, हिंदी)",
    "हिंदी": "ऐप की भाषा चुनें (English, বাংলা, हिंदी)"
  },
  "language_selector_title": {
    English: "Select App Language",
    "বাংলা": "অ্যাপের ভাষা নির্বাচন করুন",
    "हिंदी": "ऐप की भाषा चुनें"
  },
  "language_selector_sub": {
    English: "Instant real-time interface translation",
    "বাংলা": "তাৎক্ষণিক ইন্টারফেস অনুবাদ",
    "हिंदी": "तत्काल इंटरफ़ेस अनुवाद"
  },
  "active_badge": {
    English: "Active",
    "বাংলা": "সক্রিয়",
    "हिंदी": "सक्रिय"
  }
};

/**
 * Translate a key or text based on active language with fallback
 */
export function t(key: string, lang: AppLanguage = "English", fallback?: string): string {
  if (DICTIONARY[key] && DICTIONARY[key][lang]) {
    return DICTIONARY[key][lang];
  }
  return fallback ?? key;
}
