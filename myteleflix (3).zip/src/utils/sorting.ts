/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Universal Chronological Sorting Utility
 * Ensures that newly posted content (by createdAt timestamp or recent ID)
 * is always positioned at the very top (index 0) of every category, section,
 * and page, with older posts systematically descending.
 */
export function sortMediaNewestFirst<T extends { createdAt?: string; id?: string }>(items: T[]): T[] {
  if (!items || !Array.isArray(items)) return [];

  return [...items].sort((a, b) => {
    // 1. If both items have valid createdAt timestamps, sort descending
    if (a.createdAt && b.createdAt) {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();
      if (!isNaN(timeA) && !isNaN(timeB) && timeA !== timeB) {
        return timeB - timeA;
      }
    }

    // 2. An item with a real createdAt timestamp is always newer than an item without
    if (a.createdAt && !b.createdAt) return -1;
    if (!a.createdAt && b.createdAt) return 1;

    // 3. Fallback: Parse numeric timestamp from generated IDs (e.g. mv-1725..., vd-1725...)
    const extractTimestamp = (id?: string): number => {
      if (!id) return 0;
      const match = id.match(/\d{10,}/);
      return match ? parseInt(match[0], 10) : 0;
    };

    const tsA = extractTimestamp(a.id);
    const tsB = extractTimestamp(b.id);

    if (tsA > 0 && tsB > 0 && tsA !== tsB) {
      return tsB - tsA;
    }
    if (tsA > 0 && tsB === 0) return -1;
    if (tsA === 0 && tsB > 0) return 1;

    return 0;
  });
}
