/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Global in-memory set of warm and decoded image URLs
const memoryImageCache = new Set<string>();

// Initialize from sessionStorage to prevent image flashing across tab switches
if (typeof window !== "undefined") {
  try {
    const raw = sessionStorage.getItem("myteleflix_img_cache");
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        list.forEach((u) => {
          if (typeof u === "string") memoryImageCache.add(u);
        });
      }
    }
  } catch {
    // Ignore storage quota or disabled storage
  }
}

let persistTimeout: any = null;
function persistImageCache() {
  if (typeof window === "undefined") return;
  if (persistTimeout) clearTimeout(persistTimeout);
  persistTimeout = setTimeout(() => {
    try {
      // Keep most recent 500 image URLs
      const array = Array.from(memoryImageCache).slice(-500);
      sessionStorage.setItem("myteleflix_img_cache", JSON.stringify(array));
    } catch {
      // Ignore
    }
  }, 1000);
}

/**
 * Checks if an image URL is already loaded and cached in memory
 */
export function isImageCached(url?: string): boolean {
  if (!url) return false;
  return memoryImageCache.has(url);
}

/**
 * Marks an image URL as fully cached and decoded
 */
export function markImageCached(url?: string): void {
  if (!url) return;
  memoryImageCache.add(url);
  persistImageCache();
}

/**
 * Silently pre-fetches and decodes an array of image URLs in the background
 */
export function prefetchImages(urls: (string | undefined | null)[]): void {
  if (typeof window === "undefined") return;

  const validUrls = urls.filter((u): u is string => typeof u === "string" && u.trim().length > 0 && !memoryImageCache.has(u));
  if (validUrls.length === 0) return;

  // Process in small micro-batches to avoid blocking the main thread
  const processBatch = (batch: string[]) => {
    batch.forEach((url) => {
      const img = new Image();
      img.decoding = "async";
      img.referrerPolicy = "no-referrer";
      img.onload = () => {
        if ("decode" in img) {
          img.decode().then(() => markImageCached(url)).catch(() => markImageCached(url));
        } else {
          markImageCached(url);
        }
      };
      img.onerror = () => {
        // Still mark to avoid retrying continuously
        memoryImageCache.add(url);
      };
      img.src = url;
    });
  };

  // Chunk into batches of 8
  const chunkSize = 8;
  for (let i = 0; i < validUrls.length; i += chunkSize) {
    const chunk = validUrls.slice(i, i + chunkSize);
    // Stagger slightly with requestIdleCallback or setTimeout
    if (typeof window.requestIdleCallback === "function") {
      window.requestIdleCallback(() => processBatch(chunk));
    } else {
      setTimeout(() => processBatch(chunk), i * 15);
    }
  }
}
