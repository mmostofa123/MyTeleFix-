/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User } from "../types";

export const LAST_ACTIVE_STORAGE_KEY = "myteleflix_last_active_ts";
export const INACTIVITY_RESET_EVENT = "myteleflix_inactivity_reset";
export const SEVENTY_TWO_HOURS_MS = 72 * 60 * 60 * 1000; // 72 hours in milliseconds

/**
 * Returns the recorded last active timestamp from localStorage or user profile.
 */
export function getLastActiveTimestamp(user?: User | null): number {
  try {
    const localVal = localStorage.getItem(LAST_ACTIVE_STORAGE_KEY);
    if (localVal) {
      const parsed = parseInt(localVal, 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  } catch {}

  if (user?.lastActiveTimestamp && user.lastActiveTimestamp > 0) {
    return user.lastActiveTimestamp;
  }

  if (user?.last_active_at) {
    const parsedDate = new Date(user.last_active_at).getTime();
    if (!isNaN(parsedDate) && parsedDate > 0) return parsedDate;
  }

  return Date.now();
}

/**
 * Tracks user activity whenever a user opens the app, watches content, or completes a task.
 * Updates local storage timestamp and synchronizes with user profile.
 */
export async function recordUserActivity(
  user?: User | null,
  updateUserProfile?: (updates: Partial<User>) => Promise<void> | void
): Promise<number> {
  const now = Date.now();
  try {
    localStorage.setItem(LAST_ACTIVE_STORAGE_KEY, now.toString());
  } catch (e) {
    console.warn("Could not save last active timestamp in localStorage", e);
  }

  if (user && updateUserProfile) {
    const previous = user.lastActiveTimestamp || 0;
    // Debounce updates to the remote profile if within the last 5 minutes to minimize network overhead
    if (now - previous > 5 * 60 * 1000) {
      try {
        await updateUserProfile({
          lastActiveTimestamp: now,
          last_active_at: new Date(now).toISOString(),
        });
      } catch (err) {
        console.warn("Failed to sync activity timestamp with remote profile", err);
      }
    }
  }

  return now;
}

/**
 * Checks whether the user has been inactive for more than 72 hours.
 */
export function check72HourInactivity(user?: User | null): {
  isInactiveOver72Hours: boolean;
  inactiveHours: number;
  lastActiveTime: number;
} {
  const now = Date.now();
  const lastActive = getLastActiveTimestamp(user);
  const diffMs = now - lastActive;
  const inactiveHours = Math.floor(diffMs / (1000 * 60 * 60));

  return {
    isInactiveOver72Hours: diffMs >= SEVENTY_TWO_HOURS_MS,
    inactiveHours,
    lastActiveTime: lastActive,
  };
}

/**
 * 72-Hour Inactivity Rule:
 * If currentTime - lastActiveTimestamp > 72 hours, automatically reset user's
 * verification progress counters (Active Days, Completed Tasks, Quiz status) back to 0
 * while keeping the account and wallet intact for a fresh restart.
 */
export async function enforce72HourInactivityRule(
  user: User | null,
  updateUserProfile: (updates: Partial<User>) => Promise<void> | void
): Promise<boolean> {
  if (!user || user.role === 'guest') return false;

  const { isInactiveOver72Hours, inactiveHours } = check72HourInactivity(user);

  if (!isInactiveOver72Hours) {
    return false;
  }

  console.log(
    `[ActivityTracker] User ${user.id} inactive for ${inactiveHours} hours (> 72h). Resetting verification progress.`
  );

  const now = Date.now();

  const resetUpdates: Partial<User> = {
    activeDaysCount: 0,
    activeDaysList: [],
    downloadsCount: 0,
    isQuizPassed: false,
    isHumanVerified: false,
    lastActiveTimestamp: now,
    last_active_at: new Date(now).toISOString(),
    taskStats: {
      missionsCompleted: 0,
      videosWatched: 0,
      moviesWatched: 0,
      totalPointsEarned: user.taskStats?.totalPointsEarned || 0,
    },
  };

  try {
    localStorage.setItem(LAST_ACTIVE_STORAGE_KEY, now.toString());
  } catch {}

  try {
    await updateUserProfile(resetUpdates);

    // Dispatch event so UI can display a notice or update live counters
    if (typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent(INACTIVITY_RESET_EVENT, {
          detail: {
            inactiveHours,
            resetAt: now,
            message: "৭২ ঘণ্টার বেশি নিষ্ক্রিয়তার কারণে ভেরিফিকেশন প্রগ্রেস রিসেট করা হয়েছে।",
          },
        })
      );
    }

    return true;
  } catch (err) {
    console.error("[ActivityTracker] Failed to apply 72-hour inactivity reset:", err);
    return false;
  }
}
