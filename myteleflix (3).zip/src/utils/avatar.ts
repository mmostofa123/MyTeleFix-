/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Realistic Human Portrait Engine (100+ Boys / 100+ Girls Photographic Avatars)
 * Zero Robots / Zero Machines - Authentic, high-resolution human portrait photography.
 */

// 100 Authentic High-Resolution Male (Boy) Portraits from Cloudflare-accelerated CDN
export const BOYS_AVATARS_100: string[] = Array.from({ length: 100 }, (_, i) => 
  `https://randomuser.me/api/portraits/men/${i}.jpg`
);

// 100 Authentic High-Resolution Female (Girl) Portraits from Cloudflare-accelerated CDN
export const GIRLS_AVATARS_100: string[] = Array.from({ length: 100 }, (_, i) => 
  `https://randomuser.me/api/portraits/women/${i}.jpg`
);

/**
 * Computes a deterministic integer seed (0 to 9999) from any user UID, ID, email, or number.
 */
export function computeAvatarSeed(identifier?: string | number | null): number {
  if (identifier === null || identifier === undefined || identifier === "") {
    return 1;
  }
  if (typeof identifier === "number") {
    return Math.abs(identifier) % 10000;
  }

  // If the identifier is a numeric string (e.g., Telegram ID or numeric UID)
  const numericOnly = identifier.replace(/\D/g, "");
  if (numericOnly.length > 0 && numericOnly.length < 16) {
    const parsed = parseInt(numericOnly, 10);
    if (!isNaN(parsed) && parsed >= 0) {
      return parsed % 10000;
    }
  }

  // Consistent 32-bit polynomial hash for alphanumeric strings (UUIDs, Emails, Google IDs)
  let hash = 0;
  for (let i = 0; i < identifier.length; i++) {
    hash = (hash * 31 + identifier.charCodeAt(i)) & 0xffffffff;
  }
  return Math.abs(hash) % 10000;
}

/**
 * Returns an authentic human photographic portrait based on gender and seed/user identifier.
 * Completely eliminates robot/machine graphics and provides 100+ distinct boy and girl portraits.
 */
export function getHumanAvatar(gender?: string | null, identifier?: string | number | null): string {
  const isFemale = (gender || "").toLowerCase().trim() === "female";
  const seedNum = computeAvatarSeed(identifier);
  const index = seedNum % 100;
  
  return isFemale ? GIRLS_AVATARS_100[index] : BOYS_AVATARS_100[index];
}

/**
 * Backward-compatible alias for existing code:
 * Returns realistic human avatar (NOT robot/machine).
 */
export function getDiceBearAvatar(gender?: string | null, identifier?: string | number | null): string {
  return getHumanAvatar(gender, identifier);
}

/**
 * Returns a randomized realistic human portrait for boys or girls.
 */
export function getRandomHumanAvatar(gender?: string | null): string {
  const isFemale = (gender || "").toLowerCase().trim() === "female";
  const randomIndex = Math.floor(Math.random() * 100);
  return isFemale ? GIRLS_AVATARS_100[randomIndex] : BOYS_AVATARS_100[randomIndex];
}

/**
 * Checks if a photo URL is a known external placeholder, legacy robot avatar, or broken image.
 */
export function isUnsplashOrBrokenPhoto(url?: string | null): boolean {
  if (!url || typeof url !== "string") return true;
  const lower = url.toLowerCase();
  
  // Legacy robot or cartoon SVGs that should be replaced with real human portraits
  if (lower.includes("bottts") || lower.includes("api.dicebear.com/7.x/bottts")) return true;
  if (lower.includes("images.unsplash.com")) return true;
  if (lower.includes("placeholder")) return true;
  if (lower.trim() === "") return true;

  return false;
}

/**
 * Resolves user avatar with Google Photo priority and fallback to deterministic human portrait.
 */
export function resolveUserAvatar(
  user?: {
    photoURL?: string | null;
    photoUrl?: string | null;
    gender?: string | null;
    id?: string | number | null;
    uid?: string | number | null;
    email?: string | null;
  } | null,
  overrideGender?: string | null
): {
  primaryPhoto: string | null;
  diceBearAvatar: string;
  humanAvatar: string;
} {
  const gender = overrideGender || user?.gender || "male";
  const identifier = user?.uid ?? user?.id ?? user?.email ?? "teleflix_user";
  const humanAvatar = getHumanAvatar(gender, identifier);

  const rawPhoto = user?.photoURL || user?.photoUrl;
  const hasValidGooglePhoto = Boolean(rawPhoto && !isUnsplashOrBrokenPhoto(rawPhoto));

  return {
    primaryPhoto: hasValidGooglePhoto ? (rawPhoto as string) : null,
    diceBearAvatar: humanAvatar,
    humanAvatar,
  };
}
