/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { CommunitySettings } from "../types";
import { 
  DEFAULT_COMMUNITY_SETTINGS, 
  subscribeToCommunitySettings, 
  saveCommunitySettingsToFirestore 
} from "../services/firebase";

export function useCommunitySettings() {
  const [settings, setSettings] = useState<CommunitySettings>(DEFAULT_COMMUNITY_SETTINGS);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const unsubscribe = subscribeToCommunitySettings((data) => {
        setSettings(data);
        setLoading(false);
      });
      return () => unsubscribe();
    } catch (err: any) {
      console.warn("Error subscribing to community settings:", err);
      setLoading(false);
    }
  }, []);

  const updateSettings = async (
    newSettings: Partial<CommunitySettings>, 
    updatedBy?: string
  ) => {
    try {
      setError(null);
      // Optimistic local update
      setSettings(prev => ({ ...prev, ...newSettings }));
      await saveCommunitySettingsToFirestore(newSettings, updatedBy);
      return true;
    } catch (err: any) {
      console.error("Failed to save community settings:", err);
      setError(err?.message || "Failed to save settings");
      throw err;
    }
  };

  return {
    settings,
    loading,
    error,
    updateSettings,
  };
}

export default useCommunitySettings;
