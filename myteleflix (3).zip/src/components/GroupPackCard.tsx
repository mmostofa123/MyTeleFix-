/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from "react";
import { Download, Layers } from "lucide-react";
import { SeriesGroupPack } from "../types";
import { isImageCached, markImageCached } from "../utils/imageCache";
import { useLanguage } from "../context/LanguageContext";

export interface GroupPackCardProps {
  pack: SeriesGroupPack;
  onClick: () => void;
  layout?: "grid" | "carousel" | "compact";
  className?: string;
  isDrama?: boolean;
}

export const GroupPackCard: React.FC<GroupPackCardProps> = ({
  pack,
  onClick,
  layout = "grid",
  className = "",
  isDrama = false,
}) => {
  const { t } = useLanguage();
  const master = pack.masterItem;
  const isAlreadyCached = isImageCached(master.thumbnailUrl);
  const [imageLoaded, setImageLoaded] = useState<boolean>(isAlreadyCached);

  const handleImageLoad = useCallback(() => {
    markImageCached(master.thumbnailUrl);
    setImageLoaded(true);
  }, [master.thumbnailUrl]);

  const sizingClasses =
    layout === "grid"
      ? "w-full min-w-0 max-w-full"
      : "w-[108px] min-w-[108px] max-w-[108px] sm:w-[132px] sm:min-w-[132px] sm:max-w-[132px] flex-shrink-0 snap-start";

  const totalSeasons = pack.seasons && pack.seasons.length > 0 ? pack.seasons.length : 1;
  const badgeText = totalSeasons > 1 
    ? `${totalSeasons} SEASONS • ${pack.totalEpisodesCount} EPS`
    : `${pack.totalEpisodesCount} EPISODES`;

  return (
    <div
      id={`group-pack-card-${pack.groupTitle.replace(/\s+/g, '-').toLowerCase()}`}
      onClick={onClick}
      className={`group flex flex-col cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 rounded-2xl select-none ${sizingClasses} ${className}`}
    >
      {/* 2:3 Poster Frame with Layered Shadow Effect */}
      <div className="relative aspect-[2/3] w-full rounded-xl overflow-hidden shadow-lg bg-[#0B0F17] shrink-0 border border-slate-800/80 group-hover:border-sky-500/80 transition-all">
        <img
          src={master.thumbnailUrl}
          alt={pack.groupTitle}
          loading={isAlreadyCached ? "eager" : "lazy"}
          decoding="async"
          onLoad={handleImageLoad}
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
          }}
          className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-150 ${
            imageLoaded || isAlreadyCached ? "opacity-100" : "opacity-90"
          }`}
          referrerPolicy="no-referrer"
        />

        {/* Master Group Pack Top Floating Badge */}
        <div className="absolute top-1.5 left-1.5 z-10 flex items-center gap-1 bg-black/85 backdrop-blur-xs text-[8px] sm:text-[8.5px] font-mono font-extrabold text-sky-400 border border-sky-400/40 px-1.5 py-0.5 rounded shadow-md uppercase">
          <Layers size={10} className="shrink-0" />
          <span>{badgeText}</span>
        </div>

        {/* Multi-layer Stack Indicator on Bottom Corner */}
        <div className="absolute bottom-1.5 right-1.5 z-10 px-1.5 py-0.5 rounded bg-sky-950/90 border border-sky-800/80 text-[8px] font-mono font-bold text-sky-300 shadow">
          PACK
        </div>
      </div>

      {/* Series Title */}
      <h4
        title={pack.groupTitle}
        className="mt-1.5 text-[11px] sm:text-xs font-bold text-slate-200 group-hover:text-sky-300 transition-colors truncate px-0.5 w-full text-left leading-tight"
      >
        {pack.groupTitle}
      </h4>

      {/* Explore Episodes Action Button */}
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onClick();
        }}
        className={`mt-2 py-1.5 px-2 rounded-lg w-full text-center flex items-center justify-center gap-1.5 font-black text-xs uppercase tracking-wider shadow-md transition-all duration-75 ease-out shrink-0 cursor-pointer select-none active:scale-95 border ${
          isDrama
            ? "bg-gradient-to-r from-emerald-400 to-teal-600 hover:from-emerald-300 hover:to-teal-500 text-black border-emerald-400/40 shadow-emerald-950/40"
            : "bg-gradient-to-r from-sky-400 to-blue-600 hover:from-sky-300 hover:to-blue-500 text-black border-sky-400/40 shadow-sky-950/40"
        }`}
      >
        <Layers size={12} strokeWidth={2.4} className="shrink-0 text-black" />
        <span className="whitespace-nowrap font-black">{t('action.all_episodes', 'ALL EPISODES')}</span>
      </button>
    </div>
  );
};

export default GroupPackCard;
