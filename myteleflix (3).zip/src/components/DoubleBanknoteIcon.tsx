import React from "react";

interface DoubleBanknoteIconProps {
  size?: number | string;
  className?: string;
  isActive?: boolean;
}

export default function DoubleBanknoteIcon({
  size = 24,
  className = "",
  isActive = false,
}: DoubleBanknoteIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 26"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`overflow-visible select-none pointer-events-none ${className}`}
      aria-hidden="true"
    >
      <defs>
        {/* Front Note Gradient */}
        <linearGradient id="frontBillGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4ADE80" />
          <stop offset="100%" stopColor="#22C55E" />
        </linearGradient>

        {/* Back Note Gradient */}
        <linearGradient id="backBillGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#22C55E" />
          <stop offset="100%" stopColor="#15803D" />
        </linearGradient>

        {/* Center Medallion Gradient */}
        <linearGradient id="centerCircleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#15803D" />
          <stop offset="100%" stopColor="#14532D" />
        </linearGradient>
      </defs>

      {/* ========================================================= */}
      {/* 1. BACK BANKNOTE (Layered at ~ -20deg tilt for 3D stack) */}
      {/* ========================================================= */}
      <g transform="rotate(-18 16 13) translate(0, -1)">
        {/* Back note body */}
        <rect
          x="3"
          y="4.5"
          width="26"
          height="14.5"
          rx="2"
          fill="url(#backBillGrad)"
          stroke="#166534"
          strokeWidth="1.2"
        />

        {/* Back note inner margin line */}
        <rect
          x="4.8"
          y="6.2"
          width="22.4"
          height="11.1"
          rx="1.2"
          fill="none"
          stroke="#14532D"
          strokeWidth="0.8"
          strokeOpacity="0.8"
        />

        {/* Back note center circle indicator */}
        <circle cx="16" cy="11.75" r="3" fill="#14532D" fillOpacity="0.75" />
      </g>

      {/* ========================================================= */}
      {/* 2. FRONT BANKNOTE (Horizontal crisp currency bill)       */}
      {/* ========================================================= */}
      <g transform="translate(0, 1)">
        {/* Drop shadow underneath the front note */}
        <rect
          x="2.5"
          y="6.5"
          width="27"
          height="15.5"
          rx="2.2"
          fill="#052E16"
          fillOpacity="0.4"
        />

        {/* Front note main bill body */}
        <rect
          x="2"
          y="5.5"
          width="28"
          height="16"
          rx="2"
          fill="url(#frontBillGrad)"
          stroke="#166534"
          strokeWidth="1.2"
        />

        {/* Inner margin boundary with classical corner accents */}
        <rect
          x="4.2"
          y="7.4"
          width="23.6"
          height="12.2"
          rx="1.2"
          fill="none"
          stroke="#15803D"
          strokeWidth="1"
        />

        {/* Corner decorative notches */}
        <path
          d="M 4.2 9.5 A 2 2 0 0 1 6.3 7.4"
          fill="none"
          stroke="#166534"
          strokeWidth="1"
        />
        <path
          d="M 25.7 7.4 A 2 2 0 0 1 27.8 9.5"
          fill="none"
          stroke="#166534"
          strokeWidth="1"
        />
        <path
          d="M 4.2 17.5 A 2 2 0 0 0 6.3 19.6"
          fill="none"
          stroke="#166534"
          strokeWidth="1"
        />
        <path
          d="M 25.7 19.6 A 2 2 0 0 0 27.8 17.5"
          fill="none"
          stroke="#166534"
          strokeWidth="1"
        />

        {/* Center Medallion Circle */}
        <circle
          cx="16"
          cy="13.5"
          r="4.4"
          fill="url(#centerCircleGrad)"
          stroke="#166534"
          strokeWidth="0.8"
        />

        {/* Currency Mark: Bengali Taka '৳' Symbol (Razor-Sharp Vector Path) */}
        <path
          d="M 14.8 11.2 C 14.8 10.7 15.3 10.3 16 10.3 C 16.7 10.3 17.1 10.7 17.1 11.3 C 17.1 12 16.6 12.5 15.9 12.8 L 15.9 14.8 C 15.9 15.6 16.4 16.1 17.2 16.1 C 17.8 16.1 18.3 15.7 18.3 15.1 C 18.3 14.6 17.9 14.2 17.4 14.2 C 17.1 14.2 16.9 14.3 16.8 14.5 M 14.5 13.1 L 17.4 13.1"
          fill="none"
          stroke="#86EFAC"
          strokeWidth="1.1"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Left Side Medallion Dot */}
        <circle cx="8" cy="13.5" r="1.6" fill="#15803D" stroke="#166534" strokeWidth="0.6" />
        <circle cx="8" cy="13.5" r="0.8" fill="#86EFAC" fillOpacity="0.4" />

        {/* Right Side Medallion Dot */}
        <circle cx="24" cy="13.5" r="1.6" fill="#15803D" stroke="#166534" strokeWidth="0.6" />
        <circle cx="24" cy="13.5" r="0.8" fill="#86EFAC" fillOpacity="0.4" />
      </g>
    </svg>
  );
}
