/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useRef } from "react";
import { Download } from "lucide-react";
import { Video } from "../types";
import PosterDownloadOverlay from "./PosterDownloadOverlay";
import { useLanguage } from "../context/LanguageContext";

export interface VideoCardProps {
  video: Video;
  onClick?: () => void;
  showGetLink?: boolean;
  className?: string;
}

export const VideoCard: React.FC<VideoCardProps> = ({
  video,
  onClick,
  showGetLink = true,
  className = "",
}) => {
  const { t } = useLanguage();
  const [isOpening, setIsOpening] = useState(false);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleCardClick = useCallback((e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      e.stopPropagation();
    }
    if (isOpening) return;
    setIsOpening(true);

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    clickTimerRef.current = setTimeout(() => {
      onClick?.();
      setIsOpening(false);
    }, 180);
  }, [onClick, isOpening]);

  const handleGetLinkClick = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    handleCardClick(e);
  }, [handleCardClick]);

  React.useEffect(() => {
    return () => {
      if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    };
  }, []);

  return (
    <div
      id={`video-card-${video.id}`}
      onClick={handleCardClick}
      className={`group bg-[#1A1A1E] rounded-2xl p-3 border transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 flex flex-col justify-between gap-2.5 cursor-pointer select-none ${
        isOpening ? "border-emerald-500/80 shadow-lg shadow-emerald-950/40" : "border-[#2A2A2E] hover:border-[#444]"
      } ${className}`}
    >
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-black border border-[#2A2A2E] shrink-0">
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          loading="lazy"
          decoding="async"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=600&q=80";
          }}
          className={`w-full h-full object-cover transition-all duration-200 ${
            isOpening ? "filter blur-xs brightness-75 scale-105" : ""
          }`}
          referrerPolicy="no-referrer"
        />
        {isOpening && <PosterDownloadOverlay size="md" />}
      </div>

      <div className="space-y-1">
        <h4 className="text-xs font-bold text-white line-clamp-1 leading-snug">
          {video.title}
        </h4>
        {video.description && (
          <p className="text-[10px] text-slate-400 line-clamp-1 font-normal">
            {video.description}
          </p>
        )}
      </div>

      {showGetLink && (
        <div className="flex justify-center pt-0.5">
          <button
            type="button"
            onClick={handleGetLinkClick}
            onTouchEnd={(e) => e.stopPropagation()}
            className={`w-full max-w-[200px] py-1.5 px-2.5 rounded-lg font-black text-xs tracking-wide border shadow-md transition-all duration-75 ease-out flex items-center justify-center gap-1.5 shrink-0 select-none cursor-pointer uppercase active:scale-95 active:brightness-125 ${
              isOpening
                ? "bg-purple-800 border-purple-400 text-purple-200 ring-1.5 ring-purple-400"
                : "bg-[#7C3AED] hover:bg-[#6D28D9] active:bg-[#5B21B6] text-white border-purple-400/90 shadow-lg shadow-purple-950/60 active:ring-2 active:ring-purple-400/80"
            }`}
          >
            {isOpening ? (
              <>
                <div className="w-3 h-3 rounded-full border-[1.5px] border-current border-t-transparent animate-spin shrink-0" />
                <span className="text-purple-200">{t('action.opening', 'OPENING...')}</span>
              </>
            ) : (
              <>
                <Download size={13} strokeWidth={2.4} className="shrink-0 text-white" />
                <span>{t('action.download', 'DOWNLOAD')}</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};

export default VideoCard;
