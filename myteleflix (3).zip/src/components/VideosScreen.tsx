/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import VideoModule from "./VideoModule";
import { Video, Mission, User, AppLanguage } from "../types";

export interface VideosScreenProps {
  videos: Video[];
  completedMissionIds?: string[];
  userIsPremium?: boolean;
  onViewedVideo?: (id: string, isVideo: boolean) => Promise<void>;
  missions?: Mission[];
  user?: User;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  showSearchBar?: boolean;
  onBackToAll?: () => void;
  currentLanguage?: AppLanguage;
}

export const VideosScreen: React.FC<VideosScreenProps> = (props) => {
  return (
    <div id="videos-screen" className="w-full">
      <VideoModule
        videos={props.videos}
        completedMissionIds={props.completedMissionIds || []}
        userIsPremium={props.userIsPremium}
        onViewedVideo={props.onViewedVideo || (async () => {})}
        missions={props.missions || []}
        user={props.user}
        guideVideoUrl={props.guideVideoUrl}
        guideVideoLogoUrl={props.guideVideoLogoUrl}
        showSearchBar={props.showSearchBar ?? false}
        onBackToAll={props.onBackToAll}
        currentLanguage={props.currentLanguage}
      />
    </div>
  );
};

export default VideosScreen;
