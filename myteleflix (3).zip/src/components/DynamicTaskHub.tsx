/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  CheckCircle2, Clock, Flame, PlayCircle, 
  ExternalLink, Loader2, Sparkles, AlertCircle, 
  Check, ArrowRight, ShieldCheck, Zap, RefreshCw,
  Gift, Film, Trophy
} from "lucide-react";
import { User } from "../types";
import TokenIcon from "./TokenIcon";

export interface TaskUserView {
  task_id: string;
  title: string;
  description: string;
  task_type: 'EARNING' | 'SURVEY' | 'VIDEO';
  target_url?: string;
  reward_points: number;
  daily_limit_per_user: number;
  status: 'ACTIVE' | 'PAUSED' | 'EXPIRED';
  completed_count: number;
  completions_today: number;
  is_completed_today: boolean;
  can_complete: boolean;
  remaining_today: number;
}

export interface DailyActivityProgress {
  date: string;
  tasks_completed: number;
  tasks_required: number;
  content_completed: number;
  content_required: number;
  active_day_earned: boolean;
  tasks_remaining: number;
  content_remaining: number;
}

interface DynamicTaskHubProps {
  userId: string;
  user?: User;
  onUpdateUser?: (u: User) => void;
  onTriggerAuth?: (action: 'earn') => void;
}

export default function DynamicTaskHub({
  userId,
  user,
  onUpdateUser,
  onTriggerAuth
}: DynamicTaskHubProps) {
  const [tasks, setTasks] = useState<TaskUserView[]>([]);
  const [dailyProgress, setDailyProgress] = useState<DailyActivityProgress | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'EARNING' | 'SURVEY' | 'VIDEO'>('ALL');
  
  // Active execution state
  const [executingTaskId, setExecutingTaskId] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number>(0);
  const [feedbackToast, setFeedbackToast] = useState<{
    message: string;
    type: 'success' | 'warning' | 'error';
    points?: number;
  } | null>(null);

  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);

  const effectiveUser: User = user || {
    id: userId,
    telegramId: userId.replace("tg-", ""),
    username: "user",
    fullName: "Member",
    email: "",
    points: 0,
    role: "user",
    isPremium: false,
    createdAt: new Date().toISOString(),
    last_active_at: new Date().toISOString()
  };

  const fetchTasksAndProgress = async () => {
    setIsLoading(true);
    try {
      const res = await fetch(`/api/tasks?userId=${encodeURIComponent(effectiveUser.id)}`);
      const data = await res.json();
      if (data.success) {
        setTasks(data.tasks || []);
        if (data.daily_progress) {
          setDailyProgress(data.daily_progress);
        }
      }
    } catch (err) {
      console.warn("[TCE] Failed to fetch dynamic tasks:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTasksAndProgress();
    return () => {
      if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    };
  }, [effectiveUser.id]);

  const showToast = (message: string, type: 'success' | 'warning' | 'error', points?: number) => {
    setFeedbackToast({ message, type, points });
    setTimeout(() => setFeedbackToast(null), 4500);
  };

  const handleStartTask = async (task: TaskUserView) => {
    if (effectiveUser.role === 'guest') {
      onTriggerAuth?.('earn');
      return;
    }

    if (!task.can_complete) {
      if (task.is_completed_today) {
        showToast(`You have already completed this task today (${task.completions_today}/${task.daily_limit_per_user}).`, 'warning');
      } else {
        showToast(`This task is currently ${task.status.toLowerCase()}.`, 'warning');
      }
      return;
    }

    setExecutingTaskId(task.task_id);

    // Generate unique Anti-Spam Idempotency Key
    const idempotencyKey = `idemp_${task.task_id}_${effectiveUser.id}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

    // Open target link if provided
    if (task.target_url) {
      try {
        const tg = (window as any).Telegram?.WebApp;
        if (tg && typeof tg.openLink === 'function') {
          tg.openLink(task.target_url);
        } else {
          window.open(task.target_url, "_blank", "noopener,noreferrer");
        }
      } catch (e) {
        window.open(task.target_url, "_blank", "noopener,noreferrer");
      }
    }

    // Required simulation / verification delay (5s for Earning, 6s for Video, 4s for Survey)
    const verificationSeconds = task.task_type === 'VIDEO' ? 6 : task.task_type === 'SURVEY' ? 4 : 5;
    setCountdown(verificationSeconds);

    let remaining = verificationSeconds;
    if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);

    countdownTimerRef.current = setInterval(() => {
      remaining -= 1;
      setCountdown(remaining);
      if (remaining <= 0) {
        if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
        submitTaskCompletion(task, idempotencyKey);
      }
    }, 1000);
  };

  const submitTaskCompletion = async (task: TaskUserView, idempotencyKey: string) => {
    try {
      const res = await fetch("/api/tasks/complete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          taskId: task.task_id,
          userId: effectiveUser.id,
          idempotencyKey,
          metadata: {
            source: "tce_hub_web",
            client_timestamp: Date.now()
          }
        })
      });

      const data = await res.json();

      if (data.success) {
        showToast(
          data.message || `+${data.points_awarded || task.reward_points} Points credited!`,
          'success',
          data.points_awarded || task.reward_points
        );

        // Update local user wallet if provided
        if (onUpdateUser && data.new_balance !== undefined) {
          onUpdateUser({
            ...effectiveUser,
            points: data.new_balance
          });
        }

        // Refresh dynamic task lists and daily counts
        fetchTasksAndProgress();
      } else {
        showToast(data.message || "Failed to complete task.", data.code === 'DUPLICATE' ? 'warning' : 'error');
      }
    } catch (err: any) {
      showToast("Network error verifying task. Please retry.", "error");
    } finally {
      setExecutingTaskId(null);
      setCountdown(0);
    }
  };

  const filteredTasks = tasks.filter(t => {
    if (activeFilter === 'ALL') return true;
    return t.task_type === activeFilter;
  });

  return (
    <div className="space-y-4">
      {/* Dynamic Floating Feedback Banner */}
      {feedbackToast && (
        <div className={`p-3 rounded-2xl flex items-center justify-between shadow-2xl border animate-in fade-in slide-in-from-top-2 duration-200 ${
          feedbackToast.type === 'success' 
            ? 'bg-emerald-950/95 border-emerald-500/60 text-emerald-100'
            : feedbackToast.type === 'warning'
            ? 'bg-amber-950/95 border-amber-500/60 text-amber-100'
            : 'bg-rose-950/95 border-rose-500/60 text-rose-100'
        }`}>
          <div className="flex items-center gap-2.5 min-w-0">
            {feedbackToast.type === 'success' ? (
              <div className="w-7 h-7 rounded-xl bg-emerald-600/30 border border-emerald-500 flex items-center justify-center shrink-0">
                <Check size={14} className="text-emerald-400" />
              </div>
            ) : (
              <div className="w-7 h-7 rounded-xl bg-amber-600/30 border border-amber-500 flex items-center justify-center shrink-0">
                <AlertCircle size={14} className="text-amber-400" />
              </div>
            )}
            <div>
              <p className="text-xs font-bold font-sans truncate">{feedbackToast.message}</p>
              {feedbackToast.points && (
                <p className="text-[10px] text-emerald-300 font-mono font-bold">
                  + {feedbackToast.points} Cinematic Tokens credited to your balance
                </p>
              )}
            </div>
          </div>
          <button
            onClick={() => setFeedbackToast(null)}
            className="p-1 text-slate-400 hover:text-white shrink-0 ml-2"
          >
            &times;
          </button>
        </div>
      )}

      {/* Phase 2 Rule: Daily Active Day Progress Tracking Card */}
      {dailyProgress && (
        <div className="rounded-2xl p-4 bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/40 border border-indigo-500/30 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
                <Flame size={14} />
              </div>
              <div>
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  Phase 2: Daily Active Goal
                  {dailyProgress.active_day_earned && (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded-full font-mono font-bold">
                      ACTIVE DAY EARNED 🎉
                    </span>
                  )}
                </span>
                <p className="text-[10px] text-slate-400 font-mono">
                  Target: 10 Tasks + 5 Content views/downloads for +1 Active Day streak
                </p>
              </div>
            </div>

            <button
              onClick={fetchTasksAndProgress}
              className="p-1 text-slate-400 hover:text-white transition"
              title="Refresh Progress"
            >
              <RefreshCw size={12} className={isLoading ? "animate-spin text-amber-400" : ""} />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5 pt-2">
            {/* 10 Tasks Goal */}
            <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                <span className="text-slate-400 flex items-center gap-1">
                  <CheckCircle2 size={12} className="text-amber-400" />
                  Tasks Completed
                </span>
                <span className="font-bold text-amber-400">
                  {dailyProgress.tasks_completed} / {dailyProgress.tasks_required}
                </span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-amber-500 to-amber-400 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (dailyProgress.tasks_completed / dailyProgress.tasks_required) * 100)}%` }}
                />
              </div>
            </div>

            {/* 5 Content Goal */}
            <div className="bg-slate-950/70 rounded-xl p-2.5 border border-slate-800">
              <div className="flex items-center justify-between text-[11px] font-mono mb-1">
                <span className="text-slate-400 flex items-center gap-1">
                  <Film size={12} className="text-cyan-400" />
                  Content Actions
                </span>
                <span className="font-bold text-cyan-400">
                  {dailyProgress.content_completed} / {dailyProgress.content_required}
                </span>
              </div>
              <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-cyan-500 to-indigo-400 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, (dailyProgress.content_completed / dailyProgress.content_required) * 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Task Filters */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto no-scrollbar pb-1">
        <div className="flex items-center gap-1.5">
          {(['ALL', 'EARNING', 'SURVEY', 'VIDEO'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition flex items-center gap-1.5 shrink-0 ${
                activeFilter === cat
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {cat === 'ALL' && <Zap size={12} />}
              {cat === 'EARNING' && <Gift size={12} />}
              {cat === 'SURVEY' && <ShieldCheck size={12} />}
              {cat === 'VIDEO' && <PlayCircle size={12} />}
              <span>{cat}</span>
            </button>
          ))}
        </div>

        <span className="text-[11px] font-mono text-slate-500 shrink-0">
          {filteredTasks.length} Available
        </span>
      </div>

      {/* Tasks List */}
      {isLoading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-2 text-slate-500">
          <Loader2 size={24} className="animate-spin text-amber-400" />
          <span className="text-xs font-mono">Syncing server-authoritative tasks...</span>
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="py-8 bg-slate-900/60 border border-slate-800 rounded-2xl text-center space-y-1">
          <p className="text-xs text-slate-300 font-bold">No dynamic tasks available in this category.</p>
          <p className="text-[11px] text-slate-500 font-mono">Check back shortly or try another filter.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredTasks.map((task) => {
            const isExecuting = executingTaskId === task.task_id;

            return (
              <div
                key={task.task_id}
                className={`rounded-2xl p-3.5 sm:p-4 border transition duration-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  task.is_completed_today
                    ? 'bg-slate-950/60 border-slate-800/80 opacity-80'
                    : task.status !== 'ACTIVE'
                    ? 'bg-slate-950/40 border-slate-800/60 opacity-60'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700 shadow-md'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                    task.is_completed_today
                      ? 'bg-emerald-950/80 text-emerald-400 border-emerald-700/60'
                      : task.task_type === 'VIDEO'
                      ? 'bg-rose-950/60 text-rose-400 border-rose-800/50'
                      : task.task_type === 'SURVEY'
                      ? 'bg-indigo-950/60 text-indigo-400 border-indigo-800/50'
                      : 'bg-amber-950/60 text-amber-400 border-amber-800/50'
                  }`}>
                    {task.is_completed_today ? (
                      <Check size={18} />
                    ) : task.task_type === 'VIDEO' ? (
                      <PlayCircle size={18} />
                    ) : task.task_type === 'SURVEY' ? (
                      <ShieldCheck size={18} />
                    ) : (
                      <Sparkles size={18} />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <span className="text-xs font-bold text-white truncate max-w-[240px]">
                        {task.title}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                        +{task.reward_points}
                      </span>
                      {task.status !== 'ACTIVE' && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
                          {task.status}
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-400 line-clamp-1 mb-1">
                      {task.description}
                    </p>

                    <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
                      <span>Daily: {task.completions_today}/{task.daily_limit_per_user}</span>
                      <span>•</span>
                      <span>{task.completed_count || 0} claims</span>
                    </div>
                  </div>
                </div>

                {/* CTA / Execution Controls */}
                <div className="flex items-center justify-end shrink-0 pt-1 sm:pt-0 border-t sm:border-t-0 border-slate-800/60">
                  {task.is_completed_today ? (
                    <button
                      disabled
                      className="px-3.5 py-1.5 bg-slate-800/80 text-emerald-400/90 rounded-xl text-xs font-mono font-bold flex items-center gap-1.5 cursor-not-allowed border border-emerald-900/40"
                    >
                      <CheckCircle2 size={13} />
                      <span>Completed Today</span>
                    </button>
                  ) : task.status !== 'ACTIVE' ? (
                    <button
                      disabled
                      className="px-3 py-1.5 bg-slate-900 text-slate-500 rounded-xl text-xs font-mono font-bold cursor-not-allowed border border-slate-800"
                    >
                      <span>Unavailable ({task.status})</span>
                    </button>
                  ) : isExecuting ? (
                    <button
                      disabled
                      className="px-4 py-1.5 bg-amber-600/90 text-white rounded-xl text-xs font-mono font-bold flex items-center gap-2 animate-pulse border border-amber-400"
                    >
                      <Clock size={13} className="animate-spin" />
                      <span>Verifying ({countdown}s)...</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStartTask(task)}
                      className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-950 transition active:scale-95 cursor-pointer"
                    >
                      <span>{task.task_type === 'VIDEO' ? 'Watch Video' : task.task_type === 'SURVEY' ? 'Start Survey' : 'Complete Task'}</span>
                      <ArrowRight size={13} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
