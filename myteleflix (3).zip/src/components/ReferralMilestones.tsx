/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA: Gamified Vertical Milestone Journey Map (M1 to M8)
 * High-density, mobile-first, dark-organic UI standard (#0A0D12)
 * Zero emojis, pure SVG icons, 5-second top-floating toast notifications.
 */

import React, { useState, useEffect, useMemo } from "react";
import { 
  Award, 
  CheckCircle2, 
  Lock, 
  Sparkles, 
  RefreshCw, 
  X, 
  ShieldCheck, 
  Users,
  Flame,
  Zap,
  Gift,
  Target
} from "lucide-react";
import { User, MilestoneItem, MilestoneStatusData } from "../types";
import TokenIcon from "./TokenIcon";
import { useGlobalConfig } from "../context/GlobalConfigContext";

interface ReferralMilestonesProps {
  user: User;
  onTokenClaimed?: (amount: number) => void;
  qualifiedCount?: number;
  onMilestoneClaimed?: () => void;
}

export default function ReferralMilestones({ 
  user, 
  onTokenClaimed,
  qualifiedCount: externalQualifiedCount,
  onMilestoneClaimed
}: ReferralMilestonesProps) {
  const { activeCampaign } = useGlobalConfig();
  const [data, setData] = useState<MilestoneStatusData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [claimingId, setClaimingId] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  // 5-second auto-dismiss toast helper
  const showToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => {
      setToast((current) => (current?.message === message ? null : current));
    }, 5000);
  };

  const fetchMilestoneStatus = async (showSyncMessage = false) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/milestones/status?userId=${encodeURIComponent(user.id)}`, {
        headers: {
          "x-user-id": user.id
        }
      });
      if (res.ok) {
        const json = await res.json();
        if (json && json.success) {
          setData(json);
          if (showSyncMessage) {
            showToast("Server milestone status successfully synced.", "info");
          }
        }
      }
    } catch (err) {
      console.warn("Failed to fetch referral milestone status:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMilestoneStatus(false);
  }, [user.id]);

  const handleClaim = async (milestone: MilestoneItem) => {
    if (!milestone.is_claimable || claimingId) return;

    setClaimingId(milestone.milestone_id);
    try {
      const res = await fetch("/api/milestones/claim", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": user.id
        },
        body: JSON.stringify({
          userId: user.id,
          milestone_id: milestone.milestone_id,
          campaign_id: milestone.campaign_id
        })
      });

      const result = await res.json();

      if (res.ok && result.success) {
        const rewardAmount = result.claimedAmount || milestone.amount;
        showToast(
          `Milestone ${milestone.milestone_id.toUpperCase()} reward unlocked: +${rewardAmount.toLocaleString()} Tokens credited.`,
          "success"
        );
        if (onTokenClaimed && rewardAmount) {
          onTokenClaimed(rewardAmount);
        }
        if (onMilestoneClaimed) {
          onMilestoneClaimed();
        }
        await fetchMilestoneStatus(false);
      } else {
        const errorMsg = result.message || "Unable to claim milestone. Please try again.";
        showToast(errorMsg, result.code === "ALREADY_CLAIMED" ? "info" : "error");
        await fetchMilestoneStatus(false);
      }
    } catch (err: any) {
      showToast("Network request failed. Please check your connection.", "error");
    } finally {
      setClaimingId(null);
    }
  };

  // Milestone list sorted by threshold
  const milestones = useMemo(() => {
    if (!data?.milestones) return [];
    return [...data.milestones].sort((a, b) => a.threshold - b.threshold);
  }, [data?.milestones]);

  const effectiveQualified = data?.qualifiedCount ?? externalQualifiedCount ?? 0;
  const claimedCount = data?.claimedCount ?? 0;
  const totalMilestones = data?.totalMilestones ?? (milestones.length || 8);
  const totalClaimedPoints = data?.totalClaimedRewardPoints ?? 0;

  return (
    <section 
      id="referral-milestones-journey" 
      aria-label="Gamified Referral Milestone Journey Map"
      className="space-y-4 font-sans text-slate-200"
    >
      {/* 5-SECOND TOP-FLOATING TOAST NOTIFICATION */}
      {toast && (
        <aside
          aria-live="assertive"
          className="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-md shadow-2xl animate-in slide-in-from-top-4 duration-300 pointer-events-auto"
        >
          <div className={`border rounded-2xl px-4 py-3 text-xs font-mono font-bold flex items-center justify-between shadow-2xl backdrop-blur-xl ${
            toast.type === "success" 
              ? "bg-[#0A0D12]/95 border-[#00F5A0]/60 text-[#00F5A0] shadow-[0_0_30px_rgba(0,245,160,0.2)]" 
              : toast.type === "error"
              ? "bg-[#0A0D12]/95 border-[#FF3B30]/60 text-[#FF3B30] shadow-[0_0_30px_rgba(255,59,48,0.2)]"
              : "bg-[#0A0D12]/95 border-[#FFB800]/60 text-[#FFB800] shadow-[0_0_30px_rgba(255,184,0,0.2)]"
          }`}>
            <div className="flex items-center gap-2.5">
              {toast.type === "success" && <CheckCircle2 size={16} className="text-[#00F5A0] shrink-0" />}
              {toast.type === "error" && <Lock size={16} className="text-[#FF3B30] shrink-0" />}
              {toast.type === "info" && <Sparkles size={16} className="text-[#FFB800] shrink-0" />}
              <span>{toast.message}</span>
            </div>
            <button
              onClick={() => setToast(null)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/[0.08] transition cursor-pointer shrink-0 ml-2"
              aria-label="Close notification"
            >
              <X size={14} />
            </button>
          </div>
        </aside>
      )}

      {/* JOURNEY HEADER & METRICS BAR */}
      <div className="bg-[#0A0D12] border border-white/[0.08] rounded-2xl p-4 sm:p-5 shadow-xl backdrop-blur-md space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-3.5">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/[0.03] border border-white/[0.08] text-[10px] font-mono text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FFB800] animate-pulse" />
              <span>Gamified Milestone Progression Path</span>
            </div>
            <h3 className="text-sm sm:text-base font-black text-white font-mono uppercase tracking-wide flex items-center gap-2">
              <span>Referral Milestone Journey</span>
              <span className="text-xs text-[#FFB800] font-normal tracking-normal">(M1 – M8)</span>
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Unlock cumulative milestone rewards as your verified direct network expands.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-sync-milestones"
              onClick={() => fetchMilestoneStatus(true)}
              disabled={loading}
              className="px-3 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] text-slate-300 hover:text-white transition cursor-pointer active:scale-95 flex items-center gap-1.5 text-xs font-mono font-bold"
              title="Sync progression from server"
            >
              <RefreshCw size={12} className={loading ? "animate-spin text-[#FFB800]" : "text-slate-400"} />
              <span>Sync Status</span>
            </button>
          </div>
        </div>

        {/* Active Boost Campaign Banner */}
        {activeCampaign && (
          <div className="p-3 rounded-xl bg-gradient-to-r from-[#FFB800]/10 via-[#00F5A0]/10 to-transparent border border-[#FFB800]/30 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 rounded-lg bg-[#FFB800]/20 text-[#FFB800] border border-[#FFB800]/30">
                <Flame size={14} className="animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-xs font-mono">{activeCampaign.title}</span>
                  <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-black bg-[#00F5A0]/20 text-[#00F5A0] border border-[#00F5A0]/30">
                    ACTIVE MULTIPLIER
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Target: {activeCampaign.target_metrics?.referral_target || 50} referrals • Multiplier: {activeCampaign.target_metrics?.bonus_multiplier || 1.0}x
                </div>
              </div>
            </div>
            <div className="text-[10px] font-mono text-slate-400">
              Valid until {new Date(activeCampaign.end_date).toLocaleDateString()}
            </div>
          </div>
        )}

        {/* Milestone Summary Metrics Bar */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3">
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl p-2.5 sm:p-3 text-center">
            <span className="text-[9px] font-mono uppercase text-slate-400 font-bold block">
              Qualified Direct
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-[#00F5A0] tracking-tight">
              {effectiveQualified}
            </span>
          </div>

          <div className="bg-[#182030] border border-[#253146] rounded-xl p-2.5 sm:p-3 text-center shadow-sm">
            <span className="text-[9px] font-mono uppercase text-slate-400 font-bold block">
              Claimed Tiers
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-amber-400 tracking-tight">
              {claimedCount} / {totalMilestones}
            </span>
          </div>

          <div className="bg-[#182030] border border-[#253146] rounded-xl p-2.5 sm:p-3 text-center shadow-sm">
            <span className="text-[9px] font-mono uppercase text-slate-400 font-bold block">
              Milestone Earnings
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-white tracking-tight flex items-center justify-center gap-1">
              <TokenIcon size={13} />
              +{totalClaimedPoints.toLocaleString()} Tokens
            </span>
          </div>
        </div>

        {/* VERTICAL TIMELINE / PATH JOURNEY (M1 to M8) */}
        <div className="relative pt-3 pb-2 space-y-4">
          {/* Continuous Vertical Track Line */}
          <div className="absolute top-6 bottom-6 left-[19px] sm:left-[23px] w-[2px] bg-[#253146] -translate-x-1/2 pointer-events-none" />

          {loading && milestones.length === 0 ? (
            <div className="py-12 text-center text-xs font-mono text-slate-400 flex flex-col items-center justify-center gap-2">
              <RefreshCw size={16} className="animate-spin text-amber-400" />
              <span>Loading milestone roadmap...</span>
            </div>
          ) : (
            milestones.map((m, idx) => {
              const tierTag = `M${idx + 1}`;
              const isClaimable = m.status === "CLAIMABLE";
              const isClaimed = m.status === "CREDITED";
              const isLocked = m.status === "LOCKED" || (!isClaimable && !isClaimed);
              const isCurrentlyClaiming = claimingId === m.milestone_id;

              return (
                <div
                  key={m.milestone_id}
                  id={`milestone-node-${m.milestone_id}`}
                  className="relative flex items-start gap-3 sm:gap-4 group"
                >
                  {/* Timeline Indicator Circle on Track */}
                  <div className="relative z-10 shrink-0 mt-2">
                    {isClaimed ? (
                      <div className="w-9 sm:w-10 h-9 sm:h-10 rounded-full bg-[#10B981]/20 border-2 border-[#10B981] text-[#10B981] flex items-center justify-center shadow-sm">
                        <CheckCircle2 size={18} className="stroke-[2.5]" />
                      </div>
                    ) : isClaimable ? (
                      <div className="w-9 sm:w-10 h-9 sm:h-10 rounded-full bg-amber-500/20 border-2 border-amber-400 text-amber-300 flex items-center justify-center shadow-sm">
                        <Sparkles size={18} className="stroke-[2.5]" />
                      </div>
                    ) : (
                      <div className="w-9 sm:w-10 h-9 sm:h-10 rounded-full bg-[#121824] border-2 border-[#253146] text-slate-500 flex items-center justify-center">
                        <Lock size={15} className="stroke-[2]" />
                      </div>
                    )}
                  </div>

                  {/* Milestone Node Card */}
                  <div 
                    className={`flex-1 rounded-2xl p-3.5 sm:p-4 border transition-all duration-200 ${
                      isClaimable
                        ? "bg-[#1C2638] border-amber-400 shadow-md"
                        : isClaimed
                        ? "bg-[#14202C] border-[#10B981]/40"
                        : "bg-[#151D2A] border-[#253146]"
                    }`}
                  >
                    {/* Header: Tier Badge, Title, Reward */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#253146] pb-2.5">
                      <div className="flex items-center gap-2">
                        {/* Tier Badge */}
                        <span className={`px-2 py-0.5 rounded-md font-mono font-black text-[10px] tracking-wider border uppercase ${
                          isClaimable
                            ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                            : isClaimed
                            ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
                            : "bg-[#1E293B] text-slate-400 border-[#334155]"
                        }`}>
                          {tierTag}
                        </span>

                        <h4 className="text-xs font-bold text-white font-mono tracking-tight">
                          {m.title}
                        </h4>
                      </div>

                      {/* Reward Amount */}
                      <div className="flex items-center gap-1.5 self-start sm:self-auto">
                        <span className="text-[10px] font-mono text-slate-400">Reward:</span>
                        <span className={`text-xs font-black font-mono flex items-center gap-1 ${
                          isClaimable ? "text-amber-300" : isClaimed ? "text-emerald-400" : "text-white"
                        }`}>
                          <TokenIcon size={12} />
                          +{m.amount.toLocaleString()} Tokens
                        </span>
                      </div>
                    </div>

                    {/* Progress Info & Target */}
                    <div className="pt-2.5 space-y-2">
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="text-slate-400 flex items-center gap-1.5">
                          <Target size={12} className="text-slate-500" />
                          <span>Target: <strong className="text-slate-200">{m.threshold} Qualified</strong></span>
                        </span>

                        <span className={isClaimable || isClaimed ? "text-emerald-400 font-bold" : "text-slate-400"}>
                          {m.current_count} / {m.threshold}
                        </span>
                      </div>

                      {/* Horizontal Progress Bar inside Node */}
                      <div className="w-full h-1.5 bg-[#0B0F17] rounded-full overflow-hidden border border-[#253146]">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ${
                            isClaimed
                              ? "bg-emerald-500"
                              : isClaimable
                              ? "bg-amber-400"
                              : "bg-slate-600"
                          }`}
                          style={{ width: `${Math.min(100, m.progress_percent)}%` }}
                        />
                      </div>

                      {/* Card Footer: Status Action Button */}
                      <div className="pt-1.5 flex items-center justify-between flex-wrap gap-2">
                        <span className="text-[10px] font-mono text-slate-500">
                          {isClaimed 
                            ? "Reward verified & added to ledger"
                            : isClaimable 
                            ? "Target achieved! Instant claim ready"
                            : `${Math.max(0, m.threshold - m.current_count)} more qualified referrals needed`}
                        </span>

                        <div className="shrink-0">
                          {isClaimed ? (
                            <div className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold select-none">
                              <CheckCircle2 size={12} className="stroke-[2.5]" />
                              <span>Claimed</span>
                            </div>
                          ) : isClaimable ? (
                            <button
                              id={`btn-claim-${m.milestone_id}`}
                              onClick={() => handleClaim(m)}
                              disabled={isCurrentlyClaiming}
                              className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-[#0A0F17] font-mono text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer active:scale-95 disabled:opacity-50 select-none shadow-sm"
                            >
                              {isCurrentlyClaiming ? (
                                <>
                                  <RefreshCw size={12} className="animate-spin text-slate-950" />
                                  <span>Claiming...</span>
                                </>
                              ) : (
                                <>
                                  <Sparkles size={12} className="text-slate-950 stroke-[2.5]" />
                                  <span>Claim Reward</span>
                                </>
                              )}
                            </button>
                          ) : (
                            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#182030] border border-[#253146] text-slate-500 text-[11px] font-mono select-none">
                              <Lock size={11} />
                              <span>Locked</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Milestone Footer Note */}
        <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.06] flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck size={12} className="text-[#00F5A0]" />
            <span>Server-authoritative state machine • Idempotent ledgering</span>
          </span>
          <span className="text-[#00F5A0] font-bold">Anti-Fraud Protected</span>
        </div>
      </div>
    </section>
  );
}
