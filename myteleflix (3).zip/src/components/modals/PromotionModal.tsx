/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  X, 
  Gift, 
  Send, 
  MessageCircle, 
  Mail, 
  Copy, 
  Check, 
  ExternalLink,
  Sparkles,
  TrendingUp,
  ShieldCheck
} from "lucide-react";
import { CommunitySettings } from "../../types";
import { useCommunitySettings } from "../../hooks/useCommunitySettings";

export interface PromotionModalProps {
  isOpen: boolean;
  onClose: () => void;
  communitySettings?: CommunitySettings;
}

export const PromotionModal: React.FC<PromotionModalProps> = ({
  isOpen,
  onClose,
  communitySettings: propSettings
}) => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const hookSettings = useCommunitySettings();
  const settings = propSettings || hookSettings.settings;

  const promoEmail = settings.promotionEmail || "SYNCTASKSOSPROMOTION@GMAIL.COM";
  const rawWhatsApp = settings.whatsappSupportLink || "https://wa.me/?text=Hello%20MyTeleFlix%20Team,%20I%20am%20interested%20in%20product%20promotion%20and%20advertising.";
  const telegramSupportUrl = settings.telegramSupportGroupLink || settings.telegramChannelLink || "https://t.me/myteleflix_admin";

  if (!isOpen) return null;

  const handleCopyEmail = async () => {
    try {
      if (navigator?.clipboard) {
        await navigator.clipboard.writeText(promoEmail);
      } else {
        const input = document.createElement("input");
        input.value = promoEmail;
        document.body.appendChild(input);
        input.select();
        document.execCommand("copy");
        document.body.removeChild(input);
      }
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2500);
    } catch {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2500);
    }
  };

  const handleOpenTelegram = () => {
    window.open(telegramSupportUrl, "_blank", "noopener,noreferrer");
  };

  const handleOpenWhatsApp = () => {
    let target = rawWhatsApp.trim();
    if (!target.startsWith("http://") && !target.startsWith("https://")) {
      // If user entered only a phone number e.g. +8801700000000 or 01700000000
      const digitsOnly = target.replace(/[^0-9]/g, "");
      target = `https://wa.me/${digitsOnly}?text=Hello%20MyTeleFlix%20Team,%20I%20am%20interested%20in%20product%20promotion%20and%20advertising.`;
    }
    window.open(target, "_blank", "noopener,noreferrer");
  };

  return (
    <div 
      id="promotion-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="promotion-modal-card"
        className="w-full max-w-lg bg-gradient-to-b from-[#0F172A] via-[#0B1120] to-[#070A12] border border-cyan-500/35 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8),0_0_30px_rgba(6,182,212,0.15)] p-4 sm:p-6 text-white relative overflow-hidden my-auto backdrop-blur-xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Cyan/Blue Glow */}
        <div className="absolute top-0 right-0 w-48 h-32 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-32 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header with organic blur glassmorphism backdrop */}
        <div className="flex items-center justify-between pb-3.5 border-b border-cyan-500/20 relative z-10 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center text-cyan-400 shadow-inner">
              <Gift size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                  প্রমোশন কন্ট্রাক্ট
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  PROMOTION
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans mt-0.5">
                আমাদের সাইটে পণ্য বা প্রোডাক্ট প্রমোশন করার অফিসিয়াল কন্ট্রাক্ট
              </p>
            </div>
          </div>

          <button
            type="button"
            id="close-promotion-modal"
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700/60 transition cursor-pointer"
            title="বন্ধ করুন"
          >
            <X size={16} />
          </button>
        </div>

        {/* Highlight Banner */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-[#0B1B2B]/70 to-blue-950/60 border border-cyan-500/30 relative z-10">
          <div className="flex items-center gap-2 text-cyan-300 text-xs font-mono font-bold mb-1">
            <Sparkles size={14} className="text-cyan-400" />
            <span>GROW YOUR BRAND WITH MYTELEFLIX</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            আপনার টেলিগ্রাম চ্যানেল, ওয়েবসাইট, ইউটিউব ভিডিও বা যেকোনো পণ্য আমাদের লক্ষাধিক সক্রিয় ব্যবহারকারীর সামনে স্পনসরড ক্যাম্পেইন বা টাস্ক হিসেবে প্রদর্শন করতে সরাসরি যোগাযোগ করুন।
          </p>
        </div>

        {/* Direct Contact Buttons */}
        <div className="space-y-3 my-4 relative z-10">
          {/* 1. WhatsApp Chat */}
          <button
            type="button"
            onClick={handleOpenWhatsApp}
            className="w-full p-3.5 sm:p-4 rounded-2xl bg-[#0F1C18]/90 hover:bg-[#152923] border border-emerald-500/35 hover:border-emerald-400/70 flex items-center justify-between text-left transition-all duration-200 group cursor-pointer shadow-md hover:shadow-[0_0_20px_rgba(37,211,102,0.3)] active:scale-[0.98]"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
                <MessageCircle size={20} />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-emerald-300 block">
                  WhatsApp Direct Chat
                </span>
                <span className="text-[11px] text-slate-400 font-sans">
                  ইনস্ট্যান্ট রিপ্লাই ও বিজ্ঞাপনী কন্ট্রাক্ট ডিল
                </span>
              </div>
            </div>
            <ExternalLink size={16} className="text-emerald-400/80 group-hover:text-emerald-300 transition" />
          </button>

          {/* 2. Telegram Support */}
          <button
            type="button"
            onClick={handleOpenTelegram}
            className="w-full p-3.5 sm:p-4 rounded-2xl bg-[#0D1826]/90 hover:bg-[#122238] border border-cyan-500/35 hover:border-cyan-400/70 flex items-center justify-between text-left transition-all duration-200 group cursor-pointer shadow-md hover:shadow-[0_0_20px_rgba(6,182,212,0.3)] active:scale-[0.98]"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                <Send size={20} />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-cyan-300 block">
                  Telegram Direct Chat
                </span>
                <span className="text-[11px] text-slate-400 font-sans">
                  অফিসিয়াল টেলিগ্রাম সাপোর্ট ও পার্টনারশিপ
                </span>
              </div>
            </div>
            <ExternalLink size={16} className="text-cyan-400/80 group-hover:text-cyan-300 transition" />
          </button>

          {/* 3. Gmail Promotion Contact */}
          <div className="p-3.5 sm:p-4 rounded-2xl bg-[#131124]/90 border border-purple-500/35 flex flex-col gap-2.5 shadow-md hover:shadow-[0_0_20px_rgba(168,85,247,0.25)] transition-all">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-300">
                  <Mail size={18} />
                </div>
                <div>
                  <span className="text-xs sm:text-sm font-bold text-purple-200 block">
                    Official Promotion Email
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    কর্পোরেট কন্ট্রাক্ট ও স্পনসরশিপ
                  </span>
                </div>
              </div>
              <a
                href={`mailto:${promoEmail}?subject=MyTeleFlix%20Promotion%20Contract`}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 underline font-bold"
              >
                Open Mail
              </a>
            </div>

            <div className="flex items-center justify-between bg-black/50 border border-purple-500/20 rounded-xl px-3 py-2">
              <span className="text-[11px] font-mono text-purple-300 select-all font-bold truncate">
                {promoEmail}
              </span>
              <button
                type="button"
                onClick={handleCopyEmail}
                className="inline-flex items-center gap-1 text-[10px] font-mono bg-purple-950/80 hover:bg-purple-900 border border-purple-500/40 text-purple-200 px-2.5 py-1 rounded-lg transition cursor-pointer shrink-0 ml-2"
              >
                {copiedEmail ? (
                  <>
                    <Check size={11} className="text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy size={11} />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Feature Points */}
        <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 text-[11px] text-slate-400 space-y-1.5 relative z-10 font-sans">
          <div className="flex items-center gap-2 text-slate-300">
            <TrendingUp size={13} className="text-cyan-400 shrink-0" />
            <span>টার্গেটেড অডিয়েন্স: ১০০% এক্টিভ রিয়েল ইউজার ট্রাফিক</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck size={13} className="text-emerald-400 shrink-0" />
            <span>গ্যারান্টেড ক্লিক ও ভেরিফাইড টাস্ক কমপ্লিশন সিস্টেম</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5 pt-3.5 border-t border-slate-800/80 flex justify-end relative z-10">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-400 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 font-black text-xs sm:text-sm font-mono uppercase tracking-wider hover:shadow-[0_0_25px_rgba(6,182,212,0.4)] active:scale-[0.98] transition-all duration-200 cursor-pointer shadow-lg shadow-cyan-500/25"
          >
            ক্লোজ / CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

export default PromotionModal;
