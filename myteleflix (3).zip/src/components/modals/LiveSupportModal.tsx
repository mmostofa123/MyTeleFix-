/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  X, 
  Headphones, 
  Send, 
  Clock, 
  ShieldAlert, 
  LifeBuoy, 
  ExternalLink,
  MessageSquare,
  Sparkles,
  Users,
  Phone
} from "lucide-react";
import { CommunitySettings } from "../../types";
import { useCommunitySettings } from "../../hooks/useCommunitySettings";

export interface LiveSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  communitySettings?: CommunitySettings;
}

export const LiveSupportModal: React.FC<LiveSupportModalProps> = ({
  isOpen,
  onClose,
  communitySettings: propSettings
}) => {
  const hookSettings = useCommunitySettings();
  const settings = propSettings || hookSettings.settings;

  if (!isOpen) return null;

  const supportGroupUrl = settings.telegramSupportGroupLink || "https://t.me/myteleflix_support";
  const directHelplineUrl = settings.telegramChannelLink || settings.telegramSupportGroupLink || "https://t.me/myteleflix_admin";
  const operatingHoursText = settings.supportOperatingHours || "প্রতিদিন সকাল ১০:০০ টা থেকে রাত ১০:০০ টা পর্যন্ত (10:00 AM - 10:00 PM)";
  const guidelinesText = settings.supportGuidelines || "গ্রুপে যেকোনো থার্ড-পার্টি লিংক, স্প্যামিং, ব্যক্তিগত আক্রমণ কিংবা প্রতারণামূলক বার্তা দেওয়া কঠোরভাবে নিষিদ্ধ। আইন অমান্যকারীদের আইডি স্থায়ীভাবে ব্যান করা হবে।";

  const handleJoinSupportGroup = () => {
    window.open(supportGroupUrl, "_blank", "noopener,noreferrer");
  };

  const handleWhatsAppContact = () => {
    const wa = settings.whatsappSupportLink;
    if (!wa) {
      window.open("https://wa.me/?text=Hello%20MyTeleFlix%20Support", "_blank", "noopener,noreferrer");
      return;
    }
    if (wa.startsWith("http")) {
      window.open(wa, "_blank", "noopener,noreferrer");
    } else {
      window.open(`https://wa.me/${wa.replace(/[^0-9]/g, "")}?text=Hello%20MyTeleFlix%20Support`, "_blank", "noopener,noreferrer");
    }
  };

  const handleDirectHelpline = () => {
    window.open(directHelplineUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <div 
      id="live-support-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="live-support-modal-card"
        className="w-full max-w-lg bg-gradient-to-b from-[#051119] via-[#030d14] to-[#02070b] border-2 border-cyan-500/40 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_25px_rgba(6,182,212,0.15)] p-3.5 sm:p-5 text-white relative overflow-hidden my-auto backdrop-blur-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Cyan / Emerald Glow */}
        <div className="absolute top-0 right-0 w-44 h-28 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-44 h-28 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header - Compact & Mobile Clean */}
        <div className="flex items-center justify-between pb-2.5 border-b border-cyan-500/20 relative z-10">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-cyan-950/80 border border-cyan-500/50 flex items-center justify-center text-cyan-400 shrink-0 shadow-inner">
              <Headphones size={18} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-white tracking-tight">
                  অফিসিয়াল লাইভ সাপোর্ট
                </h3>
                <span className="px-2 py-0.2 rounded-full text-[9px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/35">
                  24/7 HELPLINE
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate mt-0.5">
                টেলিগ্রাম ও হোয়াটসঅ্যাপ জরুরি সহায়তা
              </p>
            </div>
          </div>

          <button
            type="button"
            id="close-live-support-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/60 transition cursor-pointer shrink-0 ml-1"
            title="বন্ধ করুন"
          >
            <X size={15} />
          </button>
        </div>

        {/* Quick Action Channels Banner - Ultra neat for Mobile */}
        <div className="my-2.5 relative z-10 space-y-2">
          {/* Button 1: Telegram Support Group */}
          <button
            type="button"
            onClick={handleJoinSupportGroup}
            className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-[#0088cc]/90 to-[#005580]/90 hover:brightness-110 text-white font-bold text-xs sm:text-sm font-sans flex items-center justify-between shadow-md active:scale-[0.985] transition-all cursor-pointer border border-[#00aaff]/40"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                <Send size={14} className="text-cyan-200" />
              </div>
              <div className="text-left truncate">
                <div className="text-xs sm:text-sm font-bold truncate">টেলিগ্রাম সাপোর্ট গ্রুপ</div>
                <div className="text-[9.5px] text-cyan-200/80 truncate">সরাসরি অ্যাডমিন ও কমিউনিটির সাথে যোগাযোগ</div>
              </div>
            </div>
            <ExternalLink size={13} className="shrink-0 text-cyan-200" />
          </button>

          {/* Button 2: WhatsApp Support */}
          <button
            type="button"
            onClick={handleWhatsAppContact}
            className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-[#128C7E]/90 to-[#075E54]/90 hover:brightness-110 text-white font-bold text-xs sm:text-sm font-sans flex items-center justify-between shadow-md active:scale-[0.985] transition-all cursor-pointer border border-[#25D366]/40"
          >
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                <Phone size={14} className="text-emerald-300" />
              </div>
              <div className="text-left truncate">
                <div className="text-xs sm:text-sm font-bold truncate">হোয়াটসঅ্যাপ সাপোর্ট চ্যাট</div>
                <div className="text-[9.5px] text-emerald-200/80 truncate">পেমেন্ট ও দ্রুত সমাধানের জন্য মেসেজ করুন</div>
              </div>
            </div>
            <ExternalLink size={13} className="shrink-0 text-emerald-200" />
          </button>
        </div>

        {/* 3 Compact Guideline Cards */}
        <div className="space-y-1.5 my-2.5 relative z-10">
          {/* 1. Opening Hours */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-[#030910] border border-cyan-500/20 flex items-start gap-2">
            <div className="w-6 h-6 rounded-lg bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
              <Clock size={13} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-1 flex-wrap">
                <span className="text-[11px] sm:text-xs font-bold text-cyan-300">
                  সাপোর্টের সময়সূচি
                </span>
                <span className="text-[9px] font-mono font-bold text-cyan-300 bg-cyan-950/90 px-1.5 py-0.2 rounded border border-cyan-500/30">
                  10 AM - 10 PM
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 mt-0.5 leading-snug">
                {operatingHoursText}
              </p>
            </div>
          </div>

          {/* 2. Direct Helpline & Rules */}
          <div className="p-2 sm:p-2.5 rounded-xl bg-[#030910] border border-cyan-500/20 flex items-start gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-950/80 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
              <LifeBuoy size={13} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[11px] sm:text-xs font-bold text-amber-300">
                  জরুরি অ্যাডমিন হেল্পলাইন
                </span>
                <button
                  type="button"
                  onClick={handleDirectHelpline}
                  className="text-[10px] font-mono text-cyan-400 hover:text-cyan-200 underline font-bold"
                >
                  Contact Admin
                </button>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 mt-0.5 leading-snug">
                যেকোনো জটিলতায় স্ক্রিনশট ও ইউজার আইডি সহ সরাসরি টেলিগ্রাম হেল্পলাইনে ইনবক্স করুন।
              </p>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex justify-end relative z-10">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-500 hover:brightness-110 text-slate-950 font-black text-xs sm:text-sm font-mono uppercase tracking-wider active:scale-[0.98] transition-all cursor-pointer shadow-md text-center"
          >
            বুঝেছি / CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

export default LiveSupportModal;
