/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  X, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Layers, 
  Inbox, 
  AlertCircle,
  RefreshCw,
  ExternalLink
} from "lucide-react";

export interface TaskItemDetail {
  id: string;
  title: string;
  type: string;
  rewardPoints: number;
  status: "completed" | "pending" | "rejected";
  timestamp?: string;
  notes?: string;
}

export interface TaskStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  pendingCount?: number;
  approvedCount?: number;
  rejectedCount?: number;
  totalCount?: number;
  tasks?: TaskItemDetail[];
  onNavigateToEarn?: () => void;
}

export const TaskStatusModal: React.FC<TaskStatusModalProps> = ({
  isOpen,
  onClose,
  pendingCount = 0,
  approvedCount = 0,
  rejectedCount = 0,
  totalCount = 0,
  tasks = [],
  onNavigateToEarn,
}) => {
  const [activeFilter, setActiveFilter] = useState<"all" | "pending" | "approved" | "rejected">("all");

  if (!isOpen) return null;

  const actualCompleted = approvedCount || tasks.filter(t => t.status === "completed").length;
  const actualPending = pendingCount || tasks.filter(t => t.status === "pending").length;
  const actualRejected = rejectedCount || tasks.filter(t => t.status === "rejected").length;
  const calculatedTotal = totalCount || (actualCompleted + actualPending + actualRejected) || tasks.length;

  const filteredTasks = tasks.filter(t => {
    if (activeFilter === "approved") return t.status === "completed";
    if (activeFilter === "pending") return t.status === "pending";
    if (activeFilter === "rejected") return t.status === "rejected";
    return true;
  });

  return (
    <div 
      id="task-status-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3.5 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="task-status-modal-card"
        className="w-full max-w-lg bg-gradient-to-b from-[#0b0914] via-[#080710] to-[#040308] border-2 border-amber-500/40 rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_25px_rgba(245,158,11,0.15)] p-3.5 sm:p-5 text-white relative overflow-hidden my-auto backdrop-blur-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Warm Glow */}
        <div className="absolute top-0 right-0 w-44 h-28 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-44 h-28 bg-orange-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header - Compact & Mobile Clean */}
        <div className="flex items-center justify-between pb-2.5 border-b border-amber-500/20 relative z-10">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-950/80 border border-amber-500/50 flex items-center justify-center text-amber-400 shrink-0 shadow-inner">
              <CheckCircle2 size={18} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-white tracking-tight">
                  টাস্ক রিভিউ ও স্ট্যাটাস
                </h3>
                <span className="px-2 py-0.2 rounded-full text-[9px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/35">
                  {actualPending} PENDING
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate mt-0.5">
                কমপ্লিট, পেন্ডিং ও রিভিউ কাজের হিসাব
              </p>
            </div>
          </div>

          <button
            type="button"
            id="close-task-status-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/60 transition cursor-pointer shrink-0 ml-1"
            title="বন্ধ করুন"
          >
            <X size={15} />
          </button>
        </div>

        {/* 4 Counter Metrics Cards - Dark, Compact, Mobile-friendly */}
        <div className="grid grid-cols-4 gap-1.5 sm:gap-2 my-2.5 relative z-10">
          {/* TOTAL */}
          <div 
            onClick={() => setActiveFilter("all")}
            className={`p-2 rounded-xl border text-center transition cursor-pointer select-none ${
              activeFilter === "all"
                ? "bg-slate-800/90 border-slate-300 shadow-sm ring-1 ring-slate-400/30"
                : "bg-[#090b10] border-white/[0.08] hover:border-slate-600"
            }`}
          >
            <div className="flex items-center justify-center mb-0.5 text-slate-400">
              <Layers size={13} />
            </div>
            <span className="text-[9px] font-mono text-slate-400 uppercase font-bold block truncate">
              সর্বমোট
            </span>
            <span className="text-xs sm:text-sm font-black font-mono text-white">
              {calculatedTotal}
            </span>
          </div>

          {/* APPROVED / COMPLETED */}
          <div 
            onClick={() => setActiveFilter("approved")}
            className={`p-2 rounded-xl border text-center transition cursor-pointer select-none ${
              activeFilter === "approved"
                ? "bg-emerald-950/80 border-emerald-400 shadow-sm ring-1 ring-emerald-400/40"
                : "bg-[#040f09] border-emerald-500/25 hover:border-emerald-500/50"
            }`}
          >
            <div className="flex items-center justify-center mb-0.5 text-emerald-400">
              <CheckCircle2 size={13} />
            </div>
            <span className="text-[9px] font-mono text-emerald-400 uppercase font-bold block truncate">
              কমপ্লিট
            </span>
            <span className="text-xs sm:text-sm font-black font-mono text-emerald-300">
              {actualCompleted}
            </span>
          </div>

          {/* PENDING */}
          <div 
            onClick={() => setActiveFilter("pending")}
            className={`p-2 rounded-xl border text-center transition cursor-pointer select-none ${
              activeFilter === "pending"
                ? "bg-amber-950/80 border-amber-400 shadow-sm ring-1 ring-amber-400/40"
                : "bg-[#110c03] border-amber-500/25 hover:border-amber-500/50"
            }`}
          >
            <div className="flex items-center justify-center mb-0.5 text-amber-400">
              <Clock size={13} />
            </div>
            <span className="text-[9px] font-mono text-amber-400 uppercase font-bold block truncate">
              পেন্ডিং
            </span>
            <span className="text-xs sm:text-sm font-black font-mono text-amber-300">
              {actualPending}
            </span>
          </div>

          {/* REJECTED */}
          <div 
            onClick={() => setActiveFilter("rejected")}
            className={`p-2 rounded-xl border text-center transition cursor-pointer select-none ${
              activeFilter === "rejected"
                ? "bg-rose-950/80 border-rose-400 shadow-sm ring-1 ring-rose-400/40"
                : "bg-[#120407] border-rose-500/25 hover:border-rose-500/50"
            }`}
          >
            <div className="flex items-center justify-center mb-0.5 text-rose-400">
              <XCircle size={13} />
            </div>
            <span className="text-[9px] font-mono text-rose-400 uppercase font-bold block truncate">
              রিজেক্ট
            </span>
            <span className="text-xs sm:text-sm font-black font-mono text-rose-300">
              {actualRejected}
            </span>
          </div>
        </div>

        {/* Task Category Summary Breakdown - Ultra-neat pill cards */}
        <div className="grid grid-cols-3 gap-1.5 mb-2.5 relative z-10">
          <div className="p-1.5 sm:p-2 rounded-lg bg-[#06080e] border border-white/[0.08] text-center">
            <span className="text-[9px] text-slate-400 block font-mono">ভিডিও টাস্ক</span>
            <span className="text-[11px] sm:text-xs font-bold text-white font-mono">
              {tasks.filter(t => t.type?.toLowerCase().includes('video')).length || 0} সম্পন্ন
            </span>
          </div>
          <div className="p-1.5 sm:p-2 rounded-lg bg-[#06080e] border border-white/[0.08] text-center">
            <span className="text-[9px] text-slate-400 block font-mono">স্পনসর/অ্যাড</span>
            <span className="text-[11px] sm:text-xs font-bold text-white font-mono">
              {tasks.filter(t => t.type?.toLowerCase().includes('ad') || t.type?.toLowerCase().includes('earning')).length || 0} সম্পন্ন
            </span>
          </div>
          <div className="p-1.5 sm:p-2 rounded-lg bg-[#06080e] border border-white/[0.08] text-center">
            <span className="text-[9px] text-slate-400 block font-mono">মিশন/রেফার</span>
            <span className="text-[11px] sm:text-xs font-bold text-white font-mono">
              {tasks.filter(t => t.type?.toLowerCase().includes('referral') || t.type?.toLowerCase().includes('survey')).length || 0} সম্পন্ন
            </span>
          </div>
        </div>

        {/* Task List or Detailed State */}
        {filteredTasks.length > 0 ? (
          <div className="my-3 space-y-2 max-h-56 overflow-y-auto pr-1 relative z-10">
            {filteredTasks.map((task) => (
              <div
                key={task.id}
                className="bg-[#0b0e14] border border-white/[0.08] hover:border-white/[0.15] rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2.5 transition"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                    task.status === "completed"
                      ? "bg-emerald-950/60 text-emerald-400 border-emerald-500/30"
                      : task.status === "pending"
                      ? "bg-amber-950/60 text-amber-400 border-amber-500/30"
                      : "bg-rose-950/60 text-rose-400 border-rose-500/30"
                  }`}>
                    {task.status === "completed" && <CheckCircle2 size={15} />}
                    {task.status === "pending" && <Clock size={15} />}
                    {task.status === "rejected" && <XCircle size={15} />}
                  </div>
                  <div className="min-w-0">
                    <h5 className="text-xs font-bold text-white truncate font-sans">
                      {task.title}
                    </h5>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                      <span className="uppercase text-amber-400">{task.type}</span>
                      {task.timestamp && (
                        <>
                          <span>•</span>
                          <span>{new Date(task.timestamp).toLocaleDateString()}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold border ${
                    task.status === "completed"
                      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
                      : task.status === "pending"
                      ? "bg-amber-500/15 text-amber-300 border-amber-500/30"
                      : "bg-rose-500/15 text-rose-300 border-rose-500/30"
                  }`}>
                    {task.status === "completed" ? "APPROVED" : task.status === "pending" ? "PENDING" : "REJECTED"}
                  </span>
                  <div className="text-[11px] font-mono font-bold text-amber-300 mt-1">
                    +{task.rewardPoints.toLocaleString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="my-3 p-6 sm:p-7 rounded-2xl bg-[#0C0B16]/80 border border-slate-800/90 text-center flex flex-col items-center justify-center relative z-10 min-h-[140px]">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-2 shadow-inner">
              <Inbox size={20} />
            </div>
            <h4 className="text-xs sm:text-sm font-bold text-slate-200 mb-1">
              {calculatedTotal === 0 ? "কোনো টাস্ক সাবমিট করা হয়নি" : "এই ফিল্টারে কোনো টাস্ক নেই"}
            </h4>
            <p className="text-[11px] text-slate-400 max-w-xs leading-relaxed font-sans">
              {calculatedTotal === 0
                ? "টাস্ক বা ইনকাম সাইট পেজ থেকে কাজ সম্পন্ন করলে অ্যাডমিন রিভিউ, কমপ্লিট ও রিজেক্ট হিসেব এখানে রিয়েল-টাইমে আপডেট হবে।"
                : "অন্যান্য ফিল্টার (সব, কমপ্লিট, পেন্ডিং, রিজেক্ট) চেক করুন।"}
            </p>
          </div>
        )}

        {/* Notice Card */}
        <div className="p-3 rounded-xl bg-amber-950/25 border border-amber-500/25 flex items-start gap-2.5 text-left text-xs text-amber-300/90 relative z-10">
          <AlertCircle size={15} className="text-amber-400 shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed">
            যেকোনো টাস্ক সাবমিটের পর অ্যাডমিন টিম সাধারণত ২৪ ঘণ্টার মধ্যে ম্যানুয়ালি রিভিউ করে আপনার মূল একাউন্টে রিওয়ার্ড পয়েন্ট যুক্ত করে দেয়।
          </p>
        </div>

        {/* Action Button */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2.5 justify-end relative z-10">
          {onNavigateToEarn && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onNavigateToEarn();
              }}
              className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs font-mono uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5"
            >
              <span>নতুন টাস্ক করুন</span>
              <ExternalLink size={13} />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs sm:text-sm font-mono uppercase tracking-wider hover:shadow-[0_0_20px_rgba(245,158,11,0.35)] active:scale-[0.98] transition-all duration-200 cursor-pointer shadow-lg shadow-amber-500/25 text-center"
          >
            বুঝেছি / CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskStatusModal;
