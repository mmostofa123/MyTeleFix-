/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useRef, useMemo } from "react";
import { Download } from "lucide-react";
import { Movie } from "../types";
import { isImageCached, markImageCached } from "../utils/imageCache";
import PosterDownloadOverlay from "./PosterDownloadOverlay";
import { useLanguage } from "../context/LanguageContext";

export interface MovieCardProps {
  movie: Movie;
  onClick?: () => void;
  layout?: "grid" | "compact" | "horizontal" | "carousel";
  priorityBadge?: string;
  isAdult?: boolean;
  className?: string;
  showGetLink?: boolean;
  showBadges?: boolean;
  sectionType?: 'movie' | 'adult' | 'series' | 'drama' | 'video';
}

function MovieCardComponent({
  movie,
  onClick,
  layout = "carousel",
  priorityBadge,
  isAdult = false,
  className = "",
  showGetLink = false,
  showBadges = true,
  sectionType,
}: MovieCardProps) {
  const { t } = useLanguage();
  const isAlreadyCached = isImageCached(movie.thumbnailUrl);
  const [imageLoaded, setImageLoaded] = useState<boolean>(isAlreadyCached);

  const handleImageLoad = useCallback(() => {
    markImageCached(movie.thumbnailUrl);
    setImageLoaded(true);
  }, [movie.thumbnailUrl]);

  const [isOpening, setIsOpening] = useState<boolean>(false);
  const clickTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const sectionBtnStyle = useMemo(() => {
    if (sectionType === 'adult' || isAdult) {
      return "bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white shadow-lg shadow-rose-950/60 border border-red-500/90 font-black";
    }
    if (sectionType === 'series' || movie.contentType === 'series' || (movie as any).isSeries) {
      return "bg-[#0284C7] hover:bg-[#0369A1] active:bg-[#075985] text-white shadow-lg shadow-sky-950/60 border border-sky-400/90 font-black";
    }
    if (sectionType === 'drama' || movie.contentType === 'drama' || (movie as any).isDrama) {
      return "bg-[#059669] hover:bg-[#047857] active:bg-[#065F46] text-white shadow-lg shadow-emerald-950/60 border border-emerald-400/90 font-black";
    }
    if (sectionType === 'video') {
      return "bg-[#7C3AED] hover:bg-[#6D28D9] active:bg-[#5B21B6] text-white shadow-lg shadow-purple-950/60 border border-purple-400/90 font-black";
    }
    return "bg-[#E5A00D] hover:bg-[#D97706] active:bg-[#B45309] text-black shadow-lg shadow-amber-950/60 border border-amber-400/90 font-black";
  }, [sectionType, isAdult, movie]);

  // Smooth click animation dispatch handler with visual feedback
  const handleCardClick = useCallback((e?: React.MouseEvent | React.TouchEvent) => {
    if (e) {
      e.stopPropagation();
    }
    if (isOpening) return;
    setIsOpening(true);

    if (clickTimeoutRef.current) {
      clearTimeout(clickTimeoutRef.current);
    }
    clickTimeoutRef.current = setTimeout(() => {
      onClick?.();
      setIsOpening(false);
    }, 180);
  }, [onClick, isOpening]);

  const handleGetLinkClick = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    handleCardClick(e);
  }, [handleCardClick]);

  // Cleanup timeout on unmount
  React.useEffect(() => {
    return () => {
      if (clickTimeoutRef.current) {
        clearTimeout(clickTimeoutRef.current);
      }
    };
  }, []);

  // Compact layout (used for dense multi-column grids like Most Trending All Releases)
  if (layout === "compact") {
    return (
      <div
        id={`movie-card-compact-${movie.id}`}
        onClick={handleCardClick}
        className={`group flex flex-col cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 rounded-2xl select-none ${className}`}
      >
        <div className="relative aspect-[2/3] w-full rounded-lg overflow-hidden shadow-md bg-[#0B0F17] shrink-0 border border-slate-800/80 group-hover:border-slate-700/90 transition-all">
          <img
            src={movie.thumbnailUrl}
            alt={movie.title}
            loading={isAlreadyCached ? "eager" : "lazy"}
            decoding="async"
            onLoad={handleImageLoad}
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
            }}
            className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-200 ${
              isOpening ? "scale-105 filter blur-xs brightness-75" : ""
            } ${
              imageLoaded || isAlreadyCached ? "opacity-100" : "opacity-90"
            }`}
            referrerPolicy="no-referrer"
          />

          {/* Organic Circular Download Animation Overlay */}
          {isOpening && <PosterDownloadOverlay size="sm" />}

          {/* Badges - Minimalist Direct Floating Text (Ultra Compact) - Only when showBadges is true */}
          {!isOpening && showBadges && (
            <>
              {priorityBadge ? (
                <div className="absolute top-1 left-1 z-10 text-[8px] sm:text-[8.5px] font-extrabold text-amber-400 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tracking-wider uppercase">
                  {priorityBadge}
                </div>
              ) : isAdult ? (
                <div className="absolute top-1 left-1 z-10 text-[8px] sm:text-[8.5px] font-extrabold text-red-500 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tracking-wider uppercase">
                  18+
                </div>
              ) : null}
            </>
          )}
        </div>

        <h4
          title={movie.title}
          className="mt-1 text-[9.5px] sm:text-[10.5px] font-medium text-slate-200 group-hover:text-amber-400 transition-colors truncate px-0.5 w-full text-left leading-tight"
        >
          {movie.title}
        </h4>
      </div>
    );
  }

  // Exact 3.3 cards view sizing on mobile with guaranteed non-sticking width:
  const sizingClasses =
    layout === "grid"
      ? "w-full min-w-0 max-w-full"
      : "w-[108px] min-w-[108px] max-w-[108px] sm:w-[132px] sm:min-w-[132px] sm:max-w-[132px] flex-shrink-0 snap-start";

  return (
    <div
      id={`movie-card-${movie.id}`}
      onClick={handleCardClick}
      className={`group flex flex-col cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 rounded-2xl select-none ${sizingClasses} ${className}`}
    >
      {/* Full-bleed 2:3 vertical poster format with solid dark-slate backing */}
      <div className="relative aspect-[2/3] w-full rounded-xl overflow-hidden shadow-lg bg-[#0B0F17] shrink-0 border border-slate-800/80 group-hover:border-slate-700/90 transition-all">
        <img
          src={movie.thumbnailUrl}
          alt={movie.title}
          loading={isAlreadyCached ? "eager" : "lazy"}
          decoding="async"
          onLoad={handleImageLoad}
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
          }}
          className={`w-full h-full object-cover group-hover:scale-105 transition-all duration-200 ${
            isOpening ? "scale-105 filter blur-xs brightness-75" : ""
          } ${
            imageLoaded || isAlreadyCached ? "opacity-100" : "opacity-90"
          }`}
          referrerPolicy="no-referrer"
        />

        {/* Organic Circular Download Animation Overlay */}
        {isOpening && <PosterDownloadOverlay size="md" />}

        {/* Badges - Minimalist Direct Floating Text (Compact & Sleek) - Only when showBadges is true */}
        {!isOpening && showBadges && (
          <>
            {priorityBadge ? (
              <div className="absolute top-1.5 left-1.5 z-10 text-[8.5px] sm:text-[9.5px] font-extrabold text-amber-400 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tracking-wider uppercase">
                {priorityBadge}
              </div>
            ) : isAdult ? (
              <div className="absolute top-1.5 left-1.5 z-10 text-[8.5px] sm:text-[9.5px] font-extrabold text-red-500 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] tracking-wider uppercase">
                18+
              </div>
            ) : null}
          </>
        )}
      </div>

      {/* Movie Title: Directly below poster with clean truncation */}
      <h4
        title={movie.title}
        className="mt-1.5 text-[11px] sm:text-xs font-semibold text-slate-200 group-hover:text-amber-400 transition-colors truncate px-0.5 w-full text-left leading-tight"
      >
        {movie.title}
      </h4>

      {/* Action Button: Visible ONLY on dedicated list views when showGetLink is true */}
      {showGetLink && (
        <button
          type="button"
          onClick={handleGetLinkClick}
          onTouchEnd={(e) => e.stopPropagation()}
          className={`mt-2 py-1.5 px-2 rounded-lg w-full text-center flex items-center justify-center gap-1.5 transition-all duration-75 ease-out shrink-0 cursor-pointer select-none active:scale-95 active:brightness-125 text-xs font-bold tracking-wide shadow-md ${sectionBtnStyle}`}
        >
          {isOpening ? (
            <>
              {/* Subtle compact spinning loader instead of disruptive large bouncy icon */}
              <div className="w-3 h-3 rounded-full border-[1.5px] border-current border-t-transparent animate-spin shrink-0" />
              <span className="whitespace-nowrap text-[11px] font-bold">{t('action.opening', 'OPENING...')}</span>
            </>
          ) : (
            <>
              <Download size={12} strokeWidth={2.4} className="shrink-0" />
              <span className="whitespace-nowrap">{t('action.download', 'DOWNLOAD')}</span>
            </>
          )}
        </button>
      )}
    </div>
  );
}

const MovieCard = React.memo(MovieCardComponent);
export default MovieCard;
