/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from "react";
import { 
  ArrowLeft, Download, Play, Pause, Volume2, VolumeX, 
  Loader2, Mic, Film, Clapperboard, ArrowRight, ShieldCheck,
  Copy, ExternalLink, Check, CheckCircle
} from "lucide-react";
import { Movie, Video } from "../types";
import { useLanguage } from "../context/LanguageContext";
import DownloadAdTimerModal from "./DownloadAdTimerModal";
import { auth } from "../services/firebase";

interface LinkUnlockModalProps {
  item: Movie | Video;
  type: 'movie' | 'video';
  userId?: string;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  onClose: () => void;
}

interface DubOption {
  id: 'original' | 'hindi' | 'bangla' | 'english' | 'video_direct';
  titleBn: string;
  subtitle?: string;
  flagSvg: React.ReactNode;
  badgeEmblem?: string;
  badgeText: string;
  fileSize: string;
  targetUrl: string;
}

export default function LinkUnlockModal({
  item,
  type,
  userId = "guest",
  guideVideoUrl = "https://t.me/myteleflix",
  guideVideoLogoUrl: _guideVideoLogoUrl,
  onClose,
}: LinkUnlockModalProps) {
  const { t, language } = useLanguage();
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [redirectStatus, setRedirectStatus] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [readyLink, setReadyLink] = useState<{ url: string; title: string } | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Phase 1: High-CPM Custom Video Ad & 15-Second Timer Modal state
  const [adModalOpen, setAdModalOpen] = useState<boolean>(false);
  const [selectedAdOption, setSelectedAdOption] = useState<{ id: string; title: string; targetUrl: string } | null>(null);
  
  const [dynamicGuideUrl, setDynamicGuideUrl] = useState(
    item.tutorialVideoUrl || guideVideoUrl
  );
  const [dynamicAudioUrl, setDynamicAudioUrl] = useState(
    item.audioUrl || ""
  );
  
  // Voice Audio State
  const [isPlayingAudio, setIsPlayingAudio] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Fetch dynamic system settings for guide video & voice audio fallback
  useEffect(() => {
    fetch("/api/system-settings")
      .then(r => r.json())
      .then(data => {
        if (data) {
          if (!item.tutorialVideoUrl && (data.guide_video_url || data.guideVideoUrl)) {
            setDynamicGuideUrl(data.guide_video_url || data.guideVideoUrl);
          }
          if (!item.audioUrl && (data.guide_audio_url || data.guideAudioUrl)) {
            setDynamicAudioUrl(data.guide_audio_url || data.guideAudioUrl);
          }
        }
      })
      .catch(err => console.warn("LinkUnlockModal settings sync notice", err));
  }, [item.tutorialVideoUrl, item.audioUrl]);

  // Audio Voice Guide Engine
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        console.warn("Speech cancel notice", e);
      }
    }

    if (dynamicAudioUrl) {
      const audio = new Audio(dynamicAudioUrl);
      audioRef.current = audio;
      audio.autoplay = true;
      audio.loop = false;

      const handleAudioEnded = () => {
        setIsPlayingAudio(false);
      };

      audio.addEventListener('ended', handleAudioEnded);

      audio.play().then(() => {
        setIsPlayingAudio(true);
      }).catch(err => {
        console.warn("Auto-audio play prevented by browser policy:", err);
        setIsPlayingAudio(false);
      });

      return () => {
        audio.removeEventListener('ended', handleAudioEnded);
        audio.pause();
        audio.src = "";
      };
    } else {
      setIsPlayingAudio(false);
    }
  }, [dynamicAudioUrl]);

  const toggleAudioPlayback = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (audioRef.current) {
      if (isPlayingAudio) {
        audioRef.current.pause();
        setIsPlayingAudio(false);
      } else {
        audioRef.current.play().then(() => setIsPlayingAudio(true));
      }
    } else {
      setIsPlayingAudio(!isPlayingAudio);
    }
  };

  const toggleMute = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    } else {
      setIsMuted(!isMuted);
    }
  };

  // Icons & National Flag Emblems for Track Cards
  const OriginalFilmIcon = (
    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-md border border-slate-700 bg-slate-800/90 flex items-center justify-center text-white shrink-0 shadow-inner">
      <Clapperboard size={14} className="text-slate-200" />
    </div>
  );

  const VideoClipIcon = (
    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-md border border-slate-700 bg-slate-800/90 flex items-center justify-center text-white shrink-0 shadow-inner">
      <Film size={14} className="text-slate-200" />
    </div>
  );

  const IndiaFlag = (
    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-md border border-slate-700 overflow-hidden shrink-0 shadow">
      <svg className="w-full h-full object-cover" viewBox="0 0 640 480">
        <path fill="#f93" d="M0 0h640v160H0z"/>
        <path fill="#fff" d="M0 160h640v160H0z"/>
        <path fill="#128807" d="M0 320h640v160H0z"/>
        <circle cx="320" cy="240" r="50" fill="none" stroke="#000080" strokeWidth="8"/>
        <circle cx="320" cy="240" r="16" fill="#000080"/>
      </svg>
    </div>
  );

  const BangladeshFlag = (
    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-md border border-slate-700 overflow-hidden shrink-0 shadow">
      <svg className="w-full h-full object-cover" viewBox="0 0 640 480">
        <path fill="#006a4e" d="M0 0h640v480H0z"/>
        <circle cx="320" cy="240" r="140" fill="#f42a41"/>
      </svg>
    </div>
  );

  const UKFlag = (
    <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-md border border-slate-700 overflow-hidden shrink-0 shadow">
      <svg className="w-full h-full object-cover" viewBox="0 0 640 480">
        <path fill="#012169" d="M0 0h640v480H0z"/>
        <path stroke="#fff" strokeWidth="60" d="m0 0 640 480M640 0 0 480"/>
        <path stroke="#c8102e" strokeWidth="40" d="m0 0 640 480M640 0 0 480"/>
        <path stroke="#fff" strokeWidth="100" d="M320 0v480M0 240h640"/>
        <path stroke="#c8102e" strokeWidth="60" d="M320 0v480M0 240h640"/>
      </svg>
    </div>
  );

  // Normalize language keys to match admin checkbox state
  const isVideo = type === 'video' || (item as any).mediaType === 'video';
  const rawLangs = Array.isArray(item.languages) && item.languages.length > 0 ? item.languages : [];
  const normalizedLangs = rawLangs.map(l => (l || '').toLowerCase().trim());

  // Deep Rich Content-Specific Theme Engine (Solid, Deep Saturated Colors)
  const contentTheme = useMemo(() => {
    if (isVideo) {
      return {
        key: 'video',
        label: t('tabs.videos', 'ভিডিও ডাউনলোড'),
        badgeClass: 'bg-purple-950/90 text-purple-300 border-purple-800/80',
        activeRing: 'ring-2 ring-purple-600 border-purple-600',
        headerIconColor: 'text-purple-400',
        buttonClass: 'bg-[#7C3AED] hover:bg-[#6D28D9] active:bg-[#5B21B6] text-white font-extrabold shadow-lg shadow-purple-950/60 border border-purple-400/90',
        buttonTextColor: 'text-white',
        iconColor: 'text-white',
      };
    }

    const m = item as Movie;
    // 1. Adult Movies (18+)
    const isAdult = (
      m.contentType === 'adult_movie' ||
      m.category === 'Adult Movies' ||
      Boolean(m.genre && (m.genre.toLowerCase().includes('adult') || m.genre.toLowerCase().includes('18+'))) ||
      Boolean(m.title && (m.title.toLowerCase().includes('adult') || m.title.toLowerCase().includes('18+')))
    );
    if (isAdult) {
      return {
        key: 'adult',
        label: t('tabs.adult_movies', '১৮+ অ্যাডাল্ট মুভি লিংক'),
        badgeClass: 'bg-rose-950/90 text-rose-300 border-rose-800/80',
        activeRing: 'ring-2 ring-rose-500 border-rose-500',
        headerIconColor: 'text-rose-400',
        buttonClass: 'bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white font-extrabold shadow-lg shadow-rose-950/60 border border-red-500/90',
        buttonTextColor: 'text-white',
        iconColor: 'text-white',
      };
    }

    // 2. Web Series
    const isSeries = (
      m.contentType === 'series' ||
      m.genre?.toLowerCase().includes('series') ||
      m.genre?.toLowerCase().includes('season') ||
      m.title?.toLowerCase().includes('season') ||
      m.title?.toLowerCase().includes('series') ||
      m.title?.toLowerCase().includes('pack') ||
      Boolean(m.totalEpisodes)
    );
    if (isSeries) {
      return {
        key: 'series',
        label: t('tabs.series', 'ওয়েব সিরিজ লিংক'),
        badgeClass: 'bg-sky-950/90 text-sky-300 border-sky-800/80',
        activeRing: 'ring-2 ring-blue-500 border-blue-500',
        headerIconColor: 'text-sky-400',
        buttonClass: 'bg-[#0284C7] hover:bg-[#0369A1] active:bg-[#075985] text-white font-extrabold shadow-lg shadow-sky-950/60 border border-sky-400/90',
        buttonTextColor: 'text-white',
        iconColor: 'text-white',
      };
    }

    // 3. Drama & Bangla Natok
    const isDrama = (
      m.contentType === 'drama' ||
      m.genre?.toLowerCase().includes('natok') ||
      m.genre?.toLowerCase().includes('drama') ||
      m.title?.toLowerCase().includes('natok')
    );
    if (isDrama) {
      return {
        key: 'drama',
        label: t('tabs.drama', 'বাংলা নাটক ও টেলিফিল্ম'),
        badgeClass: 'bg-emerald-950/90 text-emerald-300 border-emerald-800/80',
        activeRing: 'ring-2 ring-emerald-500 border-emerald-500',
        headerIconColor: 'text-emerald-400',
        buttonClass: 'bg-[#059669] hover:bg-[#047857] active:bg-[#065F46] text-white font-extrabold shadow-lg shadow-emerald-950/60 border border-emerald-400/90',
        buttonTextColor: 'text-white',
        iconColor: 'text-white',
      };
    }

    // 4. Default: Cinema Movies
    return {
      key: 'movie',
      label: t('tabs.movies', 'সিনেমা মুভি লিংক'),
      badgeClass: 'bg-amber-950/90 text-amber-300 border-amber-800/80',
      activeRing: 'ring-2 ring-amber-500 border-amber-500',
      headerIconColor: 'text-amber-400',
      buttonClass: 'bg-[#E5A00D] hover:bg-[#D97706] active:bg-[#B45309] text-black font-extrabold shadow-lg shadow-amber-950/60 border border-amber-400/90',
      buttonTextColor: 'text-black',
      iconColor: 'text-black',
    };
  }, [item, isVideo, t]);

  // Strictly respect Admin language selection
  const hasOriginal = normalizedLangs.length === 0 
    ? true 
    : normalizedLangs.some(l => l.includes('original') || l.includes('org'));

  const hasHindi = normalizedLangs.some(l => l.includes('hindi') || l.includes('hi'));
  const hasBangla = normalizedLangs.some(l => l.includes('bangla') || l.includes('bn'));
  const hasEnglish = normalizedLangs.some(l => l.includes('english') || l.includes('en'));

  // Build the specific Dubbing / Video Cards with solid fallback target URLs
  const dubOptions: DubOption[] = [];

  const baseFallback = item.videoUrl?.trim() || 
                       item.banglaLink?.trim() || 
                       (item as any).originalLink?.trim() || 
                       `https://t.me/myteleflix`;

  if (!isVideo) {
    // 1. Original Language
    if (hasOriginal) {
      dubOptions.push({
        id: 'original',
        titleBn: 'অরিজিনাল প্রিন্ট',
        flagSvg: OriginalFilmIcon,
        badgeText: '1080P',
        fileSize: (item as any).fileSize || '2.3 GB',
        targetUrl: item.originalLink?.trim() || item.videoUrl?.trim() || baseFallback,
      });
    }

    // 2. Bangla Dubbed (Prioritized for audience)
    if (hasBangla) {
      dubOptions.push({
        id: 'bangla',
        titleBn: 'বাংলা ডাবিং',
        flagSvg: BangladeshFlag,
        badgeText: '1080P',
        fileSize: '2.4 GB',
        targetUrl: item.banglaLink?.trim() || baseFallback,
      });
    }

    // 3. Hindi Dubbed
    if (hasHindi) {
      dubOptions.push({
        id: 'hindi',
        titleBn: 'হিন্দি ডাব',
        flagSvg: IndiaFlag,
        badgeText: '1080P',
        fileSize: '2.5 GB',
        targetUrl: item.hindiLink?.trim() || baseFallback,
      });
    }

    // 4. English Dubbed
    if (hasEnglish) {
      dubOptions.push({
        id: 'english',
        titleBn: 'ইংলিশ ডাব',
        flagSvg: UKFlag,
        badgeText: '1080P',
        fileSize: '2.2 GB',
        targetUrl: item.englishLink?.trim() || baseFallback,
      });
    }

    // Fallback if no specific dub matched
    if (dubOptions.length === 0) {
      dubOptions.push({
        id: 'original',
        titleBn: 'অরিজিনাল প্রিন্ট',
        flagSvg: OriginalFilmIcon,
        badgeText: '1080P',
        fileSize: (item as any).fileSize || '2.3 GB',
        targetUrl: baseFallback,
      });
    }
  } else {
    // Dedicated Single Video Clip Download Card
    dubOptions.push({
      id: 'video_direct',
      titleBn: 'ডাইরেক্ট ভিডিও লিংক',
      subtitle: 'হাই-স্পিড সার্ভার',
      flagSvg: VideoClipIcon,
      badgeText: '1080P',
      fileSize: (item as any).fileSize || '1.2 GB',
      targetUrl: item.videoUrl?.trim() || baseFallback,
    });
  }

  // Handle Download Click: Instant synchronous opening to eliminate popup blocker drops
  const handleDownloadClick = (option: DubOption) => {
    setSelectedTrackId(option.id);
    setIsRedirecting(true);
    setErrorMsg("");
    setRedirectStatus(`${option.titleBn} লিংক ওপেন হচ্ছে...`);

    // Guaranteed destination URL with safe fallback
    const destination = option.targetUrl?.trim() || 
                        item.banglaLink?.trim() || 
                        item.videoUrl?.trim() || 
                        item.hindiLink?.trim() || 
                        item.englishLink?.trim() || 
                        `https://t.me/myteleflix`;

    // Immediately display the Ready Link banner so user ALWAYS has a 1-tap direct button
    setReadyLink({ url: destination, title: option.titleBn });

    // Open synchronously inside touch event stack to prevent mobile popup blocking
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg) {
        if (destination.includes('t.me/') && typeof tg.openTelegramLink === 'function') {
          tg.openTelegramLink(destination);
        } else if (typeof tg.openLink === 'function') {
          tg.openLink(destination);
        } else {
          window.open(destination, "_blank", "noopener,noreferrer");
        }
      } else {
        const win = window.open(destination, "_blank", "noopener,noreferrer");
        if (!win || win.closed || typeof win.closed === 'undefined') {
          // Popup blocker detected - the Ready Link button below handles direct user navigation
          setRedirectStatus("নিচের 'সরাসরি ওপেন করুন' বাটনে চাপুন।");
        }
      }
    } catch (e) {
      console.warn("Synchronous window.open error handled by ready banner:", e);
    }

    // Fire API task logging in the background without blocking the user
    try {
      const savedUser = localStorage.getItem("myteleflix_user");
      const currentUserId = savedUser ? JSON.parse(savedUser).id : userId;

      fetch("/api/tasks/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: currentUserId,
          taskId: item.id,
          language: option.titleBn,
          requestedUrl: destination
        }),
      }).catch((err) => console.warn("Task tracking background notice:", err));
    } catch (err) {
      console.warn("Background tracking notice:", err);
    }

    setTimeout(() => {
      setIsRedirecting(false);
      setSelectedTrackId(null);
    }, 600);
  };

  const handleOpenTelegramGuide = () => {
    const url = dynamicGuideUrl || "https://t.me/myteleflix";
    const tg = (window as any).Telegram?.WebApp;
    if (tg && typeof tg.openLink === 'function') {
      tg.openLink(url);
    } else {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <div 
      id="link-unlock-modal" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-150"
    >
      {/* Main Modal Container with deep organic dark styling */}
      <div className="bg-[#0A0E1A] border border-[#1E293B] text-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-200 flex flex-col max-h-[94vh] sm:max-h-[90vh]">
        
        {/* Header Bar */}
        <div className="px-4 sm:px-5 py-3 border-b border-[#1A2333] bg-[#070A12] flex items-center justify-between gap-2 shrink-0 relative">
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 px-3 py-1.5 rounded-xl cursor-pointer transition active:scale-95 shrink-0 shadow-sm z-10 select-none"
          >
            <ArrowLeft size={14} />
            <span>ফিরে যান</span>
          </button>

          <div className="text-center truncate px-2 flex-1 min-w-0 space-y-0.5">
            <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide truncate">
              {item.title}
            </h3>
            <div className="flex items-center justify-center gap-1.5 pt-0.5">
              <span className={`text-[9px] font-bold tracking-wide uppercase px-2 py-0.5 rounded-full border ${contentTheme.badgeClass}`}>
                {contentTheme.label}
              </span>
            </div>
          </div>

          <div className="w-[58px] shrink-0 pointer-events-none" />
        </div>

        {/* Scrollable Content Body with Clean Margins */}
        <div className="p-3 sm:p-5 overflow-y-auto space-y-3.5 no-scrollbar pb-12 sm:pb-16 bg-[#0A0E1A]">

          {/* Guest Mode Earning Prompt Banner */}
          {(!auth.currentUser || auth.currentUser.isAnonymous) && (
            <div className="mx-1 sm:mx-2 p-3 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 border border-amber-500/40 flex items-center justify-between gap-2 shadow-lg">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-base shrink-0">🌟</span>
                <p className="text-[11px] text-amber-200 font-medium leading-tight">
                  Want to EARN from this download? Sign up now to unlock your VIP Wallet!
                </p>
              </div>
              <a
                href="/?action=signup"
                className="px-2.5 py-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] tracking-wide shrink-0 transition"
              >
                Sign Up
              </a>
            </div>
          )}

          {/* 1. TUTORIAL VIDEO PLAYER PROMPT */}
          <div 
             onClick={handleOpenTelegramGuide}
             className="mx-1 sm:mx-2 rounded-2xl border-2 border-red-500/80 bg-[#070A12] p-2.5 sm:p-4 relative overflow-hidden group cursor-pointer transition-all duration-150 ease-out active:scale-[0.98] hover:border-red-400 shadow-2xl"
           >
             <p className="text-slate-100 text-[11px] sm:text-xs font-bold text-center leading-snug px-1 mb-2 drop-shadow-sm">
               {t('modal.tutorial_prompt', 'ডাউনলোড করতে সমস্যা? নিচের ছবিতে চাপ দিয়ে গাইড ভিডিওটি দেখে নিন।')}
             </p>

            {/* Guide Video Poster Screen with Dynamic Cinematic Artwork & Live Pulse Ripple Animations */}
            <div className="rounded-2xl overflow-hidden border border-red-500/40 shadow-2xl relative aspect-[16/9] w-full bg-[#070A12] flex items-center justify-center group/poster">
              {/* Actual Cinematic Backdrop Poster Image with Ambient Hover Zoom */}
              <img 
                src={
                  (item as any).poster || 
                  (item as any).thumbnailUrl || 
                  (item as any).posterUrl || 
                  _guideVideoLogoUrl || 
                  "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&h=675&q=85"
                }
                alt="Tutorial Guide Video Poster"
                className="absolute inset-0 w-full h-full object-cover opacity-55 group-hover/poster:scale-105 transition-transform duration-500 ease-out"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&h=675&q=85";
                }}
              />
              
              {/* Dark Cinema Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-black/60 to-black/40" />

              {/* Top-Left Live Recording / Guide Indicator */}
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10 pointer-events-none bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-red-500/40 shadow-md">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
                </span>
                <span className="text-[9px] sm:text-[10px] uppercase tracking-wider font-bold text-slate-200 leading-none">
                  {t('modal.tutorial_guide', 'টিউটোরিয়াল গাইড')}
                </span>
              </div>

              {/* Centered High-Contrast Red Play Icon with Expanding Radar Pulse Rings */}
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-none p-2">
                <div className="relative flex items-center justify-center mb-2 sm:mb-2.5">
                  {/* Expanding Radar Wave Pulse Rings */}
                  <span className="absolute w-14 h-14 sm:w-18 sm:h-18 rounded-full bg-red-600/30 animate-ping pointer-events-none" />
                  <span className="absolute w-18 h-18 sm:w-22 sm:h-22 rounded-full bg-red-500/20 animate-pulse pointer-events-none" />
                  
                  {/* Embedded Glowing Red Play Button */}
                  <div className="relative w-12 h-12 sm:w-15 sm:h-15 rounded-full bg-[#E51E2B] text-white flex items-center justify-center shadow-[0_0_30px_rgba(229,30,43,0.8)] group-hover/poster:scale-110 transition-transform duration-200 border-2 border-white ring-4 ring-[#E51E2B]/40">
                    <Play size={22} className="fill-white translate-x-0.5" />
                  </div>
                </div>
                
                {/* Central Action Prompt Bar with Converging Directional Arrow Animations */}
                <div className="flex items-center gap-2 bg-[#0C121E]/90 backdrop-blur-md text-slate-100 font-bold text-[11px] sm:text-xs px-4 py-1.5 rounded-full border border-red-500/40 shadow-xl group-hover/poster:border-red-400 transition-colors">
                  <ArrowRight size={13} className="text-red-400 animate-pulse shrink-0" />
                  <span className="tracking-wide whitespace-nowrap text-white font-semibold">
                    {t('modal.watch_guide', 'গাইড ভিডিও দেখতে এখানে চাপুন')}
                  </span>
                  <ArrowLeft size={13} className="text-red-400 animate-pulse shrink-0" />
                </div>
              </div>
            </div>
          </div>

          {/* Voice Audio Options Bar */}
          {dynamicAudioUrl && (
            <div className="mx-1 sm:mx-2 rounded-2xl py-2 px-3 bg-[#070A12] border border-[#1A2333] flex items-center justify-between gap-2 shadow-md">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-lg bg-slate-800 text-white border border-slate-700 flex items-center justify-center shrink-0">
                  <Mic size={14} className={isPlayingAudio ? "text-red-500" : "text-slate-400"} />
                </div>
                <span className="text-xs font-bold text-white truncate">
                  {t('modal.voice_guide', 'ভয়েস গাইড')}
                </span>
                {isPlayingAudio && (
                  <span className="w-2 h-2 rounded-full bg-red-500 shrink-0 animate-ping" />
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={toggleAudioPlayback}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-xl border border-slate-700 text-[10px] font-bold transition flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 shadow-sm"
                >
                  {isPlayingAudio ? <Pause size={11} /> : <Play size={11} />}
                  <span>{isPlayingAudio ? t('action.pause', 'থামান') : t('action.listen', 'শুনুন')}</span>
                </button>
                <button
                  type="button"
                  onClick={toggleMute}
                  className="p-1 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-white transition cursor-pointer shrink-0 active:scale-95"
                  title={isMuted ? "আনমিউট" : "মিউট"}
                >
                  {isMuted ? <VolumeX size={13} /> : <Volume2 size={13} />}
                </button>
              </div>
            </div>
          )}

          {/* Ready Link Interactive Card (Always provides 100% reliable 1-tap open & copy) */}
          {readyLink && (
            <div className="mx-1 sm:mx-2 p-3 sm:p-3.5 bg-[#051710] border border-emerald-500/50 rounded-2xl space-y-2 shadow-xl animate-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between gap-2 text-emerald-400">
                <div className="flex items-center gap-2 font-bold text-xs sm:text-sm">
                  <CheckCircle size={16} className="shrink-0 text-emerald-400" />
                  <span>{t('modal.ready_link', 'লিংক প্রস্তুত')} ({readyLink.title})</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                  {t('modal.ready_sub', 'সক্রিয়')}
                </span>
              </div>
              <div className="flex flex-col xs:flex-row items-center gap-2 pt-0.5">
                <a
                  href={readyLink.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full xs:flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 active:scale-[0.98] text-slate-950 font-bold text-xs tracking-wide flex items-center justify-center gap-2 shadow-lg transition-all select-none cursor-pointer"
                >
                  <ExternalLink size={14} className="shrink-0" />
                  <span>{t('action.open_direct', 'সরাসরি ওপেন করুন')}</span>
                </a>
                <button
                  type="button"
                  onClick={() => {
                    if (navigator.clipboard) {
                      navigator.clipboard.writeText(readyLink.url);
                      setCopiedLink(true);
                      setTimeout(() => setCopiedLink(false), 2500);
                    }
                  }}
                  className="w-full xs:w-auto py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-transform active:scale-95 select-none cursor-pointer"
                >
                  {copiedLink ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  <span>{copiedLink ? t('action.copied', 'কপি হয়েছে') : t('action.copy', 'কপি')}</span>
                </button>
              </div>
            </div>
          )}

          {/* 2. DUBBING SELECTION OR VIDEO DIRECT DOWNLOAD */}
          <div className="space-y-2.5 pt-0.5 w-full mx-auto relative">
            {isVideo ? (
              <div className="mx-1 sm:mx-2 space-y-3 flex flex-col items-center justify-center">
                <div className="flex items-center justify-center w-full">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#070A12] border border-[#1A2333] text-slate-300 shadow-sm">
                    <ShieldCheck size={13} className="text-purple-400 shrink-0" />
                    <span className="text-[11px] font-bold tracking-wide uppercase text-slate-200">
                      {t('modal.direct_video', 'সরাসরি ভিডিও ডাউনলোড')}
                    </span>
                  </div>
                </div>

                {dubOptions[0] && (
                  <button
                    type="button"
                    disabled={isRedirecting}
                    onClick={() => handleDownloadClick(dubOptions[0])}
                    className={`w-full max-w-[270px] py-3 px-5 rounded-2xl active:scale-[0.98] font-black text-xs sm:text-sm tracking-wider transition-all flex items-center justify-center gap-2 shadow-xl cursor-pointer select-none ${contentTheme.buttonClass}`}
                  >
                    {isRedirecting && selectedTrackId === dubOptions[0].id ? (
                      <>
                        <Loader2 size={16} className="animate-spin" />
                        <span>{t('action.opening', 'OPENING...')}</span>
                      </>
                    ) : (
                      <>
                        <Download size={16} strokeWidth={2.6} className="shrink-0" />
                        <span>{t('action.download', 'DOWNLOAD')}</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between px-1 max-w-[92%] sm:max-w-[90%] mx-auto w-full">
                  <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                    <ShieldCheck size={16} className={contentTheme.headerIconColor} />
                    <span>{t('modal.available_links', 'উপলব্ধ ভাষার লিংকসমূহ')}</span>
                  </h3>
                </div>

                <div className="space-y-2 w-full flex flex-col items-center">
                  {dubOptions.map((option) => {
                    const optTitle = 
                      option.id === 'original' ? 'Original Audio' :
                      option.id === 'bangla' ? 'Bengali Dubbed' :
                      option.id === 'hindi' ? 'Hindi Dubbed' :
                      option.id === 'english' ? 'English Dubbed' :
                      option.titleBn;

                    return (
                      <div
                        key={option.id}
                        onClick={() => handleDownloadClick(option)}
                        className={`w-full max-w-[92%] sm:max-w-[90%] mx-auto flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-2xl bg-[#0C121E] border border-[#1E293B] hover:border-slate-600 transition-all duration-150 cursor-pointer shadow-md select-none active:scale-[0.98] ${
                          selectedTrackId === option.id && adModalOpen
                            ? "border-cyan-500 ring-2 ring-cyan-500/30"
                            : ""
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0 flex-1 overflow-hidden">
                          {option.flagSvg}
                          <div className="min-w-0 flex-1">
                            <span className="text-xs sm:text-sm font-bold text-white tracking-wide truncate block">
                              {optTitle}
                            </span>
                            {option.subtitle && (
                              <span className="text-[10px] text-slate-400 font-mono truncate block">
                                {option.subtitle}
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadClick(option);
                          }}
                          className={`shrink-0 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider whitespace-nowrap flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95 transition-all select-none ${contentTheme.buttonClass}`}
                        >
                          <Download size={13} strokeWidth={2.4} className="shrink-0" />
                          <span>{t('action.download', 'DOWNLOAD')}</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>

          {/* Status Message Display */}
          {isRedirecting && (
            <div className="mx-1 sm:mx-2 p-2.5 bg-[#070A12] border border-[#1E293B] rounded-2xl flex items-center gap-2 text-xs text-white shadow-md animate-in fade-in">
              <Loader2 size={14} className="animate-spin text-emerald-400 shrink-0" />
              <span className="truncate">{redirectStatus || "লিংক ওপেন হচ্ছে..."}</span>
            </div>
          )}

          {errorMsg && (
            <div className="mx-1 sm:mx-2 p-2.5 bg-red-950/80 border border-red-800/80 rounded-2xl text-xs text-red-300 shadow-md">
              {errorMsg}
            </div>
          )}

        </div>
      </div>

      {/* Phase 1: High-CPM Custom Video Ad & 15-Second Timer Modal */}
      {adModalOpen && selectedAdOption && (
        <DownloadAdTimerModal
          isOpen={adModalOpen}
          item={item}
          selectedOption={selectedAdOption}
          onClose={() => setAdModalOpen(false)}
          onSuccess={() => {
            setAdModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
