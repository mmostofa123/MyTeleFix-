/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Notification, NotificationType } from "../types";
import { markNoticeAsSeen } from "../NoticeBox";
import { 
  Bell, 
  CheckCheck, 
  X, 
  CheckCircle2, 
  ShieldAlert, 
  Trophy, 
  Coins, 
  AlertTriangle, 
  Inbox, 
  Clock, 
  Layers
} from "lucide-react";

interface NotificationCenterTrayProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
  onClearAll?: () => void;
  unreadCount: number;
}

type TabKey = 'All' | 'Unread' | 'System';

export const NotificationCenterTray: React.FC<NotificationCenterTrayProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkRead,
  onMarkAllRead,
  onClearAll,
  unreadCount
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('All');

  // When Tray is opened, record all visible notifications as seen in seen_notice_ids
  // and trigger onMarkAllRead so the red glowing alert light immediately turns OFF.
  useEffect(() => {
    if (isOpen && notifications.length > 0) {
      notifications.forEach((n) => {
        const id = n.notification_id || n.id;
        if (id) markNoticeAsSeen(id);
      });
      if (unreadCount > 0) {
        onMarkAllRead();
      }
    }
  }, [isOpen, notifications, unreadCount, onMarkAllRead]);

  if (!isOpen) return null;

  const handleClear = () => {
    if (onClearAll) {
      onClearAll();
    } else {
      try {
        localStorage.removeItem("myteleflix_notifications");
        localStorage.removeItem("myteleflix_system_notices");
        window.dispatchEvent(new CustomEvent("myteleflix_notices_cleared"));
        window.dispatchEvent(new CustomEvent("myteleflix_notices_updated"));
      } catch (e) {}
    }
  };

  // Filter based on active tab
  const filteredNotifications = notifications.filter(n => {
    const isUnread = !(n.is_read ?? n.isRead);
    if (activeTab === 'Unread') return isUnread;
    if (activeTab === 'System') return (n.type || 'SYSTEM').toUpperCase() === 'SYSTEM' || (n.type || '').toUpperCase() === 'SECURITY';
    return true;
  });

  const getTabCounts = () => {
    return {
      All: notifications.length,
      Unread: unreadCount,
      System: notifications.filter(n => (n.type || 'SYSTEM').toUpperCase() === 'SYSTEM' || (n.type || '').toUpperCase() === 'SECURITY').length
    };
  };

  const counts = getTabCounts();

  const renderTypeIcon = (notif: Notification) => {
    const type = (notif.type || '').toUpperCase();
    if (type === 'VERIFICATION') {
      return <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />;
    }
    if (type === 'SALARY') {
      return <Coins size={15} className="text-amber-400 shrink-0" />;
    }
    if (type === 'SECURITY') {
      return <ShieldAlert size={15} className="text-rose-400 shrink-0" />;
    }
    if (type === 'MILESTONE') {
      return <Trophy size={15} className="text-cyan-400 shrink-0" />;
    }
    if (notif.title?.includes("⚠️") || notif.title?.includes("Inactivity") || notif.title?.includes("নিষ্ক্রিয়তা")) {
      return <AlertTriangle size={15} className="text-amber-400 shrink-0" />;
    }
    return <Bell size={15} className="text-indigo-400 shrink-0" />;
  };

  const getTypeBadge = (notif: Notification) => {
    const type = (notif.type || 'SYSTEM').toUpperCase();
    switch (type) {
      case 'VERIFICATION':
        return <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">VERIFY</span>;
      case 'SALARY':
        return <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">SALARY</span>;
      case 'SECURITY':
        return <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">SECURITY</span>;
      case 'MILESTONE':
        return <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">MILESTONE</span>;
      default:
        return <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-slate-500/10 text-slate-300 border border-slate-500/20">SYSTEM</span>;
    }
  };

  return (
    <div 
      id="notification-center-overlay" 
      className="fixed inset-0 z-50 flex items-start justify-end sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="notification-center-tray"
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:w-[420px] h-full sm:h-[620px] max-h-screen bg-[#111216] border border-[#262832] sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden text-left animate-in slide-in-from-right-4 duration-200"
      >
        {/* Tray Header */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#16171E] border-b border-[#242632] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0">
              <Bell size={16} />
            </div>
            <h3 className="text-base sm:text-[17px] font-bold text-white tracking-tight truncate">
              নোটিশ বোর্ড
            </h3>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Button 1: [ 👀 দেখেছি ] */}
            <button
              type="button"
              id="btn-mark-all-read"
              onClick={onMarkAllRead}
              title="সবগুলো পঠিত হিসেবে চিহ্নিত করুন"
              className="px-2.5 py-1.5 rounded-xl bg-[#1D1E26] hover:bg-[#272834] active:bg-[#323342] text-slate-200 hover:text-white border border-white/10 text-[11px] sm:text-xs font-semibold flex items-center gap-1 transition cursor-pointer select-none"
            >
              <span>👀</span>
              <span>দেখেছি</span>
            </button>

            {/* Button 2: [ 🗑️ ক্লিয়ার ] */}
            <button
              type="button"
              id="btn-clear-all-notifs"
              onClick={handleClear}
              title="সব নোটিশ মুছে ফেলুন"
              className="px-2.5 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 active:bg-rose-900 text-rose-300 hover:text-rose-100 border border-rose-800/40 text-[11px] sm:text-xs font-semibold flex items-center gap-1 transition cursor-pointer select-none"
            >
              <span>🗑️</span>
              <span>ক্লিয়ার</span>
            </button>

            {/* Far Right: Simple ✕ Close Icon with high contrast */}
            <button
              type="button"
              id="btn-close-notification-tray"
              onClick={onClose}
              className="p-1.5 sm:p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.14] active:bg-white/[0.2] text-slate-300 hover:text-white border border-white/[0.1] transition cursor-pointer shrink-0 ml-0.5"
              aria-label="Close tray"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Tab Filters: All, Unread, System */}
        <div className="px-4 py-2.5 bg-[#13141A] border-b border-[#22242E] flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          {(['All', 'Unread', 'System'] as TabKey[]).map((tab) => {
            const isActive = activeTab === tab;
            const count = counts[tab];
            return (
              <button
                key={tab}
                type="button"
                id={`tab-notif-${tab.toLowerCase()}`}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04] border border-transparent'
                }`}
              >
                <span>{tab}</span>
                {count > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isActive ? 'bg-amber-400 text-black' : 'bg-white/10 text-slate-400'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Notification Cards List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 scrollbar-thin">
          {filteredNotifications.length === 0 ? (
            <div className="py-16 text-center flex flex-col items-center justify-center px-4">
              <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-center text-slate-500 mb-3">
                <Inbox size={24} />
              </div>
              <h4 className="text-sm font-semibold text-slate-300">
                {activeTab === 'Unread' ? 'All caught up!' : `No ${activeTab} notifications`}
              </h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                {activeTab === 'Unread' 
                  ? 'You have read all received alerts. Any new events will appear here in real-time.' 
                  : 'System event broadcasts and status updates will be logged here.'}
              </p>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const isUnread = !(notif.is_read ?? notif.isRead);
              const notifId = notif.notification_id || notif.id;
              const dateStr = notif.created_at || notif.timestamp;
              const formattedDate = dateStr 
                ? new Date(dateStr).toLocaleString(undefined, { 
                    month: 'short', 
                    day: 'numeric', 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })
                : 'Recent';

              return (
                <div
                  key={notifId}
                  id={`notif-card-${notifId}`}
                  onClick={() => {
                    if (isUnread) {
                      onMarkRead(notifId);
                    }
                  }}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer select-none group relative ${
                    isUnread
                      ? 'bg-[#181B26] border-amber-500/30 hover:border-amber-500/60 shadow-[0_2px_12px_rgba(245,158,11,0.06)]'
                      : 'bg-[#13141A] border-[#22242E] hover:border-[#2D303E] opacity-80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="p-1.5 rounded-lg bg-white/[0.04] border border-white/[0.08]">
                        {renderTypeIcon(notif)}
                      </div>
                      <span className={`text-xs font-bold truncate ${isUnread ? 'text-white' : 'text-slate-300'}`}>
                        {notif.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {getTypeBadge(notif)}
                      {isUnread && (
                        <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0 shadow-[0_0_8px_#F59E0B]" />
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 mt-2 leading-relaxed whitespace-pre-line font-normal">
                    {notif.message}
                  </p>

                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/[0.04] text-[10px] text-slate-500 font-mono">
                    <div className="flex items-center gap-1">
                      <Clock size={11} className="text-slate-500" />
                      <span>{formattedDate}</span>
                    </div>

                    {isUnread ? (
                      <span className="text-amber-400/90 group-hover:underline">
                        Tap to mark as read
                      </span>
                    ) : (
                      <span className="text-slate-600 flex items-center gap-1">
                        <CheckCheck size={11} /> Read
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Tray Footer info */}
        <div className="px-5 py-2.5 bg-[#14151B] border-t border-[#22242E] flex items-center justify-between text-[10px] text-slate-500 font-mono shrink-0">
          <div className="flex items-center gap-1.5">
            <Layers size={11} className="text-slate-400" />
            <span>VRMS-3 NAE v12.0</span>
          </div>
          <span>Total: {notifications.length} alerts</span>
        </div>
      </div>
    </div>
  );
};
