/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  X,
  HelpCircle,
  RotateCcw,
  Check,
  Loader2,
} from "lucide-react";
import { PublicQuizQuestion, QuizAttemptResponse } from "../types";

export interface HumanVerificationQuizModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userId?: string;
}

export const HumanVerificationQuizModal: React.FC<HumanVerificationQuizModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  userId = "tg-101",
}) => {
  const [questions, setQuestions] = useState<PublicQuizQuestion[]>([]);
  const [attemptId, setAttemptId] = useState<string>("");
  const [, setQuestionSetVersion] = useState<string>("");
  const [resetsRemaining, setResetsRemaining] = useState<number>(5);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // 1. Fetch server-authoritative quiz questions (without answers)
  const fetchQuestions = useCallback(async () => {
    try {
      setIsLoading(true);
      setErrorMessage(null);
      const res = await fetch(`/api/quiz/get-questions?userId=${encodeURIComponent(userId)}`);
      if (!res.ok) {
        throw new Error("কুইজ প্রশ্ন লোড করা সম্ভব হয়নি।");
      }
      const data: QuizAttemptResponse = await res.json();
      setQuestions(data.questions || []);
      setAttemptId(data.attempt_id);
      setQuestionSetVersion(data.question_set_version);
      setResetsRemaining(typeof data.resets_remaining === "number" ? data.resets_remaining : 5);
      setSelectedAnswers({});
    } catch (err: any) {
      setErrorMessage(err.message || "কুইজ প্রশ্ন লোড করতে সমস্যা হয়েছে।");
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  // Load questions when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchQuestions();
    } else {
      setSelectedAnswers({});
      setErrorMessage(null);
      setSuccessMessage(null);
    }
  }, [isOpen, fetchQuestions]);

  // 5-second auto-dismiss for top-floating alerts (Non-negotiable specification)
  useEffect(() => {
    if (!errorMessage) return;
    const timer = setTimeout(() => {
      setErrorMessage(null);
    }, 5000);
    return () => clearTimeout(timer);
  }, [errorMessage]);

  useEffect(() => {
    if (!successMessage) return;
    const timer = setTimeout(() => {
      setSuccessMessage(null);
    }, 5000);
    return () => clearTimeout(timer);
  }, [successMessage]);

  if (!isOpen) return null;

  const handleSelectOption = (questionId: number, optionId: string) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionId,
    }));
    setErrorMessage(null);
  };

  // Handle server-authoritative rate-limited reset & question shuffling
  const handleResetCaptcha = async () => {
    if (isResetting || isSubmitting) return;

    try {
      setIsResetting(true);
      setErrorMessage(null);
      setSuccessMessage(null);

      const res = await fetch("/api/quiz/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setErrorMessage(data.error || "খুব বেশি রিসেট অনুরোধ করা হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।");
        return;
      }

      setQuestions(data.questions || []);
      setAttemptId(data.attempt_id);
      setQuestionSetVersion(data.question_set_version || "");
      setResetsRemaining(typeof data.resets_remaining === "number" ? data.resets_remaining : 0);
      setSelectedAnswers({});
    } catch (err: any) {
      setErrorMessage("ক্যাপচা রিসেট ব্যর্থ হয়েছে। পুনরায় চেষ্টা করুন।");
    } finally {
      setIsResetting(false);
    }
  };

  // Submit answers for server-side evaluation
  const handleSubmit = async () => {
    const unanswered = questions.some((q) => !selectedAnswers[q.id]);
    if (unanswered) {
      setErrorMessage("দয়া করে ৩টি প্রশ্নেরই উত্তর নির্বাচন করুন।");
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMessage(null);

      const res = await fetch("/api/quiz/submit-answers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          attemptId,
          answers: selectedAnswers,
        }),
      });

      const data = await res.json();

      if (data.success && data.quiz_status === "PASSED") {
        setSuccessMessage("অভিনন্দন! হিউম্যান ভেরিফিকেশন সফল হয়েছে (৩/৩)।");
        setTimeout(() => {
          setIsSubmitting(false);
          onSuccess();
          onClose();
        }, 1200);
      } else {
        // Wrong submission:
        // Top-Floating Toast: "ভেরিফিকেশন ভুল হয়েছে! আবার চেষ্টা করুন।" with 5-second auto-dismiss
        setIsSubmitting(false);
        setErrorMessage("ভেরিফিকেশন ভুল হয়েছে! আবার চেষ্টা করুন।");
        setSelectedAnswers({});

        // Apply newly shuffled questions from server response
        if (data.newAttempt && Array.isArray(data.newAttempt.questions)) {
          setQuestions(data.newAttempt.questions);
          setAttemptId(data.newAttempt.attempt_id);
          setQuestionSetVersion(data.newAttempt.question_set_version || "");
          if (typeof data.newAttempt.resets_remaining === "number") {
            setResetsRemaining(data.newAttempt.resets_remaining);
          }
        } else {
          // Fallback fetch
          fetchQuestions();
        }
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage("সার্ভার যাচাইকরণে সমস্যা হয়েছে। আবার চেষ্টা করুন।");
    }
  };

  const answeredCount = Object.keys(selectedAnswers).length;

  return (
    <>
      {/* 1. TOP-FLOATING PROFESSIONAL NOTIFICATION TOAST (5-second auto-dismiss) */}
      {errorMessage && (
        <div
          id="quiz-floating-error-toast"
          role="alert"
          aria-live="assertive"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] w-[92%] max-w-md bg-gradient-to-r from-[#180808] via-[#240B0E] to-[#180808] border border-red-500/50 rounded-2xl p-3 sm:p-3.5 text-white shadow-[0_20px_50px_rgba(0,0,0,0.95),0_0_25px_rgba(239,68,68,0.25)] flex items-center justify-between gap-3 animate-in slide-in-from-top-4 duration-300 backdrop-blur-xl"
        >
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8 h-8 rounded-xl bg-red-950/90 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
              <AlertCircle size={17} />
            </div>
            <div className="min-w-0 flex-1">
              <span className="font-semibold text-xs sm:text-sm text-red-200 block truncate">
                {errorMessage}
              </span>
              <span className="text-[10px] text-red-300/70 font-mono block">
                নতুন প্রশ্ন লোড করা হয়েছে
              </span>
            </div>
          </div>
          <button
            type="button"
            id="btn-dismiss-quiz-error"
            onClick={() => setErrorMessage(null)}
            className="p-1 rounded-lg hover:bg-red-950 text-red-400 hover:text-white transition cursor-pointer shrink-0"
            title="Dismiss"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* TOP-FLOATING SUCCESS NOTIFICATION TOAST */}
      {successMessage && (
        <div
          id="quiz-floating-success-toast"
          role="alert"
          aria-live="polite"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] w-[92%] max-w-md bg-gradient-to-r from-[#07170F] via-[#0D2418] to-[#07170F] border border-emerald-500/50 rounded-2xl p-3 sm:p-3.5 text-white shadow-[0_20px_50px_rgba(0,0,0,0.95),0_0_25px_rgba(16,185,129,0.25)] flex items-center justify-between gap-3 animate-in slide-in-from-top-4 duration-300 backdrop-blur-xl"
        >
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8 h-8 rounded-xl bg-emerald-950/90 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <CheckCircle2 size={18} />
            </div>
            <span className="font-bold text-xs sm:text-sm text-emerald-200 truncate">
              {successMessage}
            </span>
          </div>
        </div>
      )}

      {/* MODAL BACKDROP & CARD */}
      <div
        id="human-quiz-modal-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div
          id="human-quiz-modal-card"
          className="w-full max-w-lg bg-[#0F141E] border border-[#1C2536] rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] p-4 sm:p-6 text-white relative overflow-hidden my-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Modal Header */}
          <div className="flex items-center justify-between pb-3 sm:pb-3.5 border-b border-[#1C2536] relative z-10">
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
              <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-[#090D14] border border-[#1C2536] flex items-center justify-center text-emerald-400 shrink-0">
                <HelpCircle size={22} />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-tight flex items-center gap-1.5 truncate">
                  <span>হিউম্যান ভেরিফিকেশন কুইজ</span>
                </h3>
                <p className="text-[10px] sm:text-[11px] text-slate-400 font-mono tracking-wider uppercase truncate mt-0.5">
                  ANTI-BOT CAPTCHA (৩টি প্রশ্নের সঠিক উত্তর দিন)
                </p>
              </div>
            </div>

            <button
              type="button"
              id="btn-close-quiz-modal"
              onClick={onClose}
              className="p-2 sm:p-2.5 rounded-2xl bg-[#090D14] hover:bg-[#1C2536] text-slate-400 hover:text-white border border-[#1C2536] transition cursor-pointer shrink-0 ml-2"
              title="বন্ধ করুন"
            >
              <X size={15} />
            </button>
          </div>

          {/* Status & Question Progress Tracker with Rate-Limited Quick Refresh */}
          <div className="my-3 sm:my-3.5 flex items-center justify-between bg-[#090D14] border border-[#1C2536] rounded-2xl px-3 sm:px-3.5 py-2 relative z-10 text-xs font-mono">
            <span className="text-slate-300 flex items-center gap-1.5 text-[11px] sm:text-xs">
              <CheckCircle2 size={13} className="text-emerald-400" />
              {answeredCount} / {questions.length} উত্তর দেওয়া হয়েছে
            </span>
            <button
              type="button"
              id="btn-refresh-captcha-top"
              onClick={handleResetCaptcha}
              disabled={isResetting || isLoading || resetsRemaining <= 0}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] sm:text-[11px] font-sans transition cursor-pointer border ${
                resetsRemaining <= 0
                  ? "bg-[#090D14] text-slate-500 border-[#1C2536] cursor-not-allowed opacity-60"
                  : "bg-[#141B28] hover:bg-[#1C2536] text-slate-300 hover:text-white border-[#1C2536]"
              }`}
              title={`নতুন সহজ ক্যাপচা আনুন (বাকি: ${resetsRemaining}/৫)`}
            >
              {isResetting ? (
                <Loader2 size={11} className="animate-spin text-emerald-400" />
              ) : (
                <RotateCcw size={11} className="text-emerald-400" />
              )}
              <span>নতুন ক্যাপচা ({resetsRemaining})</span>
            </button>
          </div>

          {/* Loading State */}
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400 font-mono text-xs">
              <Loader2 size={24} className="animate-spin text-emerald-400" />
              <span>সার্ভার থেকে প্রশ্ন লোড করা হচ্ছে...</span>
            </div>
          ) : (
            /* 3 Questions Container */
            <div className="space-y-3 max-h-[55vh] overflow-y-auto pr-1 relative z-10">
              {questions.map((q, idx) => {
                const isAnswered = Boolean(selectedAnswers[q.id]);
                return (
                  <div
                    key={`${q.id}-${q.questionBn}`}
                    id={`quiz-question-box-${q.id}`}
                    className="bg-[#090D14] border border-[#1C2536] rounded-2xl p-3 sm:p-3.5 space-y-2.5 shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className="w-5 h-5 rounded-full bg-[#141B28] text-slate-200 font-mono font-bold text-xs flex items-center justify-center shrink-0 border border-[#1C2536]">
                          {idx + 1}
                        </span>
                        <h4 className="text-xs sm:text-sm font-bold text-white leading-snug truncate">
                          {q.questionBn}
                        </h4>
                      </div>
                      {isAnswered && (
                        <span className="text-[9px] sm:text-[10px] font-mono text-emerald-400 flex items-center gap-0.5 shrink-0 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                          <Check size={10} /> উত্তর নির্বাচিত
                        </span>
                      )}
                    </div>

                    {/* Option Buttons: Touch-friendly min 44px */}
                    <div className="grid grid-cols-2 gap-2">
                      {q.options.map((opt) => {
                        const isSelected = selectedAnswers[q.id] === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            id={`btn-opt-${q.id}-${opt.id}`}
                            onClick={() => handleSelectOption(q.id, opt.id)}
                            className={`min-h-[44px] p-2.5 rounded-xl font-sans text-xs transition-all duration-150 text-left flex items-center gap-2 cursor-pointer select-none touch-manipulation ${
                              isSelected
                                ? "bg-emerald-950/70 text-white font-bold border border-emerald-500 shadow-sm scale-[1.01]"
                                : "bg-[#141B28] hover:bg-[#1C2536] text-slate-300 border border-[#1C2536]"
                            }`}
                          >
                            <span
                              className={`w-4 h-4 rounded-full border flex items-center justify-center text-[9px] shrink-0 font-mono ${
                                isSelected
                                  ? "bg-emerald-500 text-black border-emerald-500 font-bold"
                                  : "border-[#1C2536] text-slate-400"
                              }`}
                            >
                              {opt.id.toUpperCase()}
                            </span>
                            <span className="truncate leading-tight text-[11px] sm:text-xs">
                              {opt.textBn}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Modal Actions */}
          <div className="mt-3.5 sm:mt-4 pt-3 border-t border-[#1C2536] flex items-center gap-2.5 relative z-10">
            <button
              type="button"
              id="btn-reset-quiz"
              onClick={handleResetCaptcha}
              disabled={isResetting || isLoading || resetsRemaining <= 0}
              className={`py-3 px-3.5 rounded-2xl font-mono font-medium text-xs border transition flex items-center gap-1.5 shrink-0 ${
                resetsRemaining <= 0
                  ? "bg-[#090D14] text-slate-600 border-[#1C2536] cursor-not-allowed opacity-50"
                  : "bg-[#090D14] hover:bg-[#1C2536] text-slate-300 border-[#1C2536] cursor-pointer"
              }`}
              title="নতুন ক্যাপচা লোড করুন"
            >
              <RotateCcw size={14} className={isResetting ? "animate-spin" : ""} />
              <span>নতুন ক্যাপচা</span>
            </button>

            <button
              type="button"
              id="btn-submit-quiz"
              disabled={isSubmitting || isLoading || answeredCount < questions.length}
              onClick={handleSubmit}
              className={`flex-1 py-3 px-3 sm:px-4 rounded-2xl font-mono font-bold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 transition-all duration-200 select-none ${
                answeredCount < questions.length || isLoading
                  ? "bg-[#090D14] text-slate-500 border border-[#1C2536] cursor-not-allowed opacity-60"
                  : "bg-emerald-600 hover:bg-emerald-500 text-white active:scale-[0.98] cursor-pointer shadow-sm"
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={16} className="animate-spin shrink-0" />
                  <span className="truncate whitespace-nowrap">যাচাই করা হচ্ছে...</span>
                </>
              ) : (
                <>
                  <ShieldCheck size={16} className="shrink-0" />
                  <span className="truncate whitespace-nowrap">
                    {answeredCount < questions.length
                      ? `সবগুলো উত্তর দিন (${answeredCount}/${questions.length || 3})`
                      : "সাবমিট করুন (VERIFY NOW)"}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default HumanVerificationQuizModal;
