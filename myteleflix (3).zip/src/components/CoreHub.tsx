/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * CORE HUB (গুরুত্বপূর্ণ সেকশন)
 * Ultra-compact mobile-first containers with single-line text clamping:
 *  1. Title: "মাই ওয়ালেট ও উইথড্র" | Subtext: "টোকেন ক্যাশআউট (bKash/Nagad)" | Action Tag: [ 👛 Wallet ]
 *  2. Title: "টাস্ক রিভিউ" | Subtext: "জমা দেওয়া কাজের স্ট্যাটাস" | Action Tag: [ 📋 Review ]
 *  3. Title: "অফিসিয়াল সাপোর্ট" | Subtext: "টেলিগ্রাম হেল্পলাইন ২৪/৭" | Action Tag: [ 🎧 Help ]
 */

import React from "react";
import { 
  Zap, 
  Wallet, 
  CheckCircle2, 
  Headphones, 
  ChevronRight 
} from "lucide-react";
import { DEFAULT_TELEGRAM_SUPPORT_LINK } from "../constants";

export interface CoreHubProps {
  onOpenWallet: () => void;
  onOpenTaskStatus: () => void;
  onOpenLiveSupport?: () => void;
  telegramSupportLink?: string;
  userPoints?: number;
  pendingTaskCount?: number;
  onOpenPromotion?: () => void;
}

export const CoreHub: React.FC<CoreHubProps> = ({
  onOpenWallet,
  onOpenTaskStatus,
  onOpenLiveSupport,
  telegramSupportLink = DEFAULT_TELEGRAM_SUPPORT_LINK,
  pendingTaskCount = 0,
}) => {
  const handleSupportClick = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) e.stopPropagation();
    if (telegramSupportLink && telegramSupportLink.startsWith("http")) {
      window.open(telegramSupportLink, "_blank", "noopener,noreferrer");
    } else if (onOpenLiveSupport) {
      onOpenLiveSupport();
    } else {
      window.open(DEFAULT_TELEGRAM_SUPPORT_LINK, "_blank", "noopener,noreferrer");
    }
  };

  const handleWalletClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    onOpenWallet();
  };

  const handleTaskReviewClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    onOpenTaskStatus();
  };

  return (
    <div 
      id="profile-core-hub"
      className="relative overflow-hidden bg-gradient-to-b from-[#0b0e17] via-[#090b12] to-[#05070b] border border-white/[0.08] rounded-2xl p-3 sm:p-4 shadow-2xl backdrop-blur-xl"
    >
      {/* Subtle Deep Ambient Highlights */}
      <div className="absolute top-0 right-0 w-44 h-28 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-44 h-28 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Container */}
      <div className="flex items-center justify-between mb-3 relative z-10">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Zap size={14} className="text-amber-400 fill-amber-400" />
          </div>
          <h3 className="text-xs sm:text-sm font-black text-white tracking-tight uppercase font-mono truncate">
            গুরুত্বপূর্ণ সেকশন (CORE HUB)
          </h3>
        </div>
        <span className="text-[9.5px] font-mono font-bold text-amber-300 bg-amber-500/10 border border-amber-500/25 px-2 py-0.5 rounded-full shrink-0 shadow-sm">
          3 SERVICES
        </span>
      </div>

      {/* 3 Ultra-Dark Organic Core Hub Action Cards */}
      <div className="space-y-2 relative z-10">
        {/* Card 1: মাই ওয়ালেট ও উইথড্র | Organic Deep Emerald */}
        <div
          id="btn-core-hub-wallet"
          onClick={handleWalletClick}
          onTouchEnd={(e) => e.stopPropagation()}
          role="button"
          tabIndex={0}
          className="relative overflow-hidden bg-[#040d08] hover:bg-[#07160d] active:bg-[#091d12] border-2 border-emerald-500/40 hover:border-emerald-400/80 active:border-emerald-400 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2 transition-all duration-150 cursor-pointer active:scale-[0.985] shadow-[0_4px_16px_rgba(0,0,0,0.6),0_0_12px_rgba(16,185,129,0.12)] select-none group"
        >
          {/* Organic Ambient Aura */}
          <div className="absolute -right-6 -bottom-6 w-20 h-20 bg-emerald-500/15 rounded-full blur-xl pointer-events-none group-hover:bg-emerald-500/25 transition-all" />

          <div className="flex items-center gap-2.5 min-w-0 flex-1 relative z-10">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-emerald-950/90 border border-emerald-500/60 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner group-hover:scale-105 group-hover:border-emerald-400 transition-transform">
              <Wallet size={17} className="text-emerald-400" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-emerald-300 transition-colors truncate leading-tight">
                  মাই ওয়ালেট ও উইথড্র
                </h4>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 font-bold shrink-0">
                  ৳ বিকাশ / নগদ
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 font-sans truncate mt-0.5">
                টোকেন ক্যাশআউট ও লেনদেন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0 pl-1 relative z-10">
            <span className="px-2 py-0.5 rounded-md text-[10px] sm:text-[11px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/50 whitespace-nowrap shadow-sm flex items-center gap-1 group-hover:bg-emerald-900/90 transition-colors">
              <Wallet size={12} className="text-emerald-400" />
              <span>ওয়ালেট</span>
            </span>
            <ChevronRight size={15} className="text-emerald-400/80 group-hover:text-emerald-300 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Card 2: টাস্ক রিভিউ | Organic Deep Amber / Gold */}
        <div
          id="btn-core-hub-task-review"
          onClick={handleTaskReviewClick}
          onTouchEnd={(e) => e.stopPropagation()}
          role="button"
          tabIndex={0}
          className="relative overflow-hidden bg-[#0d0902] hover:bg-[#150f04] active:bg-[#1c1305] border-2 border-amber-500/40 hover:border-amber-400/80 active:border-amber-400 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2 transition-all duration-150 cursor-pointer active:scale-[0.985] shadow-[0_4px_16px_rgba(0,0,0,0.6),0_0_12px_rgba(245,158,11,0.12)] select-none group"
        >
          {/* Organic Ambient Aura */}
          <div className="absolute -right-6 -bottom-6 w-20 h-20 bg-amber-500/15 rounded-full blur-xl pointer-events-none group-hover:bg-amber-500/25 transition-all" />

          <div className="flex items-center gap-2.5 min-w-0 flex-1 relative z-10">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-amber-950/90 border border-amber-500/60 flex items-center justify-center text-amber-400 shrink-0 shadow-inner group-hover:scale-105 group-hover:border-amber-400 transition-transform">
              <CheckCircle2 size={17} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-amber-300 transition-colors truncate leading-tight">
                  টাস্ক রিভিউ
                </h4>
                {pendingTaskCount > 0 ? (
                  <span className="px-1.5 py-0.2 text-[9px] font-mono font-bold bg-amber-500/30 text-amber-300 rounded border border-amber-500/50 shrink-0">
                    {pendingTaskCount} PENDING
                  </span>
                ) : (
                  <span className="px-1.5 py-0.2 text-[9px] font-mono font-bold bg-amber-500/20 text-amber-300 rounded border border-amber-500/30 shrink-0">
                    STATUS
                  </span>
                )}
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 font-sans truncate mt-0.5">
                কমপ্লিট ও পেন্ডিং কাজের হিসাব
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0 pl-1 relative z-10">
            <span className="px-2 py-0.5 rounded-md text-[10px] sm:text-[11px] font-bold bg-amber-950/80 text-amber-300 border border-amber-500/50 whitespace-nowrap shadow-sm flex items-center gap-1 group-hover:bg-amber-900/90 transition-colors">
              <CheckCircle2 size={12} className="text-amber-400" />
              <span>রিভিউ</span>
            </span>
            <ChevronRight size={15} className="text-amber-400/80 group-hover:text-amber-300 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>

        {/* Card 3: অফিসিয়াল সাপোর্ট | Organic Deep Cyan / Blue */}
        <div
          id="btn-core-hub-support"
          onClick={handleSupportClick}
          onTouchEnd={(e) => e.stopPropagation()}
          role="button"
          tabIndex={0}
          className="relative overflow-hidden bg-[#030910] hover:bg-[#05111f] active:bg-[#07182c] border-2 border-cyan-500/40 hover:border-cyan-400/80 active:border-cyan-400 rounded-xl p-2.5 sm:p-3 flex items-center justify-between gap-2 transition-all duration-150 cursor-pointer active:scale-[0.985] shadow-[0_4px_16px_rgba(0,0,0,0.6),0_0_12px_rgba(6,182,212,0.12)] select-none group"
        >
          {/* Organic Ambient Aura */}
          <div className="absolute -right-6 -bottom-6 w-20 h-20 bg-cyan-500/15 rounded-full blur-xl pointer-events-none group-hover:bg-cyan-500/25 transition-all" />

          <div className="flex items-center gap-2.5 min-w-0 flex-1 relative z-10">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-cyan-950/90 border border-cyan-500/60 flex items-center justify-center text-cyan-400 shrink-0 shadow-inner group-hover:scale-105 group-hover:border-cyan-400 transition-transform">
              <Headphones size={17} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs sm:text-sm font-black text-white group-hover:text-cyan-300 transition-colors truncate leading-tight">
                  অফিসিয়াল সাপোর্ট
                </h4>
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 font-bold shrink-0">
                  ২৪/৭ লাইভ
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 font-sans truncate mt-0.5">
                টেলিগ্রাম ও সহায়তা কেন্দ্র
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0 pl-1 relative z-10">
            <span className="px-2 py-0.5 rounded-md text-[10px] sm:text-[11px] font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-500/50 whitespace-nowrap shadow-sm flex items-center gap-1 group-hover:bg-cyan-900/90 transition-colors">
              <Headphones size={12} className="text-cyan-400" />
              <span>সাপোর্ট</span>
            </span>
            <ChevronRight size={15} className="text-cyan-400/80 group-hover:text-cyan-300 group-hover:translate-x-0.5 transition-all" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoreHub;
