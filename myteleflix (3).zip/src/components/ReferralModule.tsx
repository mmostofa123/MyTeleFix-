/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VRMS-3 ULTRA: Referral & Milestone Engine (Step 3 Redesign)
 * High-density, mobile-first, dark-organic UI standard (#0A0D12)
 * Zero emojis, pure SVG icons, 5-second top-floating toast notifications.
 */

import React, { useState, useEffect, useCallback } from "react";
import { 
  Copy, 
  Check, 
  Users, 
  Clock, 
  CheckCircle2, 
  RefreshCw, 
  ShieldCheck, 
  Flame, 
  CheckSquare, 
  ChevronDown, 
  ChevronUp, 
  X,
  Share2,
  Info,
  Award
} from "lucide-react";
import { User } from "../types";
import TokenIcon from "./TokenIcon";
import ReferralMilestones from "./ReferralMilestones";

interface ReferralModuleProps {
  user: User;
  onTokenClaimed?: (amount: number) => void;
}

interface ReferralItem {
  referral_id: string;
  referred_user_id: string;
  referred_username: string;
  referred_fullname: string;
  status: "REGISTERED" | "QUALIFIED" | "PURGED";
  status_label: string;
  registered_at: string;
  qualified_at: string | null;
  bonus_amount: number;
  active_days: number;
  valid_actions: number;
  quiz_status: string;
  is_verified: boolean;
}

interface ReferralDashboardData {
  referralCode: string;
  referralLink: string;
  registeredCount: number;
  qualifiedCount: number;
  totalInvited: number;
  totalEarnedPoints: number;
  referrals: ReferralItem[];
}

export default function ReferralModule({
  user,
  onTokenClaimed
}: ReferralModuleProps) {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [rulesOpen, setRulesOpen] = useState(false);

  // Browser-based dynamic referral link
  const telegramId = user.telegramId || user.id.replace(/^tg-/, "") || "101";
  const defaultRefCode = `REF_${telegramId}`;
  const webOrigin = typeof window !== "undefined" && window.location?.origin ? window.location.origin : "https://myteleflix.com";
  const defaultRefLink = `${webOrigin}/?ref=${defaultRefCode}`;

  const [data, setData] = useState<ReferralDashboardData>({
    referralCode: defaultRefCode,
    referralLink: defaultRefLink,
    registeredCount: 0,
    qualifiedCount: 0,
    totalInvited: 0,
    totalEarnedPoints: 0,
    referrals: []
  });

  // Top-floating 5-second auto-dismiss toast helper
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 5000);
  }, []);

  const fetchReferrals = async (showSyncToast = false) => {
    setLoading(true);
    try {
      // 1. Fetch VRMS-3 ULTRA stats endpoint
      const statsRes = await fetch(`/api/referrals/stats?userId=${encodeURIComponent(user.id)}`);
      if (statsRes.ok) {
        const json = await statsRes.json();
        if (json && json.success) {
          setData({
            referralCode: json.referralCode || defaultRefCode,
            referralLink: json.referralLink || defaultRefLink,
            registeredCount: Number(json.registeredCount || 0),
            qualifiedCount: Number(json.qualifiedCount || 0),
            totalInvited: Number(json.totalInvited || 0),
            totalEarnedPoints: Number(json.totalEarnedPoints || 0),
            referrals: Array.isArray(json.referrals) ? json.referrals : []
          });
          if (showSyncToast) {
            showToast("Referral network data updated from server.");
          }
          return;
        }
      }

      // 2. Fallback to /api/referrals
      const fallbackRes = await fetch(`/api/referrals?userId=${encodeURIComponent(user.id)}`);
      if (fallbackRes.ok) {
        const json = await fallbackRes.json();
        const vrmsList: ReferralItem[] = json.vrmsReferrals || (json.referrals || []).map((r: any) => ({
          referral_id: r.referral_id || r.id,
          referred_user_id: r.referred_user_id || r.referredId,
          referred_username: r.referred_username || r.referredUsername || "user",
          referred_fullname: r.referred_fullname || r.referredFullName || "Member",
          status: (r.status === "QUALIFIED" || r.isVerified) ? "QUALIFIED" : "REGISTERED",
          status_label: (r.status === "QUALIFIED" || r.isVerified) ? "Qualified" : "Pending Verification",
          registered_at: r.registered_at || r.timestamp,
          qualified_at: r.qualified_at || null,
          bonus_amount: r.bonus_amount || r.pointsEarned || 0,
          active_days: r.active_days ?? r.activeDays ?? 0,
          valid_actions: r.valid_actions ?? r.tasksCompleted ?? 0,
          quiz_status: r.quiz_status || (r.humanQuizCompleted ? "PASSED" : "PENDING"),
          is_verified: Boolean(r.is_verified || r.isVerified || r.status === "QUALIFIED")
        }));

        setData({
          referralCode: json.referralCode || defaultRefCode,
          referralLink: json.referralLink || defaultRefLink,
          registeredCount: json.registeredCount ?? vrmsList.filter(r => r.status === "REGISTERED").length,
          qualifiedCount: json.qualifiedCount ?? vrmsList.filter(r => r.status === "QUALIFIED").length,
          totalInvited: json.totalInvited ?? vrmsList.length,
          totalEarnedPoints: json.totalEarnedPoints ?? 0,
          referrals: vrmsList
        });

        if (showSyncToast) {
          showToast("Referral network data updated from server.");
        }
      }
    } catch (err) {
      console.warn("Failed to fetch referral records:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferrals(false);
  }, [user.id]);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(data.referralLink);
      setCopiedLink(true);
      showToast("Unique referral link copied to clipboard.");
      setTimeout(() => setCopiedLink(false), 2500);
    } catch (e) {
      showToast("Could not copy automatically. Please copy manually.");
    }
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(data.referralCode);
      setCopiedCode(true);
      showToast(`Referral code ${data.referralCode} copied to clipboard.`);
      setTimeout(() => setCopiedCode(false), 2500);
    } catch (e) {
      showToast("Could not copy automatically. Please copy manually.");
    }
  };

  // Telegram Quick Share
  const handleTelegramShare = () => {
    const message = "Watch videos, complete tasks & earn verified daily tokens! Join with my invitation link:";
    const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(data.referralLink)}&text=${encodeURIComponent(message)}`;
    
    if (typeof window !== "undefined" && (window as any).Telegram?.WebApp?.openTelegramLink) {
      (window as any).Telegram.WebApp.openTelegramLink(shareUrl);
    } else {
      window.open(shareUrl, "_blank");
    }
  };

  // WhatsApp Quick Share
  const handleWhatsAppShare = () => {
    const text = `Join to earn verified daily tokens: ${data.referralLink}`;
    const shareUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, "_blank");
  };

  return (
    <div id="vrms-referral-module" className="w-full max-w-4xl mx-auto space-y-4 pb-20 animate-in fade-in duration-200 font-sans text-slate-200">
      
      {/* 5-SECOND TOP-FLOATING TOAST NOTIFICATION */}
      {toastMessage && (
        <aside 
          aria-live="polite"
          className="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-md shadow-2xl animate-in slide-in-from-top-4 duration-300 pointer-events-auto"
        >
          <div className="bg-[#0A0D12]/95 border border-[#00F5A0]/60 rounded-2xl px-4 py-3 text-white text-xs font-mono font-bold flex items-center justify-between shadow-[0_0_30px_rgba(0,245,160,0.2)] backdrop-blur-xl">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 size={16} className="text-[#00F5A0] shrink-0 stroke-[2.5]" />
              <span>{toastMessage}</span>
            </div>
            <button 
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-white/[0.08] transition cursor-pointer shrink-0 ml-2"
              aria-label="Dismiss toast"
            >
              <X size={14} />
            </button>
          </div>
        </aside>
      )}

      {/* 1. TOP REFERRAL HERO CARD (1-Click Share & Primary Metric) */}
      <div className="bg-[#0A0D12] border border-white/[0.08] rounded-2xl p-4 sm:p-5 shadow-xl backdrop-blur-md space-y-4">
        
        {/* Top Header Row with Hero Metric */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.06] pb-4">
          <div className="space-y-1.5">
            {/* Glowing Neon Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00F5A0]/10 border border-[#00F5A0]/30 text-[#00F5A0] text-[10px] font-mono font-bold uppercase tracking-wider shadow-[0_0_15px_rgba(0,245,160,0.2)]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00F5A0] animate-pulse" />
              <span>Direct Referral Network</span>
            </div>

            {/* Primary Hero Metric: QUALIFIED REFERRALS */}
            <div className="flex items-baseline gap-3 pt-0.5">
              <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                {data.qualifiedCount}
              </span>
              <span className="text-xs font-mono font-bold text-[#00F5A0] uppercase tracking-wide flex items-center gap-1">
                <CheckCircle2 size={14} className="stroke-[2.5]" />
                <span>Qualified Referrals</span>
              </span>
            </div>

            {/* Subtle Sub-Metric: Registered (Without equal visual weight) */}
            <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
              <Clock size={11} className="text-slate-500" />
              <span>Registered: <strong className="text-slate-300 font-semibold">{data.registeredCount}</strong> (Pending Verification)</span>
              <span className="text-slate-600">•</span>
              <span>Total Invited: <strong className="text-slate-300 font-semibold">{data.totalInvited}</strong></span>
            </div>
          </div>

          {/* Reward Value Sub-Card */}
          <div className="bg-[#182030] border border-[#253146] rounded-xl p-3 text-left sm:text-right space-y-0.5 shrink-0 shadow-sm">
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold block">
              Direct Bounty Credited
            </span>
            <span className="text-base sm:text-lg font-black text-amber-400 font-mono flex items-center sm:justify-end gap-1.5">
              <TokenIcon size={14} />
              +{data.totalEarnedPoints.toLocaleString()} Tokens
            </span>
            <span className="text-[10px] text-slate-400 font-mono block">
              +300 Tokens per verified member
            </span>
          </div>
        </div>

        {/* 1-Click Copy Box for Referral Link */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[10px] text-slate-400 uppercase font-mono font-bold tracking-wider block">
              Unique Invitation Link
            </label>
            {/* Quick Code Badge */}
            <button
              onClick={handleCopyCode}
              className="text-[10px] font-mono text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
            >
              <span>Code:</span>
              <strong className="text-amber-400 font-bold">{data.referralCode}</strong>
              {copiedCode ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            </button>
          </div>

          {/* Clean, Deep Solid Dark Input Field with Solid Action */}
          <div className="bg-[#0B0F17] border border-[#253146] focus-within:border-amber-400 rounded-xl p-1.5 flex items-center gap-2 shadow-sm transition">
            <input
              type="text"
              readOnly
              value={data.referralLink}
              className="bg-transparent text-xs text-slate-200 font-mono flex-1 outline-none px-2.5 select-all truncate"
            />
            <button
              id="btn-copy-referral-link"
              onClick={handleCopyLink}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-[#0A0F17] rounded-lg text-xs font-mono font-black uppercase tracking-wider flex items-center gap-1.5 transition cursor-pointer shrink-0 shadow-sm active:scale-95 select-none"
            >
              {copiedLink ? (
                <>
                  <Check size={13} className="stroke-[3]" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Copy size={13} className="stroke-[2.5]" />
                  <span>Copy Link</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Compact Share Action Row: Solid buttons without light rays */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          {/* Telegram Quick Share */}
          <button
            id="btn-share-telegram"
            onClick={handleTelegramShare}
            className="py-2.5 px-3 rounded-xl bg-[#0284C7]/20 hover:bg-[#0284C7]/30 border border-[#0284C7]/40 text-sky-200 hover:text-white font-mono text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-sm select-none"
          >
            <svg className="w-4 h-4 fill-sky-400 shrink-0" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.75-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
            </svg>
            <span>Telegram Share</span>
          </button>

          {/* WhatsApp Quick Share */}
          <button
            id="btn-share-whatsapp"
            onClick={handleWhatsAppShare}
            className="py-2.5 px-3 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-200 hover:text-white font-mono text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-sm select-none"
          >
            <svg className="w-4 h-4 fill-emerald-400 shrink-0" viewBox="0 0 24 24">
              <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0012.04 2m.01 1.67c2.2 0 4.26.86 5.82 2.41a8.18 8.18 0 012.41 5.83c0 4.54-3.7 8.24-8.24 8.24-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.19 8.19 0 01-1.26-4.38c0-4.54 3.7-8.24 8.24-8.24m4.52 11.54c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.25-.75-.67-1.26-1.5-1.4-1.75-.15-.25-.02-.39.11-.51.11-.11.25-.29.37-.44.13-.15.17-.25.25-.42.08-.17.04-.31-.02-.44-.06-.13-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1 0 1.24.9 2.44 1.03 2.61.13.17 1.77 2.71 4.3 3.8.6.26 1.07.41 1.44.53.61.19 1.16.17 1.6.1.49-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.15-1.18-.06-.1-.23-.16-.48-.28z"/>
            </svg>
            <span>WhatsApp Share</span>
          </button>
        </div>
      </div>

      {/* 2. CLAIM SAFETY & TRANSPARENCY: Expandable Eligibility Rules Drawer */}
      <div className="bg-[#0A0D12] border border-white/[0.08] rounded-2xl overflow-hidden shadow-lg">
        <button
          type="button"
          onClick={() => setRulesOpen(!rulesOpen)}
          className="w-full p-3.5 flex items-center justify-between text-left text-xs font-mono font-bold text-slate-300 hover:text-white transition cursor-pointer select-none"
        >
          <div className="flex items-center gap-2">
            <ShieldCheck size={16} className="text-[#00F5A0]" />
            <span>Eligibility Rules & Server Verification Guard</span>
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-normal">
            <span>{rulesOpen ? "Collapse" : "View Rules"}</span>
            {rulesOpen ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
          </div>
        </button>

        {rulesOpen && (
          <div className="p-4 border-t border-white/[0.06] bg-white/[0.01] space-y-3 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
              
              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[#00F5A0] font-bold block">1. Verification Requirement</span>
                <p className="text-slate-400 text-[10px] leading-relaxed">
                  Signup registers status as REGISTERED. Qualification requires referred user to complete 10-day active streak, 100 valid actions, and pass human verification.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[#00D8F6] font-bold block">2. Direct Isolation</span>
                <p className="text-slate-400 text-[10px] leading-relaxed">
                  Only direct authentic referrers are credited. Pyramid multi-level schemes are blocked by server-authoritative integrity checks.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[#FFB800] font-bold block">3. Milestone Independence</span>
                <p className="text-slate-400 text-[10px] leading-relaxed">
                  Referral milestones (M1 to M8) are separate reward states with idempotent one-time crediting, isolated from monthly salary.
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-1">
                <span className="text-[#FF3B30] font-bold block">4. Anti-Abuse Lock</span>
                <p className="text-slate-400 text-[10px] leading-relaxed">
                  Purged, banned, or circular referrals (A → B → A) are strictly excluded from all qualification and milestone calculations.
                </p>
              </div>

            </div>
          </div>
        )}
      </div>

      {/* 3. VERTICAL MILESTONE JOURNEY MAP (M1 to M8 Gamified Progression) */}
      <ReferralMilestones 
        user={user} 
        onTokenClaimed={onTokenClaimed}
        qualifiedCount={data.qualifiedCount}
        onMilestoneClaimed={() => fetchReferrals(false)}
      />

      {/* 4. REFERRED MEMBERS AUDIT BREAKDOWN */}
      <div className="bg-[#0A0D12] border border-white/[0.08] rounded-2xl p-4 sm:p-5 shadow-xl backdrop-blur-md space-y-3">
        <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
          <div className="flex items-center gap-2">
            <Users size={15} className="text-[#00D8F6]" />
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Referred Members Audit ({data.referrals.length})
            </h4>
          </div>

          <button
            id="btn-sync-referrals"
            onClick={() => fetchReferrals(true)}
            disabled={loading}
            className="text-xs text-slate-400 hover:text-white font-mono flex items-center gap-1.5 transition cursor-pointer py-1 px-2 rounded-lg hover:bg-white/[0.04]"
          >
            <RefreshCw size={12} className={loading ? "animate-spin text-[#00F5A0]" : ""} />
            <span>Sync</span>
          </button>
        </div>

        {data.referrals.length === 0 ? (
          <div className="bg-white/[0.01] border border-white/[0.06] rounded-xl p-8 text-center text-slate-400 font-mono text-xs space-y-1.5">
            <Users size={24} className="mx-auto text-slate-600 mb-1" />
            <p className="text-slate-300 font-bold">No referrals registered yet</p>
            <p className="text-[11px] text-slate-500">Share your invitation link to build your network and unlock milestones.</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {data.referrals.map((ref) => {
              const isQualified = ref.status === "QUALIFIED" || ref.is_verified;
              const activeDays = ref.active_days || 0;
              const validActions = ref.valid_actions || 0;
              const quizStatus = ref.quiz_status || "PENDING";
              const regDate = ref.registered_at ? new Date(ref.registered_at).toLocaleDateString([], { month: "short", day: "numeric" }) : "Recent";
              const qualDate = ref.qualified_at ? new Date(ref.qualified_at).toLocaleDateString([], { month: "short", day: "numeric" }) : null;

              return (
                <div 
                  key={ref.referral_id || ref.referred_user_id}
                  className={`rounded-xl p-3 border transition-all ${
                    isQualified 
                      ? "bg-white/[0.02] border-[#00F5A0]/30 shadow-[0_0_10px_rgba(0,245,160,0.05)]" 
                      : "bg-white/[0.01] border-white/[0.06]"
                  }`}
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold font-mono text-xs uppercase shrink-0 border ${
                        isQualified 
                          ? "bg-[#00F5A0]/10 text-[#00F5A0] border-[#00F5A0]/30" 
                          : "bg-white/[0.03] text-slate-400 border-white/[0.08]"
                      }`}>
                        {ref.referred_username ? ref.referred_username.slice(0, 2) : "UR"}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h5 className="text-xs font-bold text-white truncate font-mono">
                            {ref.referred_fullname || "Network Member"}
                          </h5>
                          <span className="text-[10px] font-mono text-slate-400 truncate">
                            @{ref.referred_username}
                          </span>
                        </div>
                        <span className="text-[9px] font-mono text-slate-500 block">
                          Joined {regDate} {qualDate && `• Verified ${qualDate}`}
                        </span>
                      </div>
                    </div>

                    {/* Status Indicator Badge */}
                    <div className="text-right shrink-0">
                      {isQualified ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          <CheckCircle2 size={11} className="stroke-[2.5]" />
                          QUALIFIED (+{ref.bonus_amount || 300} Tokens)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold bg-white/[0.03] text-slate-400 border border-white/[0.08]">
                          <Clock size={11} />
                          PENDING VERIFICATION
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Verification Progress for Pending Referrals */}
                  {!isQualified && (
                    <div className="mt-2 pt-2 border-t border-white/[0.04] flex items-center justify-between text-[10px] font-mono text-slate-400 flex-wrap gap-2">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1 text-slate-300">
                          <Flame size={11} className={activeDays >= 10 ? "text-[#00F5A0]" : "text-[#FFB800]"} />
                          <span>Streak: <strong className="text-white">{activeDays}/10d</strong></span>
                        </span>
                        <span className="flex items-center gap-1 text-slate-300">
                          <CheckSquare size={11} className={validActions >= 100 ? "text-[#00F5A0]" : "text-[#FFB800]"} />
                          <span>Actions: <strong className="text-white">{validActions}/100</strong></span>
                        </span>
                        <span className="text-slate-400">
                          Quiz: <strong className={quizStatus === "PASSED" ? "text-[#00F5A0]" : "text-slate-400"}>{quizStatus}</strong>
                        </span>
                      </div>
                      <span className="text-slate-500 text-[9px]">
                        Awaiting user streak completion
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
