/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TelegramIdHelpModal: Minimalist, clean popup modal explaining
 * how to get Telegram Numeric ID via @userinfobot.
 */

import React, { useState } from "react";
import { X, Send, ExternalLink, Copy, Check } from "lucide-react";

interface TelegramIdHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TelegramIdHelpModal({
  isOpen,
  onClose
}: TelegramIdHelpModalProps) {
  const [copied, setCopied] = useState(false);
  const botUrl = "https://t.me/userinfobot";

  if (!isOpen) return null;

  const handleCopy = () => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(botUrl);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleOpenBot = (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      window.open(botUrl, "_blank", "noopener,noreferrer");
    } catch {
      window.location.href = botUrl;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-[400px] bg-[#0F1422] border border-[#1E293B] rounded-[16px] p-5 sm:p-6 text-white shadow-2xl space-y-4 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Title & Close button */}
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <h3 className="text-base font-semibold text-white tracking-tight">
              Get Telegram ID
            </h3>
            <p className="text-xs text-slate-400">
              Find your numeric ID in 3 easy steps
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#141A29] hover:bg-[#1E2538] text-slate-400 hover:text-white flex items-center justify-center transition border border-[#1E293B] cursor-pointer"
          >
            <X size={15} />
          </button>
        </div>

        {/* 3 Clean Steps */}
        <div className="space-y-2.5 pt-1 text-left">
          {/* Step 1 */}
          <div className="p-3 rounded-xl bg-[#141A29] border border-[#1E293B] space-y-2">
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-md bg-[#0284C7]/20 text-[#38BDF8] text-[11px] font-semibold font-mono flex items-center justify-center shrink-0 mt-0.5">
                1
              </span>
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                Open <span className="text-white font-semibold">@userinfobot</span> on Telegram:
              </p>
            </div>
            <div className="flex items-center gap-2 pl-7">
              <a
                href={botUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleOpenBot}
                className="flex-1 h-9 px-3 rounded-lg bg-gradient-to-r from-[#2563EB] to-[#0284C7] hover:from-[#1D4ED8] hover:to-[#0369A1] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer"
              >
                <Send size={12} />
                <span>Open @userinfobot</span>
                <ExternalLink size={11} className="opacity-75" />
              </a>
              <button
                type="button"
                onClick={handleCopy}
                className="h-9 px-3 rounded-lg bg-[#1B2337] hover:bg-[#232D46] border border-[#273552] text-xs text-slate-300 font-mono transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                <span>{copied ? "Copied" : "Copy"}</span>
              </button>
            </div>
          </div>

          {/* Step 2 */}
          <div className="p-3 rounded-xl bg-[#141A29] border border-[#1E293B] flex items-start gap-2.5">
            <span className="w-5 h-5 rounded-md bg-[#0284C7]/20 text-[#38BDF8] text-[11px] font-semibold font-mono flex items-center justify-center shrink-0 mt-0.5">
              2
            </span>
            <p className="text-xs text-slate-200 leading-relaxed">
              Press <span className="text-white font-semibold font-mono">Start</span> in the chat. The bot will instantly reply with your User ID.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-3 rounded-xl bg-[#141A29] border border-[#1E293B] flex items-start gap-2.5">
            <span className="w-5 h-5 rounded-md bg-[#0284C7]/20 text-[#38BDF8] text-[11px] font-semibold font-mono flex items-center justify-center shrink-0 mt-0.5">
              3
            </span>
            <p className="text-xs text-slate-200 leading-relaxed">
              Copy the numbers (e.g. <span className="text-[#38BDF8] font-mono font-semibold">7031193156</span>) and paste them into the Telegram ID field.
            </p>
          </div>
        </div>

        {/* Got it button */}
        <button
          type="button"
          onClick={onClose}
          className="w-full h-10 rounded-xl bg-[#1B2337] hover:bg-[#232D46] border border-[#273552] text-slate-200 text-xs font-semibold transition cursor-pointer flex items-center justify-center"
        >
          Got it
        </button>
      </div>
    </div>
  );
}
