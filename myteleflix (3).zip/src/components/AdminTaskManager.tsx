/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AdminTaskManager: Clean, Mobile-Friendly, Unique Task Publisher & Manager
 * Enables admin to publish and manage tasks across 4 strict categories:
 * 1. Daily Reward
 * 2. Watch Video Ads
 * 3. Social Tasks
 * 4. Telegram (Exclusively for official Telegram channels)
 */

import React, { useState, useMemo } from "react";
import { 
  Layers, Plus, Pencil, Trash2, CheckCircle2, 
  Coins, ExternalLink, Send, PlayCircle, Share2, 
  Gift, Check, X, Loader2, Sparkles, Eye,
  Clock, Youtube, Twitter, Facebook, Instagram, Globe,
  Search, Shield, AlertCircle
} from "lucide-react";
import { Mission, MissionCategory } from "../types";
import TokenIcon from "./TokenIcon";

export interface AdminTaskManagerProps {
  missions: Mission[];
  onAddMission: (mission: Partial<Mission>) => Promise<void>;
  onEditMission?: (mission: Mission) => Promise<void>;
  onToggleMission: (id: string) => Promise<void>;
  onDeleteMission: (id: string) => Promise<void>;
  showAdminToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const TASK_CATEGORIES: {
  id: MissionCategory;
  label: string;
  shortLabel: string;
  icon: React.ElementType;
  color: string;
  badgeBg: string;
  borderColor: string;
  description: string;
}[] = [
  {
    id: "daily_reward",
    label: "Daily Reward",
    shortLabel: "Daily",
    icon: Gift,
    color: "text-amber-400",
    badgeBg: "bg-amber-500/15 text-amber-300 border-amber-500/30",
    borderColor: "border-amber-500/50",
    description: "Daily check-in streaks, continuous bonus claims, and activity rewards"
  },
  {
    id: "video_ads",
    label: "Watch Video Ads",
    shortLabel: "Video Ads",
    icon: PlayCircle,
    color: "text-rose-400",
    badgeBg: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    borderColor: "border-rose-500/50",
    description: "Rewarded video ads, movie trailers, and YouTube stream watches"
  },
  {
    id: "social_tasks",
    label: "Social Tasks",
    shortLabel: "Social",
    icon: Share2,
    color: "text-sky-400",
    badgeBg: "bg-sky-500/15 text-sky-300 border-sky-500/30",
    borderColor: "border-sky-500/50",
    description: "YouTube subscribe, Twitter/X follow, Facebook, Instagram & websites"
  },
  {
    id: "telegram",
    label: "Telegram",
    shortLabel: "Telegram",
    icon: Send,
    color: "text-cyan-400",
    badgeBg: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
    borderColor: "border-cyan-500/50",
    description: "Official Telegram announcement channels and community groups"
  }
];

export function resolveMissionCategory(m: Mission): MissionCategory {
  if (m.category === "daily_reward" || m.category === "video_ads" || m.category === "social_tasks" || m.category === "telegram") {
    return m.category;
  }
  const type = (m.type || "").toLowerCase();
  const title = (m.title || "").toLowerCase();
  const url = (m.url || "").toLowerCase();

  if (type === "telegram_join" || type === "telegram" || title.includes("telegram") || url.includes("t.me")) {
    return "telegram";
  }
  if (type === "daily_checkin" || type === "daily" || title.includes("daily") || title.includes("check-in") || title.includes("streak")) {
    return "daily_reward";
  }
  if (type === "youtube" || type === "video_watch" || type === "adsgram" || title.includes("video") || title.includes("watch") || url.includes("youtube.com/watch") || url.includes("youtu.be")) {
    return "video_ads";
  }
  return "social_tasks";
}

export default function AdminTaskManager({
  missions,
  onAddMission,
  onEditMission,
  onToggleMission,
  onDeleteMission,
  showAdminToast
}: AdminTaskManagerProps) {
  // Form State
  const [selectedCategory, setSelectedCategory] = useState<MissionCategory>("video_ads");
  const [platform, setPlatform] = useState<string>("youtube");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [rewardPoints, setRewardPoints] = useState<number>(350);
  const [url, setUrl] = useState("");
  const [durationSeconds, setDurationSeconds] = useState<number>(15);
  const [isActive, setIsActive] = useState<boolean>(true);
  
  // UI Management State
  const [editingMissionId, setEditingMissionId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [listCategoryFilter, setListCategoryFilter] = useState<"all" | MissionCategory>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showLivePreview, setShowLivePreview] = useState(true);

  // When category changes, provide smart defaults
  const handleSelectCategory = (cat: MissionCategory) => {
    setSelectedCategory(cat);
    if (editingMissionId) return; // don't override while editing

    switch (cat) {
      case "daily_reward":
        setPlatform("daily");
        setTitle("Daily Check-in Streak Reward");
        setDescription("Check in daily to claim your bonus tokens and maintain your streak.");
        setRewardPoints(150);
        setUrl("internal://daily_reward");
        setDurationSeconds(0);
        break;
      case "video_ads":
        setPlatform("youtube");
        setTitle("Watch 30s Sponsored Video Ad");
        setDescription("Watch this short video advertisement to earn instant reward tokens.");
        setRewardPoints(350);
        setUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
        setDurationSeconds(15);
        break;
      case "social_tasks":
        setPlatform("youtube_subscribe");
        setTitle("Subscribe to Official YouTube Channel");
        setDescription("Subscribe to our channel to receive exclusive updates and claim tokens.");
        setRewardPoints(300);
        setUrl("https://www.youtube.com/@TeleFlixOfficial");
        setDurationSeconds(10);
        break;
      case "telegram":
        setPlatform("telegram_channel");
        setTitle("Join Official Telegram Channel");
        setDescription("Join our official Telegram announcement channel for daily updates & alerts.");
        setRewardPoints(500);
        setUrl("https://t.me/teleflix_announcements");
        setDurationSeconds(6);
        break;
    }
  };

  // Pre-fill form when editing a mission
  const handleStartEdit = (m: Mission) => {
    setEditingMissionId(m.id);
    const cat = resolveMissionCategory(m);
    setSelectedCategory(cat);
    setTitle(m.title || "");
    setDescription(m.description || "");
    setRewardPoints(m.rewardPoints || m.pointsReward || 300);
    setUrl(m.url || "");
    setPlatform(m.platform || m.type || "custom");
    setDurationSeconds(m.durationSeconds || (cat === "video_ads" ? 15 : cat === "telegram" ? 6 : 10));
    setIsActive(m.isActive !== false);

    const el = document.getElementById("admin-task-form-container");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleCancelEdit = () => {
    setEditingMissionId(null);
    setTitle("");
    setDescription("");
    setUrl("");
    setRewardPoints(350);
    setDurationSeconds(15);
    setIsActive(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showAdminToast("Task title is required", "error");
      return;
    }
    if (selectedCategory !== "daily_reward" && !url.trim()) {
      showAdminToast("Destination URL is required for this task category", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const taskData: Partial<Mission> = {
        title: title.trim(),
        description: description.trim() || "Complete this task to claim your reward.",
        rewardPoints: Number(rewardPoints),
        pointsReward: Number(rewardPoints),
        type: platform || selectedCategory,
        category: selectedCategory,
        platform: (platform as any) || (selectedCategory === "telegram" ? "telegram" : "website"),
        url: url.trim(),
        durationSeconds: Number(durationSeconds) || 0,
        isActive,
      };

      if (editingMissionId) {
        const existing = missions.find(m => m.id === editingMissionId);
        const updated: Mission = {
          id: editingMissionId,
          ...taskData,
          order: existing?.order || 1,
        } as Mission;

        if (onEditMission) {
          await onEditMission(updated);
        } else {
          await onAddMission(updated);
        }
        showAdminToast("✓ Task updated successfully!", "success");
        handleCancelEdit();
      } else {
        await onAddMission({
          ...taskData,
          order: missions.length + 1,
        });
        showAdminToast("✓ New task published successfully!", "success");
        handleCancelEdit();
      }
    } catch (err: any) {
      showAdminToast("Failed to save task: " + (err.message || "Unknown error"), "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filtered directory
  const filteredMissions = useMemo(() => {
    return missions.filter(m => {
      const cat = resolveMissionCategory(m);
      const matchesCategory = listCategoryFilter === "all" || cat === listCategoryFilter;
      const matchesSearch = searchQuery.trim() === "" || 
        m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.url || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (m.description || "").toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [missions, listCategoryFilter, searchQuery]);

  // Counts by category
  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {
      all: missions.length,
      daily_reward: 0,
      video_ads: 0,
      social_tasks: 0,
      telegram: 0,
    };
    missions.forEach(m => {
      const cat = resolveMissionCategory(m);
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return counts;
  }, [missions]);

  // Platform icon helper
  const renderPlatformIcon = (cat: MissionCategory, plat?: string, size = 16) => {
    const p = (plat || "").toLowerCase();
    if (cat === "telegram" || p.includes("telegram")) return <Send size={size} className="text-cyan-400" />;
    if (cat === "daily_reward") return <Gift size={size} className="text-amber-400" />;
    if (p.includes("youtube")) return <Youtube size={size} className="text-rose-500" />;
    if (p.includes("twitter") || p.includes("x")) return <Twitter size={size} className="text-sky-400" />;
    if (p.includes("facebook")) return <Facebook size={size} className="text-blue-500" />;
    if (p.includes("instagram")) return <Instagram size={size} className="text-pink-400" />;
    if (cat === "video_ads") return <PlayCircle size={size} className="text-rose-400" />;
    return <Globe size={size} className="text-slate-400" />;
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      
      {/* Top Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3.5">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-md">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Layers size={14} />
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Total Tasks</span>
          </div>
          <p className="text-base sm:text-lg font-black font-mono text-white">{missions.length}</p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-md">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <CheckCircle2 size={14} />
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Active Live</span>
          </div>
          <p className="text-base sm:text-lg font-black font-mono text-emerald-400">
            {missions.filter(m => m.isActive !== false).length}
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-md">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Send size={14} />
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Telegram</span>
          </div>
          <p className="text-base sm:text-lg font-black font-mono text-cyan-300">
            {categoryCounts.telegram || 0} Channels
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-md">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Coins size={14} />
            </span>
            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Reward Pool</span>
          </div>
          <p className="text-base sm:text-lg font-black font-mono text-amber-300 truncate">
            {missions.reduce((acc, m) => acc + (m.rewardPoints || m.pointsReward || 0), 0).toLocaleString()} 🪙
          </p>
        </div>
      </div>

      {/* Task Publisher & Editor Box */}
      <div 
        id="admin-task-form-container"
        className={`bg-slate-900/95 border rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl backdrop-blur-md space-y-4 transition-all duration-200 ${
          editingMissionId 
            ? "border-amber-500/60 ring-2 ring-amber-500/20" 
            : "border-slate-800"
        }`}
      >
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl border ${
              editingMissionId 
                ? "bg-amber-500/15 border-amber-500/30 text-amber-400" 
                : "bg-indigo-500/15 border-indigo-500/30 text-indigo-400"
            }`}>
              {editingMissionId ? <Pencil size={18} /> : <Plus size={18} />}
            </span>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white font-mono uppercase tracking-tight flex items-center gap-1.5">
                {editingMissionId ? "Edit Task Parameters" : "Publish New Task"}
              </h3>
              <p className="text-[11px] text-slate-400">
                Select category, input task requirements, and preview live on mobile
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowLivePreview(prev => !prev)}
              className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-mono font-bold flex items-center gap-1.5 transition cursor-pointer ${
                showLivePreview 
                  ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-300" 
                  : "bg-slate-800 border-slate-700 text-slate-400 hover:text-white"
              }`}
              title="Toggle Live Mobile Preview"
            >
              <Eye size={12} />
              <span className="hidden sm:inline">Preview</span>
            </button>

            {editingMissionId && (
              <button
                type="button"
                onClick={handleCancelEdit}
                className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-[11px] font-mono font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <X size={12} />
                <span>Cancel</span>
              </button>
            )}
          </div>
        </div>

        {/* STEP 1: CATEGORY SELECTOR (The 4 Strict Categories) */}
        <div className="space-y-2">
          <label className="text-[11px] font-bold font-mono text-slate-300 uppercase tracking-wider flex items-center justify-between">
            <span>1. Select Task Category (ক্যাটাগরি নির্বাচন করুন) *</span>
            <span className="text-[10px] text-amber-400 font-normal">Active: {selectedCategory.replace('_', ' ').toUpperCase()}</span>
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {TASK_CATEGORIES.map(cat => {
              const Icon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleSelectCategory(cat.id)}
                  className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden flex flex-col justify-between min-h-[76px] cursor-pointer ${
                    isSelected 
                      ? `${cat.borderColor} bg-slate-950/90 shadow-lg ring-1 ${cat.borderColor}` 
                      : "border-slate-800/80 bg-slate-950/40 hover:bg-slate-950/70 opacity-75 hover:opacity-100"
                  }`}
                >
                  {isSelected && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  )}
                  <div className="flex items-center gap-1.5">
                    <Icon size={16} className={cat.color} />
                    <span className={`text-xs font-bold font-mono truncate ${isSelected ? "text-white" : "text-slate-300"}`}>
                      {cat.label}
                    </span>
                  </div>
                  <span className="text-[9.5px] text-slate-400 line-clamp-1 mt-1 font-sans">
                    {cat.id === "telegram" ? "Official Channels" : cat.shortLabel}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* STEP 2: TASK FORM INPUTS */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* Task Title */}
            <div className="space-y-1 sm:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono block">
                Task Title *
              </label>
              <input
                type="text"
                placeholder={
                  selectedCategory === "telegram" 
                    ? "e.g. Join TeleFlix Official Announcement Channel" 
                    : selectedCategory === "video_ads"
                    ? "e.g. Watch 30s Sponsored Trailer Ad"
                    : selectedCategory === "daily_reward"
                    ? "e.g. Daily Check-in Streak Reward"
                    : "e.g. Subscribe to TeleFlix YouTube Channel"
                }
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-indigo-500 font-sans transition"
                required
              />
            </div>

            {/* Platform / Sub-Type Selection */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono block">
                Platform / Provider Type
              </label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 outline-none font-mono focus:border-indigo-500 transition cursor-pointer"
              >
                {selectedCategory === "telegram" && (
                  <>
                    <option value="telegram_channel">Official Telegram Channel (Default)</option>
                    <option value="telegram_group">Telegram Community Group</option>
                    <option value="telegram_bot">Telegram Bot Direct Link</option>
                  </>
                )}
                {selectedCategory === "video_ads" && (
                  <>
                    <option value="youtube">YouTube Video Watch</option>
                    <option value="adsgram">Adsgram Rewarded Video</option>
                    <option value="monetag">Monetag Video Tag</option>
                    <option value="video_watch">Direct Video Stream</option>
                  </>
                )}
                {selectedCategory === "social_tasks" && (
                  <>
                    <option value="youtube_subscribe">YouTube Subscribe / Watch</option>
                    <option value="twitter_follow">Twitter / X Follow</option>
                    <option value="facebook_like">Facebook Page Like</option>
                    <option value="instagram_follow">Instagram Follow</option>
                    <option value="website_visit">Website Visit</option>
                    <option value="custom_task">Custom Social Mission</option>
                  </>
                )}
                {selectedCategory === "daily_reward" && (
                  <>
                    <option value="daily_checkin">Daily Check-In Reward</option>
                    <option value="daily_streak">7-Day Streak Bonus</option>
                    <option value="daily_bonus">Mystery Box Token Drop</option>
                  </>
                )}
              </select>
            </div>

            {/* Reward Points */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono flex items-center justify-between">
                <span>Reward Tokens (🪙) *</span>
                <span className="text-amber-400 font-mono font-bold">+{rewardPoints} Tokens</span>
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="10"
                  max="100000"
                  step="10"
                  value={rewardPoints}
                  onChange={(e) => setRewardPoints(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-amber-300 font-mono font-bold outline-none focus:border-amber-500 transition pr-16"
                  required
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  {[150, 300, 500].map(pt => (
                    <button
                      key={pt}
                      type="button"
                      onClick={() => setRewardPoints(pt)}
                      className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                    >
                      {pt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Target URL */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono block">
                Target URL / Invite Link {selectedCategory !== "daily_reward" && "*"}
              </label>
              <input
                type="text"
                placeholder={
                  selectedCategory === "telegram"
                    ? "https://t.me/your_channel_username"
                    : selectedCategory === "video_ads"
                    ? "https://youtube.com/watch?v=..."
                    : "https://..."
                }
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-200 outline-none font-mono focus:border-indigo-500 transition"
                required={selectedCategory !== "daily_reward"}
              />
            </div>

            {/* Verification Dwell Time / Timer */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono flex items-center justify-between">
                <span>Verification Delay / Timer (Sec)</span>
                <span className="text-cyan-400 font-mono">{durationSeconds}s cooldown</span>
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0"
                  max="60"
                  step="5"
                  value={durationSeconds}
                  onChange={(e) => setDurationSeconds(Number(e.target.value))}
                  className="flex-1 accent-indigo-500 cursor-pointer"
                />
                <span className="text-xs font-mono font-bold text-slate-300 w-10 text-right">
                  {durationSeconds}s
                </span>
              </div>
            </div>

            {/* Task Description */}
            <div className="space-y-1 sm:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase font-mono block">
                Instructions / Description
              </label>
              <input
                type="text"
                placeholder="Brief instructions telling users how to complete and claim"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 outline-none focus:border-indigo-500 transition"
              />
            </div>

            {/* Active Status Toggle */}
            <div className="sm:col-span-2 flex items-center justify-between bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5">
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full ${isActive ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}`} />
                <span className="text-xs font-mono font-bold text-slate-200">
                  {isActive ? "Live Task (Users will see this task immediately)" : "Draft / Inactive (Hidden from users)"}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsActive(prev => !prev)}
                className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                  isActive 
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" 
                    : "bg-slate-800 text-slate-400 border border-slate-700"
                }`}
              >
                {isActive ? "ACTIVE" : "INACTIVE"}
              </button>
            </div>
          </div>

          {/* STEP 3: LIVE MOBILE USER VIEW PREVIEW */}
          {showLivePreview && (
            <div className="pt-2 border-t border-slate-800/80 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span className="flex items-center gap-1.5">
                  <Eye size={13} className="text-indigo-400" />
                  Live Mobile User View Preview (ইউজার ইন্টারফেসে যেমন দেখাবে):
                </span>
                <span className="text-[10px] text-emerald-400 font-bold">Interactive Card</span>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-inner">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
                    selectedCategory === "telegram"
                      ? "bg-cyan-500/15 border-cyan-500/30"
                      : selectedCategory === "video_ads"
                      ? "bg-rose-500/15 border-rose-500/30"
                      : selectedCategory === "daily_reward"
                      ? "bg-amber-500/15 border-amber-500/30"
                      : "bg-sky-500/15 border-sky-500/30"
                  }`}>
                    {renderPlatformIcon(selectedCategory, platform, 20)}
                  </div>

                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded border ${
                        TASK_CATEGORIES.find(c => c.id === selectedCategory)?.badgeBg
                      }`}>
                        {TASK_CATEGORIES.find(c => c.id === selectedCategory)?.label}
                      </span>
                      {durationSeconds > 0 && (
                        <span className="text-[9px] font-mono text-slate-400 flex items-center gap-0.5">
                          <Clock size={10} /> {durationSeconds}s
                        </span>
                      )}
                    </div>
                    <h5 className="text-xs font-bold text-white truncate">
                      {title || "Task Title Placeholder"}
                    </h5>
                    <p className="text-[10px] text-slate-400 truncate">
                      {description || "Complete instructions placeholder..."}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/25">
                    <TokenIcon size={12} />
                    <span className="text-xs font-mono font-black text-amber-300">
                      +{rewardPoints}
                    </span>
                  </div>
                  <button
                    type="button"
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 text-white font-mono font-bold text-xs uppercase shadow-md pointer-events-none"
                  >
                    Start
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 py-3 text-white font-black text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                editingMissionId
                  ? "bg-amber-600 hover:bg-amber-500 shadow-amber-600/20"
                  : "bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/20"
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>Saving to System...</span>
                </>
              ) : (
                <>
                  {editingMissionId ? <Check size={14} /> : <Plus size={14} />}
                  <span>{editingMissionId ? "Save Task Changes" : "Publish Task Online"}</span>
                </>
              )}
            </button>

            {editingMissionId && (
              <button
                type="button"
                onClick={handleCancelEdit}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono font-bold text-xs rounded-xl transition cursor-pointer"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* STEP 4: CONFIGURED TASKS DIRECTORY & MANAGEMENT */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4">
        
        {/* Directory Header with Search */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div>
            <h4 className="text-xs sm:text-sm font-black text-white uppercase font-mono flex items-center gap-2">
              <Layers size={15} className="text-indigo-400" />
              <span>Published Tasks Directory ({missions.length})</span>
            </h4>
            <p className="text-[11px] text-slate-400">
              Filter by category, toggle live status, edit parameters or delete
            </p>
          </div>

          <div className="relative min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search published tasks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 outline-none focus:border-indigo-500 font-sans"
            />
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            type="button"
            onClick={() => setListCategoryFilter("all")}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition cursor-pointer ${
              listCategoryFilter === "all"
                ? "bg-indigo-600 text-white shadow-md"
                : "bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800"
            }`}
          >
            All Tasks ({categoryCounts.all})
          </button>

          {TASK_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setListCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition flex items-center gap-1.5 cursor-pointer ${
                listCategoryFilter === cat.id
                  ? `${cat.badgeBg} border ring-1 ring-white/20 font-black`
                  : "bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800"
              }`}
            >
              <span>{cat.label}</span>
              <span className="opacity-75 font-normal">({categoryCounts[cat.id] || 0})</span>
            </button>
          ))}
        </div>

        {/* Task Cards List */}
        {filteredMissions.length === 0 ? (
          <div className="text-center py-10 bg-slate-950/40 rounded-2xl border border-dashed border-slate-800 space-y-2">
            <Layers size={28} className="mx-auto text-slate-600" />
            <p className="text-xs text-slate-400 font-mono">No tasks found for this category</p>
            <p className="text-[11px] text-slate-600">Use the form above to publish your first task in this category</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredMissions.map((m) => {
              const cat = resolveMissionCategory(m);
              const isBeingEdited = editingMissionId === m.id;
              const reward = m.rewardPoints || m.pointsReward || 300;

              return (
                <div
                  key={m.id}
                  className={`bg-slate-950/70 border rounded-2xl p-3 sm:p-3.5 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isBeingEdited 
                      ? "border-amber-500/80 bg-amber-950/20" 
                      : m.isActive === false
                      ? "border-slate-800/40 opacity-60"
                      : "border-slate-800/80 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-start sm:items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0 mt-0.5 sm:mt-0">
                      {renderPlatformIcon(cat, m.platform || m.type, 18)}
                    </div>

                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-full border ${
                          TASK_CATEGORIES.find(c => c.id === cat)?.badgeBg
                        }`}>
                          {TASK_CATEGORIES.find(c => c.id === cat)?.label}
                        </span>

                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                          m.isActive !== false 
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                            : "bg-slate-800 text-slate-400 border-slate-700"
                        }`}>
                          {m.isActive !== false ? "LIVE ONLINE" : "OFFLINE"}
                        </span>

                        {m.durationSeconds ? (
                          <span className="text-[10px] font-mono text-slate-400 flex items-center gap-0.5">
                            <Clock size={10} /> {m.durationSeconds}s
                          </span>
                        ) : null}
                      </div>

                      <h5 className="text-xs sm:text-sm font-bold text-white truncate font-sans">
                        {m.title}
                      </h5>

                      {m.url && (
                        <a
                          href={m.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[10px] font-mono text-slate-400 hover:text-indigo-300 flex items-center gap-1 truncate max-w-sm"
                        >
                          <ExternalLink size={10} />
                          <span className="truncate">{m.url}</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Actions & Rewards */}
                  <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/60">
                    <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/25">
                      <TokenIcon size={13} />
                      <span className="text-xs font-mono font-black text-amber-300">
                        +{reward}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      {/* Live Toggle */}
                      <button
                        type="button"
                        onClick={() => onToggleMission(m.id)}
                        className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-mono font-bold transition cursor-pointer ${
                          m.isActive !== false
                            ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30"
                            : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"
                        }`}
                        title={m.isActive !== false ? "Deactivate Task" : "Activate Task"}
                      >
                        {m.isActive !== false ? "Active" : "Paused"}
                      </button>

                      {/* Edit Button */}
                      <button
                        type="button"
                        onClick={() => handleStartEdit(m)}
                        className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                        title="Edit Task Parameters"
                      >
                        <Pencil size={13} />
                      </button>

                      {/* Delete Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`Permanently delete "${m.title}"?`)) {
                            onDeleteMission(m.id);
                          }
                        }}
                        className="p-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/25 border border-rose-500/30 text-rose-400 hover:text-rose-200 transition cursor-pointer"
                        title="Delete Task"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
