/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { 
  Shield, Users, DollarSign, Plus, 
  Trash2, Check, HelpCircle, 
  Layers, Film, Video as VideoIcon, Pencil, Share2, Globe, Radio,
  Tv, Coins, FileText, Volume2, Link2, Languages, Image as ImageIcon,
  Clock, Sparkles, AlertCircle, AlertTriangle, PlayCircle, Upload, Search, Database, Eye,
  EyeOff, Copy, ExternalLink, CheckCircle2, Zap, X, RefreshCw, Bot, Send, Loader2, Tag, Flame, Lock,
  Mail, Ban, UserCheck, Smartphone, Cloud,
  Activity
} from "lucide-react";
import { Movie, Video, Mission, WithdrawalRequest, MovieRequest, SystemSettings, AdminAnalytics } from "../types";
import { uploadMediaToCloudStorage } from "../services/mediaCloud";
import TokenIcon from "./TokenIcon";
import AdminTaskManager from "./AdminTaskManager";
import AdminPostPublisher from "./AdminPostPublisher";
import Phase6AdminControlPanel from "./admin/Phase6AdminControlPanel";

interface AdminDashboardProps {
  movies: Movie[];
  videos: Video[];
  missions: Mission[];
  withdrawals: WithdrawalRequest[];
  requests?: MovieRequest[];
  settings: SystemSettings;
  analytics: AdminAnalytics;
  onUpdateSettings: (s: Partial<SystemSettings>) => Promise<void>;
  onAddMovie: (m: any) => Promise<void>;
  onAddVideo: (v: any) => Promise<void>;
  onDeleteMovie?: (id: string) => Promise<void>;
  onDeleteVideo?: (id: string) => Promise<void>;
  onClearAllMedia?: (type?: 'movies' | 'videos' | 'all') => Promise<void>;
  onAddMission: (m: Omit<Mission, "id" | "order">) => Promise<void>;
  onEditMission?: (m: Mission) => Promise<void>;
  onDeleteMission?: (id: string) => Promise<void>;
  onToggleMovie: (id: string) => Promise<void>;
  onToggleVideo: (id: string) => Promise<void>;
  onToggleMission: (id: string) => Promise<void>;
  onUpdateWithdrawal: (id: string, status: 'approved' | 'rejected') => Promise<void>;
  onUpdateRequestStatus?: (id: string, status: 'approved' | 'rejected') => Promise<void>;
  onBroadcastNotification?: (title: string, message: string) => Promise<void>;
  onReorderMissions?: (orders: { id: string; order: number }[]) => Promise<void>;
  onBanUser?: (userId: string, isBanned: boolean, reason?: string) => Promise<void>;
  onClose?: () => void;
}

export type AdminTabType = 
  | 'phase6'       // 🛡️ Phase 6 Gateway & Ads Control
  | 'library'      // 🎬 Media Catalog
  | 'content'      // ⚡ Fast Publisher
  | 'ads'          // 📡 Ad Networks
  | 'guide'        // 🎓 Global Guide & Voice
  | 'telegram'     // 🤖 Telegram Bot Control
  | 'rewards'      // 💰 Rewards & Program
  | 'missions'     // ⚡ Tasks Control
  | 'withdrawals'  // 🏦 Cashout Pipeline
  | 'system';      // Alias for guide

export default function AdminDashboard({
  movies,
  videos,
  missions,
  withdrawals,
  settings,
  analytics,
  onUpdateSettings,
  onAddMovie,
  onAddVideo,
  onDeleteMovie,
  onDeleteVideo,
  onClearAllMedia,
  onToggleMovie,
  onToggleVideo,
  onAddMission,
  onEditMission,
  onDeleteMission,
  onToggleMission,
  onUpdateWithdrawal,
  onBanUser,
  onClose,
}: AdminDashboardProps) {
  const [adminTab, setAdminTab] = useState<AdminTabType>('library');

  // Media Library & AI Search States
  const [libSearchQuery, setLibSearchQuery] = useState('');
  const [libFilter, setLibFilter] = useState<'all' | 'movies' | 'adult_movies' | 'drama' | 'series' | 'videos'>('all');
  const [visibleCount, setVisibleCount] = useState(25);
  const [copiedItemId, setCopiedItemId] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState(false);
  const [isClearingMedia, setIsClearingMedia] = useState(false);
  const [adminToast, setAdminToast] = useState<{ message: string; type?: 'success' | 'info' | 'error' } | null>(null);
  // Users List (used for applicant identity & 1-click ban in Withdrawals)
  const [usersList, setUsersList] = useState<any[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [banningUserId, setBanningUserId] = useState<string | null>(null);

  const fetchUsers = async () => {
    setIsLoadingUsers(true);
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsersList(Array.isArray(data) ? data : []);
      }
    } catch (e) {
      console.warn('Failed to load users list:', e);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  useEffect(() => {
    if (adminTab === 'withdrawals') {
      fetchUsers();
    }
  }, [adminTab]);

  const handleToggleUserBan = async (userId: string, currentBanned: boolean, email?: string) => {
    if (!userId) return;
    setBanningUserId(userId);
    const newBanned = !currentBanned;
    try {
      if (onBanUser) {
        await onBanUser(userId, newBanned, newBanned ? 'Restricted by Admin (Anti-Fraud Device Binding Policy)' : undefined);
      } else {
        const res = await fetch('/api/admin/users/ban', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId,
            isBanned: newBanned,
            reason: newBanned ? 'Restricted by Admin (Anti-Fraud Device Binding Policy)' : undefined,
          }),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to update ban status');
        }
      }

      // Optimistically update local usersList
      setUsersList(prev => prev.map(u => u.id === userId ? {
        ...u, 
        isBanned: newBanned, 
        status: newBanned ? 'banned' : 'active',
        banReason: newBanned ? 'Restricted by Admin (Anti-Fraud Device Binding Policy)' : ''
      } : u));
      
      showAdminToast(
        newBanned 
          ? `Banned profile ${email || userId}. Cashouts restricted.` 
          : `Restored profile ${email || userId}. Account active.`,
        newBanned ? 'info' : 'success'
      );
    } catch (err: any) {
      showAdminToast(err.message || 'Failed to update ban state', 'error');
    } finally {
      setBanningUserId(null);
    }
  };

  // Withdrawal Requests Approval Panel States
  const [withdrawalFilter, setWithdrawalFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [withdrawalSearchQuery, setWithdrawalSearchQuery] = useState('');
  const [copiedWithdrawalId, setCopiedWithdrawalId] = useState<string | null>(null);

  const filteredWithdrawals = useMemo(() => {
    return withdrawals.filter(w => {
      // 1. Status filter
      if (withdrawalFilter === 'pending' && w.status !== 'pending') return false;
      if (withdrawalFilter === 'approved' && w.status !== 'approved' && (w as any).status !== 'paid') return false;
      if (withdrawalFilter === 'rejected' && w.status !== 'rejected') return false;

      // 2. Search query
      if (withdrawalSearchQuery.trim()) {
        const q = withdrawalSearchQuery.toLowerCase();
        const applicant = (w.email || (w as any).userEmail || '').toLowerCase();
        const username = (w.username || '').toLowerCase();
        const account = (w.accountNumber || w.walletAddress || '').toLowerCase();
        const method = (w.paymentMethod || '').toLowerCase();
        const id = (w.id || '').toLowerCase();
        return applicant.includes(q) || username.includes(q) || account.includes(q) || method.includes(q) || id.includes(q);
      }

      return true;
    });
  }, [withdrawals, withdrawalFilter, withdrawalSearchQuery]);

  const showAdminToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setAdminToast({ message, type });
    setTimeout(() => setAdminToast(null), 5000);
  };

  const handleExecuteClearDatabase = async () => {
    setIsClearingMedia(true);
    try {
      if (onClearAllMedia) {
        await onClearAllMedia('all');
      } else {
        const res = await fetch('/api/media/clear-all', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'all' }),
        });
        if (!res.ok) throw new Error("Failed to clear database");
      }
      showAdminToast("✓ সকল পোস্ট ডাটাবেজ থেকে সম্পূর্ণ ডিলিট করা হয়েছে!");
      setShowClearConfirmModal(false);
    } catch (e: any) {
      showAdminToast("ডাটাবেজ ক্লিয়ার করতে ব্যর্থ হয়েছে: " + (e.message || "Error"), 'error');
    } finally {
      setIsClearingMedia(false);
    }
  };

  // Form States
  // 1. Settings Sub-states
  const [settDomain, setSettDomain] = useState(settings.domain);
  const [settRefReward, setSettRefReward] = useState(settings.referralReward);
  const [settCommPercent, setSettCommPercent] = useState(settings.referralCommissionPercent);
  const [settMinWithdrawal, setSettMinWithdrawal] = useState(settings.minimumWithdrawal);
  const [settBotLink, setSettBotLink] = useState(settings.telegramBotLink);
  const [settDefaultRewardPts, setSettDefaultRewardPts] = useState(settings.default_reward_pts || 500);
  const [settGuideVideo, setSettGuideVideo] = useState(() => {
    return localStorage.getItem('teleflix_sett_guide_video') || settings.guide_video_url || settings.guideVideoUrl || "";
  });
  const [settGuideAudio, setSettGuideAudio] = useState(() => {
    return localStorage.getItem('teleflix_sett_guide_audio') || settings.guide_audio_url || settings.guideAudioUrl || "";
  });
  const [settGuideLogo, setSettGuideLogo] = useState(() => {
    return localStorage.getItem('teleflix_sett_guide_logo') || settings.guideVideoLogoUrl || "";
  });
  const [isSavingGuideSettings, setIsSavingGuideSettings] = useState(false);
  const [settActiveMags, setSettActiveMags] = useState(settings.activeMagazines || 3);
  const [settBatterySites, setSettBatterySites] = useState((settings.battery_site_urls || settings.batterySites || []).join("\n"));
  const [settChannelUrl, setSettChannelUrl] = useState(settings.telegramChannelUrl || "https://t.me/myteleflix_official");
  const [settPostId, setSettPostId] = useState(settings.telegramPostId || "https://t.me/myteleflix_official/124");
  const [settReactionReward, setSettReactionReward] = useState(settings.reactionRewardPoints || 50);
  const [settTokenRateBdt, setSettTokenRateBdt] = useState(settings.tokenRateBdt || 100);
  const [settTokenRateUsd, setSettTokenRateUsd] = useState(settings.tokenRateUsd || 0.85);

  // Sync settings when props change
  useEffect(() => {
    if (settings.guide_video_url || settings.guideVideoUrl) {
      setSettGuideVideo(settings.guide_video_url || settings.guideVideoUrl || "");
    }
    if (settings.guide_audio_url || settings.guideAudioUrl) {
      setSettGuideAudio(settings.guide_audio_url || settings.guideAudioUrl || "");
    }
    if (settings.guideVideoLogoUrl) {
      setSettGuideLogo(settings.guideVideoLogoUrl || "");
    }
    if (settings.tokenRateBdt) {
      setSettTokenRateBdt(settings.tokenRateBdt);
    }
    if (settings.tokenRateUsd) {
      setSettTokenRateUsd(settings.tokenRateUsd);
    }
  }, [settings.guide_video_url, settings.guideVideoUrl, settings.guide_audio_url, settings.guideAudioUrl, settings.guideVideoLogoUrl, settings.tokenRateBdt, settings.tokenRateUsd]);

  // Dedicated Ad Networks states
  const [settMonetagKey, setSettMonetagKey] = useState((settings as any).monetagKey || "monetag_direct_tag_default");
  const [settAdsgramZone, setSettAdsgramZone] = useState((settings as any).adsgramZone || "adsgram_3521");
  const [settTelegaId, setSettTelegaId] = useState((settings as any).telegaId || "telega_pub_108");
  const [settAdNetworkType, setSettAdNetworkType] = useState<'adsterra' | 'monetag' | 'adsense' | 'direct'>(
    (settings as any).adNetworkType || 'monetag'
  );
  const [settAdNetworkEnabled, setSettAdNetworkEnabled] = useState<boolean>(
    (settings as any).adNetworkEnabled ?? true
  );
  const [settAdsterraDirectLink, setSettAdsterraDirectLink] = useState(
    (settings as any).adsterraDirectLink || "https://www.profitablecpmrate.com/sample"
  );
  const [settAdsterraScriptTag, setSettAdsterraScriptTag] = useState(
    (settings as any).adsterraScriptTag || "//pl23456789.profitablecpmrate.com/sample.js"
  );
  const [settMonetagDirectTag, setSettMonetagDirectTag] = useState(
    (settings as any).monetagDirectTag || (settings as any).monetagKey || "https://alwingulla.com/sample"
  );
  const [settMonetagScriptCode, setSettMonetagScriptCode] = useState(
    (settings as any).monetagScriptCode || "https://alwingulla.com/tag.min.js"
  );
  const [settAdsenseClient, setSettAdsenseClient] = useState(
    (settings as any).adsenseClient || "ca-pub-1234567890123456"
  );
  const [settAdsenseSlot, setSettAdsenseSlot] = useState(
    (settings as any).adsenseSlot || "9876543210"
  );
  const [settDirectImpressionUrl, setSettDirectImpressionUrl] = useState(
    (settings as any).directImpressionUrl || "https://t.me/myteleflix_bot"
  );
  const [settAdRewardPoints, setSettAdRewardPoints] = useState<number>(
    (settings as any).adRewardPoints || 150
  );
  const [settVideoPreRollAd, setSettVideoPreRollAd] = useState<boolean>(
    (settings as any).videoPreRollAd ?? true
  );
  const [settVideoMidRollAd, setSettVideoMidRollAd] = useState<boolean>(
    (settings as any).videoMidRollAd ?? false
  );

  // Content Post Form States
  const [postContentType, setPostContentType] = useState<'movie' | 'adult_movie' | 'video' | 'drama' | 'series'>('movie');
  const [isAdultUnlocked, setIsAdultUnlocked] = useState(false);
  const [postTitle, setPostTitle] = useState('');
  const [postGenre, setPostGenre] = useState('Cinema Release');
  const [postCategory, setPostCategory] = useState<string>('Deshi');
  const [postRating, setPostRating] = useState('8.8');
  const [postDescription, setPostDescription] = useState('');
  const [postDuration, setPostDuration] = useState('2h 15m');
  const [postTotalEpisodes, setPostTotalEpisodes] = useState('Season 1 • Full Pack');
  const [postAttachmentUrl, setPostAttachmentUrl] = useState('');
  const [postTutorialVideoUrl, setPostTutorialVideoUrl] = useState('');
  const [postAudioUrl, setPostAudioUrl] = useState('');
  const [postLanguages, setPostLanguages] = useState<string[]>(['original']);
  const [postDestinationLink, setPostDestinationLink] = useState('');
  const [postBanglaLink, setPostBanglaLink] = useState('');
  const [postHindiLink, setPostHindiLink] = useState('');
  const [postEnglishLink, setPostEnglishLink] = useState('');
  const [postOriginalLink, setPostOriginalLink] = useState('');
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [editingPostItem, setEditingPostItem] = useState<Movie | Video | null>(null);
  const [postPublishing, setPostPublishing] = useState(false);

  const normalizeLangKey = (lang: string): string => {
    const l = (lang || '').toLowerCase().trim();
    if (l.includes('bangla') || l.includes('bn')) return 'bangla';
    if (l.includes('hindi') || l.includes('hi')) return 'hindi';
    if (l.includes('english') || l.includes('en')) return 'english';
    if (l.includes('original') || l.includes('org')) return 'original';
    return l || 'original';
  };

  const toggleLanguage = (langKey: string) => {
    const normKey = normalizeLangKey(langKey);
    setPostLanguages(prev => {
      const currentNorms = Array.from(new Set(prev.map(normalizeLangKey)));
      if (currentNorms.includes(normKey)) {
        const remaining = currentNorms.filter(l => l !== normKey);
        return remaining;
      } else {
        return [...currentNorms, normKey];
      }
    });
  };

  // Referral Payout Plan Switch State (Plan A vs Plan B)
  const [activeReferralPlan, setActiveReferralPlan] = useState<'PLAN_A' | 'PLAN_B'>(
    settings.referralPayoutPlan || 'PLAN_A'
  );
  const [isSwitchingReferralPlan, setIsSwitchingReferralPlan] = useState(false);

  useEffect(() => {
    if (settings.referralPayoutPlan) {
      setActiveReferralPlan(settings.referralPayoutPlan);
    }
  }, [settings.referralPayoutPlan]);

  const handleSwitchReferralPlan = async (targetPlan: 'PLAN_A' | 'PLAN_B') => {
    if (isSwitchingReferralPlan || targetPlan === activeReferralPlan) return;
    setIsSwitchingReferralPlan(true);
    try {
      const res = await fetch('/api/admin/referral-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: targetPlan }),
      });
      if (res.ok) {
        setActiveReferralPlan(targetPlan);
        await onUpdateSettings({ referralPayoutPlan: targetPlan });
        showAdminToast(`✓ ${targetPlan === 'PLAN_A' ? 'Plan A (Viral Expansion)' : 'Plan B (Profit Optimization)'} Activated!`, 'success');
      } else {
        throw new Error("Failed to update referral plan on server");
      }
    } catch (err: any) {
      setActiveReferralPlan(targetPlan);
      await onUpdateSettings({ referralPayoutPlan: targetPlan });
      showAdminToast(`✓ Referral model updated to ${targetPlan === 'PLAN_A' ? 'Plan A' : 'Plan B'}`, 'success');
    } finally {
      setIsSwitchingReferralPlan(false);
    }
  };

  // Helper to scroll horizontal containers so clicked item smoothly moves to the left/start edge
  const scrollContainerToElement = (target: HTMLElement) => {
    const container = target.closest('[data-scroll-container="true"]') as HTMLElement | null;
    if (container) {
      const containerRect = container.getBoundingClientRect();
      const targetRect = target.getBoundingClientRect();
      const scrollOffset = targetRect.left - containerRect.left + container.scrollLeft - 8;
      container.scrollTo({
        left: Math.max(0, scrollOffset),
        behavior: 'smooth',
      });
    } else {
      target.scrollIntoView({ behavior: 'smooth', inline: 'start', block: 'nearest' });
    }
  };

  const handleSelectTab = (tab: AdminTabType, e?: React.MouseEvent<HTMLElement>) => {
    setAdminTab(tab);
    if (e?.currentTarget) {
      scrollContainerToElement(e.currentTarget);
    }
  };

  const handleSelectCategory = (cat: 'all' | 'movies' | 'adult_movies' | 'drama' | 'series' | 'videos', e?: React.MouseEvent<HTMLElement>) => {
    setLibFilter(cat);
    if (e?.currentTarget) {
      scrollContainerToElement(e.currentTarget);
    }
  };

  // Auto-scroll the active tab into view on the left edge whenever adminTab changes
  useEffect(() => {
    const timer = setTimeout(() => {
      const activeBtn = document.querySelector(`[data-tab-key="${adminTab}"]`) as HTMLElement | null;
      if (activeBtn) {
        scrollContainerToElement(activeBtn);
      }
    }, 60);
    return () => clearTimeout(timer);
  }, [adminTab]);

  // Client-side image compressor for mobile phones (resizes 8MB-20MB camera photos down to crisp ~400KB WebP/JPEG)
  const compressImageForUpload = async (file: File): Promise<File> => {
    if (!file.type.startsWith('image/') || file.type.includes('svg') || file.type.includes('gif')) {
      return file;
    }
    // If image is already lightweight (< 600KB), keep as-is
    if (file.size < 600 * 1024) {
      return file;
    }

    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        try {
          const MAX_WIDTH = 1440;
          const MAX_HEIGHT = 2160;
          let { width, height } = img;

          if (width > MAX_WIDTH || height > MAX_HEIGHT) {
            if (width / height > MAX_WIDTH / MAX_HEIGHT) {
              height = Math.round((height * MAX_WIDTH) / width);
              width = MAX_WIDTH;
            } else {
              width = Math.round((width * MAX_HEIGHT) / height);
              height = MAX_HEIGHT;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(file);
            return;
          }

          ctx.drawImage(img, 0, 0, width, height);

          canvas.toBlob(
            (blob) => {
              if (blob && blob.size < file.size) {
                const cleanName = file.name.replace(/\.[^/.]+$/, "") + ".jpg";
                const compressedFile = new File([blob], cleanName, {
                  type: 'image/jpeg',
                  lastModified: Date.now(),
                });
                resolve(compressedFile);
              } else {
                resolve(file);
              }
            },
            'image/jpeg',
            0.85
          );
        } catch (err) {
          console.warn("Image compression fallback to original", err);
          resolve(file);
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        resolve(file);
      };
      img.src = url;
    });
  };

  // Upload and Server Media States
  const [uploadingGuideAudio, setUploadingGuideAudio] = useState(false);
  const [posterInputKey, setPosterInputKey] = useState(0);
  
  // Real-time Upload Progress Tracker for heavy 2GB - 3GB+ files
  const [activeUpload, setActiveUpload] = useState<{
    fileName: string;
    percent: number;
    sizeText: string;
    speedText: string;
    status: 'uploading' | 'processing' | 'done' | 'error';
    message?: string;
  } | null>(null);

  // High-Capacity Resilient Upload Helper with Chunking (Prevents 413 Request Entity Too Large on 2GB-3GB+ files)
  const uploadFileWithProgress = async (initialFile: File, label: string): Promise<string> => {
    // 1. Mobile Camera Optimization: Compress oversized images to avoid browser tab memory exhaustion
    let file = initialFile;
    if (initialFile.type.startsWith('image/')) {
      try {
        file = await compressImageForUpload(initialFile);
      } catch (err) {
        file = initialFile;
      }
    }

    const startTime = Date.now();
    const formattedTotal = file.size > 1024 * 1024 * 1024 
      ? `${(file.size / (1024 * 1024 * 1024)).toFixed(2)} GB` 
      : `${(file.size / (1024 * 1024)).toFixed(1)} MB`;

    setActiveUpload({
      fileName: `${label}: ${file.name}`,
      percent: 0,
      sizeText: `0.0 MB / ${formattedTotal}`,
      speedText: 'Starting transfer...',
      status: 'uploading',
    });

    // Strategy 1: Direct High-Speed Cloud Storage (Firebase Cloud Storage Bucket)
    try {
      const cloudFolder = file.type.startsWith('video/') ? 'videos' : file.type.startsWith('audio/') ? 'audio' : 'posters';
      const cloudUrl = await uploadMediaToCloudStorage(file, cloudFolder, (p) => {
        setActiveUpload({
          fileName: `${label}: ${file.name}`,
          percent: p.percent,
          sizeText: `${(p.bytesTransferred / (1024 * 1024)).toFixed(1)} MB / ${formattedTotal}`,
          speedText: p.status === 'completed' ? 'Cloud Saved' : `${p.speedMB} MB/s`,
          status: p.status === 'completed' ? 'done' : p.status === 'optimizing' ? 'processing' : 'uploading',
          message: p.status === 'completed' ? 'Cloud CDN media ready for instant streaming!' : undefined,
        });
      });
      if (cloudUrl) {
        setTimeout(() => setActiveUpload(null), 1500);
        showAdminToast(`✓ ${label} Cloud CDN-এ সফলভাবে আপলোড হয়েছে!`);
        return cloudUrl;
      }
    } catch (cloudErr) {
      console.warn("[Cloud Storage Upload fallback to Server Upload]", cloudErr);
    }

    // Strategy 2: Server Chunked & Direct Fallback
    const DIRECT_UPLOAD_LIMIT = 15 * 1024 * 1024;
    const CHUNK_SIZE = 3 * 1024 * 1024; // 3MB chunk size for huge 2GB+ video files

    if (file.size <= DIRECT_UPLOAD_LIMIT) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.timeout = 120000; // 120s timeout safeguard
        
        xhr.upload.addEventListener('progress', (e) => {
          if (e.lengthComputable) {
            const rawPercent = Math.round((e.loaded / e.total) * 100);
            const isComplete = e.loaded >= e.total;
            const percent = isComplete ? 100 : Math.min(rawPercent, 99);
            const elapsedSec = (Date.now() - startTime) / 1000;
            const speedMB = elapsedSec > 0 ? ((e.loaded / (1024 * 1024)) / elapsedSec).toFixed(1) : '0';
            setActiveUpload({
              fileName: `${label}: ${file.name}`,
              percent,
              sizeText: `${(e.loaded / (1024 * 1024)).toFixed(1)} MB / ${formattedTotal}`,
              speedText: isComplete ? 'Saving to server...' : `${speedMB} MB/s`,
              status: isComplete ? 'processing' : 'uploading',
            });
          }
        });

        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const data = JSON.parse(xhr.responseText);
              const returnedUrl = data.url || (data.filename ? `/uploads/${data.filename}` : '');
              if (returnedUrl) {
                setActiveUpload({
                  fileName: `${label}: ${file.name}`,
                  percent: 100,
                  sizeText: 'Upload Complete',
                  speedText: 'Saved to Disk',
                  status: 'done',
                  message: 'Media saved permanently to server storage!',
                });
                setTimeout(() => setActiveUpload(null), 1500);
                showAdminToast(`✓ ${label} আপলোড সম্পন্ন হয়েছে!`);
                resolve(returnedUrl);
              } else {
                throw new Error("Invalid response format");
              }
            } catch (e: any) {
              setActiveUpload({
                fileName: file.name,
                percent: 0,
                sizeText: 'Error',
                speedText: 'Failed',
                status: 'error',
                message: e.message || "Failed to parse upload response",
              });
              setTimeout(() => setActiveUpload(null), 3000);
              reject(new Error(e.message || "Failed to parse upload response"));
            }
          } else {
            setActiveUpload({
              fileName: file.name,
              percent: 0,
              sizeText: 'Error',
              speedText: 'Failed',
              status: 'error',
              message: `Upload failed with status ${xhr.status}`,
            });
            setTimeout(() => setActiveUpload(null), 3000);
            reject(new Error(`Upload failed with status ${xhr.status}`));
          }
        };

        xhr.ontimeout = () => {
          setActiveUpload({
            fileName: file.name,
            percent: 0,
            sizeText: 'Timeout',
            speedText: 'Failed',
            status: 'error',
            message: "Upload timed out. Please retry.",
          });
          setTimeout(() => setActiveUpload(null), 3000);
          reject(new Error("Upload timed out. Please retry."));
        };

        xhr.onerror = () => {
          setActiveUpload({
            fileName: file.name,
            percent: 0,
            sizeText: 'Error',
            speedText: 'Failed',
            status: 'error',
            message: "Network connection interrupted",
          });
          setTimeout(() => setActiveUpload(null), 3000);
          reject(new Error("Network connection interrupted"));
        };

        const formData = new FormData();
        formData.append('file', file);
        xhr.open('POST', '/api/upload');
        xhr.send(formData);
      });
    }

    // For huge files (> 15MB), use Sliced Chunk Upload to guarantee 0% failure & 0% 413 errors
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
    const uploadId = `up_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

    let uploadedBytes = 0;

    for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
      const start = chunkIndex * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, file.size);
      const chunkBlob = file.slice(start, end);

      const chunkForm = new FormData();
      chunkForm.append('uploadId', uploadId);
      chunkForm.append('chunkIndex', String(chunkIndex));
      chunkForm.append('totalChunks', String(totalChunks));
      chunkForm.append('filename', file.name);
      chunkForm.append('chunk', chunkBlob, `part_${chunkIndex}.bin`);

      const chunkEndpoint = `/api/upload/chunk?uploadId=${encodeURIComponent(uploadId)}&chunkIndex=${chunkIndex}&totalChunks=${totalChunks}&filename=${encodeURIComponent(file.name)}`;

      let chunkSuccess = false;
      let attempts = 0;

      while (!chunkSuccess && attempts < 3) {
        attempts++;
        try {
          const res = await fetch(chunkEndpoint, {
            method: 'POST',
            headers: {
              'x-upload-id': uploadId,
              'x-chunk-index': String(chunkIndex),
              'x-total-chunks': String(totalChunks),
            },
            body: chunkForm,
          });
          if (res.ok) {
            chunkSuccess = true;
          } else {
            const errJson = await res.json().catch(() => ({}));
            if (attempts >= 3) throw new Error(errJson.error || `Chunk ${chunkIndex + 1}/${totalChunks} failed with status ${res.status}`);
            await new Promise(r => setTimeout(r, 600));
          }
        } catch (err: any) {
          if (attempts >= 3) {
            setActiveUpload({
              fileName: file.name,
              percent: 0,
              sizeText: 'Upload Failed',
              speedText: '0 MB/s',
              status: 'error',
              message: `Transfer error on part ${chunkIndex + 1}: ${err.message}`,
            });
            setTimeout(() => setActiveUpload(null), 4000);
            throw err;
          }
          await new Promise(r => setTimeout(r, 1000));
        }
      }

      uploadedBytes += (end - start);
      const rawPercent = Math.round((uploadedBytes / file.size) * 100);
      const isComplete = chunkIndex === totalChunks - 1;
      const elapsedSec = (Date.now() - startTime) / 1000;
      const speedMB = elapsedSec > 0 ? ((uploadedBytes / (1024 * 1024)) / elapsedSec).toFixed(1) : '0';
      
      const currentSizeFormatted = file.size > 1024 * 1024 * 1024 
        ? `${(uploadedBytes / (1024 * 1024 * 1024)).toFixed(2)} GB` 
        : `${(uploadedBytes / (1024 * 1024)).toFixed(1)} MB`;

      setActiveUpload({
        fileName: `${label}: ${file.name}`,
        percent: isComplete ? 100 : Math.min(rawPercent, 99),
        sizeText: `${currentSizeFormatted} / ${formattedTotal} • Part ${chunkIndex + 1}/${totalChunks}`,
        speedText: isComplete ? 'Assembling on server...' : `${speedMB} MB/s`,
        status: isComplete ? 'processing' : 'uploading',
      });
    }

    // All chunks uploaded: trigger assembly on server
    try {
      const completeRes = await fetch('/api/upload/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uploadId,
          totalChunks,
          originalName: file.name,
          mimeType: file.type,
        }),
      });

      if (!completeRes.ok) {
        const errJson = await completeRes.json().catch(() => ({}));
        throw new Error(errJson.error || `Server assembly failed with status ${completeRes.status}`);
      }

      const completeData = await completeRes.json();
      const finalUrl = completeData.url || `/uploads/${completeData.filename}`;

      setActiveUpload({
        fileName: `${label}: ${file.name}`,
        percent: 100,
        sizeText: 'Upload Complete',
        speedText: 'Saved to Disk',
        status: 'done',
        message: 'Media saved permanently to server storage!',
      });
      setTimeout(() => setActiveUpload(null), 2000);

      return finalUrl;
    } catch (err: any) {
      setActiveUpload({
        fileName: file.name,
        percent: 0,
        sizeText: 'Assembly Failed',
        speedText: '0 MB/s',
        status: 'error',
        message: err.message || "Failed to finalize uploaded media.",
      });
      setTimeout(() => setActiveUpload(null), 4000);
      throw err;
    }
  };

  // Safe Disk File Deletion Helper
  const deleteUploadedFile = async (url: string) => {
    if (!url || !url.startsWith('/uploads/')) return;
    try {
      await fetch('/api/upload/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
    } catch (e) {
      console.warn("Delete file error:", e);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await uploadFileWithProgress(file, "Poster Image");
      setPostAttachmentUrl(url);
    } catch (err: any) {
      alert("Failed to upload poster: " + (err.message || "Unknown error"));
    } finally {
      try {
        if (e.target) e.target.value = '';
      } catch (err) {}
      setPosterInputKey(prev => prev + 1);
    }
  };

  const handleSystemGuideAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setUploadingGuideAudio(true);
      const url = await uploadFileWithProgress(file, "Voice Audio (MP3)");
      setSettGuideAudio(url);
      localStorage.setItem('teleflix_sett_guide_audio', url);
      await onUpdateSettings({
        guide_audio_url: url,
        guideAudioUrl: url,
      } as any);
      alert("✅ Voice Guide Audio uploaded and configured successfully!");
    } catch (err: any) {
      alert("Failed to upload audio: " + (err.message || "Unknown error"));
    } finally {
      setUploadingGuideAudio(false);
      e.target.value = '';
    }
  };

  const handleSaveGuideSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    try {
      setIsSavingGuideSettings(true);
      // 1. Cache to local storage immediately
      localStorage.setItem('teleflix_sett_guide_video', settGuideVideo || '');
      localStorage.setItem('teleflix_sett_guide_audio', settGuideAudio || '');
      localStorage.setItem('teleflix_sett_guide_logo', settGuideLogo || '');

      const payload = {
        guide_video_url: settGuideVideo || '',
        guideVideoUrl: settGuideVideo || '',
        guide_audio_url: settGuideAudio || '',
        guideAudioUrl: settGuideAudio || '',
        guideVideoLogoUrl: settGuideLogo || '',
      };

      // 2. Call parent onUpdateSettings
      await onUpdateSettings(payload as any);

      // 3. Post directly to server API /api/settings to guarantee server-side persistence in database
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(err => console.warn("API settings save backup error:", err));

      showAdminToast("✓ গাইড লিংক সেটিংস সংরক্ষিত হয়েছে!");
    } catch (err: any) {
      console.error("Save guide settings error:", err);
      showAdminToast("Failed to save settings: " + (err.message || "Unknown error"), 'error');
    } finally {
      setIsSavingGuideSettings(false);
    }
  };

  const handleDeleteGuideVideo = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (confirm("Are you sure you want to delete this Telegram Guide Bot Link?")) {
      const oldUrl = settGuideVideo;
      // 1. Immediately clear input state and cached storage
      setSettGuideVideo('');
      localStorage.removeItem('teleflix_sett_guide_video');
      // 2. Delete file from disk if uploaded
      if (oldUrl) {
        await deleteUploadedFile(oldUrl);
      }
      const payload = {
        guide_video_url: '',
        guideVideoUrl: '',
      };
      // 3. Persist cleared settings to backend
      await onUpdateSettings(payload as any);
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(err => console.warn("API delete guide video error:", err));

      showAdminToast("✓ গাইড ভিডিও লিংক মুছে ফেলা হয়েছে!");
    }
  };

  const handleDeleteGuideAudio = async (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (confirm("Are you sure you want to delete this Voice Guide Audio?")) {
      const oldUrl = settGuideAudio;
      // 1. Immediately clear input state and cached storage
      setSettGuideAudio('');
      localStorage.removeItem('teleflix_sett_guide_audio');
      // 2. Delete file from disk if uploaded
      if (oldUrl) {
        await deleteUploadedFile(oldUrl);
      }
      const payload = {
        guide_audio_url: '',
        guideAudioUrl: '',
      };
      // 3. Persist cleared settings to backend
      await onUpdateSettings(payload as any);
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(err => console.warn("API delete guide audio error:", err));

      alert("🗑️ Voice Guide Audio deleted and removed successfully!");
    }
  };

  const handleStartEditMovie = (m: Movie) => {
    setEditingPostId(m.id);
    setEditingPostItem(m);
    const targetType = (m.contentType || (m.category === 'Adult Movies' ? 'adult_movie' : 'movie')) as 'movie' | 'adult_movie' | 'drama' | 'series';
    setPostContentType(targetType);
    if (targetType === 'adult_movie') {
      setIsAdultUnlocked(true);
    }
    setPostTitle(m.title);
    setPostGenre(m.genre || (targetType === 'drama' ? 'Bangla Natok' : targetType === 'series' ? 'Web Series' : targetType === 'adult_movie' ? 'Adult 18+' : 'Cinema Release'));
    setPostCategory(m.category || '');
    setPostRating(String(m.rating || 8.8));
    setPostDescription(m.description || '');
    setPostDuration(m.duration || (targetType === 'drama' ? '45m' : targetType === 'series' ? '25m/Ep' : targetType === 'adult_movie' ? '1h 35m' : '2h 15m'));
    setPostTotalEpisodes(m.totalEpisodes || 'Season 1 • Full Pack');
    setPostAttachmentUrl(m.thumbnailUrl || '');
    setPostTutorialVideoUrl(m.tutorialVideoUrl || '');
    setPostAudioUrl(m.audioUrl || '');
    setPostLanguages(m.languages && m.languages.length > 0 ? m.languages.map(normalizeLangKey) : ['original']);
    setPostDestinationLink(m.videoUrl || '');
    setPostBanglaLink(m.banglaLink || '');
    setPostHindiLink(m.hindiLink || '');
    setPostEnglishLink(m.englishLink || '');
    setPostOriginalLink(m.originalLink || '');
    setAdminTab('content');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartEditVideo = (v: Video) => {
    setEditingPostId(v.id);
    setEditingPostItem(v);
    setPostContentType('video');
    setPostTitle(v.title);
    setPostGenre(v.genre || 'Clip Release');
    setPostCategory(v.category || 'Deshi');
    setPostRating(String(v.rating || 8.5));
    setPostDescription(v.description || '');
    setPostDuration(v.duration || '3m 45s');
    setPostAttachmentUrl(v.thumbnailUrl || '');
    setPostTutorialVideoUrl(v.tutorialVideoUrl || '');
    setPostAudioUrl(v.audioUrl || '');
    setPostLanguages(v.languages && v.languages.length > 0 ? v.languages : ['Original language']);
    setPostDestinationLink(v.videoUrl || '');
    setPostBanglaLink(v.banglaLink || '');
    setPostHindiLink(v.hindiLink || '');
    setPostEnglishLink(v.englishLink || '');
    setPostOriginalLink(v.originalLink || '');
    setAdminTab('content');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCopyLink = async (url: string, id: string) => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopiedItemId(id);
      setTimeout(() => setCopiedItemId(null), 2000);
    } catch (e) {
      console.error("Copy error:", e);
    }
  };

  const handleDeleteRecord = async (id: string, type: 'movie' | 'video') => {
    if (type === 'movie' && onDeleteMovie) {
      await onDeleteMovie(id);
    } else if (type === 'video' && onDeleteVideo) {
      await onDeleteVideo(id);
    }
    setDeletingId(null);
  };

  const handleToggleRecord = async (id: string, type: 'movie' | 'video') => {
    if (type === 'movie') {
      await onToggleMovie(id);
    } else {
      await onToggleVideo(id);
    }
  };

  // Helper to determine if an item is within the 48-hour active window
  const isItemWithin48Hours = (item: { createdAt?: string }, index: number, total: number) => {
    if (item.createdAt) {
      const itemTime = new Date(item.createdAt).getTime();
      if (!isNaN(itemTime)) {
        return (Date.now() - itemTime) <= 48 * 60 * 60 * 1000;
      }
    }
    // For items without explicit createdAt timestamp, treat the latest items as recent active window
    return index < Math.min(8, Math.max(2, Math.ceil(total * 0.45)));
  };

  // Unified items list with normalized type
  const allMediaItems = useMemo(() => {
    const mList = movies.map((m, idx) => ({
      ...m,
      mediaType: 'movie' as const,
      isRecent48h: isItemWithin48Hours(m, idx, movies.length),
    }));
    const vList = videos.map((v, idx) => ({
      ...v,
      mediaType: 'video' as const,
      isRecent48h: isItemWithin48Hours(v, idx, videos.length),
    }));
    return [...mList, ...vList];
  }, [movies, videos]);

  // Dynamic filter and search computation
  const filteredMediaItems = useMemo(() => {
    const q = libSearchQuery.trim().toLowerCase();

    return allMediaItems.filter((item) => {
      // 1. Tab category filter (all, movies, adult_movies, drama, series, videos)
      const isAdultMovie = (item as any).contentType === 'adult_movie' || (item as any).category === 'Adult Movies' || ((item as any).genre && ((item as any).genre.toLowerCase().includes('adult') || (item as any).genre.toLowerCase().includes('18+')));
      const itemType = isAdultMovie ? 'adult_movie' : ((item as any).contentType || (item.mediaType === 'video' ? 'video' : 'movie'));
      
      if (libFilter === 'movies' && (itemType !== 'movie' || isAdultMovie)) {
        return false;
      }
      if (libFilter === 'adult_movies' && !isAdultMovie) {
        return false;
      }
      if (libFilter === 'drama' && itemType !== 'drama') {
        return false;
      }
      if (libFilter === 'series' && itemType !== 'series') {
        return false;
      }
      if (libFilter === 'videos' && itemType !== 'video') {
        return false;
      }

      // 2. Real-time instant search across titles, genres, dubs, links, descriptions, ratings, tags
      if (q) {
        const titleMatch = (item.title || '').toLowerCase().includes(q);
        const genreMatch = (item.genre || '').toLowerCase().includes(q);
        const descMatch = (item.description || '').toLowerCase().includes(q);
        const urlMatch = (item.videoUrl || '').toLowerCase().includes(q);
        const ratingMatch = String(item.rating || '').includes(q);
        const langMatch = (item.languages || []).some(l => l.toLowerCase().includes(q));
        const formatMatch = (itemType || '').toLowerCase().includes(q);
        const categoryMatch = ((item as any).category || '').toLowerCase().includes(q);
        const episodeMatch = ((item as any).totalEpisodes || '').toLowerCase().includes(q);
        const dubLinkMatch = Boolean(
          (item.banglaLink && item.banglaLink.toLowerCase().includes(q)) ||
          (item.hindiLink && item.hindiLink.toLowerCase().includes(q)) ||
          (item.englishLink && item.englishLink.toLowerCase().includes(q)) ||
          (item.originalLink && item.originalLink.toLowerCase().includes(q))
        );

        if (!titleMatch && !genreMatch && !descMatch && !urlMatch && !ratingMatch && !langMatch && !formatMatch && !categoryMatch && !episodeMatch && !dubLinkMatch) {
          return false;
        }
      }

      return true;
    });
  }, [allMediaItems, libSearchQuery, libFilter]);

  // Lazy render slicing to prevent UI lag on large libraries
  const displayedMediaItems = useMemo(() => {
    return filteredMediaItems.slice(0, visibleCount);
  }, [filteredMediaItems, visibleCount]);

  // Reset lazy load count when search query or filter changes
  useEffect(() => {
    setVisibleCount(25);
  }, [libSearchQuery, libFilter]);

  const handleCancelEdit = () => {
    setEditingPostId(null);
    setEditingPostItem(null);
    setPostTitle('');
    setPostGenre('Cinema Release');
    setPostCategory('Deshi');
    setPostRating('8.8');
    setPostDescription('');
    setPostDuration('2h 15m');
    setPostTotalEpisodes('Season 1 • Full Pack');
    setPostAttachmentUrl('');
    setPostTutorialVideoUrl('');
    setPostAudioUrl('');
    setPostLanguages(['original']);
    setPostDestinationLink('');
    setPostBanglaLink('');
    setPostHindiLink('');
    setPostEnglishLink('');
    setPostOriginalLink('');
    setPosterInputKey(prev => prev + 1);
  };

  const handleUltralightPublish = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalPrimaryLink = postDestinationLink.trim() || postBanglaLink.trim() || postHindiLink.trim() || postEnglishLink.trim() || postOriginalLink.trim();
    if (!postTitle.trim() || !finalPrimaryLink) {
      alert("Please enter title and at least one destination/dub link.");
      return;
    }
    setPostPublishing(true);
    try {
      const rewardPts = Number(settDefaultRewardPts) || settings.default_reward_pts || 500;
      const defaultThumb = postContentType === 'video' 
        ? "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&h=450&q=80"
        : postContentType === 'drama'
        ? "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&h=1200&q=80"
        : postContentType === 'series'
        ? "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=1200&q=80"
        : postContentType === 'adult_movie'
        ? "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&h=1200&q=80"
        : "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&h=1200&q=80";
      
      const thumb = postAttachmentUrl.trim() || defaultThumb;
      const numericRating = parseFloat(postRating) || 8.8;

      // Store exact selected languages array
      let activeLangs = Array.from(new Set(postLanguages.map(normalizeLangKey)));
      if (activeLangs.length === 0) {
        activeLangs = ['original'];
      }

      if (postContentType === 'video') {
        const payload: any = {
          title: postTitle.trim(),
          description: postDescription.trim() || "Ad-Reward video clip release.",
          thumbnailUrl: thumb,
          videoUrl: postDestinationLink.trim() || finalPrimaryLink,
          duration: postDuration.trim() || "3m 45s",
          genre: postGenre.trim() || "Clip Release",
          category: postCategory || 'Deshi',
          contentType: 'video',
          rating: numericRating,
          isFree: true,
          requiredPoints: rewardPts,
          tutorialVideoUrl: postTutorialVideoUrl.trim() || undefined,
          audioUrl: postAudioUrl.trim() || undefined,
          banglaLink: postBanglaLink.trim() || undefined,
          hindiLink: postHindiLink.trim() || undefined,
          englishLink: postEnglishLink.trim() || undefined,
          originalLink: postOriginalLink.trim() || undefined,
          createdAt: editingPostId ? undefined : new Date().toISOString(),
        };
        if (editingPostId) {
          payload.id = editingPostId;
        }
        await onAddVideo(payload);
      } else {
        // movie, adult_movie, drama, series
        const defaultGenre = postContentType === 'drama' 
          ? 'Bangla Natok' 
          : postContentType === 'series' 
          ? 'Web Series' 
          : postContentType === 'adult_movie'
          ? 'Adult 18+'
          : 'Cinema Release';

        const defaultDuration = postContentType === 'drama' 
          ? '45m' 
          : postContentType === 'series' 
          ? '25m/Ep' 
          : postContentType === 'adult_movie'
          ? '1h 35m'
          : '2h 15m';

        const defaultDesc = postContentType === 'drama' 
          ? 'HD Bangla Natok & Telefilm special release.' 
          : postContentType === 'series' 
          ? 'Full season web series release.' 
          : postContentType === 'adult_movie'
          ? '18+ Adult Movie exclusive release.'
          : 'Ad-Reward HD movie release.';
        
        const payload: any = {
          title: postTitle.trim(),
          description: postDescription.trim() || defaultDesc,
          thumbnailUrl: thumb,
          videoUrl: finalPrimaryLink,
          genre: postGenre.trim() || defaultGenre,
          category: postContentType === 'adult_movie' ? 'Adult Movies' : undefined,
          contentType: postContentType,
          duration: postDuration.trim() || defaultDuration,
          totalEpisodes: postContentType === 'series' ? (postTotalEpisodes.trim() || 'Season 1 • Full Pack') : undefined,
          releaseYear: 2026,
          rating: numericRating,
          isFree: true,
          requiredPoints: rewardPts,
          languages: activeLangs,
          tutorialVideoUrl: postTutorialVideoUrl.trim() || undefined,
          audioUrl: postAudioUrl.trim() || undefined,
          banglaLink: postBanglaLink.trim() || undefined,
          hindiLink: postHindiLink.trim() || undefined,
          englishLink: postEnglishLink.trim() || undefined,
          originalLink: postOriginalLink.trim() || undefined,
          createdAt: editingPostId ? undefined : new Date().toISOString(),
        };
        if (editingPostId) {
          payload.id = editingPostId;
        }
        await onAddMovie(payload);
      }

      showAdminToast(editingPostId ? "✓ পোস্ট সফলভাবে আপডেট করা হয়েছে!" : "✓ নতুন পোস্ট সফলভাবে পাবলিশ হয়েছে!");
      handleCancelEdit();
    } catch (err: any) {
      showAdminToast("পোস্ট ব্যর্থ হয়েছে: " + (err.message || "Server error"), 'error');
    } finally {
      setPostPublishing(false);
    }
  };

  const handleSaveAllSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const batterySitesArr = settBatterySites
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);

    await onUpdateSettings({
      domain: settDomain,
      telegramBotLink: settBotLink,
      referralReward: Number(settRefReward),
      referralCommissionPercent: Number(settCommPercent),
      minimumWithdrawal: Number(settMinWithdrawal),
      default_reward_pts: Number(settDefaultRewardPts),
      guide_video_url: settGuideVideo,
      guideVideoUrl: settGuideVideo,
      guide_audio_url: settGuideAudio,
      guideAudioUrl: settGuideAudio,
      guideVideoLogoUrl: settGuideLogo,
      activeMagazines: Number(settActiveMags),
      battery_site_urls: batterySitesArr,
      batterySites: batterySitesArr,
      telegramChannelUrl: settChannelUrl,
      telegramPostId: settPostId,
      reactionRewardPoints: Number(settReactionReward),
      tokenRateBdt: Number(settTokenRateBdt),
      tokenRateUsd: Number(settTokenRateUsd),
      monetagKey: settMonetagKey,
      adsgramZone: settAdsgramZone,
      telegaId: settTelegaId,
      adNetworkType: settAdNetworkType,
      adNetworkEnabled: settAdNetworkEnabled,
      adsterraDirectLink: settAdsterraDirectLink,
      adsterraScriptTag: settAdsterraScriptTag,
      monetagDirectTag: settMonetagDirectTag,
      monetagScriptCode: settMonetagScriptCode,
      adsenseClient: settAdsenseClient,
      adsenseSlot: settAdsenseSlot,
      directImpressionUrl: settDirectImpressionUrl,
      adRewardPoints: Number(settAdRewardPoints),
      videoPreRollAd: settVideoPreRollAd,
      videoMidRollAd: settVideoMidRollAd,
    } as any);
    alert("Configuration parameters updated successfully!");
  };

  return (
    <div id="admin-dashboard-container" className="space-y-3.5 sm:space-y-5 animate-in fade-in duration-300 max-w-full overflow-hidden relative">
      
      {/* Sleek Mobile Toast Notification */}
      {adminToast && (
        <div className="fixed top-4 right-4 sm:top-6 sm:right-6 z-50 animate-in fade-in slide-in-from-top-3 duration-200 pointer-events-none">
          <div className={`px-4 py-2.5 rounded-xl shadow-2xl border text-xs font-mono font-bold flex items-center gap-2 backdrop-blur-md ${
            adminToast.type === 'error'
              ? 'bg-rose-950/95 border-rose-500/50 text-rose-200 shadow-rose-950/50'
              : adminToast.type === 'info'
              ? 'bg-cyan-950/95 border-cyan-500/50 text-cyan-200 shadow-cyan-950/50'
              : 'bg-emerald-950/95 border-emerald-500/50 text-emerald-200 shadow-emerald-950/50'
          }`}>
            <span>{adminToast.message}</span>
          </div>
        </div>
      )}

      {/* Header Bar - Mobile First Optimized */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl p-3 sm:p-5 md:p-6 text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="p-2 sm:p-3 bg-gradient-to-tr from-indigo-500 to-purple-500 text-white rounded-xl sm:rounded-2xl shadow-lg shadow-indigo-500/20 shrink-0">
            <Shield size={20} className="sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <h2 className="text-xs sm:text-base md:text-lg font-black tracking-tight font-sans truncate">Admin Controller Room</h2>
              <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono text-[8px] sm:text-[9px] font-extrabold px-1.5 sm:px-2 py-0.5 rounded-full uppercase tracking-wider whitespace-nowrap">
                Live Active
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-slate-400 font-sans mt-0.5 leading-snug line-clamp-1 sm:line-clamp-none">
              Manage Content releases, Ad shorteners, Reward rules, and System settings.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          <div
            className="px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 flex items-center gap-2 text-xs font-semibold select-none"
            title="System Status: Optimal"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <Activity size={13} className="text-emerald-400" />
            <span className="hidden md:inline">System:</span> Optimal
          </div>

          {onClose && (
            <button
              type="button"
              id="btn-lock-admin-console"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 sm:px-4.5 sm:py-2 bg-rose-950/80 hover:bg-rose-900 active:bg-rose-950 text-rose-200 hover:text-white rounded-xl text-xs sm:text-sm font-mono font-bold transition border border-rose-600/50 shadow-lg shadow-rose-950/60 cursor-pointer flex items-center justify-center gap-2 active:scale-95 whitespace-nowrap shrink-0"
              title="Lock Admin Console & Return to Standard Stealth View"
            >
              <Lock size={15} className="text-rose-400 shrink-0" />
              <span>Lock Admin Console</span>
            </button>
          )}
        </div>
      </div>

      {/* Horizontal Scrollable Tab Navigation (Mobile-Optimized with Auto-Slide to Left on Click) */}
      <div 
        data-scroll-container="true"
        className="bg-slate-900/95 p-1.5 sm:p-2 rounded-2xl border border-slate-800 shadow-xl overflow-x-auto no-scrollbar scrollbar-none font-mono -mx-1 px-2 sm:mx-0 scroll-smooth"
      >
        <div className="flex whitespace-nowrap gap-2 py-1 items-center min-w-max">
          
          <button
            data-tab-key="phase6"
            onClick={(e) => handleSelectTab('phase6', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'phase6'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30 border-cyan-400/50 scale-[1.02]'
                : 'text-cyan-400 hover:text-white hover:bg-cyan-950/40 border-cyan-800/40'
            }`}
          >
            <Shield size={14} className={adminTab === 'phase6' ? 'text-white shrink-0' : 'text-cyan-400 shrink-0'} />
            <span className="whitespace-nowrap">Phase 6 Gateway & Ads</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded font-mono font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/30">
              LIVE
            </span>
          </button>

          <button
            data-tab-key="library"
            onClick={(e) => handleSelectTab('library', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'library'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Database size={14} className={adminTab === 'library' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Media Catalog</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
              adminTab === 'library' ? 'bg-indigo-700/80 text-white' : 'bg-slate-950/80 text-slate-400 border border-slate-800'
            }`}>
              {allMediaItems.length}
            </span>
          </button>

          <button
            data-tab-key="content"
            onClick={(e) => handleSelectTab('content', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'content'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Zap size={14} className={adminTab === 'content' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Post Publisher</span>
          </button>

          <button
            data-tab-key="ads"
            onClick={(e) => handleSelectTab('ads', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'ads'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Radio size={14} className={adminTab === 'ads' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Ad Networks</span>
          </button>

          <button
            data-tab-key="guide"
            onClick={(e) => handleSelectTab('guide', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'guide' || adminTab === 'system'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Tv size={14} className={adminTab === 'guide' || adminTab === 'system' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">গাইড ভিডিও ও অডিও</span>
          </button>

          <button
            data-tab-key="telegram"
            onClick={(e) => handleSelectTab('telegram', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'telegram'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Bot size={14} className={adminTab === 'telegram' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Telegram Bot</span>
          </button>

          <button
            data-tab-key="rewards"
            onClick={(e) => handleSelectTab('rewards', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'rewards'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Coins size={14} className={adminTab === 'rewards' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Rewards</span>
          </button>

          <button
            data-tab-key="missions"
            onClick={(e) => handleSelectTab('missions', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'missions'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <Layers size={14} className={adminTab === 'missions' ? 'text-white shrink-0' : 'text-indigo-400 shrink-0'} />
            <span className="whitespace-nowrap">Tasks</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
              adminTab === 'missions' ? 'bg-indigo-700/80 text-white' : 'bg-slate-950/80 text-slate-400 border border-slate-800'
            }`}>
              {missions.length}
            </span>
          </button>

          <button
            data-tab-key="withdrawals"
            onClick={(e) => handleSelectTab('withdrawals', e)}
            className={`flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shrink-0 border ${
              adminTab === 'withdrawals'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50 scale-[1.02]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border-transparent'
            }`}
          >
            <DollarSign size={14} className={adminTab === 'withdrawals' ? 'text-white shrink-0' : 'text-emerald-400 shrink-0'} />
            <span className="whitespace-nowrap">Withdrawals</span>
            {withdrawals.filter(w => w.status === 'pending').length > 0 && (
              <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-1.5 py-0.2 rounded-full font-mono font-bold">
                {withdrawals.filter(w => w.status === 'pending').length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* SLEEK, COMPACT, MOBILE-FRIENDLY UPLOAD PROGRESS BAR (0%-100%) */}
      {activeUpload && (
        <div className="fixed bottom-4 left-3 right-3 sm:left-auto sm:right-6 sm:w-96 z-50 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className={`rounded-xl sm:rounded-2xl px-3.5 py-2.5 sm:px-4 sm:py-3 border shadow-2xl backdrop-blur-xl transition-all duration-300 ${
            activeUpload.status === 'done'
              ? 'bg-emerald-950/95 border-emerald-500/50 text-emerald-100 shadow-emerald-950/70'
              : activeUpload.status === 'error'
              ? 'bg-rose-950/95 border-rose-500/50 text-rose-100 shadow-rose-950/70'
              : 'bg-slate-900/95 border-teal-500/50 text-white shadow-black/80'
          }`}>
            <div className="flex items-center justify-between gap-2.5">
              {/* Status Icon */}
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border ${
                activeUpload.status === 'done'
                  ? 'bg-emerald-600/90 text-white border-emerald-400'
                  : activeUpload.status === 'error'
                  ? 'bg-rose-600/90 text-white border-rose-400'
                  : 'bg-teal-600/90 text-white border-teal-400'
              }`}>
                {activeUpload.status === 'done' ? (
                  <Check size={14} className="stroke-[3]" />
                ) : activeUpload.status === 'error' ? (
                  <X size={14} className="stroke-[3]" />
                ) : (
                  <Loader2 size={14} className="animate-spin" />
                )}
              </div>

              {/* File Info */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1.5 mb-0.5">
                  <span className="text-[11px] sm:text-xs font-bold truncate text-slate-100 font-sans">
                    {activeUpload.fileName}
                  </span>
                  <span className={`text-[10px] sm:text-xs font-mono font-black px-1.5 py-0.5 rounded ${
                    activeUpload.status === 'done'
                      ? 'text-emerald-400 bg-emerald-500/10'
                      : activeUpload.status === 'error'
                      ? 'text-rose-400 bg-rose-500/10'
                      : 'text-teal-300 bg-teal-500/10'
                  }`}>
                    {activeUpload.percent}%
                  </span>
                </div>

                <div className="text-[9px] sm:text-[10px] font-mono text-slate-400 flex items-center gap-1.5 truncate">
                  <span className="text-teal-300 font-semibold">{activeUpload.sizeText}</span>
                  <span>•</span>
                  <span>{activeUpload.speedText}</span>
                </div>
              </div>

              {/* Close Button (if error or done) */}
              <button 
                type="button"
                onClick={() => setActiveUpload(null)} 
                className="text-slate-400 hover:text-white p-1 -mr-1 rounded-lg hover:bg-slate-800 transition"
              >
                <X size={14} />
              </button>
            </div>

            {/* Compact Progress Line */}
            <div className="w-full h-1.5 bg-slate-950/80 rounded-full overflow-hidden mt-2 border border-slate-800">
              <div
                className={`h-full rounded-full transition-all duration-200 ${
                  activeUpload.status === 'done'
                    ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                    : activeUpload.status === 'error'
                    ? 'bg-rose-500'
                    : 'bg-gradient-to-r from-teal-400 to-emerald-400 shadow-[0_0_8px_rgba(45,212,191,0.6)]'
                }`}
                style={{ width: `${activeUpload.percent}%` }}
              />
            </div>

            {activeUpload.message && (
              <div className="mt-1.5 text-center text-[10px] font-mono font-bold text-emerald-300 flex items-center justify-center gap-1 truncate">
                <Check size={11} />
                <span>{activeUpload.message}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 0: PHASE 6 GATEWAY & ADS CONTROL CONSOLE */}
      {adminTab === 'phase6' && (
        <Phase6AdminControlPanel onBackToApp={onClose} />
      )}

      {/* TAB 1: ADVANCED MEDIA LIBRARY & AI SEARCH ENGINE */}
      {adminTab === 'library' && (
        <div className="space-y-4 sm:space-y-6 animate-in fade-in duration-300">
          
          {/* Main Control & Intelligence Bar */}
          <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-800/90 rounded-2xl sm:rounded-3xl p-3 sm:p-5 md:p-6 shadow-2xl space-y-3.5 sm:space-y-4 text-slate-100">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 sm:gap-3 border-b border-slate-800/80 pb-3 sm:pb-4">
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="p-1.5 sm:p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20 shrink-0">
                    <Database size={16} className="sm:w-[18px] sm:h-[18px]" />
                  </div>
                  <h3 className="text-xs sm:text-sm md:text-base font-black text-white uppercase tracking-wider font-mono whitespace-nowrap truncate">
                    Media Library & AI Search
                  </h3>
                  <span className="text-[9px] sm:text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 px-2 sm:px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1 whitespace-nowrap">
                    <Zap size={10} className="text-emerald-400" />
                    Instant Engine
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-400 font-sans line-clamp-1 sm:line-clamp-none">
                  Search, filter, edit, or control visibility for all movie and video releases in real time.
                </p>
              </div>

              {/* Quick Action Button to Add New Post */}
              <button
                onClick={() => {
                  handleCancelEdit();
                  setAdminTab('content');
                }}
                className="max-w-max mx-auto md:mx-0 py-2 px-4 bg-violet-600 hover:bg-violet-700 text-white rounded-lg text-sm font-semibold transition flex items-center justify-center shadow-none drop-shadow-none cursor-pointer shrink-0 whitespace-nowrap"
              >
                <span>Publish New Release</span>
              </button>
            </div>

            {/* AI-Powered High Performance Search Bar */}
            {/* Search Input Box */}
            <div className="relative">
              <div className="relative flex items-center">
                <Search size={16} className="absolute left-3 sm:left-3.5 text-indigo-400 pointer-events-none" />
                <input
                  type="text"
                  value={libSearchQuery}
                  onChange={(e) => setLibSearchQuery(e.target.value)}
                  placeholder="Search titles, genres, dubs, links (e.g. Action, Bangla)..."
                  className="w-full bg-slate-950/90 border border-slate-700/80 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/30 rounded-2xl pl-9 sm:pl-11 pr-20 sm:pr-24 py-2.5 sm:py-3.5 text-xs sm:text-sm text-slate-100 font-mono outline-none transition placeholder-slate-500 shadow-inner"
                />
                {libSearchQuery ? (
                  <button
                    onClick={() => setLibSearchQuery('')}
                    className="absolute right-2.5 sm:right-3 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] sm:text-[11px] font-mono transition flex items-center gap-1 cursor-pointer whitespace-nowrap"
                  >
                    <X size={11} /> Clear
                  </button>
                ) : (
                  <div className="absolute right-2.5 sm:right-3 hidden xs:flex items-center gap-1 text-[9px] sm:text-[10px] text-slate-500 font-mono bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg whitespace-nowrap">
                    <Sparkles size={10} className="text-amber-400" />
                    <span>AI Indexed</span>
                  </div>
                )}
              </div>

              {/* Dynamic Search Status Bar with Clear Database Trigger */}
              <div className="flex items-center justify-between mt-1.5 px-1 text-[10px] sm:text-[11px] font-mono text-slate-400 flex-wrap gap-2">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-indigo-400 font-bold whitespace-nowrap">
                    ⚡ {filteredMediaItems.length} records found
                  </span>
                  {libSearchQuery && (
                    <span className="text-slate-500 truncate">
                      (matching "{libSearchQuery}")
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[9px] sm:text-[10px] whitespace-nowrap">
                    Total DB: {allMediaItems.length}
                  </span>
                  {allMediaItems.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setShowClearConfirmModal(true)}
                      className="px-2.5 py-1 bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 hover:text-rose-200 border border-rose-800/40 hover:border-rose-500 rounded-lg text-[10px] font-mono font-bold transition flex items-center gap-1 cursor-pointer whitespace-nowrap shadow-sm active:scale-95"
                      title="Clear all database posts for testing"
                    >
                      <Trash2 size={11} className="text-rose-400" />
                      <span>ক্লিয়ার ডাটাবেজ</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Clear Database Confirmation Modal */}
            {showClearConfirmModal && (
              <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
                <div className="bg-slate-900 border border-rose-800/70 rounded-2xl p-5 max-w-sm w-full space-y-4 shadow-2xl font-mono text-slate-100">
                  <div className="flex items-center gap-2.5 text-rose-400 font-bold text-sm">
                    <AlertTriangle size={20} className="shrink-0 animate-bounce" />
                    <span>সকল পোস্ট ডিলিট করতে চান?</span>
                  </div>
                  <p className="text-xs text-slate-300 font-sans leading-relaxed">
                    ডাটাবেজ থেকে সমস্ত মুভি, ভিডিও, নাটক ও সিরিজের টেস্ট ডাটা সম্পূর্ণ ডিলিট হয়ে যাবে যাতে আপনি নিজের মত করে নতুন পোস্ট করতে পারেন।
                  </p>
                  <div className="flex items-center justify-end gap-2 pt-2">
                    <button
                      type="button"
                      disabled={isClearingMedia}
                      onClick={() => setShowClearConfirmModal(false)}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
                    >
                      বাতিল
                    </button>
                    <button
                      type="button"
                      disabled={isClearingMedia}
                      onClick={handleExecuteClearDatabase}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-rose-950"
                    >
                      {isClearingMedia ? (
                        <>
                          <Loader2 size={13} className="animate-spin" />
                          <span>মুছে ফেলা হচ্ছে...</span>
                        </>
                      ) : (
                        <>
                          <Trash2 size={13} />
                          <span>হ্যাঁ, সম্পূর্ণ ডিলিট করুন</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Streamlined Category Filter Tabs (Horizontal Scrollable Bar on Mobile with Auto-Scroll on Click) */}
            <div 
              data-scroll-container="true"
              className="flex overflow-x-auto no-scrollbar scrollbar-none whitespace-nowrap gap-2 py-1 font-mono text-[11px] sm:text-xs scroll-smooth"
            >
              <button
                onClick={(e) => handleSelectCategory('all', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'all'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <Database size={13} className={libFilter === 'all' ? "text-white shrink-0" : "text-indigo-400 shrink-0"} />
                <span>All Catalog ({allMediaItems.length})</span>
              </button>

              <button
                onClick={(e) => handleSelectCategory('movies', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'movies'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <Film size={13} className={libFilter === 'movies' ? "text-white shrink-0" : "text-indigo-400 shrink-0"} />
                <span>Movies ({movies.filter(m => (!m.contentType || m.contentType === 'movie') && m.category !== 'Adult Movies' && !m.genre?.toLowerCase().includes('adult') && !m.genre?.toLowerCase().includes('18+')).length})</span>
              </button>

              <button
                onClick={(e) => handleSelectCategory('adult_movies', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'adult_movies'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <Flame size={13} className={libFilter === 'adult_movies' ? "text-white shrink-0" : "text-rose-400 shrink-0"} />
                <span>Adult Movies ({movies.filter(m => m.contentType === 'adult_movie' || m.category === 'Adult Movies' || (m.genre && (m.genre.toLowerCase().includes('adult') || m.genre.toLowerCase().includes('18+')))).length})</span>
              </button>

              <button
                onClick={(e) => handleSelectCategory('drama', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'drama'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <Tv size={13} className={libFilter === 'drama' ? "text-white shrink-0" : "text-indigo-400 shrink-0"} />
                <span>Drama ({movies.filter(m => m.contentType === 'drama').length})</span>
              </button>

              <button
                onClick={(e) => handleSelectCategory('series', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'series'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <Layers size={13} className={libFilter === 'series' ? "text-white shrink-0" : "text-indigo-400 shrink-0"} />
                <span>Series ({movies.filter(m => m.contentType === 'series').length})</span>
              </button>

              <button
                onClick={(e) => handleSelectCategory('videos', e)}
                className={`py-2 px-3.5 rounded-xl border font-bold transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shrink-0 ${
                  libFilter === 'videos'
                    ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/25"
                    : "bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
              >
                <VideoIcon size={13} className={libFilter === 'videos' ? "text-white shrink-0" : "text-indigo-400 shrink-0"} />
                <span>Videos ({videos.length})</span>
              </button>
            </div>

          </div>

          {/* Media Items Display List with Lazy Render */}
          <div className="w-full max-w-full overflow-hidden px-2 box-border space-y-3">
            {filteredMediaItems.length === 0 ? (
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-8 text-center space-y-3 font-mono">
                <Search size={32} className="text-slate-600 mx-auto" />
                <h4 className="text-sm font-bold text-slate-300">No media records found</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto font-sans">
                  {libSearchQuery 
                    ? `No releases matched your search "${libSearchQuery}". Try a different keyword or check your spelling.` 
                    : "There are no media releases in this view filter."}
                </p>
                <button
                  onClick={() => {
                    setLibSearchQuery('');
                    setLibFilter('all');
                  }}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition cursor-pointer"
                >
                  View All Database Records
                </button>
              </div>
            ) : (
              <>
                {displayedMediaItems.map((item) => {
                const isAdultMovie = (item as any).contentType === 'adult_movie' || (item as any).category === 'Adult Movies' || ((item as any).genre && ((item as any).genre.toLowerCase().includes('adult') || (item as any).genre.toLowerCase().includes('18+')));
                const itemContentType = isAdultMovie ? 'adult_movie' : ((item as any).contentType || (item.mediaType === 'video' ? 'video' : 'movie'));
                const isDrama = itemContentType === 'drama';
                const isSeries = itemContentType === 'series';
                const isMovie = itemContentType === 'movie' || (item.mediaType === 'movie' && !isDrama && !isSeries && !isAdultMovie);
                const isVideo = itemContentType === 'video';
                const isCopied = copiedItemId === item.id;
                const isConfirmingDelete = deletingId === item.id;

                return (
                  <div
                    key={item.id}
                    className="w-full max-w-full bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-3 sm:p-4 transition-all shadow-xl space-y-2.5 sm:space-y-3 overflow-hidden box-border"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2.5 sm:gap-3 w-full min-w-0 box-border">
                      
                      {/* Left: Thumbnail & Details */}
                      <div className="flex items-start gap-2.5 sm:gap-3 min-w-0 w-full sm:w-auto flex-1">
                        <div className={`relative ${!isVideo ? 'w-13 h-19 sm:w-16 sm:h-22' : 'w-20 h-14 sm:w-22 sm:h-16'} bg-slate-950 rounded-xl overflow-hidden shrink-0 border border-slate-800 shadow-md`}>
                          <img
                            src={item.thumbnailUrl}
                            alt={item.title}
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = isVideo
                                ? "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&h=450&q=80"
                                : isDrama
                                ? "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=400&h=600&q=80"
                                : isSeries
                                ? "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&h=600&q=80"
                                : isAdultMovie
                                ? "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&h=600&q=80"
                                : "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=400&h=600&q=80";
                            }}
                            className="w-full h-full object-cover contrast-105 saturate-110 drop-shadow-md"
                          />
                          <div className="absolute top-0.5 right-0.5 bg-slate-950/90 text-amber-400 text-[7px] sm:text-[8px] font-mono font-bold px-1 py-0.2 rounded shadow">
                            ★{item.rating || 8.8}
                          </div>
                          <div className="absolute bottom-0.5 left-0.5 bg-slate-950/90 text-slate-200 text-[6.5px] sm:text-[7.5px] font-mono font-extrabold px-1 py-0.2 rounded uppercase">
                            {isAdultMovie ? '18+' : isDrama ? 'Drama' : isSeries ? 'Series' : isMovie ? 'Movie' : 'Clip'}
                          </div>
                        </div>

                        <div className="min-w-0 flex-1 space-y-1.5">
                          <h4 className="text-xs sm:text-sm font-extrabold text-white leading-snug line-clamp-2 break-words">
                            {item.title}
                          </h4>

                          {/* Responsive Flex-Wrap Badges Row */}
                          <div className="flex flex-wrap gap-1 items-center">
                            {isAdultMovie && (
                              <span className="text-[7.5px] sm:text-[8px] bg-rose-700/30 text-rose-300 border border-rose-500/40 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap flex items-center gap-0.5">
                                <Flame size={9} className="text-rose-400" /> Adult 18+
                              </span>
                            )}
                            {isDrama && (
                              <span className="text-[7.5px] sm:text-[8px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                📺 Drama
                              </span>
                            )}
                            {isSeries && (
                              <span className="text-[7.5px] sm:text-[8px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🍿 Series
                              </span>
                            )}
                            {isMovie && !isAdultMovie && (
                              <span className="text-[7.5px] sm:text-[8px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🎬 Movie
                              </span>
                            )}
                            {isVideo && (
                              <span className="text-[7.5px] sm:text-[8px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🎥 Clip
                              </span>
                            )}
                            
                            {item.isRecent48h ? (
                              <span className="text-[7.5px] sm:text-[8px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                ⚡ 48H
                              </span>
                            ) : (
                              <span className="text-[7.5px] sm:text-[8px] bg-slate-800 text-slate-400 border border-slate-700 px-1.5 py-0.5 rounded font-mono whitespace-nowrap">
                                📁 Archive
                              </span>
                            )}

                            {item.isActive ? (
                              <span className="text-[7.5px] sm:text-[8px] bg-teal-500/20 text-teal-300 border border-teal-500/30 px-1.5 py-0.5 rounded font-mono font-bold flex items-center gap-1 whitespace-nowrap">
                                <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
                                Live
                              </span>
                            ) : (
                              <span className="text-[7.5px] sm:text-[8px] bg-rose-500/20 text-rose-300 border border-rose-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                Hidden
                              </span>
                            )}

                            {/* Meta attributes */}
                            <span className="text-[7.5px] sm:text-[8px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-1.5 py-0.5 rounded font-mono font-bold uppercase whitespace-nowrap">
                              {item.genre || (isDrama ? "Natok" : isSeries ? "Series" : isMovie ? "Cinema" : "Clip")}
                            </span>
                            {(item as any).category && (
                              <span className="text-[7.5px] sm:text-[8px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🏷️ {(item as any).category}
                              </span>
                            )}
                            {(item as any).totalEpisodes && (
                              <span className="text-[7.5px] sm:text-[8px] bg-blue-500/20 text-blue-300 border border-blue-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                📦 {(item as any).totalEpisodes}
                              </span>
                            )}
                            {item.duration && (
                              <span className="text-[7.5px] sm:text-[8px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded font-mono border border-slate-700 flex items-center gap-0.5 whitespace-nowrap">
                                <Clock size={8} /> {item.duration}
                              </span>
                            )}
                            <span className="text-[7.5px] sm:text-[8px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono border border-slate-700 whitespace-nowrap">
                              👁️ {item.views || 0}
                            </span>

                            {/* Languages & Extras */}
                            {(item.banglaLink || item.languages?.some(l => l.toLowerCase().includes('bangla'))) && (
                              <span className="text-[7.5px] sm:text-[8px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🇧🇩 Bangla
                              </span>
                            )}
                            {(item.hindiLink || item.languages?.some(l => l.toLowerCase().includes('hindi'))) && (
                              <span className="text-[7.5px] sm:text-[8px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🇮🇳 Hindi
                              </span>
                            )}
                            {(item.englishLink || item.languages?.some(l => l.toLowerCase().includes('english'))) && (
                              <span className="text-[7.5px] sm:text-[8px] bg-blue-500/20 text-blue-300 border border-blue-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🌐 English
                              </span>
                            )}
                            {(item.originalLink || item.languages?.some(l => l.toLowerCase().includes('original')) || (!item.languages && !item.banglaLink && !item.hindiLink && !item.englishLink)) && (
                              <span className="text-[7.5px] sm:text-[8px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-1.5 py-0.5 rounded font-mono font-bold whitespace-nowrap">
                                🎬 Original
                              </span>
                            )}
                            {item.tutorialVideoUrl && (
                              <span className="text-[7.5px] sm:text-[8px] bg-slate-800 text-purple-300 px-1.5 py-0.5 rounded font-mono border border-slate-700 flex items-center gap-0.5 whitespace-nowrap">
                                <PlayCircle size={9} /> 3:4 Video
                              </span>
                            )}
                            {item.audioUrl && (
                              <span className="text-[7.5px] sm:text-[8px] bg-slate-800 text-amber-300 px-1.5 py-0.5 rounded font-mono border border-slate-700 flex items-center gap-0.5 whitespace-nowrap">
                                <Volume2 size={9} /> Voice MP3
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Action Buttons: Full-width responsive 3-column grid on mobile, flex on desktop */}
                    <div className="grid grid-cols-3 sm:flex items-center sm:justify-end gap-1.5 w-full mt-2 pt-2 border-t border-slate-800/80 box-border">
                      
                      {/* Edit Button */}
                      <button
                        onClick={() => {
                          if (isMovie) handleStartEditMovie(item as Movie);
                          else handleStartEditVideo(item as Video);
                        }}
                        className="w-full sm:w-auto px-2.5 py-1.5 bg-slate-800 hover:bg-indigo-600 text-slate-200 hover:text-white rounded-xl text-[11px] sm:text-xs font-mono font-bold transition-all duration-200 flex items-center justify-center gap-1.5 border border-slate-700 hover:border-indigo-500 shadow-sm cursor-pointer whitespace-nowrap min-h-[34px]"
                        title="Edit & Update Post"
                      >
                        <Pencil size={12} className="text-indigo-400 shrink-0" />
                        <span>Edit</span>
                      </button>

                      {/* Toggle Live Visibility */}
                      <button
                        onClick={() => handleToggleRecord(item.id, item.mediaType)}
                        className={`w-full sm:w-auto px-2.5 py-1.5 rounded-xl text-[11px] sm:text-xs font-mono font-bold transition-all duration-200 flex items-center justify-center gap-1.5 border cursor-pointer min-h-[34px] ${
                          item.isActive 
                            ? "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border-emerald-500/30" 
                            : "bg-rose-950/40 text-rose-300 border-rose-800/60 hover:bg-rose-900/40"
                        }`}
                        title={item.isActive ? "Hide from website" : "Make live on website"}
                      >
                        {item.isActive ? <Eye size={13} className="shrink-0" /> : <EyeOff size={13} className="shrink-0" />}
                        <span>{item.isActive ? 'Live' : 'Hidden'}</span>
                      </button>

                      {/* Copy Download Link */}
                      <button
                        onClick={() => handleCopyLink(item.videoUrl, item.id)}
                        className={`w-full sm:w-auto px-2.5 py-1.5 rounded-xl text-[11px] sm:text-xs font-mono font-bold transition-all duration-200 flex items-center justify-center gap-1.5 border cursor-pointer min-h-[34px] ${
                          isCopied 
                            ? "bg-indigo-600 text-white border-indigo-400 shadow-md shadow-indigo-600/30" 
                            : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                        }`}
                        title="Copy Master Link"
                      >
                        {isCopied ? <Check size={13} className="shrink-0" /> : <Copy size={13} className="shrink-0" />}
                        <span>{isCopied ? 'Copied' : 'Copy'}</span>
                      </button>

                      {/* Open / Share Link */}
                      {item.videoUrl && (
                        <a
                          href={item.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full sm:w-auto px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-mono font-bold min-h-[34px]"
                          title="Open / Share Link"
                        >
                          <ExternalLink size={12} className="shrink-0" />
                          <span>Open</span>
                        </a>
                      )}

                      {/* Delete Button with inline confirmation */}
                      {isConfirmingDelete ? (
                        <div className="col-span-2 sm:col-span-1 flex items-center gap-1 bg-rose-950/90 border border-rose-500/60 p-0.5 rounded-xl min-h-[34px]">
                          <button
                            onClick={() => handleDeleteRecord(item.id, item.mediaType)}
                            className="flex-1 px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[10px] sm:text-[11px] font-mono font-bold rounded-lg transition cursor-pointer whitespace-nowrap min-h-[28px]"
                          >
                            Confirm
                          </button>
                          <button
                            onClick={() => setDeletingId(null)}
                            className="px-2 py-1 bg-slate-800 text-slate-300 text-[10px] sm:text-[11px] font-mono rounded-lg cursor-pointer min-h-[28px]"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeletingId(item.id)}
                          className="w-full sm:w-auto px-2.5 py-1.5 bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 rounded-xl border border-slate-700 transition cursor-pointer min-h-[34px] flex items-center justify-center gap-1.5 text-[11px] sm:text-xs font-mono font-bold"
                          title="Delete Record"
                        >
                          <Trash2 size={12} className="shrink-0" />
                          <span>Delete</span>
                        </button>
                      )}

                    </div>

                    {/* Master Target Link Preview Box (Compact & Safe Truncate) */}
                    <div className="w-full max-w-full bg-slate-950/80 border border-slate-800/80 rounded-lg sm:rounded-xl px-2.5 py-1.5 flex items-center justify-between gap-1.5 text-[9px] sm:text-[10px] font-mono overflow-hidden box-border">
                      <div className="flex items-center gap-1.5 min-w-0 flex-1 overflow-hidden">
                        <Link2 size={11} className="text-slate-500 shrink-0" />
                        <span className="text-slate-500 shrink-0 font-bold">Link:</span>
                        <span className="text-slate-300 truncate max-w-[180px] sm:max-w-none font-mono">
                          {item.videoUrl}
                        </span>
                      </div>
                      <button
                        onClick={() => handleCopyLink(item.videoUrl, item.id)}
                        className="text-[9px] sm:text-[10px] text-indigo-400 hover:text-indigo-300 shrink-0 transition cursor-pointer font-bold whitespace-nowrap pl-1"
                      >
                        {isCopied ? "✓ Copied" : "Copy"}
                      </button>
                    </div>

                  </div>
                );
              })}

              {/* Lazy Load More Trigger */}
              {displayedMediaItems.length < filteredMediaItems.length && (
                <div className="pt-2 text-center">
                  <button
                    onClick={() => setVisibleCount(prev => prev + 25)}
                    className="w-full sm:w-auto px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs font-mono font-bold transition border border-slate-700 shadow-md cursor-pointer flex items-center justify-center gap-2 mx-auto"
                  >
                    <span>Load More Releases ({displayedMediaItems.length} of {filteredMediaItems.length})</span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        </div>
      )}

      {/* TAB 2: ⚡ POST PUBLISHER */}
      {adminTab === "content" && (
        <AdminPostPublisher
          onAddMovie={onAddMovie}
          onAddVideo={onAddVideo}
          editingPost={editingPostItem}
          editingPostId={editingPostId}
          onCancelEdit={handleCancelEdit}
          showAdminToast={showAdminToast}
          onNavigateToCatalog={() => setAdminTab("library")}
          catalogCount={allMediaItems.length}
          uploadFileWithProgress={uploadFileWithProgress}
          defaultRewardPts={Number(settDefaultRewardPts) || settings.default_reward_pts || 500}
        />
      )}

      {/* TAB 2: REAL AD MONETIZATION & NETWORK CONTROLLER */}
      {adminTab === 'ads' && (
        <div className="bg-slate-900/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-5 text-slate-100 animate-in fade-in duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div>
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-2 whitespace-nowrap">
                <Radio size={16} className="text-cyan-400 shrink-0" />
                <span>Real Ad Network Integration Controller</span>
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans mt-0.5">
                Configure real publisher scripts, high-CPM smartlinks, and impression URLs for Monetag, Adsterra, and Google AdSense.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const target = settAdNetworkType === 'adsterra' ? settAdsterraDirectLink : settMonetagDirectTag;
                  window.open(target || settDirectImpressionUrl, '_blank', 'noopener,noreferrer');
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] font-mono font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <ExternalLink size={12} className="text-cyan-400" />
                <span>Test Live Ad</span>
              </button>
            </div>
          </div>

          <form onSubmit={handleSaveAllSettings} className="space-y-4 max-w-3xl">
            {/* Primary Network Selector */}
            <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles size={14} className="text-amber-400" /> Active Ad Network Engine
                </span>
                <label className="flex items-center gap-2 cursor-pointer">
                  <span className="text-[11px] font-mono text-slate-400">Status:</span>
                  <input
                    type="checkbox"
                    checked={settAdNetworkEnabled}
                    onChange={(e) => setSettAdNetworkEnabled(e.target.checked)}
                    className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
                  />
                  <span className={`text-[11px] font-mono font-bold ${settAdNetworkEnabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                    {settAdNetworkEnabled ? 'Enabled' : 'Disabled'}
                  </span>
                </label>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'monetag' as const, label: 'Monetag', desc: 'Direct Tag & Pop' },
                  { id: 'adsterra' as const, label: 'Adsterra', desc: 'High-CPM Smartlink' },
                  { id: 'adsense' as const, label: 'Google Ads', desc: 'AdSense / AdMob' },
                  { id: 'direct' as const, label: 'Direct Sponsor', desc: 'Custom Channel URL' },
                ].map((net) => (
                  <button
                    key={net.id}
                    type="button"
                    onClick={() => setSettAdNetworkType(net.id)}
                    className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                      settAdNetworkType === net.id
                        ? 'bg-cyan-950/40 border-cyan-500/60 ring-1 ring-cyan-500/40'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs font-bold text-white font-mono block">{net.label}</span>
                    <span className="text-[10px] text-slate-400 font-sans block truncate">{net.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              
              {/* Monetag Configuration */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-2">
                <span className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-1.5 whitespace-nowrap">
                  <Globe size={13} className="text-indigo-400 shrink-0" /> Monetag Direct Tag Key / URL
                </span>
                <input
                  type="text"
                  value={settMonetagDirectTag}
                  onChange={(e) => setSettMonetagDirectTag(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="https://alwingulla.com/sample"
                />
                <span className="text-[10px] font-mono text-slate-400 block">
                  Monetag Script Tag / In-Page URL:
                </span>
                <input
                  type="text"
                  value={settMonetagScriptCode}
                  onChange={(e) => setSettMonetagScriptCode(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="https://alwingulla.com/tag.min.js"
                />
              </div>

              {/* Adsterra Configuration */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-2">
                <span className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-1.5 whitespace-nowrap">
                  <Zap size={13} className="text-amber-400 shrink-0" /> Adsterra Direct Smartlink URL
                </span>
                <input
                  type="text"
                  value={settAdsterraDirectLink}
                  onChange={(e) => setSettAdsterraDirectLink(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="https://www.profitablecpmrate.com/sample"
                />
                <span className="text-[10px] font-mono text-slate-400 block">
                  Adsterra Dynamic Script Tag (JS):
                </span>
                <input
                  type="text"
                  value={settAdsterraScriptTag}
                  onChange={(e) => setSettAdsterraScriptTag(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="//pl23456789.profitablecpmrate.com/sample.js"
                />
              </div>

              {/* Google AdSense / AdMob Configuration */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-2">
                <span className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-1.5 whitespace-nowrap">
                  <Radio size={13} className="text-emerald-400 shrink-0" /> Google AdSense Publisher ID
                </span>
                <input
                  type="text"
                  value={settAdsenseClient}
                  onChange={(e) => setSettAdsenseClient(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="ca-pub-1234567890123456"
                />
                <span className="text-[10px] font-mono text-slate-400 block">
                  Google Ad Slot ID:
                </span>
                <input
                  type="text"
                  value={settAdsenseSlot}
                  onChange={(e) => setSettAdsenseSlot(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-emerald-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="9876543210"
                />
              </div>

              {/* Direct Sponsor Impression URL */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-2">
                <span className="text-xs font-bold text-slate-200 uppercase font-mono flex items-center gap-1.5 whitespace-nowrap">
                  <Share2 size={13} className="text-blue-400 shrink-0" /> Direct Sponsor Impression URL
                </span>
                <input
                  type="text"
                  value={settDirectImpressionUrl}
                  onChange={(e) => setSettDirectImpressionUrl(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-blue-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="https://t.me/myteleflix_bot"
                />
                <span className="text-[10px] font-mono text-slate-400 block flex items-center gap-1">
                  <TokenIcon size={12} /> Reward Credited per Completed Ad:
                </span>
                <input
                  type="number"
                  min={10}
                  max={5000}
                  value={settAdRewardPoints}
                  onChange={(e) => setSettAdRewardPoints(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                />
              </div>

              {/* Video Playback Pre-Roll & Mid-Roll Injections */}
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-2 sm:col-span-2">
                <span className="text-xs font-bold text-slate-200 uppercase font-mono block">
                  Cinema & Video Player Monetization Toggles
                </span>
                <div className="flex flex-wrap gap-4 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settVideoPreRollAd}
                      onChange={(e) => setSettVideoPreRollAd(e.target.checked)}
                      className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">
                      Enable Video Pre-Roll Ad (Before Playback Starts)
                    </span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settVideoMidRollAd}
                      onChange={(e) => setSettVideoMidRollAd(e.target.checked)}
                      className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
                    />
                    <span className="text-xs font-mono text-slate-300">
                      Enable Mid-Stream Ad Boost Button
                    </span>
                  </label>
                </div>
              </div>

            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-black text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg shadow-cyan-600/20 transition cursor-pointer whitespace-nowrap"
            >
              Save Real Ad Configuration
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: REWARDS & REFERRAL SETUP */}
      {adminTab === 'rewards' && (
        <div className="bg-slate-900/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-5 text-slate-100 animate-in fade-in duration-300">
          <div className="border-b border-slate-800/80 pb-3">
            <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-2 whitespace-nowrap">
              <Coins size={16} className="text-emerald-400 shrink-0" />
              <span>Rewards, Referral Program & Cashout Thresholds</span>
            </h3>
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans truncate mt-0.5">
              Set task awards, referral payout plan model, tiered invites, commission percentages, and minimum withdrawal limits.
            </p>
          </div>

          {/* PLAN A / PLAN B SINGLE-CLICK SWITCH */}
          <div className="p-4 sm:p-5 bg-slate-950/80 rounded-2xl border border-slate-800 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    <Zap size={15} />
                  </span>
                  <h4 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono">
                    Referral Payout Model Controller
                  </h4>
                </div>
                <p className="text-[11px] text-slate-400 font-medium mt-1">
                  Single-click dynamic switch between Viral Expansion and Profit Optimization payout structures
                </p>
              </div>

              {/* Instant Single-Click Toggle Switch */}
              <div className="flex items-center gap-1.5 self-start sm:self-center bg-slate-900 border border-slate-800 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => handleSwitchReferralPlan('PLAN_A')}
                  disabled={isSwitchingReferralPlan}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeReferralPlan === 'PLAN_A'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border border-indigo-400/50'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Flame size={12} className={activeReferralPlan === 'PLAN_A' ? 'text-rose-300' : ''} />
                  <span>Plan A (Viral)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSwitchReferralPlan('PLAN_B')}
                  disabled={isSwitchingReferralPlan}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-mono font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeReferralPlan === 'PLAN_B'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border border-indigo-400/50'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Coins size={12} className={activeReferralPlan === 'PLAN_B' ? 'text-amber-300' : ''} />
                  <span>Plan B (Profit)</span>
                </button>
              </div>
            </div>

            {/* Side-by-side Comparative Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              
              {/* PLAN A CARD */}
              <div
                onClick={() => handleSwitchReferralPlan('PLAN_A')}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                  activeReferralPlan === 'PLAN_A'
                    ? 'bg-slate-900/90 border-indigo-500/60 shadow-lg shadow-indigo-900/20 ring-1 ring-indigo-500/40'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 opacity-75 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black font-mono text-indigo-300 uppercase">
                      Plan A (Viral Expansion Mode)
                    </span>
                  </div>
                  {activeReferralPlan === 'PLAN_A' ? (
                    <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                      ACTIVE MODEL
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">Click to Activate</span>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 font-sans mb-3">
                  Aggressive growth tier rewards designed to maximize social sharing & rapid user acquisition.
                </p>

                <div className="space-y-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 1 (1–10 Invites) • Bronze</span>
                    <span className="font-bold text-amber-300">+300 Token / invite</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 2 (11–25 Invites) • Silver</span>
                    <span className="font-bold text-indigo-300">+500 Token / invite</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 3 (26+ Invites) • Gold VIP</span>
                    <span className="font-black text-emerald-400">+1,000 Token / invite</span>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">Model Focus:</span>
                  <span className="text-indigo-400 font-bold">Viral Expansion & Rapid Growth</span>
                </div>
              </div>

              {/* PLAN B CARD */}
              <div
                onClick={() => handleSwitchReferralPlan('PLAN_B')}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                  activeReferralPlan === 'PLAN_B'
                    ? 'bg-slate-900/90 border-indigo-500/60 shadow-lg shadow-indigo-900/20 ring-1 ring-indigo-500/40'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 opacity-75 hover:opacity-100'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black font-mono text-indigo-300 uppercase">
                      Plan B (Profit Optimization Mode)
                    </span>
                  </div>
                  {activeReferralPlan === 'PLAN_B' ? (
                    <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse"></span>
                      ACTIVE MODEL
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">Click to Activate</span>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 font-sans mb-3">
                  Conservative reward payouts structured to safeguard platform profitability & sustainable unit margins.
                </p>

                <div className="space-y-2 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 1 (1–10 Invites) • Bronze</span>
                    <span className="font-bold text-amber-300">+200 Token / invite</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 2 (11–25 Invites) • Silver</span>
                    <span className="font-bold text-indigo-300">+350 Token / invite</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 text-[11px]">Tier 3 (26+ Invites) • Gold VIP</span>
                    <span className="font-black text-emerald-400">+600 Token / invite</span>
                  </div>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between text-[10px] font-mono">
                  <span className="text-slate-400">Model Focus:</span>
                  <span className="text-indigo-400 font-bold">Profit Margin & Unit Retention</span>
                </div>
              </div>

            </div>
          </div>

          <form onSubmit={handleSaveAllSettings} className="space-y-4 max-w-3xl">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              
              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-amber-400 uppercase font-mono block whitespace-nowrap">
                  Default Task Reward Amount
                </label>
                <input
                  type="number"
                  value={settDefaultRewardPts}
                  onChange={(e) => setSettDefaultRewardPts(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-amber-300 font-mono outline-none"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-slate-200 uppercase font-mono block whitespace-nowrap">
                  Direct Referral Reward Amount
                </label>
                <input
                  type="number"
                  value={settRefReward}
                  onChange={(e) => setSettRefReward(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-slate-100 font-mono outline-none"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-slate-200 uppercase font-mono block whitespace-nowrap">
                  Referred Friends Task Commission (%)
                </label>
                <input
                  type="number"
                  value={settCommPercent}
                  onChange={(e) => setSettCommPercent(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-slate-100 font-mono outline-none"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-slate-200 uppercase font-mono block whitespace-nowrap">
                  Minimum Cashout Threshold (Tokens)
                </label>
                <input
                  type="number"
                  value={settMinWithdrawal}
                  onChange={(e) => setSettMinWithdrawal(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-slate-100 font-mono outline-none"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-emerald-400 uppercase font-mono block whitespace-nowrap">
                  BDT Conversion Rate (per 1,000 Tokens)
                </label>
                <input
                  type="number"
                  step="any"
                  value={settTokenRateBdt}
                  onChange={(e) => setSettTokenRateBdt(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-emerald-300 font-mono outline-none"
                  placeholder="e.g. 100"
                  required
                />
              </div>

              <div className="p-3.5 bg-slate-950/70 rounded-2xl border border-slate-800 space-y-1.5">
                <label className="text-xs font-bold text-teal-400 uppercase font-mono block whitespace-nowrap">
                  USD / USDT Conversion Rate (per 1,000 Tokens)
                </label>
                <input
                  type="number"
                  step="any"
                  value={settTokenRateUsd}
                  onChange={(e) => setSettTokenRateUsd(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl p-2.5 text-sm font-bold text-teal-300 font-mono outline-none"
                  placeholder="e.g. 0.85"
                  required
                />
              </div>

            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-600/20 transition cursor-pointer whitespace-nowrap border border-indigo-400/40"
            >
              Update Reward & Referral Rules
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: 🎓 গাইড ভিডিও লিংক কনফিগারেশন */}
      {(adminTab === 'guide' || adminTab === 'system') && (
        <div className="bg-slate-900/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-4 text-slate-100 animate-in fade-in duration-300">
          <div className="border-b border-slate-800/80 pb-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-2 whitespace-nowrap">
                <Tv size={16} className="text-purple-400 shrink-0" />
                <span>গাইড ভিডিও লিংক কনফিগারেশন</span>
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans mt-0.5">
                ডাউনলোড পোর্টালে ব্যবহারকারীদের জন্য গাইড ভিডিও লিঙ্ক ও নির্দেশক অডিও পরিচালনা করুন।
              </p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono font-bold px-2.5 py-0.5 rounded-full">
                ⚡ Active in Download Portal
              </span>
            </div>
          </div>

          <form onSubmit={handleSaveGuideSettings} className="space-y-4 max-w-3xl">
            
            <div className="p-3.5 sm:p-5 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-4 sm:space-y-5">
              
              {/* Field 1: Guide Video Link 🔗 */}
              <div className="space-y-1.5 sm:space-y-2">
                <label className="text-[10px] sm:text-[11px] font-bold text-slate-200 uppercase font-mono flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-cyan-400 truncate">
                    <Send size={12} className="shrink-0" /> গাইড ভিডিও লিংক 🔗 (Telegram / Web Link)
                  </span>
                  {settGuideVideo && (
                    <button
                      type="button"
                      onClick={handleDeleteGuideVideo}
                      className="text-[9px] sm:text-[10px] text-white bg-red-600 hover:bg-red-500 border border-red-400 px-2 py-0.5 rounded-lg font-mono font-bold whitespace-nowrap cursor-pointer transition active:scale-95 shrink-0 flex items-center gap-1 shadow-sm"
                    >
                      <Trash2 size={10} /> Delete Link
                    </button>
                  )}
                </label>
                <input
                  type="text"
                  value={settGuideVideo}
                  onChange={(e) => setSettGuideVideo(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-cyan-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                  placeholder="https://t.me/MrMovieBox_bot?start=guide or paste bot video link"
                />

                {/* Clean Telegram Link Preview */}
                {settGuideVideo && (
                  <div className="p-2 sm:p-2.5 bg-slate-900/90 border border-cyan-500/30 rounded-xl flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
                        <Send size={12} />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[10px] sm:text-[11px] font-mono font-bold text-cyan-300 flex items-center gap-1">
                          <Check size={10} className="text-cyan-400" /> Link Active
                        </span>
                        <p className="text-[9px] sm:text-[10px] text-slate-400 font-mono truncate">{settGuideVideo}</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => window.open(settGuideVideo, "_blank", "noopener,noreferrer")}
                      className="text-[9px] sm:text-[10px] text-cyan-200 hover:text-white bg-cyan-900/70 hover:bg-cyan-800 border border-cyan-500/40 px-2 sm:px-2.5 py-1 rounded-lg flex items-center gap-1 transition cursor-pointer font-bold active:scale-95 shadow-sm shrink-0 whitespace-nowrap"
                    >
                      <ExternalLink size={10} /> Test Link ↗
                    </button>
                  </div>
                )}
              </div>

              {/* Field 2: Voice Audio 🎙️ (Optional MP3 Audio Guide) */}
              <div className="space-y-1.5 sm:space-y-2 pt-3 border-t border-slate-800/60">
                <label className="text-[10px] sm:text-[11px] font-bold text-slate-200 uppercase font-mono flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-amber-400 truncate">
                    <Volume2 size={12} className="shrink-0" /> সহায়ক ভয়েস অডিও 🎙️ (Voice Audio Guide)
                  </span>
                  {settGuideAudio && (
                    <button
                      type="button"
                      onClick={handleDeleteGuideAudio}
                      className="text-[9px] sm:text-[10px] text-white bg-red-600 hover:bg-red-500 border border-red-400 px-2 py-0.5 rounded-lg font-mono font-bold whitespace-nowrap cursor-pointer transition active:scale-95 shrink-0 flex items-center gap-1 shadow-sm"
                    >
                      <Trash2 size={10} /> Delete Audio
                    </button>
                  )}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={settGuideAudio}
                    onChange={(e) => setSettGuideAudio(e.target.value)}
                    className="flex-1 min-w-0 bg-slate-900 border border-slate-800 focus:border-amber-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none placeholder-slate-600"
                    placeholder="Audio URL or upload MP3 (/uploads/voice_guide.mp3)"
                  />
                  <label className={`bg-amber-600 hover:bg-amber-500 text-white px-3 sm:px-3.5 py-2 sm:py-2.5 rounded-xl cursor-pointer flex items-center gap-1.5 text-xs font-mono font-bold shrink-0 transition whitespace-nowrap ${uploadingGuideAudio ? 'opacity-50 pointer-events-none' : ''}`}>
                    {uploadingGuideAudio ? <Loader2 size={12} className="animate-spin" /> : <Upload size={12} />}
                    <span className="hidden sm:inline">{uploadingGuideAudio ? 'Uploading...' : 'Upload MP3'}</span>
                    <input type="file" accept="audio/*" onChange={handleSystemGuideAudioUpload} className="hidden" />
                  </label>
                </div>

                {/* Embedded Audio Player Preview */}
                {settGuideAudio && (
                  <div className="mt-2 p-2 sm:p-2.5 bg-slate-900/90 border border-amber-500/30 rounded-xl space-y-1.5">
                    <span className="text-[9px] sm:text-[10px] font-mono text-amber-300 flex items-center gap-1 font-bold">
                      <Check size={10} /> Voice Guide Audio Ready
                    </span>
                    <audio src={settGuideAudio} controls className="w-full h-8" />
                  </div>
                )}
              </div>

            </div>

            <div className="pt-2 flex items-center justify-between gap-3 flex-wrap">
              <button
                type="button"
                onClick={handleSaveGuideSettings}
                disabled={isSavingGuideSettings}
                className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-black text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-600/30 transition cursor-pointer whitespace-nowrap active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 disabled:pointer-events-none"
              >
                {isSavingGuideSettings ? <Loader2 size={14} className="animate-spin" /> : <Check size={14} />}
                <span>{isSavingGuideSettings ? "SAVING SETTINGS..." : "SAVE GUIDE LINK"}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB: 🤖 TELEGRAM BOT CONTROL */}
      {adminTab === 'telegram' && (
        <div className="bg-slate-900/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-3.5 sm:p-6 shadow-2xl space-y-4 sm:space-y-5 text-slate-100 animate-in fade-in duration-300 overflow-hidden max-w-full break-words">
          <div className="border-b border-slate-800/80 pb-3">
            <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-2 flex-wrap leading-snug">
              <Bot size={16} className="text-indigo-400 shrink-0" />
              <span className="break-words">Telegram Bot Control & Channel Configuration</span>
            </h3>
            <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans mt-1 leading-relaxed break-words">
              Manage Telegram Bot links, access domains, channel integration, and reaction bounties.
            </p>
          </div>

          <form onSubmit={handleSaveAllSettings} className="space-y-4 max-w-3xl">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 sm:gap-4">

              <div className="p-3.5 sm:p-4 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1.5 min-w-0">
                <label className="text-xs font-bold text-slate-200 uppercase font-mono block break-words">
                  Telegram Bot Direct URL
                </label>
                <input
                  type="text"
                  value={settBotLink}
                  onChange={(e) => setSettBotLink(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                  placeholder="https://t.me/YourBotName_bot"
                  required
                />
              </div>

              <div className="p-3.5 sm:p-4 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-1.5 min-w-0">
                <label className="text-xs font-bold text-slate-200 uppercase font-mono block break-words">
                  Telegram Bot Access Domain Links
                </label>
                <input
                  type="text"
                  value={settDomain}
                  onChange={(e) => setSettDomain(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                  placeholder="https://t.me/YourBotName_bot?start="
                  required
                />
              </div>

              {/* Telegram Channel Suite */}
              <div className="p-3.5 sm:p-4 bg-slate-950/70 rounded-2xl border border-slate-800/80 space-y-3 sm:col-span-2 min-w-0">
                <h5 className="text-xs font-black text-indigo-400 uppercase font-mono tracking-wider flex items-center gap-2 flex-wrap leading-snug">
                  <Share2 size={13} className="shrink-0" /> <span className="break-words">Telegram Channel Controller</span>
                </h5>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="min-w-0">
                    <label className="text-[10px] text-slate-400 uppercase font-mono font-bold block mb-1 break-words">
                      Telegram Channel Link / Username
                    </label>
                    <input
                      type="text"
                      value={settChannelUrl}
                      onChange={(e) => setSettChannelUrl(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                      placeholder="https://t.me/YourChannel"
                      required
                    />
                  </div>

                  <div className="min-w-0">
                    <label className="text-[10px] text-slate-400 uppercase font-mono font-bold block mb-1 break-words">
                      Target Channel Post Link / ID
                    </label>
                    <input
                      type="text"
                      value={settPostId}
                      onChange={(e) => setSettPostId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                      placeholder="1234"
                      required
                    />
                  </div>

                  <div className="sm:col-span-2 min-w-0">
                    <label className="text-[10px] text-slate-400 uppercase font-mono font-bold block mb-1 break-words">
                      Daily Reaction Bounty Amount (Coins)
                    </label>
                    <input
                      type="number"
                      value={settReactionReward}
                      onChange={(e) => setSettReactionReward(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 font-mono outline-none"
                      required
                    />
                  </div>
                </div>
              </div>

            </div>

            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-600/25 transition cursor-pointer flex items-center justify-center gap-2"
            >
              Save Telegram Bot & Channel Settings
            </button>
          </form>
        </div>
      )}

      {/* TAB 6: TASKS CONTROL */}
      {adminTab === "missions" && (
        <AdminTaskManager
          missions={missions}
          onAddMission={onAddMission as any}
          onEditMission={onEditMission}
          onToggleMission={onToggleMission}
          onDeleteMission={onDeleteMission || (async () => {})}
          showAdminToast={showAdminToast}
        />
      )}

      {/* TAB 7: WITHDRAWAL REQUESTS APPROVAL PANEL */}
      {adminTab === 'withdrawals' && (
        <div className="bg-slate-900/95 border border-slate-800/90 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-5 text-slate-100 animate-in fade-in duration-300">
          {/* Header & Stats Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400">
                <DollarSign size={20} />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-black text-white uppercase tracking-wider font-mono flex items-center gap-2">
                  <span>Withdrawal Requests Approval Panel</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                    Super Admin Suite
                  </span>
                </h3>
                <p className="text-xs text-slate-400 font-sans">
                  Manage user disbursements across bKash, Nagad, TON & USDT with one-click approval and instant refund rollback
                </p>
              </div>
            </div>

            {/* Metric Counters */}
            <div className="flex items-center gap-2 font-mono text-xs flex-wrap">
              <div className="bg-slate-950/80 border border-amber-500/30 px-3 py-1.5 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 block uppercase">Pending</span>
                <span className="text-amber-400 font-bold">{withdrawals.filter(w => w.status === 'pending').length}</span>
              </div>
              <div className="bg-slate-950/80 border border-emerald-500/30 px-3 py-1.5 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 block uppercase">Approved / Paid</span>
                <span className="text-emerald-400 font-bold">{withdrawals.filter(w => w.status === 'approved' || (w as any).status === 'paid').length}</span>
              </div>
              <div className="bg-slate-950/80 border border-rose-500/30 px-3 py-1.5 rounded-xl text-center">
                <span className="text-[10px] text-slate-400 block uppercase">Rejected</span>
                <span className="text-rose-400 font-bold">{withdrawals.filter(w => w.status === 'rejected').length}</span>
              </div>
            </div>
          </div>

          {/* Filter & Search Toolbar */}
          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
            {/* Filter Tabs */}
            <div 
              data-scroll-container="true"
              className="flex items-center gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800 self-start overflow-x-auto no-scrollbar max-w-full scroll-smooth"
            >
              {(['all', 'pending', 'approved', 'rejected'] as const).map((filter) => {
                const count = filter === 'all' 
                  ? withdrawals.length 
                  : filter === 'approved'
                  ? withdrawals.filter(w => w.status === 'approved' || (w as any).status === 'paid').length
                  : withdrawals.filter(w => w.status === filter).length;
                return (
                  <button
                    key={filter}
                    onClick={(e) => {
                      setWithdrawalFilter(filter);
                      scrollContainerToElement(e.currentTarget);
                    }}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition cursor-pointer whitespace-nowrap capitalize shrink-0 ${
                      withdrawalFilter === filter
                        ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border border-indigo-400/40"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    {filter === 'approved' ? 'Paid / Approved' : filter} ({count})
                  </button>
                );
              })}
            </div>

            {/* Search Input */}
            <div className="relative flex-1 max-w-xs">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={withdrawalSearchQuery}
                onChange={(e) => setWithdrawalSearchQuery(e.target.value)}
                placeholder="Search email, account, user..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-7 py-1.5 text-xs text-white placeholder-slate-500 font-mono outline-none focus:border-indigo-500/70 transition"
              />
              {withdrawalSearchQuery && (
                <button
                  onClick={() => setWithdrawalSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                >
                  <X size={12} />
                </button>
              )}
            </div>
          </div>

          {/* Requests List */}
          <div className="space-y-3">
            {filteredWithdrawals.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/60 border border-slate-800/60 rounded-2xl">
                <DollarSign size={28} className="text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400 font-mono">No withdrawal requests match current criteria.</p>
              </div>
            ) : (
              filteredWithdrawals.map((w) => {
                const isPending = w.status === 'pending';
                const isApproved = w.status === 'approved' || (w as any).status === 'paid';

                // Method badge styling
                const methodStr = (w.paymentMethod || 'bKash').toLowerCase();
                const isBkash = methodStr.includes('bkash');
                const isNagad = methodStr.includes('nagad');
                const isTrc20 = methodStr.includes('trc') || methodStr.includes('usdt') || methodStr.includes('crypto');

                const methodBadgeClass = isBkash
                  ? 'bg-pink-500/15 text-pink-300 border-pink-500/40'
                  : isNagad
                  ? 'bg-orange-500/15 text-orange-300 border-orange-500/40'
                  : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40';

                const destination = w.accountNumber || w.walletAddress || 'N/A';
                const applicantEmail = w.email || (w as any).userEmail || (w.username?.includes('@') ? w.username : `${w.username || 'user'}@applicant.com`);
                const formattedDate = w.timestamp ? new Date(w.timestamp).toLocaleString() : 'Recent';

                const applicantUser = usersList.find(u => u.id === w.userId || (u.email && w.email && u.email.toLowerCase() === w.email.toLowerCase()));
                const isSuspicious = (w as any).isSuspicious || applicantUser?.isSuspicious;
                const isApplicantBanned = (w as any).isBanned || applicantUser?.isBanned || applicantUser?.status === 'banned';
                const userFp = (w as any).deviceFingerprint || applicantUser?.device_fingerprint || applicantUser?.deviceFingerprint;

                // Estimated fiat value using dynamic rates
                const rateBdt = settTokenRateBdt || 100;
                const rateUsd = settTokenRateUsd || 0.85;
                const fiatEst = isBkash || isNagad
                  ? `≈ ৳ ${((w.amount * rateBdt) / 1000).toFixed(2)} BDT`
                  : `≈ $ ${((w.amount * rateUsd) / 1000).toFixed(2)} USDT (TRC-20)`;

                return (
                  <div 
                    key={w.id} 
                    className={`p-4 rounded-2xl border transition shadow-lg space-y-3 ${
                      isApplicantBanned
                        ? 'bg-rose-950/20 border-rose-500/40 ring-1 ring-rose-500/30'
                        : isSuspicious
                        ? 'bg-amber-950/20 border-amber-500/40 ring-1 ring-amber-500/20'
                        : 'bg-slate-950/80 border-slate-800/90 hover:border-slate-700/80'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                      {/* Left: Applicant Email & Identity */}
                      <div className="space-y-1.5 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[10px] font-mono font-black px-2.5 py-0.5 rounded-full border uppercase ${methodBadgeClass}`}>
                            {isBkash && '🇧🇩 '}
                            {isNagad && '🇧🇩 '}
                            {isTrc20 && '🌐 '}
                            {w.paymentMethod || 'bKash'}
                          </span>

                          <span className="text-xs font-mono font-extrabold text-white flex items-center gap-1.5">
                            <Mail size={13} className="text-slate-400 shrink-0" />
                            <span className="text-emerald-400 select-all truncate max-w-xs">{applicantEmail}</span>
                          </span>

                          <span className="text-[10px] text-slate-500 font-mono">
                            (@{w.username || w.userId})
                          </span>

                          {isApplicantBanned && (
                            <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 uppercase flex items-center gap-1">
                              <Ban size={10} /> Banned
                            </span>
                          )}

                          {isSuspicious && !isApplicantBanned && (
                            <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase flex items-center gap-1">
                              <AlertTriangle size={10} /> High Risk / Multi-Account
                            </span>
                          )}
                        </div>

                        {/* Destination Account */}
                        <div className="flex items-center gap-2 text-xs font-mono">
                          <span className="text-slate-400 text-[11px]">
                            {isBkash ? 'bKash No:' : isNagad ? 'Nagad No:' : 'Wallet / Address:'}
                          </span>
                          <span className="font-bold text-slate-100 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 select-all truncate max-w-xs">
                            {destination}
                          </span>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(destination);
                              setCopiedWithdrawalId(w.id);
                              setTimeout(() => setCopiedWithdrawalId(null), 2000);
                            }}
                            className="p-1 text-slate-400 hover:text-white transition cursor-pointer"
                            title="Copy Account Number"
                          >
                            {copiedWithdrawalId === w.id ? (
                              <Check size={13} className="text-emerald-400" />
                            ) : (
                              <Copy size={13} />
                            )}
                          </button>
                        </div>

                        {/* Hardware ID & Fraud Detection Details */}
                        {userFp && (
                          <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400 flex-wrap pt-0.5">
                            <span className="flex items-center gap-1 bg-slate-900/80 px-2 py-0.5 rounded border border-slate-800">
                              <Smartphone size={10} className="text-slate-500" />
                              <span>Hardware ID:</span>
                              <span className="text-indigo-300 font-bold select-all">{userFp.slice(0, 16)}...</span>
                            </span>

                            {applicantUser?.boundAccountsCount > 1 && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-bold">
                                ⚡ {applicantUser.boundAccountsCount} accounts on device
                              </span>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Right: Amount & Payout Status / Actions */}
                      <div className="flex flex-col sm:items-end gap-0.5 font-mono shrink-0">
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-base font-black text-emerald-400">
                            🪙 {w.amount.toLocaleString()}
                          </span>
                          <span className="text-xs text-slate-400 font-sans">Token</span>
                        </div>
                        <span className="text-[11px] text-slate-300 font-semibold">
                          {fiatEst}
                        </span>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Clock size={10} />
                          <span>{formattedDate}</span>
                        </span>
                      </div>
                    </div>

                    {/* Action Bar / Status Indicator */}
                    <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-3 flex-wrap">
                      <div className="text-[10px] font-mono text-slate-500 flex items-center gap-2">
                        <span>Request ID: <span className="text-slate-400 font-bold">{w.id}</span></span>
                      </div>

                      <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full sm:w-auto justify-start sm:justify-end">
                        {/* 1-Click Ban / Unban Toggle Button */}
                        <button
                          type="button"
                          disabled={banningUserId === (w.userId || applicantUser?.id)}
                          onClick={() => handleToggleUserBan(w.userId || applicantUser?.id, isApplicantBanned, applicantEmail)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 flex-1 sm:flex-initial ${
                            isApplicantBanned
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
                          }`}
                          title={isApplicantBanned ? "Unban user account" : "Ban user account from cashouts"}
                        >
                          {banningUserId === (w.userId || applicantUser?.id) ? (
                            <Loader2 size={13} className="animate-spin" />
                          ) : isApplicantBanned ? (
                            <UserCheck size={13} />
                          ) : (
                            <Ban size={13} />
                          )}
                          <span>{isApplicantBanned ? "Unban Profile" : "1-Click Ban"}</span>
                        </button>

                        {isPending ? (
                          <>
                            <button
                              onClick={async () => {
                                if (isApplicantBanned) {
                                  alert(`Warning: This user (${applicantEmail}) is currently banned. Unban them first if you want to disburse funds.`);
                                  return;
                                }
                                try {
                                  await onUpdateWithdrawal(w.id, 'approved');
                                  showAdminToast(`✓ Approved payout of ${w.amount.toLocaleString()} Token for ${applicantEmail}`, 'success');
                                } catch (err: any) {
                                  showAdminToast(err.message || 'Failed to approve', 'error');
                                }
                              }}
                              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold font-mono transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 active:scale-95 flex-1 sm:flex-initial"
                            >
                              <Check size={14} strokeWidth={3} />
                              <span>Approve & Pay</span>
                            </button>
                            
                            <button
                              onClick={async () => {
                                if (confirm(`Reject this withdrawal of ${w.amount.toLocaleString()} Token? Tokens will be instantly refunded to ${applicantEmail}.`)) {
                                  try {
                                    await onUpdateWithdrawal(w.id, 'rejected');
                                    showAdminToast(`✕ Rejected request. ${w.amount.toLocaleString()} Token refunded to user.`, 'info');
                                  } catch (err: any) {
                                    showAdminToast(err.message || 'Failed to reject', 'error');
                                  }
                                }
                              }}
                              className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold font-mono transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/20 active:scale-95 flex-1 sm:flex-initial"
                            >
                              <X size={14} strokeWidth={3} />
                              <span>Reject & Refund</span>
                            </button>
                          </>
                        ) : isApproved ? (
                          <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-extrabold flex items-center gap-1.5 uppercase">
                            <CheckCircle2 size={13} />
                            <span>Paid / Approved</span>
                          </span>
                        ) : (
                          <span className="px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-mono font-extrabold flex items-center gap-1.5 uppercase">
                            <X size={13} />
                            <span>Rejected (Points Refunded)</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

    </div>
  );
}
