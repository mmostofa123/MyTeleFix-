/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Re-export wrapper for IdentityVerifyModal
 */

export { 
  default,
  IdentityVerifyModal,
  shouldShowSecurityNotice,
  markSecurityNoticeAsShown,
  SEEN_STORAGE_KEY
} from "./IdentityVerifyModal";
export type { IdentityVerifyModalProps } from "./IdentityVerifyModal";
