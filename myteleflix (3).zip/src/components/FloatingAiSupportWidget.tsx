/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Floating Draggable AI Support Chat Widget (TeleFlix Customer Support)
 * 
 * Complies strictly with the GLOBAL PREMIUM UI/UX VISUAL DESIGN DIRECTIVE:
 * - Natural, deep, matte organic dark-mode palette (#0A0F1D / #11182A / #131B2E)
 * - Zero glow, zero neon light rays, no pinging animations
 * - Speaker / audio icon completely removed
 * - Sculpted, ultra-premium single-line input container with integrated send action
 * - High-contrast typography, clear hierarchy, and executive-grade layout
 * - Default position: Right-center edge (right: 16px, top: 50%, translateY(-50%))
 * - Full fluid dragging with viewport clamping and edge snapping
 * - Tap vs. drag gesture differentiation
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  X, Send, RotateCcw, Copy, Check, ShieldCheck, 
  HelpCircle, MessageSquare
} from "lucide-react";
import { User } from "../types";

interface MessageItem {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

interface FloatingAiSupportWidgetProps {
  user?: User | null;
  onNavigateTab?: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
}

/**
 * Human Customer Support Agent Vector Avatar
 * Clean, matte, executive-grade representation of a professional support specialist
 */
function SupportAgentAvatar({ size = 22, className = "" }: { size?: number; className?: string }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      {/* Agent Shoulders / Bust */}
      <path 
        d="M4.5 19.5C4.5 16.5 7.5 15 12 15C16.5 15 19.5 16.5 19.5 19.5" 
        stroke="currentColor" 
        strokeWidth="1.8" 
        strokeLinecap="round" 
      />
      {/* Agent Head */}
      <circle 
        cx="12" 
        cy="9.5" 
        r="4" 
        stroke="currentColor" 
        strokeWidth="1.8" 
      />
      {/* Headset Arc */}
      <path 
        d="M7.5 9.5C7.5 7 9.5 5 12 5C14.5 5 16.5 7 16.5 9.5" 
        stroke="currentColor" 
        strokeWidth="1.6" 
        strokeLinecap="round" 
      />
      {/* Headset Earcups */}
      <rect x="6.2" y="8" width="2" height="3.5" rx="1" fill="currentColor" />
      <rect x="15.8" y="8" width="2" height="3.5" rx="1" fill="currentColor" />
      {/* Headset Microphone Boom */}
      <path 
        d="M16.5 10.5L16 12.5C15.6 13.5 14.5 14 13.5 14H13" 
        stroke="currentColor" 
        strokeWidth="1.5" 
        strokeLinecap="round" 
      />
      <circle cx="12.5" cy="14" r="0.8" fill="currentColor" />
    </svg>
  );
}

const DEFAULT_WELCOME_MESSAGE: MessageItem = {
  id: "welcome_msg",
  sender: "assistant",
  text: `👋 <b>স্বাগতম MyTeleFlix কাস্টমার সাপোর্টে!</b>\n\nমুভি ডাউনলোড, চ্যানেল ভেরিফিকেশন, কিংবা বিকাশ/নগদে ওয়ালেট ক্যাশআউট সংক্রান্ত যেকোনো সমস্যা বা প্রশ্ন থাকলে নিচে লিখুন। আমি তাৎক্ষণিক সহায়তা প্রদান করছি।\n\n<i>Ask me anything about downloads, verification, or wallet points!</i>`,
  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
};

const SUGGESTED_QUESTIONS = [
  { id: "dl", label: "🎬 How to Download?", query: "মুভি কিভাবে ডাউনলোড করব? পুরো নিয়ম বলে দিন।" },
  { id: "wallet", label: "💰 Wallet & Cashout Rules", query: "পয়েন্ট রেট কত এবং বিকাশ/নগদে উইথড্র করার নিয়ম কী?" },
  { id: "vip", label: "🌟 Guest vs VIP Mode", query: "গেস্ট মোড ও ভিআইপি মোডের মধ্যে পার্থক্য এবং সুবিধা কী?" },
  { id: "verify", label: "🔐 Channel Verification", query: "চ্যানেল ভেরিফিকেশন কিভাবে সম্পন্ন করব?" },
];

export default function FloatingAiSupportWidget({ user, onNavigateTab }: FloatingAiSupportWidgetProps) {
  // Widget Open / Closed State
  const [isOpen, setIsOpen] = useState<boolean>(false);

  // Messages & Session Memory
  const [messages, setMessages] = useState<MessageItem[]>(() => {
    try {
      const saved = sessionStorage.getItem("myteleflix_ai_chat_history");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return [DEFAULT_WELCOME_MESSAGE];
  });

  const [inputText, setInputText] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);

  // Initial Position: RIGHT-CENTER EDGE (right: 16px, top: 50%, translateY(-50%))
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window !== "undefined") {
      const initialX = Math.max(12, window.innerWidth - 68);
      const initialY = Math.max(70, Math.floor(window.innerHeight / 2 - 26));
      return { x: initialX, y: initialY };
    }
    return { x: 300, y: 350 };
  });

  const [isDragging, setIsDragging] = useState<boolean>(false);
  const hasUserDraggedRef = useRef<boolean>(false);

  const dragRef = useRef<{
    startX: number;
    startY: number;
    initialPosX: number;
    initialPosY: number;
    hasMoved: boolean;
  }>({
    startX: 0,
    startY: 0,
    initialPosX: 0,
    initialPosY: 0,
    hasMoved: false,
  });

  const chatContainerRef = useRef<HTMLDivElement | null>(null);

  // Persist messages to sessionStorage
  useEffect(() => {
    try {
      sessionStorage.setItem("myteleflix_ai_chat_history", JSON.stringify(messages));
    } catch {}
  }, [messages]);

  // Scroll to bottom when messages update or typing indicator displays
  useEffect(() => {
    if (isOpen && chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages, isLoading, isOpen]);

  // Window resize bounds handler
  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => {
        if (!hasUserDraggedRef.current) {
          return {
            x: Math.max(12, window.innerWidth - 68),
            y: Math.max(70, Math.floor(window.innerHeight / 2 - 26)),
          };
        }
        return {
          x: Math.min(Math.max(12, prev.x), window.innerWidth - 68),
          y: Math.min(Math.max(70, prev.y), window.innerHeight - 80),
        };
      });
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Touch Drag Handlers (Mobile)
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (!touch) return;
    dragRef.current = {
      startX: touch.clientX,
      startY: touch.clientY,
      initialPosX: position.x,
      initialPosY: position.y,
      hasMoved: false,
    };
    setIsDragging(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    if (!touch) return;

    const deltaX = touch.clientX - dragRef.current.startX;
    const deltaY = touch.clientY - dragRef.current.startY;

    if (Math.abs(deltaX) > 6 || Math.abs(deltaY) > 6) {
      dragRef.current.hasMoved = true;
      hasUserDraggedRef.current = true;
    }

    const newX = Math.min(Math.max(12, dragRef.current.initialPosX + deltaX), window.innerWidth - 68);
    const newY = Math.min(Math.max(70, dragRef.current.initialPosY + deltaY), window.innerHeight - 80);

    setPosition({ x: newX, y: newY });
  };

  const handleTouchEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);

    // If tap without significant movement, toggle open
    if (!dragRef.current.hasMoved) {
      setIsOpen((prev) => !prev);
      return;
    }

    // Snap to nearest edge (left or right)
    const midX = window.innerWidth / 2;
    const snappedX = position.x < midX ? 16 : window.innerWidth - 68;
    setPosition((prev) => ({ ...prev, x: snappedX }));
  };

  // Mouse Drag Handlers (Desktop)
  const handleMouseDown = (e: React.MouseEvent) => {
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialPosX: position.x,
      initialPosY: position.y,
      hasMoved: false,
    };
    setIsDragging(true);

    const onMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - dragRef.current.startX;
      const deltaY = moveEvent.clientY - dragRef.current.startY;

      if (Math.abs(deltaX) > 6 || Math.abs(deltaY) > 6) {
        dragRef.current.hasMoved = true;
        hasUserDraggedRef.current = true;
      }

      const newX = Math.min(Math.max(12, dragRef.current.initialPosX + deltaX), window.innerWidth - 68);
      const newY = Math.min(Math.max(70, dragRef.current.initialPosY + deltaY), window.innerHeight - 80);
      setPosition({ x: newX, y: newY });
    };

    const onMouseUp = () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      setIsDragging(false);

      if (!dragRef.current.hasMoved) {
        setIsOpen((prev) => !prev);
        return;
      }

      // Snap to nearest edge
      const midX = window.innerWidth / 2;
      const snappedX = position.x < midX ? 16 : window.innerWidth - 68;
      setPosition((prev) => ({ ...prev, x: snappedX }));
    };

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
  };

  // Send Message Query to Backend
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMessage: MessageItem = {
      id: `user_${Date.now()}`,
      sender: "user",
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInputText("");
    setIsLoading(true);

    try {
      const historyMemory = nextMessages.slice(-6).map((m) => ({
        role: m.sender === "user" ? ("user" as const) : ("assistant" as const),
        content: m.text.replace(/<[^>]*>/g, ""),
      }));

      const res = await fetch("/api/support/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query,
          user: user ? { id: user.id, name: user.fullName || user.username } : undefined,
          history: historyMemory,
        }),
      });

      const data = await res.json();
      const replyText = data?.reply || "I am here to help! Please ask any question about MyTeleFlix.";

      const aiReply: MessageItem = {
        id: `ai_${Date.now()}`,
        sender: "assistant",
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiReply]);
    } catch (err: any) {
      const errorReply: MessageItem = {
        id: `err_${Date.now()}`,
        sender: "assistant",
        text: `⚠️ সার্ভারের সাথে সংযোগে সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।\n\n<i>Temporary connection issue. Please retry in a moment.</i>`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorReply]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    try {
      const clean = text.replace(/<[^>]*>/g, "");
      navigator.clipboard.writeText(clean);
      setCopiedMsgId(id);
      setTimeout(() => setCopiedMsgId(null), 2000);
    } catch {}
  };

  const handleResetChat = () => {
    setMessages([DEFAULT_WELCOME_MESSAGE]);
    sessionStorage.removeItem("myteleflix_ai_chat_history");
  };

  return (
    <>
      {/* 1. FLOATING DRAGGABLE ACTION BUTTON (RIGHT-CENTER DEFAULT, MATTE ORGANIC DARK, NO GLOW) */}
      {!isOpen && (
        <div
          id="btn-floating-ai-support"
          style={{
            transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
            transition: isDragging ? "none" : "transform 0.22s cubic-bezier(0.2, 0.9, 0.3, 1)",
            touchAction: "none",
          }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onMouseDown={handleMouseDown}
          className="fixed top-0 left-0 z-40 select-none cursor-grab active:cursor-grabbing group"
          title="Customer Support"
        >
          {/* Main Floating Orb Button (Natural Matte #121824, Solid Refined Border, No Neon Glow) */}
          <div className="relative w-13 h-13 rounded-full bg-[#121824] hover:bg-[#162032] border border-[#232F46] hover:border-slate-500 shadow-[0_8px_24px_rgba(0,0,0,0.6)] flex items-center justify-center text-slate-200 hover:text-white transition-all duration-150 active:scale-95">
            {/* Human / Support Agent Vector Avatar */}
            <SupportAgentAvatar size={24} className="text-slate-300 group-hover:text-cyan-400 transition-colors" />

            {/* Clean Solid Online Status Indicator (No Pulsing Light / No Glow) */}
            <span className="absolute top-1 right-1 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#121824]" />

            {/* Subtle Compact Support Tag */}
            <span className="absolute -bottom-1.5 px-1.5 py-0.2 rounded-full bg-[#182133] border border-[#28364F] text-[8.5px] font-bold text-slate-300 tracking-wider uppercase font-mono shadow-xs">
              Help
            </span>
          </div>
        </div>
      )}

      {/* 2. RESPONSIVE SUPPORT CHAT WINDOW (EXECUTIVE-GRADE DEEP DARK OTT DESIGN) */}
      {isOpen && (
        <div 
          id="ai-support-chat-window"
          className="fixed inset-0 sm:inset-auto sm:bottom-6 sm:right-6 z-50 flex flex-col justify-end sm:justify-start items-center sm:items-end pointer-events-none"
        >
          {/* Backdrop on mobile screens */}
          <div 
            className="sm:hidden fixed inset-0 bg-black/75 backdrop-blur-xs pointer-events-auto transition-opacity"
            onClick={() => setIsOpen(false)}
          />

          {/* Chat Window Panel - Sculpted Multi-Layered Surface */}
          <div className="relative pointer-events-auto w-full sm:w-[425px] max-w-full h-[590px] max-h-[90vh] sm:max-h-[84vh] bg-[#0A0F1D] border border-[#1E293B]/90 sm:rounded-3xl rounded-t-3xl shadow-[0_24px_60px_-12px_rgba(0,0,0,0.95)] flex flex-col overflow-hidden animate-in slide-in-from-bottom-8 sm:zoom-in-95 duration-200">
            
            {/* Fine Top Accent Hairline */}
            <div className="h-[2px] w-full bg-gradient-to-r from-transparent via-cyan-500/40 to-transparent shrink-0" />

            {/* Header: Human Support Agent, Title, Status, Reset, Close (NO SPEAKER ICON) */}
            <div className="px-4 py-3 bg-gradient-to-b from-[#131B2E] to-[#0E1524] border-b border-[#1E2A42] flex items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <div className="relative w-9.5 h-9.5 rounded-xl bg-[#182338] border border-[#2A3A58] flex items-center justify-center text-cyan-400 shrink-0 shadow-inner">
                  <SupportAgentAvatar size={21} />
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#0E1524]" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2 truncate tracking-tight">
                    <span>TeleFlix Support</span>
                    <span className="text-[9.5px] px-1.5 py-0.2 rounded-md bg-[#16233B] text-emerald-400 border border-emerald-500/30 font-mono font-semibold">
                      ONLINE
                    </span>
                  </h3>
                  <p className="text-[10.5px] text-slate-400 font-medium truncate">
                    Verified Desk · Instant response 24/7
                  </p>
                </div>
              </div>

              {/* Action Buttons: Reset Chat, Close (Speaker Icon is permanently removed) */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleResetChat}
                  title="Clear & Reset Conversation"
                  className="w-8 h-8 rounded-xl bg-[#162034] hover:bg-[#1E2C48] text-slate-300 hover:text-white flex items-center justify-center transition active:scale-95 cursor-pointer border border-[#253550]"
                >
                  <RotateCcw size={14} />
                </button>

                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  title="Close support window"
                  className="w-8 h-8 rounded-xl bg-[#162034] hover:bg-[#1E2C48] text-slate-300 hover:text-white flex items-center justify-center transition active:scale-95 cursor-pointer border border-[#253550]"
                >
                  <X size={15} />
                </button>
              </div>
            </div>

            {/* Scrollable Message Thread */}
            <div 
              ref={chatContainerRef}
              className="flex-1 p-4 overflow-y-auto space-y-3.5 no-scrollbar bg-[#090D18]"
            >
              {messages.map((msg) => {
                const isAssistant = msg.sender === "assistant";
                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 ${isAssistant ? "justify-start" : "justify-end"}`}
                  >
                    {isAssistant && (
                      <div className="w-7 h-7 rounded-xl bg-[#131B2C] border border-[#202E46] text-cyan-400 flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                        <SupportAgentAvatar size={15} />
                      </div>
                    )}

                    <div className="max-w-[85%] sm:max-w-[80%] space-y-1">
                      <div
                        className={`p-3.5 rounded-2xl text-xs sm:text-[13px] leading-relaxed shadow-sm ${
                          isAssistant
                            ? "bg-[#11182A] border border-[#1E2B44] text-slate-100 rounded-tl-xs"
                            : "bg-gradient-to-r from-[#1D4ED8] to-[#2563EB] text-white rounded-tr-xs font-medium shadow-md"
                        }`}
                      >
                        <div
                          className="prose prose-invert prose-xs max-w-none space-y-1.5 text-slate-100"
                          dangerouslySetInnerHTML={{ __html: msg.text }}
                        />
                      </div>

                      {/* Message Footer: Timestamp & Copy Button */}
                      <div className={`flex items-center gap-2 text-[10px] text-slate-400 px-1 ${isAssistant ? "justify-start" : "justify-end"}`}>
                        <span>{msg.timestamp}</span>
                        {isAssistant && (
                          <button
                            type="button"
                            onClick={() => handleCopyText(msg.id, msg.text)}
                            title="Copy reply text"
                            className="text-slate-400 hover:text-cyan-300 transition inline-flex items-center gap-1 cursor-pointer"
                          >
                            {copiedMsgId === msg.id ? (
                              <>
                                <Check size={11} className="text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy size={11} />
                                <span>Copy</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Typing / Loading Indicator */}
              {isLoading && (
                <div className="flex items-center gap-2.5 justify-start animate-in fade-in">
                  <div className="w-7 h-7 rounded-xl bg-[#131B2C] border border-[#202E46] text-cyan-400 flex items-center justify-center shrink-0">
                    <SupportAgentAvatar size={15} />
                  </div>
                  <div className="px-3.5 py-2.5 rounded-2xl bg-[#11182A] border border-[#1E2B44] text-slate-300 text-xs flex items-center gap-2 shadow-xs">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.15s]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-bounce [animation-delay:0.3s]" />
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">Agent is formulating guidance...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Quick-Prompt Suggestions (Clean Segmented Chips) */}
            <div className="px-3 py-2 bg-[#0C1220] border-t border-b border-[#19243A] flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
              {SUGGESTED_QUESTIONS.map((sug) => (
                <button
                  key={sug.id}
                  type="button"
                  onClick={() => handleSendMessage(sug.query)}
                  className="px-3 py-1.5 rounded-xl bg-[#131B2E] hover:bg-[#1A2640] border border-[#202E4A] hover:border-cyan-500/40 text-slate-300 hover:text-white text-[11px] font-medium whitespace-nowrap transition active:scale-95 cursor-pointer shrink-0 shadow-xs"
                >
                  {sug.label}
                </button>
              ))}
            </div>

            {/* 3. REDESIGNED SCULPTED PREMIUM INPUT BAR & FOOTER */}
            <div className="p-3 sm:p-3.5 bg-[#0D1322] border-t border-[#1C273E] shrink-0 space-y-2">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendMessage();
                }}
                className="relative bg-[#080C16] border border-[#22304A] focus-within:border-cyan-500/80 focus-within:ring-2 focus-within:ring-cyan-500/20 rounded-2xl p-1.5 flex items-center gap-2 shadow-inner transition-all duration-200"
              >
                {/* Single-line polished text input */}
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Ask anything about MyTeleFlix..."
                  className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-[13px] text-white placeholder-slate-500 outline-none font-medium"
                />

                {/* Sleek Action Send Button */}
                <button
                  type="submit"
                  disabled={!inputText.trim() || isLoading}
                  title="Send message"
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-35 disabled:cursor-not-allowed text-white font-bold flex items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shrink-0 shadow-md text-xs"
                >
                  <span>Send</span>
                  <Send size={13} className="stroke-[2.5]" />
                </button>
              </form>

              {/* Privacy & Guardrail Tag */}
              <div className="flex items-center justify-center gap-1.5 text-[10px] font-mono text-slate-400 text-center">
                <ShieldCheck size={11} className="text-emerald-400 shrink-0" />
                <span>24/7 Verified Support Desk · Privacy & Guardrail Protected</span>
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
}
