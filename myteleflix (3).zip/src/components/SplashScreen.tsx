/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Tv, Sparkles } from "lucide-react";

interface SplashScreenProps {
  onFinish: () => void;
  user?: any;
}

export default function SplashScreen({ onFinish }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [isShockwaveExiting, setIsShockwaveExiting] = useState(false);

  useEffect(() => {
    const totalDuration = 2200; // 2.2 seconds fluid load
    const intervalTime = 25;
    const increment = 100 / (totalDuration / intervalTime);
    let exitTimeout1: ReturnType<typeof setTimeout> | null = null;
    let exitTimeout2: ReturnType<typeof setTimeout> | null = null;

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(timer);
          // 1000ms (1s) exit delay so 100% completion animation and glow effect finish naturally
          exitTimeout1 = setTimeout(() => {
            setIsShockwaveExiting(true);
            exitTimeout2 = setTimeout(() => {
              onFinish();
            }, 420);
          }, 1000);
          return 100;
        }
        return next;
      });
    }, intervalTime);

    return () => {
      clearInterval(timer);
      if (exitTimeout1) clearTimeout(exitTimeout1);
      if (exitTimeout2) clearTimeout(exitTimeout2);
    };
  }, [onFinish]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={
        isShockwaveExiting
          ? {
              scale: [1, 1.08, 0.94],
              opacity: [1, 0.95, 0],
              filter: ["brightness(1)", "brightness(1.5)", "brightness(1) blur(4px)"],
              transition: { duration: 0.42, ease: [0.22, 1, 0.36, 1] }
            }
          : { opacity: 1 }
      }
      exit={{ opacity: 0, scale: 1.1, filter: "blur(8px)" }}
      transition={{ duration: 0.35 }}
      className="fixed inset-0 z-[100] bg-[#070709] text-white flex flex-col justify-between items-center p-6 sm:p-8 select-none font-sans overflow-hidden"
    >
      {/* Cinematic Vignette Backdrop */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-80"
        style={{
          background: "radial-gradient(circle at 50% 45%, rgba(16, 185, 129, 0.08) 0%, transparent 60%), radial-gradient(circle at center, transparent 40%, rgba(0, 0, 0, 0.8) 100%)"
        }}
      />

      {/* Dynamic Cinematic Shockwave & Sparkling Starburst that bursts when loading finishes */}
      {isShockwaveExiting && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-40 overflow-hidden">
          {/* Radial Optical Flash */}
          <motion.div
            initial={{ scale: 0.1, opacity: 1 }}
            animate={{ scale: 4.2, opacity: 0 }}
            transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
            className="w-48 h-48 rounded-full bg-emerald-400/30 blur-xl"
          />

          {/* Shockwave Ring 1 */}
          <motion.div
            initial={{ scale: 0.3, opacity: 1 }}
            animate={{ scale: 3.8, opacity: 0 }}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="absolute w-56 h-56 rounded-full border-2 border-emerald-300 shadow-[0_0_50px_rgba(52,211,153,0.9)]"
          />

          {/* Shockwave Ring 2 */}
          <motion.div
            initial={{ scale: 0.2, opacity: 1 }}
            animate={{ scale: 3.2, opacity: 0 }}
            transition={{ duration: 0.4, ease: "easeOut", delay: 0.04 }}
            className="absolute w-56 h-56 rounded-full border border-teal-200 shadow-[0_0_35px_rgba(20,184,166,0.8)]"
          />

          {/* Anamorphic Lens Flare Line */}
          <motion.div
            initial={{ scaleX: 0.1, opacity: 1 }}
            animate={{ scaleX: 3.5, opacity: 0 }}
            transition={{ duration: 0.38, ease: "easeOut" }}
            className="absolute w-full h-[2px] bg-gradient-to-r from-transparent via-white to-transparent shadow-[0_0_15px_#ffffff]"
          />

          {/* Sparkling Orbiting Particles Burst (8 directional stars) */}
          {[0, 45, 90, 135, 180, 225, 270, 315].map((deg, i) => {
            const rad = (deg * Math.PI) / 180;
            const dist = 140;
            const x = Math.cos(rad) * dist;
            const y = Math.sin(rad) * dist;
            return (
              <motion.div
                key={`sparkle-${deg}`}
                initial={{ x: 0, y: 0, scale: 0, opacity: 1, rotate: 0 }}
                animate={{ 
                  x, 
                  y, 
                  scale: [0, 1.4, 0], 
                  opacity: [1, 1, 0], 
                  rotate: deg + 180 
                }}
                transition={{ duration: 0.42, ease: "easeOut", delay: i * 0.015 }}
                className="absolute flex items-center justify-center text-emerald-300"
              >
                <Sparkles size={16} className="text-emerald-300 drop-shadow-[0_0_8px_#6ee7b7]" />
              </motion.div>
            );
          })}
        </div>
      )}

      {/* 1. TOP BAR: SITE NAME (LEFT) + ONLINE STATUS (RIGHT) */}
      <div className="w-full max-w-md flex justify-between items-center text-[10.5px] sm:text-[11.5px] font-mono tracking-widest uppercase font-bold relative z-10 pt-2 px-1">
        {/* Left: Site Brand Name with Mini TV Emblem */}
        <div className="flex items-center gap-2 text-white font-extrabold tracking-wider">
          <div className="p-1 rounded-md bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shadow-sm">
            <Tv size={13} className="shrink-0" />
          </div>
          <span className="text-white text-xs tracking-widest">
            MY <span className="text-emerald-400">TELEFLIX</span>
          </span>
        </div>

        {/* Right: Live ONLINE Status Indicator */}
        <div className="flex items-center gap-1.5 text-slate-300 font-semibold bg-slate-900/90 px-3 py-1 rounded-full border border-slate-700/80 shadow-sm">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
          </span>
          <span className="text-[10px] tracking-wider text-emerald-400 font-bold">ONLINE</span>
        </div>
      </div>

      {/* 2. CENTER: ULTRA-PREMIUM CINEMA RETRO-MODERN TV LOGO & BRAND (Balanced Ratio) */}
      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 sm:space-y-5 relative z-10 my-auto">
        
        {/* Custom High-Craft Television Screen Logo - Slightly scaled down for pristine vertical balance */}
        <motion.div
          initial={{ scale: 0.92, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
          className="relative group flex flex-col items-center justify-center"
        >
          {/* TV Outer Chassis Container */}
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl sm:rounded-3xl bg-gradient-to-b from-[#1C1E24] via-[#121318] to-[#0A0B0E] border-2 border-emerald-500/40 p-2 sm:p-2.5 flex flex-col justify-between shadow-[0_12px_32px_rgba(0,0,0,0.8)] ring-1 ring-white/10">
            
            {/* Top Antennas Stylized Bracket */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex items-center justify-center gap-3.5 pointer-events-none">
              {/* Left Antenna */}
              <div className="w-0.5 h-3.5 bg-gradient-to-t from-slate-400 to-emerald-400 -rotate-[32deg] origin-bottom rounded-full flex flex-col items-center">
                <div className="w-1.5 h-1.5 -mt-0.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#10B981]" />
              </div>
              {/* Center Mount */}
              <div className="w-2 h-1 bg-slate-600 rounded-t-sm" />
              {/* Right Antenna */}
              <div className="w-0.5 h-3.5 bg-gradient-to-t from-slate-400 to-emerald-400 rotate-[32deg] origin-bottom rounded-full flex flex-col items-center">
                <div className="w-1.5 h-1.5 -mt-0.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#10B981]" />
              </div>
            </div>

            {/* Inner Cinema Curved TV Display Screen */}
            <div className="relative flex-1 w-full rounded-xl bg-[#08090C] border border-slate-700/60 overflow-hidden flex flex-col items-center justify-center shadow-inner">
              
              {/* Screen Glass Curve Reflection */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.04] to-emerald-400/10 pointer-events-none" />
              
              {/* Horizontal Subtle Scanline effect */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-20" 
                style={{
                  backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(16,185,129,0.12) 3px)"
                }}
              />

              {/* Centered Cinema Icon inside TV: Play Action Emblem with Smooth Radiance */}
              <div className="relative flex items-center justify-center pt-0">
                {/* Ethereal Broadcast Ripple */}
                <motion.div
                  animate={{ scale: [1, 1.45, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute w-10 h-10 rounded-full border border-emerald-400/40 pointer-events-none"
                />
                
                {/* Secondary Glow Ring */}
                <motion.div
                  animate={{ scale: [1, 1.25, 1], opacity: [0.4, 0.1, 0.4] }}
                  transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
                  className="absolute w-8 h-8 rounded-full bg-emerald-500/20 blur-[2px] pointer-events-none"
                />

                {/* Main Play Action Emblem */}
                <motion.div 
                  animate={{ scale: [1, 1.04, 1] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  className="relative z-10 w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-emerald-400 via-emerald-500 to-teal-700 text-slate-950 flex items-center justify-center shadow-[0_0_18px_rgba(16,185,129,0.7)] border border-emerald-200 cursor-pointer select-none"
                >
                  <svg 
                    viewBox="1.5 0 24 24" 
                    fill="currentColor" 
                    className="w-4 h-4 text-slate-950"
                  >
                    <path d="M8 5.14v13.72a1 1 0 001.5.86l11-6.86a1 1 0 000-1.72l-11-6.86a1 1 0 00-1.5.86z" />
                  </svg>
                </motion.div>
              </div>
            </div>

            {/* TV Bottom Chassis / Stand Plate with Embossed Silver/Neon "My TeleFlix" Branding */}
            <div className="h-3.5 w-full mt-1 px-2 rounded bg-gradient-to-r from-[#0C0E12] via-[#1A1D24] to-[#0C0E12] border-t border-white/10 shadow-inner flex items-center justify-center">
              <span className="text-[7.5px] sm:text-[8px] font-mono font-extrabold tracking-[0.22em] uppercase select-none flex items-center gap-1 drop-shadow-[0_1px_1.5px_rgba(0,0,0,0.9)]">
                <span className="text-slate-200">MY</span>
                <span className="text-emerald-400 drop-shadow-[0_0_6px_rgba(16,185,129,0.6)]">TELEFLIX</span>
              </span>
            </div>

          </div>
        </motion.div>

        {/* Brand Text "My TeleFlix" & Tagline Under TV Logo with Crisp Spacing */}
        <div className="pt-1 space-y-1 max-w-sm mx-auto">
          <motion.h1
            initial={{ y: 6, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.35 }}
            className="text-2xl sm:text-3xl font-black tracking-tight flex items-center justify-center gap-2 leading-none"
          >
            <span className="text-white">My </span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-500 drop-shadow-sm">
              TeleFlix
            </span>
          </motion.h1>

          <motion.p
            initial={{ y: 6, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.25, duration: 0.35 }}
            className="text-[9.5px] sm:text-[10.5px] font-mono font-bold tracking-[0.22em] text-slate-400 uppercase flex items-center justify-center pt-0.5 leading-none"
          >
            <span className="whitespace-nowrap">PREMIUM CINEMA & DRAMA HUB</span>
          </motion.p>
        </div>
      </div>

      {/* 3. BOTTOM: MINIMALIST OTT CINEMA PROGRESS BAR */}
      <div className="w-full max-w-xs sm:max-w-sm mx-auto space-y-2.5 pb-8 sm:pb-10 relative z-10">
        {/* Ultra-slim, elegant progress line (h-1, rounded-full) */}
        <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden relative">
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.05, ease: "linear" }}
            className="h-full rounded-full bg-emerald-500 relative drop-shadow-[0_0_6px_#10B981]"
          >
            {/* Subtle, soft leading light pulse gliding naturally as the bar fills */}
            {progress > 1 && (
              <div className="absolute right-0 top-0 bottom-0 w-2.5 bg-emerald-200 rounded-full shadow-[0_0_8px_#10B981]" />
            )}
          </motion.div>
        </div>

        {/* Organic Faint Status Text & Seamless Percentage Counter */}
        <div className="flex justify-between items-center text-[11px] font-mono px-0.5 pt-0.5">
          <span className="text-slate-400 font-medium tracking-wide flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400/80 animate-pulse shrink-0" />
            Loading Cinema Experience...
          </span>
          <span className="text-emerald-400 font-semibold tracking-wider text-xs">
            {Math.round(progress)}%
          </span>
        </div>
      </div>
    </motion.div>
  );
}
