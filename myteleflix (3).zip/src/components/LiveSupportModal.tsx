/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { default } from "./modals/LiveSupportModal";
export * from "./modals/LiveSupportModal";
