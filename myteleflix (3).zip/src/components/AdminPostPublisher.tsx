/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AdminPostPublisher Component
 * 
 * Hardened Content Post Publisher & Group Pack Architecture.
 * Supports Movies, Adult 18+, Videos, single Natok/Drama, and multi-episode Series / Mega Serials
 * with structured group aggregation tags (series_group_title, season_number, episode_number)
 * and harmonized dubbing & language arrays.
 */

import React, { useState, useEffect } from "react";
import {
  Film,
  Video as VideoIcon,
  Layers,
  Tv,
  Flame,
  Lock,
  Cloud,
  Check,
  FileText,
  Link2,
  Languages,
  Tag,
  Upload,
  Sparkles,
  Zap,
  ImageIcon,
  Database,
  Info,
  FolderPlus
} from "lucide-react";
import { Movie, Video } from "../types";

export interface AdminPostPublisherProps {
  onAddMovie: (m: any) => Promise<void>;
  onAddVideo: (v: any) => Promise<void>;
  editingPost?: Movie | Video | null;
  editingPostId?: string | null;
  onCancelEdit?: () => void;
  showAdminToast?: (msg: string, type?: 'success' | 'error') => void;
  onNavigateToCatalog?: () => void;
  catalogCount?: number;
  uploadFileWithProgress?: (file: File, label: string) => Promise<string>;
  defaultRewardPts?: number;
}

export const normalizeLangKey = (lang: string): string => {
  const l = (lang || '').toLowerCase().trim();
  if (l.includes('bangla') || l.includes('bn')) return 'bangla';
  if (l.includes('hindi') || l.includes('hi')) return 'hindi';
  if (l.includes('english') || l.includes('en')) return 'english';
  if (l.includes('original') || l.includes('org')) return 'original';
  return l || 'original';
};

/**
 * Harmonizes checked language boxes into backend queryable arrays:
 * 1. Movie Tags -> Dubbing Labels
 * 2. Series Tags -> Language / Origin Labels
 * 3. Drama Tags -> Drama Classification Labels
 */
export function harmonizeLanguageTags(
  selectedLangs: string[],
  contentType: 'movie' | 'adult_movie' | 'video' | 'drama' | 'series'
) {
  const normLangs = Array.from(new Set(selectedLangs.map(normalizeLangKey)));
  const activeLangs = normLangs.length > 0 ? normLangs : ['original'];

  const dubbingLabels: string[] = [];
  const languageOriginLabels: string[] = [];
  const dramaClassificationLabels: string[] = [];

  for (const l of activeLangs) {
    if (l === 'original') {
      dubbingLabels.push("Original Audio", "Original");
      languageOriginLabels.push("Original Series", "Original");
      dramaClassificationLabels.push("Original Broadcast", "Original Natok");
    } else if (l === 'bangla') {
      dubbingLabels.push("Bangla Dubbed", "Bangla");
      languageOriginLabels.push("Bangla Web Series", "Bangla");
      dramaClassificationLabels.push("Bangla Natok", "Bangla");
    } else if (l === 'hindi') {
      dubbingLabels.push("Hindi Dubbed", "Hindi");
      languageOriginLabels.push("Hindi Web Series", "Hindi");
      dramaClassificationLabels.push("Hindi Dubbed", "Hindi");
    } else if (l === 'english') {
      dubbingLabels.push("English Dubbed", "English");
      languageOriginLabels.push("English Series", "English");
      dramaClassificationLabels.push("English Sub/Dub", "English");
    }
  }

  return {
    activeLangs,
    dubbingLabels: Array.from(new Set(dubbingLabels)),
    languageOriginLabels: Array.from(new Set(languageOriginLabels)),
    dramaClassificationLabels: Array.from(new Set(dramaClassificationLabels)),
  };
}

export const AdminPostPublisher: React.FC<AdminPostPublisherProps> = ({
  onAddMovie,
  onAddVideo,
  editingPost,
  editingPostId,
  onCancelEdit,
  showAdminToast,
  onNavigateToCatalog,
  catalogCount = 0,
  uploadFileWithProgress,
  defaultRewardPts = 500,
}) => {
  // Release format state
  const [postContentType, setPostContentType] = useState<'movie' | 'adult_movie' | 'video' | 'drama' | 'series'>('movie');
  const [isAdultUnlocked, setIsAdultUnlocked] = useState(false);

  // Common core fields
  const [postTitle, setPostTitle] = useState('');
  const [postGenre, setPostGenre] = useState('Cinema Release');
  const [postCategory, setPostCategory] = useState<string>('Deshi');
  const [postRating, setPostRating] = useState('8.8');
  const [postDescription, setPostDescription] = useState('');
  const [postDuration, setPostDuration] = useState('2h 15m');
  const [postAttachmentUrl, setPostAttachmentUrl] = useState('');
  const [postDestinationLink, setPostDestinationLink] = useState('');

  // Structured Series & Group Pack Architecture Fields
  const [seriesGroupTitle, setSeriesGroupTitle] = useState('');
  const [seasonNumber, setSeasonNumber] = useState('');
  const [episodeNumber, setEpisodeNumber] = useState('');
  const [postTotalEpisodes, setPostTotalEpisodes] = useState('Season 1 • Full Pack');

  // Multi-link & Dubbing links
  const [postLanguages, setPostLanguages] = useState<string[]>(['original']);
  const [postBanglaLink, setPostBanglaLink] = useState('');
  const [postHindiLink, setPostHindiLink] = useState('');
  const [postEnglishLink, setPostEnglishLink] = useState('');
  const [postOriginalLink, setPostOriginalLink] = useState('');
  const [postTutorialVideoUrl, setPostTutorialVideoUrl] = useState('');
  const [postAudioUrl, setPostAudioUrl] = useState('');

  // UI state
  const [postPublishing, setPostPublishing] = useState(false);
  const [posterInputKey, setPosterInputKey] = useState(0);

  // Synchronize when editingPost prop changes
  useEffect(() => {
    if (editingPost) {
      const p = editingPost as any;
      const targetType = (p.contentType || (p.category === 'Adult Movies' ? 'adult_movie' : 'movie')) as 'movie' | 'adult_movie' | 'video' | 'drama' | 'series';
      setPostContentType(targetType);
      if (targetType === 'adult_movie') {
        setIsAdultUnlocked(true);
      }
      setPostTitle(p.title || '');
      setPostGenre(p.genre || (targetType === 'drama' ? 'Bangla Natok' : targetType === 'series' ? 'Web Series' : targetType === 'adult_movie' ? 'Adult 18+' : 'Cinema Release'));
      setPostCategory(p.category || 'Deshi');
      setPostRating(String(p.rating || (targetType === 'video' ? 8.5 : 8.8)));
      setPostDescription(p.description || '');
      setPostDuration(p.duration || (targetType === 'drama' ? '45m' : targetType === 'series' ? '25m/Ep' : targetType === 'adult_movie' ? '1h 35m' : targetType === 'video' ? '3m 45s' : '2h 15m'));
      
      // Structured Series & Group Pack fields
      setSeriesGroupTitle(p.groupTitle || p.series_group_title || '');
      setSeasonNumber(p.season !== undefined ? String(p.season) : (p.season_number !== undefined ? String(p.season_number) : ''));
      setEpisodeNumber(p.episode !== undefined ? String(p.episode) : (p.episode_number !== undefined ? String(p.episode_number) : ''));
      setPostTotalEpisodes(p.totalEpisodes || 'Season 1 • Full Pack');

      setPostAttachmentUrl(p.thumbnailUrl || '');
      setPostDestinationLink(p.videoUrl || '');
      setPostTutorialVideoUrl(p.tutorialVideoUrl || '');
      setPostAudioUrl(p.audioUrl || '');
      
      if (Array.isArray(p.languages) && p.languages.length > 0) {
        setPostLanguages(p.languages.map(normalizeLangKey));
      } else {
        setPostLanguages(['original']);
      }

      setPostBanglaLink(p.banglaLink || '');
      setPostHindiLink(p.hindiLink || '');
      setPostEnglishLink(p.englishLink || '');
      setPostOriginalLink(p.originalLink || '');
    }
  }, [editingPost]);

  // Auto-compose totalEpisodes tag when seasonNumber or episodeNumber updates if in series mode
  useEffect(() => {
    if (postContentType === 'series') {
      const s = seasonNumber.trim();
      const ep = episodeNumber.trim();
      if (s && ep) {
        setPostTotalEpisodes(`${s.toLowerCase().startsWith('season') || s.toLowerCase().startsWith('s') ? s : `Season ${s}`} • ${ep.toLowerCase().startsWith('ep') ? ep : `Episode ${ep}`}`);
      } else if (s) {
        setPostTotalEpisodes(`${s.toLowerCase().startsWith('season') || s.toLowerCase().startsWith('s') ? s : `Season ${s}`} • Full Pack`);
      } else if (ep) {
        setPostTotalEpisodes(`Episode ${ep}`);
      }
    }
  }, [seasonNumber, episodeNumber, postContentType]);

  const toggleLanguage = (langKey: string) => {
    const normKey = normalizeLangKey(langKey);
    setPostLanguages(prev => {
      const currentNorms = Array.from(new Set(prev.map(normalizeLangKey)));
      if (currentNorms.includes(normKey)) {
        const remaining = currentNorms.filter(l => l !== normKey);
        return remaining.length > 0 ? remaining : ['original'];
      } else {
        return [...currentNorms, normKey];
      }
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (uploadFileWithProgress) {
      try {
        const url = await uploadFileWithProgress(file, "Poster Image");
        setPostAttachmentUrl(url);
      } catch (err: any) {
        if (showAdminToast) showAdminToast("Upload failed: " + (err.message || "Network error"), 'error');
        else alert("Upload failed: " + err.message);
      }
    } else {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPostAttachmentUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetForm = () => {
    if (onCancelEdit) {
      onCancelEdit();
    }
    setPostTitle('');
    setPostGenre('Cinema Release');
    setPostCategory('Deshi');
    setPostRating('8.8');
    setPostDescription('');
    setPostDuration('2h 15m');
    setSeriesGroupTitle('');
    setSeasonNumber('');
    setEpisodeNumber('');
    setPostTotalEpisodes('Season 1 • Full Pack');
    setPostAttachmentUrl('');
    setPostTutorialVideoUrl('');
    setPostAudioUrl('');
    setPostLanguages(['original']);
    setPostDestinationLink('');
    setPostBanglaLink('');
    setPostHindiLink('');
    setPostEnglishLink('');
    setPostOriginalLink('');
    setPosterInputKey(prev => prev + 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalPrimaryLink =
      postDestinationLink.trim() ||
      postBanglaLink.trim() ||
      postHindiLink.trim() ||
      postEnglishLink.trim() ||
      postOriginalLink.trim();

    if (!postTitle.trim() || !finalPrimaryLink) {
      const msg = "Please enter title and at least one destination/dub stream link.";
      if (showAdminToast) showAdminToast(msg, 'error');
      else alert(msg);
      return;
    }

    setPostPublishing(true);
    try {
      const rewardPts = defaultRewardPts || 500;
      const defaultThumb =
        postContentType === 'video'
          ? "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&h=450&q=80"
          : postContentType === 'drama'
          ? "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&h=1200&q=80"
          : postContentType === 'series'
          ? "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=1200&q=80"
          : postContentType === 'adult_movie'
          ? "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=800&h=1200&q=80"
          : "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=800&h=1200&q=80";

      const thumb = postAttachmentUrl.trim() || defaultThumb;
      const numericRating = parseFloat(postRating) || 8.8;

      // Harmonize dubbing & language tag arrays
      const {
        activeLangs,
        dubbingLabels,
        languageOriginLabels,
        dramaClassificationLabels,
      } = harmonizeLanguageTags(postLanguages, postContentType);

      if (postContentType === 'video') {
        const payload: any = {
          title: postTitle.trim(),
          description: postDescription.trim() || "Ad-Reward video clip release.",
          thumbnailUrl: thumb,
          videoUrl: postDestinationLink.trim() || finalPrimaryLink,
          duration: postDuration.trim() || "3m 45s",
          genre: postGenre.trim() || "Clip Release",
          category: postCategory || 'Deshi',
          contentType: 'video',
          rating: numericRating,
          isFree: true,
          requiredPoints: rewardPts,
          groupTitle: seriesGroupTitle.trim() || undefined,
          series_group_title: seriesGroupTitle.trim() || undefined,
          season: seasonNumber.trim() || undefined,
          season_number: seasonNumber.trim() || undefined,
          episode: episodeNumber.trim() || undefined,
          episode_number: episodeNumber.trim() || undefined,
          languages: activeLangs,
          dubbingLabels,
          dubbing_labels: dubbingLabels,
          tutorialVideoUrl: postTutorialVideoUrl.trim() || undefined,
          audioUrl: postAudioUrl.trim() || undefined,
          banglaLink: postBanglaLink.trim() || undefined,
          hindiLink: postHindiLink.trim() || undefined,
          englishLink: postEnglishLink.trim() || undefined,
          originalLink: postOriginalLink.trim() || undefined,
          createdAt: editingPostId ? undefined : new Date().toISOString(),
        };
        if (editingPostId) {
          payload.id = editingPostId;
        }
        await onAddVideo(payload);
      } else {
        // movie, adult_movie, drama, series
        const defaultGenre =
          postContentType === 'drama'
            ? 'Bangla Natok'
            : postContentType === 'series'
            ? 'Web Series'
            : postContentType === 'adult_movie'
            ? 'Adult 18+'
            : 'Cinema Release';

        const defaultDuration =
          postContentType === 'drama'
            ? '45m'
            : postContentType === 'series'
            ? '25m/Ep'
            : postContentType === 'adult_movie'
            ? '1h 35m'
            : '2h 15m';

        const defaultDesc =
          postContentType === 'drama'
            ? 'HD Bangla Natok & Telefilm special release.'
            : postContentType === 'series'
            ? 'Full season web series release.'
            : postContentType === 'adult_movie'
            ? '18+ Adult Movie exclusive release.'
            : 'Ad-Reward HD movie release.';

        const cleanGroup = seriesGroupTitle.trim();
        const cleanSeason = seasonNumber.trim();
        const cleanEpisode = episodeNumber.trim();

        // Calculate combined totalEpisodes display label
        let finalEpisodesTag: string | undefined = undefined;
        if (postContentType === 'series' || cleanGroup || cleanSeason || cleanEpisode) {
          finalEpisodesTag = postTotalEpisodes.trim() || (cleanSeason && cleanEpisode ? `${cleanSeason} • ${cleanEpisode}` : 'Season 1 • Full Pack');
        }

        const payload: any = {
          title: postTitle.trim(),
          description: postDescription.trim() || defaultDesc,
          thumbnailUrl: thumb,
          videoUrl: finalPrimaryLink,
          genre: postGenre.trim() || defaultGenre,
          category: postContentType === 'adult_movie' ? 'Adult Movies' : undefined,
          contentType: postContentType,
          duration: postDuration.trim() || defaultDuration,
          
          // Group Pack Metadata
          groupTitle: cleanGroup || undefined,
          series_group_title: cleanGroup || undefined,
          season: cleanSeason || undefined,
          season_number: cleanSeason || undefined,
          episode: cleanEpisode || undefined,
          episode_number: cleanEpisode || undefined,
          totalEpisodes: finalEpisodesTag,

          releaseYear: 2026,
          rating: numericRating,
          isFree: true,
          requiredPoints: rewardPts,

          // Harmonized queryable arrays
          languages: activeLangs,
          dubbingLabels,
          dubbing_labels: dubbingLabels,
          languageOriginLabels,
          language_origin_labels: languageOriginLabels,
          dramaClassificationLabels,
          drama_classification_labels: dramaClassificationLabels,

          tutorialVideoUrl: postTutorialVideoUrl.trim() || undefined,
          audioUrl: postAudioUrl.trim() || undefined,
          banglaLink: postBanglaLink.trim() || undefined,
          hindiLink: postHindiLink.trim() || undefined,
          englishLink: postEnglishLink.trim() || undefined,
          originalLink: postOriginalLink.trim() || undefined,
          createdAt: editingPostId ? undefined : new Date().toISOString(),
        };

        if (editingPostId) {
          payload.id = editingPostId;
        }
        await onAddMovie(payload);
      }

      const successMsg = editingPostId
        ? "✓ পোস্ট সফলভাবে আপডেট করা হয়েছে!"
        : "✓ নতুন পোস্ট সফলভাবে পাবলিশ হয়েছে!";
      if (showAdminToast) {
        showAdminToast(successMsg, 'success');
      } else {
        alert(successMsg);
      }
      handleResetForm();
    } catch (err: any) {
      const errMsg = "পোস্ট ব্যর্থ হয়েছে: " + (err.message || "Server error");
      if (showAdminToast) {
        showAdminToast(errMsg, 'error');
      } else {
        alert(errMsg);
      }
    } finally {
      setPostPublishing(false);
    }
  };

  return (
    <div id="admin-post-publisher-root" className="space-y-5 sm:space-y-6 animate-in fade-in duration-300">
      {/* Post Publisher Card */}
      <div className="bg-slate-900/95 backdrop-blur-xl border border-slate-800/90 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-2xl space-y-4 sm:space-y-5 text-slate-100 relative overflow-hidden">
        {/* Form Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800/80 pb-3 sm:pb-4 gap-2 sm:gap-3 relative z-10">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="p-2 sm:p-2.5 bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 rounded-xl shrink-0 shadow-md">
              <Zap size={18} className="text-indigo-400" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider font-mono flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <span className="truncate">{editingPostId ? "Edit Release Entry" : "Post Publisher"}</span>
                <span className="text-[9px] bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full font-mono whitespace-nowrap font-bold">
                  {postContentType === 'movie'
                    ? 'Movie Post'
                    : postContentType === 'adult_movie'
                    ? 'Adult Movies (18+)'
                    : postContentType === 'video'
                    ? 'Video Post'
                    : postContentType === 'drama'
                    ? 'Drama Post'
                    : 'Series Group Pack'}
                </span>
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans mt-0.5 line-clamp-1 sm:line-clamp-none">
                {postContentType === 'movie'
                  ? 'Publish full cinema & blockbuster movie release with dubbing tags.'
                  : postContentType === 'adult_movie'
                  ? 'Publish 18+ adult movie release with private lock.'
                  : postContentType === 'video'
                  ? 'Publish short viral clips & reels with category tags.'
                  : postContentType === 'drama'
                  ? 'Publish single telefilms & Bangla natok releases.'
                  : 'Publish multi-episode web series, serial seasons, and Bachelor Point group packs.'}
              </p>
            </div>
          </div>

          {editingPostId && (
            <button
              type="button"
              id="admin-publisher-cancel-edit-btn"
              onClick={handleResetForm}
              className="w-full sm:w-auto px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-bold transition border border-slate-700 cursor-pointer shrink-0 text-center whitespace-nowrap"
            >
              Cancel Edit
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 relative z-10">
          {/* Release Format Selector */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3 sm:p-4">
            <label className="text-[10px] sm:text-[11px] text-slate-400 uppercase font-mono font-bold block mb-2 whitespace-nowrap">
              Select Post Type
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 sm:gap-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800">
              {/* Option 1: Movie */}
              <button
                type="button"
                id="publisher-type-movie"
                onClick={() => {
                  setPostContentType('movie');
                  if (!editingPostId) setPostGenre('Cinema Release');
                }}
                className={`py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-bold font-mono transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap border ${
                  postContentType === 'movie'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border-transparent'
                }`}
              >
                <Film size={13} className="shrink-0" />
                <span className="truncate">Movie</span>
              </button>

              {/* Option 2: Series */}
              <button
                type="button"
                id="publisher-type-series"
                onClick={() => {
                  setPostContentType('series');
                  if (!editingPostId) {
                    setPostGenre('Web Series');
                    setPostDuration('25m/Ep');
                    if (!seriesGroupTitle) setSeriesGroupTitle('Bachelor Point');
                    if (!seasonNumber) setSeasonNumber('Season 4');
                    if (!episodeNumber) setEpisodeNumber('Episode 1');
                    setPostTotalEpisodes('Season 4 • Episode 1');
                  }
                }}
                className={`py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-bold font-mono transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap border ${
                  postContentType === 'series'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border-transparent'
                }`}
              >
                <Layers size={13} className="shrink-0" />
                <span className="truncate">Series</span>
              </button>

              {/* Option 3: Video */}
              <button
                type="button"
                id="publisher-type-video"
                onClick={() => {
                  setPostContentType('video');
                  if (!editingPostId) setPostGenre('Clip Release');
                }}
                className={`py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-bold font-mono transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap border ${
                  postContentType === 'video'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border-transparent'
                }`}
              >
                <VideoIcon size={13} className="shrink-0" />
                <span className="truncate">Video</span>
              </button>

              {/* Option 4: Drama */}
              <button
                type="button"
                id="publisher-type-drama"
                onClick={() => {
                  setPostContentType('drama');
                  if (!editingPostId) {
                    setPostGenre('Bangla Natok');
                    setPostDuration('45m');
                  }
                }}
                className={`py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-bold font-mono transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap border ${
                  postContentType === 'drama'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 border-indigo-400/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border-transparent'
                }`}
              >
                <Tv size={13} className="shrink-0" />
                <span className="truncate">Drama</span>
              </button>

              {/* Option 5: Adult 18+ */}
              {!isAdultUnlocked ? (
                <button
                  type="button"
                  id="publisher-type-adult-locked"
                  onClick={() => {
                    setIsAdultUnlocked(true);
                    setPostContentType('adult_movie');
                    if (!editingPostId) {
                      setPostGenre('Adult 18+');
                      setPostDuration('1h 35m');
                    }
                  }}
                  title="Click to Unlock 18+"
                  className="py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-mono col-span-2 sm:col-span-1 bg-white/10 backdrop-blur-xl border border-white/20 shadow-inner cursor-pointer relative overflow-hidden flex items-center justify-center gap-1.5 transition-all duration-300 ease-in-out active:scale-95 hover:bg-white/15 hover:border-white/30 select-none group"
                >
                  <Flame size={13} className="shrink-0 text-white/30 blur-[4px]" />
                  <span className="truncate blur-[6px] select-none text-white/30 font-medium">Adult 18+</span>
                  <div className="absolute inset-0 z-20 flex items-center justify-center pointer-events-none bg-black/10">
                    <div className="flex items-center gap-1.5 text-white font-bold tracking-wider text-[11px] sm:text-xs drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                      <Lock size={13} className="shrink-0 text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]" />
                      <span>UNLOCK</span>
                    </div>
                  </div>
                </button>
              ) : (
                <button
                  type="button"
                  id="publisher-type-adult-unlocked"
                  onClick={() => {
                    setPostContentType('adult_movie');
                    if (!editingPostId) {
                      setPostGenre('Adult 18+');
                      setPostDuration('1h 35m');
                    }
                  }}
                  className={`py-2 sm:py-2.5 px-2 rounded-lg text-[11px] sm:text-xs font-bold font-mono transition-all duration-500 ease-in-out flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap col-span-2 sm:col-span-1 border ${
                    postContentType === 'adult_movie'
                      ? 'border-rose-500 bg-rose-500/20 text-rose-400 font-bold shadow-md shadow-rose-900/30'
                      : 'text-slate-400 hover:text-rose-300 hover:bg-rose-950/30 border-rose-900/30'
                  }`}
                >
                  <Flame size={13} className="shrink-0 text-rose-400" />
                  <span className="truncate">Adult 18+</span>
                </button>
              )}
            </div>
          </div>

          {/* POST TYPE SPECIFIC FORM */}
          {postContentType !== 'video' ? (
            /* UNIFIED POSTER CONTENT FORMAT (Movie / Adult 18+ / Drama / Series) */
            <div className="space-y-3.5 sm:space-y-4">
              {/* Field 1: Poster Image URL */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 whitespace-nowrap">
                    <ImageIcon size={12} className="text-indigo-400 shrink-0" /> 1) Poster Image URL (Vertical 2:3)
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-emerald-400 font-mono flex items-center gap-1">
                    <Cloud size={10} /> Cloud CDN / URL / Upload
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    id="publisher-poster-url"
                    placeholder="https://firebasestorage... or https://cdn... or /uploads/poster.png"
                    value={postAttachmentUrl}
                    onChange={(e) => setPostAttachmentUrl(e.target.value)}
                    className="flex-1 min-w-0 bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 font-mono outline-none transition placeholder-slate-600"
                  />
                  <label className="px-3 sm:px-3.5 py-2 sm:py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shrink-0 border border-indigo-500/40 shadow-sm whitespace-nowrap min-h-[38px]">
                    <Cloud size={13} />
                    <span className="hidden xs:inline">Cloud Upload</span>
                    <input
                      key={`movie-poster-input-${posterInputKey}`}
                      type="file"
                      accept="image/*"
                      onClick={(e) => {
                        (e.currentTarget as HTMLInputElement).value = '';
                      }}
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {postAttachmentUrl && (
                  <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center gap-2.5 sm:gap-3">
                    <div className="w-10 h-14 sm:w-12 sm:h-16 bg-slate-950 rounded-lg overflow-hidden border border-slate-800 shrink-0">
                      <img
                        src={postAttachmentUrl}
                        alt="Poster Preview"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=400&h=600&q=80";
                        }}
                        className="w-full h-full object-cover contrast-105 saturate-110 drop-shadow-md"
                      />
                    </div>
                    <div className="text-[10px] sm:text-[11px] text-slate-300 space-y-0.5 min-w-0">
                      <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
                        <Check size={12} /> Poster Active
                      </span>
                      <p className="text-[9px] sm:text-[10px] text-slate-500 font-mono truncate">{postAttachmentUrl}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Field 2: Content Title */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 whitespace-nowrap">
                    <FileText size={12} className="text-indigo-400 shrink-0" />
                    <span>
                      2) {postContentType === 'adult_movie'
                        ? 'Adult Movie Title (18+)'
                        : postContentType === 'drama'
                        ? 'Drama / Natok Title'
                        : postContentType === 'series'
                        ? 'Web Series Episode / Pack Title'
                        : 'Movie Title'} *
                    </span>
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-slate-400 font-mono whitespace-nowrap">Required</span>
                </label>
                <input
                  type="text"
                  id="publisher-content-title"
                  placeholder={
                    postContentType === 'adult_movie'
                      ? "e.g. Midnight Romance (18+) or Wild Heart HD 1080p"
                      : postContentType === 'drama'
                      ? "e.g. Buker Dak Bangla Natok (2025) or Shomoy Telefilm"
                      : postContentType === 'series'
                      ? "e.g. Bachelor Point Season 4 Episode 12 or Sacred Games S02"
                      : "e.g. Pushpa 2: The Rule HD (2025) or Inception 1080p"
                  }
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none transition font-medium"
                  required
                />
              </div>

              {/* Structured Series & Group Pack Architecture Inputs (Prominently rendered for Series & Mega Serials) */}
              {(postContentType === 'series' || postContentType === 'drama' || Boolean(seriesGroupTitle)) && (
                <div className="bg-indigo-950/30 border border-indigo-500/30 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-3 relative overflow-hidden">
                  <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
                    <div className="flex items-center gap-2">
                      <FolderPlus size={14} className="text-indigo-400" />
                      <span className="text-[11px] sm:text-xs font-mono font-bold text-indigo-200 uppercase tracking-wide">
                        Series & Group Pack Aggregation (Mega Serials)
                      </span>
                    </div>
                    <span className="text-[8px] sm:text-[9px] bg-indigo-500/20 text-indigo-300 font-mono px-2 py-0.5 rounded-full border border-indigo-500/30">
                      Multi-Episode Architecture
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-400 font-sans">
                    Assign a <strong>Group Title</strong> to aggregate multiple individual episodes under a single master card (e.g. "Bachelor Point"), with season and episode numbers for seamless frontend filtering.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
                    {/* Field: series_group_title */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono font-bold text-slate-300 uppercase flex items-center gap-1">
                        <span>Group / Series Master Title</span>
                        <span className="text-indigo-400 font-normal">(series_group_title)</span>
                      </label>
                      <input
                        type="text"
                        id="publisher-series-group-title"
                        placeholder="e.g. Bachelor Point or Mirzapur"
                        value={seriesGroupTitle}
                        onChange={(e) => setSeriesGroupTitle(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700/80 focus:border-indigo-400 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 font-mono outline-none transition"
                      />
                    </div>

                    {/* Field: season_number */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono font-bold text-slate-300 uppercase flex items-center gap-1">
                        <span>Season</span>
                        <span className="text-indigo-400 font-normal">(season_number)</span>
                      </label>
                      <input
                        type="text"
                        id="publisher-season-number"
                        placeholder="e.g. Season 4, S04, or 4"
                        value={seasonNumber}
                        onChange={(e) => setSeasonNumber(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700/80 focus:border-indigo-400 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 font-mono outline-none transition"
                      />
                    </div>

                    {/* Field: episode_number */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-mono font-bold text-slate-300 uppercase flex items-center gap-1">
                        <span>Episode</span>
                        <span className="text-indigo-400 font-normal">(episode_number)</span>
                      </label>
                      <input
                        type="text"
                        id="publisher-episode-number"
                        placeholder="e.g. Episode 12, Ep 1, or Full Pack"
                        value={episodeNumber}
                        onChange={(e) => setEpisodeNumber(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700/80 focus:border-indigo-400 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 font-mono outline-none transition"
                      />
                    </div>
                  </div>

                  {/* Combined Card Label */}
                  <div className="pt-2 border-t border-indigo-500/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[10px] font-mono">
                    <span className="text-slate-400 flex items-center gap-1">
                      <Info size={11} className="text-indigo-400 shrink-0" />
                      Composite Badge:
                    </span>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        id="publisher-total-episodes"
                        placeholder="e.g. Season 4 • Episode 12 or Complete Season"
                        value={postTotalEpisodes}
                        onChange={(e) => setPostTotalEpisodes(e.target.value)}
                        className="bg-slate-900/90 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-indigo-200 font-mono focus:border-indigo-400 outline-none"
                      />
                      <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded font-bold border border-indigo-500/30 whitespace-nowrap">
                        Tag Badge Preview
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Field 3: Master Target Link */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-emerald-400 whitespace-nowrap">
                    <Link2 size={12} className="shrink-0" /> 3) Main Download / Stream Link 🔗 *
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-emerald-400 font-mono flex items-center gap-1 whitespace-nowrap">
                    <Cloud size={10} /> Cloud CDN / HLS / MP4
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    id="publisher-destination-link"
                    placeholder="Paste Cloud CDN, HLS .m3u8, direct MP4, or Telegram Bot link..."
                    value={postDestinationLink}
                    onChange={(e) => setPostDestinationLink(e.target.value)}
                    className="flex-1 min-w-0 bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 font-mono outline-none transition placeholder-slate-600"
                    required
                  />
                  {uploadFileWithProgress && (
                    <label className="px-3 sm:px-3.5 py-2 sm:py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shrink-0 border border-slate-700 whitespace-nowrap min-h-[38px]">
                      <Upload size={13} />
                      <span className="hidden xs:inline">Upload Video</span>
                      <input
                        type="file"
                        accept="video/*"
                        onClick={(e) => {
                          (e.currentTarget as HTMLInputElement).value = '';
                        }}
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            const url = await uploadFileWithProgress(file, "Feature Video");
                            setPostDestinationLink(url);
                          } catch (err: any) {
                            alert("Video upload failed: " + (err.message || "Unknown error"));
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>

              {/* Field 4: Dubbing & Language Tag Harmonization */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center gap-1.5 whitespace-nowrap">
                    <Languages size={12} className="text-indigo-400 shrink-0" />
                    <span>
                      4) {postContentType === 'series'
                        ? 'Language / Origin Labels'
                        : postContentType === 'drama'
                        ? 'Drama Classification Labels'
                        : 'Dubbing & Audio Labels'}
                    </span>
                  </label>
                  <span className="text-[8px] sm:text-[9px] text-indigo-400 font-mono whitespace-nowrap">
                    Auto-Mapped to Queryable Arrays
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 sm:gap-2">
                  {/* Original Tag */}
                  <button
                    type="button"
                    id="publisher-lang-original"
                    onClick={() => toggleLanguage('original')}
                    className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between select-none text-left ${
                      postLanguages.map(normalizeLangKey).includes('original')
                        ? "bg-indigo-950/60 border-indigo-500 text-indigo-100 shadow-md shadow-indigo-950/50"
                        : "bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <input
                        type="checkbox"
                        checked={postLanguages.map(normalizeLangKey).includes('original')}
                        readOnly
                        className="rounded border-indigo-500 text-indigo-600 focus:ring-indigo-500 cursor-pointer pointer-events-none shrink-0"
                      />
                      <span className="text-[11px] sm:text-xs font-bold font-mono whitespace-nowrap">Original</span>
                    </div>
                    <span className="text-[7px] sm:text-[8px] bg-indigo-500/20 text-indigo-300 px-1 py-0.5 rounded font-mono font-bold shrink-0">
                      {postContentType === 'drama' ? 'Broadcast' : postContentType === 'series' ? 'Origin' : 'Audio'}
                    </span>
                  </button>

                  {/* Bangla Tag */}
                  <button
                    type="button"
                    id="publisher-lang-bangla"
                    onClick={() => toggleLanguage('bangla')}
                    className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between select-none text-left ${
                      postLanguages.map(normalizeLangKey).includes('bangla')
                        ? "bg-emerald-950/60 border-emerald-500 text-emerald-100 shadow-md shadow-emerald-950/50"
                        : "bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <input
                        type="checkbox"
                        checked={postLanguages.map(normalizeLangKey).includes('bangla')}
                        readOnly
                        className="rounded border-emerald-500 text-emerald-600 focus:ring-emerald-500 cursor-pointer pointer-events-none shrink-0"
                      />
                      <span className="text-[11px] sm:text-xs font-bold font-mono whitespace-nowrap">Bangla</span>
                    </div>
                    <span className="text-[7px] sm:text-[8px] bg-emerald-500/20 text-emerald-300 px-1 py-0.5 rounded font-mono font-bold shrink-0">
                      {postContentType === 'drama' ? 'Natok' : postContentType === 'series' ? 'Series' : 'Dub'}
                    </span>
                  </button>

                  {/* Hindi Tag */}
                  <button
                    type="button"
                    id="publisher-lang-hindi"
                    onClick={() => toggleLanguage('hindi')}
                    className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between select-none text-left ${
                      postLanguages.map(normalizeLangKey).includes('hindi')
                        ? "bg-amber-950/60 border-amber-500 text-amber-100 shadow-md shadow-amber-950/50"
                        : "bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <input
                        type="checkbox"
                        checked={postLanguages.map(normalizeLangKey).includes('hindi')}
                        readOnly
                        className="rounded border-amber-500 text-amber-600 focus:ring-amber-500 cursor-pointer pointer-events-none shrink-0"
                      />
                      <span className="text-[11px] sm:text-xs font-bold font-mono whitespace-nowrap">Hindi</span>
                    </div>
                    <span className="text-[7px] sm:text-[8px] bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded font-mono font-bold shrink-0">
                      {postContentType === 'series' ? 'Web Series' : 'Dub'}
                    </span>
                  </button>

                  {/* English Tag */}
                  <button
                    type="button"
                    id="publisher-lang-english"
                    onClick={() => toggleLanguage('english')}
                    className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between select-none text-left ${
                      postLanguages.map(normalizeLangKey).includes('english')
                        ? "bg-indigo-950/60 border-indigo-500 text-indigo-100 shadow-md shadow-indigo-950/50"
                        : "bg-slate-900/50 border-slate-800 text-slate-400 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 min-w-0">
                      <input
                        type="checkbox"
                        checked={postLanguages.map(normalizeLangKey).includes('english')}
                        readOnly
                        className="rounded border-indigo-500 text-indigo-600 focus:ring-indigo-500 cursor-pointer pointer-events-none shrink-0"
                      />
                      <span className="text-[11px] sm:text-xs font-bold font-mono whitespace-nowrap">English</span>
                    </div>
                    <span className="text-[7px] sm:text-[8px] bg-indigo-500/20 text-indigo-300 px-1 py-0.5 rounded font-mono font-bold shrink-0">
                      {postContentType === 'series' ? 'English' : 'Dub'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* VIDEO CLIP FORMAT */
            <div className="space-y-3.5 sm:space-y-4">
              {/* Field 1: Video Title */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 whitespace-nowrap">
                    <FileText size={12} className="text-indigo-400 shrink-0" /> 1) Video Title *
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-slate-400 font-mono whitespace-nowrap">Required</span>
                </label>
                <input
                  type="text"
                  id="publisher-video-title"
                  placeholder="e.g. Viral Action Scene 1080p HD"
                  value={postTitle}
                  onChange={(e) => setPostTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-none transition font-medium"
                  required
                />
              </div>

              {/* Field 2: Poster / Thumbnail URL */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 whitespace-nowrap">
                    <ImageIcon size={12} className="text-indigo-400 shrink-0" /> 2) Thumbnail URL
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-emerald-400 font-mono flex items-center gap-1">
                    <Cloud size={10} /> Cloud CDN / URL / Upload
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    id="publisher-video-thumb"
                    placeholder="https://firebasestorage... or https://cdn... or /uploads/thumb.jpg"
                    value={postAttachmentUrl}
                    onChange={(e) => setPostAttachmentUrl(e.target.value)}
                    className="flex-1 min-w-0 bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 font-mono outline-none transition placeholder-slate-600"
                  />
                  <label className="px-3 sm:px-3.5 py-2 sm:py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shrink-0 border border-indigo-500/40 shadow-sm whitespace-nowrap min-h-[38px]">
                    <Cloud size={13} />
                    <span className="hidden xs:inline">Cloud Upload</span>
                    <input
                      key={`video-thumb-input-${posterInputKey}`}
                      type="file"
                      accept="image/*"
                      onClick={(e) => {
                        (e.currentTarget as HTMLInputElement).value = '';
                      }}
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>

                {postAttachmentUrl && (
                  <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center gap-2.5 sm:gap-3">
                    <div className="w-14 h-10 sm:w-16 sm:h-12 bg-slate-950 rounded-lg overflow-hidden border border-slate-800 shrink-0">
                      <img
                        src={postAttachmentUrl}
                        alt="Thumbnail Preview"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=400&h=300&q=80";
                        }}
                        className="w-full h-full object-cover contrast-105 saturate-110 drop-shadow-md"
                      />
                    </div>
                    <div className="text-[10px] sm:text-[11px] text-slate-300 space-y-0.5 min-w-0">
                      <span className="text-emerald-400 font-mono font-bold flex items-center gap-1">
                        <Check size={12} /> Thumbnail Active
                      </span>
                      <p className="text-[9px] sm:text-[10px] text-slate-500 font-mono truncate">{postAttachmentUrl}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Field 3: Video Category Selection */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-indigo-400 whitespace-nowrap">
                    <Tag size={12} className="shrink-0" /> 3) Video Category *
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-slate-400 font-mono whitespace-nowrap">Filter Tag</span>
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                  {[
                    { id: 'All', label: 'All (সব)' },
                    { id: 'Deshi', label: 'Deshi (দেশি)' },
                    { id: 'Indian', label: 'Indian (ইন্ডিয়ান)' },
                    { id: 'Russian', label: 'Russian (রাশিয়ান)' },
                    { id: 'Pakistani', label: 'Pakistani (পাকিস্তানি)' },
                    { id: 'English', label: 'English (ইংলিশ)' },
                  ].map((cat) => {
                    const isSelected = (postCategory || 'Deshi') === cat.id;
                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setPostCategory(cat.id)}
                        className={`py-2 px-2 rounded-xl text-[10px] sm:text-[11px] font-bold font-mono transition-all cursor-pointer flex flex-col items-center justify-center text-center border ${
                          isSelected
                            ? 'bg-indigo-600 border-indigo-400/60 text-white shadow-md shadow-indigo-600/30'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                        }`}
                      >
                        <span className="truncate w-full">{cat.id}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Field 4: Direct Video Link */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4 space-y-2">
                <label className="text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 uppercase flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-emerald-400 whitespace-nowrap">
                    <Link2 size={12} className="shrink-0" /> 4) Direct Video Link *
                  </span>
                  <span className="text-[8px] sm:text-[9px] text-emerald-400 font-mono flex items-center gap-1 whitespace-nowrap">
                    <Cloud size={10} /> Cloud CDN / HLS / MP4
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    id="publisher-video-link"
                    placeholder="Paste Cloud CDN, HLS .m3u8, direct MP4, or Telegram Bot link..."
                    value={postDestinationLink}
                    onChange={(e) => setPostDestinationLink(e.target.value)}
                    className="flex-1 min-w-0 bg-slate-900 border border-slate-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/40 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 font-mono outline-none transition placeholder-slate-600"
                    required
                  />
                  {uploadFileWithProgress && (
                    <label className="px-3 sm:px-3.5 py-2 sm:py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shrink-0 border border-slate-700 whitespace-nowrap min-h-[38px]">
                      <Upload size={13} />
                      <span className="hidden xs:inline">Upload Video</span>
                      <input
                        type="file"
                        accept="video/*"
                        onClick={(e) => {
                          (e.currentTarget as HTMLInputElement).value = '';
                        }}
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (!file) return;
                          try {
                            const url = await uploadFileWithProgress(file, "Video Clip");
                            setPostDestinationLink(url);
                          } catch (err: any) {
                            alert("Video upload failed: " + (err.message || "Unknown error"));
                          }
                        }}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Form Submission Action Bar */}
          <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-[10px] sm:text-[11px] text-slate-400 flex items-center gap-1.5 font-mono">
              <Sparkles size={13} className="text-indigo-400 shrink-0" />
              <span>Auto-defaults rating, dubbing arrays, and group pack metadata.</span>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              {editingPostId && (
                <button
                  type="button"
                  id="publisher-cancel-edit-action"
                  onClick={handleResetForm}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-bold transition border border-slate-700 cursor-pointer text-center whitespace-nowrap"
                >
                  Cancel
                </button>
              )}

              <button
                type="submit"
                id="publisher-submit-btn"
                disabled={postPublishing}
                className="flex-1 sm:flex-initial px-6 py-2.5 sm:py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs font-mono uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-600/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap border border-indigo-400/40"
              >
                <Zap size={14} />
                <span>
                  {postPublishing
                    ? "Publishing..."
                    : editingPostId
                    ? "Save Changes"
                    : postContentType === 'movie'
                    ? "Publish Movie Post"
                    : postContentType === 'adult_movie'
                    ? "Publish Adult Movie (18+)"
                    : postContentType === 'video'
                    ? "Publish Video Post"
                    : postContentType === 'drama'
                    ? "Publish Drama Post"
                    : "Publish Series Post"}
                </span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Quick Notice to Open Media Library */}
      {onNavigateToCatalog && (
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-slate-100 font-mono shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30 shrink-0">
              <Database size={16} />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-white">Central Media Catalog</h4>
              <p className="text-[11px] text-slate-400 font-sans">
                Published items are cataloged in Media Catalog. View, toggle live status, edit, or delete items.
              </p>
            </div>
          </div>

          <button
            id="publisher-open-catalog-btn"
            onClick={onNavigateToCatalog}
            className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:brightness-110 text-white rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-indigo-500/20 shrink-0 cursor-pointer"
          >
            <Database size={13} />
            <span>Open Media Catalog ({catalogCount}) →</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default AdminPostPublisher;
