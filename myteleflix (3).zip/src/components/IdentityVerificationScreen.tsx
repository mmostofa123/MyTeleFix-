/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from "react";
import {
  ShieldCheck,
  ShieldAlert,
  Calendar,
  CheckCircle2,
  HelpCircle,
  Award,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Zap,
  Check,
  Clock,
  RotateCcw,
  AlertCircle,
  FileText,
  Download,
  X,
  Lock,
  UserCheck,
  Info,
  Sparkles,
  Shield,
  Activity
} from "lucide-react";
import {
  VerificationSettings,
  UserDailyActivityStats,
  UserActivityEngineStats,
  VerificationStatusResponse,
} from "../types";
import HumanVerificationQuizModal from "./HumanVerificationQuizModal";

export interface IdentityVerificationScreenProps {
  userId?: string;
  activeDays?: number;
  completedTasksCount?: number;
  isAccountCreated?: boolean;
  isQuizPassed?: boolean;
  requiredActiveDays?: number;
  requiredTasks?: number;
  verificationSettings?: VerificationSettings;
  activeDayStreak?: number;
  validActionCount?: number;
  lastActiveAt?: string;
  todayActivity?: UserDailyActivityStats;
  onStartQuiz?: () => void;
  onQuizSuccess?: () => void;
}

export const IdentityVerificationScreen: React.FC<IdentityVerificationScreenProps> = ({
  userId = "tg-101",
  activeDays = 0,
  completedTasksCount = 0,
  isAccountCreated = true,
  isQuizPassed = false,
  requiredActiveDays = 10,
  requiredTasks = 100,
  verificationSettings,
  activeDayStreak,
  validActionCount,
  lastActiveAt,
  todayActivity,
  onStartQuiz,
  onQuizSuccess,
}) => {
  const [internalQuizOpen, setInternalQuizOpen] = useState<boolean>(false);
  const [localQuizPassed, setLocalQuizPassed] = useState<boolean>(isQuizPassed);

  // Real-time server-authoritative engine state
  const [serverStats, setServerStats] = useState<UserActivityEngineStats | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationStatusResponse | null>(null);
  const [inactivityInfo, setInactivityInfo] = useState<{
    inactivity_days: number;
    days_until_purge: number;
    warning_active: boolean;
    warning_message: string | null;
  } | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Accordion state (default to first incomplete pillar or null)
  const [expandedPillar, setExpandedPillar] = useState<number | null>(null);

  // Inactivity & Purge drawer state
  const [isProtectionDrawerOpen, setIsProtectionDrawerOpen] = useState<boolean>(false);

  // Top-floating 5-second auto-dismiss toast state
  const [toast, setToast] = useState<{ message: string; type: "success" | "info" | "error" } | null>(null);

  const showToast = useCallback((message: string, type: "success" | "info" | "error" = "success") => {
    setToast({ message, type });
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Non-negotiable target thresholds
  const targetDays = verificationResult?.prerequisites?.activeDays?.required ?? requiredActiveDays ?? 10;
  const targetTasks = verificationResult?.prerequisites?.validActions?.required ?? requiredTasks ?? 100;

  // 1. Fetch server-authoritative Verification Status
  const fetchVerificationStatus = useCallback(async () => {
    if (!userId || userId === "guest") return;
    try {
      const res = await fetch("/api/verification/check-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      if (res.ok) {
        const data: VerificationStatusResponse = await res.json();
        setVerificationResult(data);
        if (data.prerequisites?.quizPassed?.passed) {
          setLocalQuizPassed(true);
        }
      }
    } catch (err) {
      console.warn("[IdentityVerification] Failed to fetch server verification status:", err);
    }
  }, [userId]);

  // 2. Fetch server-authoritative UAE Stats
  const fetchActivityStats = useCallback(async () => {
    if (!userId || userId === "guest") return;
    try {
      setIsLoadingStats(true);
      const res = await fetch(`/api/user/activity-stats?userId=${encodeURIComponent(userId)}`);
      if (res.ok) {
        const data: UserActivityEngineStats = await res.json();
        setServerStats(data);
      }
    } catch (err) {
      console.warn("[IdentityVerification] Failed to fetch server activity stats:", err);
    } finally {
      setIsLoadingStats(false);
    }
  }, [userId]);

  // 3. Fetch server-authoritative Inactivity & Purge Status
  const fetchInactivityStatus = useCallback(async () => {
    if (!userId || userId === "guest") return;
    try {
      const res = await fetch(`/api/user/inactivity-status?userId=${encodeURIComponent(userId)}`);
      if (res.ok) {
        const data = await res.json();
        setInactivityInfo(data);
      }
    } catch (err) {
      console.warn("[IdentityVerification] Inactivity status notice:", err);
    }
  }, [userId]);

  // Load server-authoritative datasets on mount or userId change
  useEffect(() => {
    fetchVerificationStatus();
    fetchActivityStats();
    fetchInactivityStatus();
  }, [fetchVerificationStatus, fetchActivityStats, fetchInactivityStatus]);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await Promise.all([fetchVerificationStatus(), fetchActivityStats(), fetchInactivityStatus()]);
      showToast("ভেরিফিকেশন স্ট্যাটাস সফলভাবে সিঙ্ক হয়েছে", "success");
    } catch {
      showToast("সিঙ্ক করতে সমস্যা হয়েছে। পুনরায় চেষ্টা করুন।", "error");
    } finally {
      setIsRefreshing(false);
    }
  };

  // Derive effective stats (backend values prioritized)
  const currentStreak =
    verificationResult?.prerequisites?.activeDays?.current ??
    serverStats?.active_day_streak ??
    activeDayStreak ??
    activeDays;

  const currentValidActions =
    verificationResult?.prerequisites?.validActions?.current ??
    serverStats?.valid_action_count ??
    validActionCount ??
    completedTasksCount;

  const currentToday = serverStats?.today ?? todayActivity ?? {
    date: new Date().toISOString().split("T")[0],
    tasksCompleted: 0,
    tasksRequired: 10,
    contentCompleted: 0,
    contentRequired: 5,
    activeDayEarned: false,
    tasksRemaining: 10,
    contentRemaining: 5,
  };

  const hoursRemaining =
    serverStats?.hoursUntilInactivityReset ??
    (() => {
      const lastActive = serverStats?.last_activity_at || lastActiveAt;
      if (!lastActive) return 72;
      const diffHours = (Date.now() - new Date(lastActive).getTime()) / (1000 * 60 * 60);
      return Math.max(0, Math.round(72 - diffHours));
    })();

  // Prerequisite checks
  const req1Passed =
    verificationResult?.prerequisites?.accountValid?.passed ?? isAccountCreated;
  const req2Passed =
    verificationResult?.prerequisites?.activeDays?.passed ?? (currentStreak >= targetDays);
  const req3Passed =
    verificationResult?.prerequisites?.validActions?.passed ??
    (currentValidActions >= targetTasks);
  const req4Passed =
    verificationResult?.prerequisites?.quizPassed?.passed ?? (isQuizPassed || localQuizPassed);

  // Status: Backend sets status to 'VERIFIED'
  const isFullyVerified = verificationResult?.status === "VERIFIED" || (req1Passed && req2Passed && req3Passed && req4Passed);

  // Calculate progress metrics
  const completedCount = [req1Passed, req2Passed, req3Passed, req4Passed].filter(Boolean).length;
  const progressPercent = Math.round((completedCount / 4) * 100);

  // Status Badge resolution in Bengali
  const statusBadge = isFullyVerified
    ? {
        label: "যাচাইকৃত (VERIFIED)" as const,
        color: "text-[#00F5A0]",
        bg: "bg-[#00F5A0]/10",
        border: "border-[#00F5A0]/30",
        icon: <CheckCircle2 size={13} className="text-[#00F5A0]" />,
      }
    : completedCount > 0
    ? {
        label: "চলমান (PENDING)" as const,
        color: "text-[#FFB800]",
        bg: "bg-[#FFB800]/10",
        border: "border-[#FFB800]/30",
        icon: <Clock size={13} className="text-[#FFB800]" />,
      }
    : {
        label: "শুরু হয়নি (UNVERIFIED)" as const,
        color: "text-[#00D8F6]",
        bg: "bg-[#00D8F6]/10",
        border: "border-[#00D8F6]/30",
        icon: <ShieldAlert size={13} className="text-[#00D8F6]" />,
      };

  // Today dual-metric calculations
  const tasksGoal = 10;
  const contentGoal = 5;
  const tasksRatio = Math.min(1, (currentToday.tasksCompleted || 0) / tasksGoal);
  const contentRatio = Math.min(1, (currentToday.contentCompleted || 0) / contentGoal);
  const todayEarned = Boolean(currentToday.activeDayEarned || (tasksRatio >= 1 && contentRatio >= 1));
  const todayCombinedPercent = Math.min(100, Math.round((tasksRatio * 0.5 + contentRatio * 0.5) * 100));

  const handleOpenQuiz = () => {
    if (onStartQuiz) {
      onStartQuiz();
    } else {
      setInternalQuizOpen(true);
    }
  };

  const handleQuizSuccess = async () => {
    setLocalQuizPassed(true);
    showToast("হিউম্যান ভেরিফিকেশন কুইজ সফলভাবে সম্পন্ন হয়েছে!", "success");
    if (onQuizSuccess) {
      onQuizSuccess();
    }
    // Re-verify immediately via backend
    await Promise.all([fetchVerificationStatus(), fetchActivityStats()]);
  };

  const toggleAccordion = (pillarIndex: number) => {
    setExpandedPillar((prev) => (prev === pillarIndex ? null : pillarIndex));
  };

  // Circular progress dimensions
  const circleRadius = 38;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset = circumference - (progressPercent / 100) * circumference;

  return (
    <div
      id="identity-verification-screen"
      className="space-y-3.5 sm:space-y-4 text-slate-200 select-none"
      style={{ backgroundColor: "#0A0D12" }}
    >
      {/* TOP FLOATING 5-SECOND AUTO-DISMISS TOAST */}
      {toast && (
        <div
          role="alert"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 max-w-sm sm:max-w-md w-[92%] p-3 sm:p-3.5 rounded-2xl bg-[#0A0D12]/95 border shadow-2xl backdrop-blur-md transition-all duration-300 flex items-center justify-between gap-3 text-xs font-medium"
          style={{
            borderColor:
              toast.type === "error"
                ? "rgba(255, 59, 48, 0.4)"
                : toast.type === "info"
                ? "rgba(0, 216, 246, 0.4)"
                : "rgba(0, 245, 160, 0.4)",
          }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {toast.type === "error" ? (
              <AlertCircle size={16} className="text-[#FF3B30] shrink-0" />
            ) : toast.type === "info" ? (
              <ShieldCheck size={16} className="text-[#00D8F6] shrink-0" />
            ) : (
              <CheckCircle2 size={16} className="text-[#00F5A0] shrink-0" />
            )}
            <span className="text-slate-200 truncate">{toast.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/[0.06] transition cursor-pointer"
            aria-label="বার্তা বন্ধ করুন"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* 1. TOP HERO SECTION (Consolidated Status Banner in Bengali) */}
      <div
        id="identity-hero-card"
        className="relative overflow-hidden rounded-3xl p-4 sm:p-5 border transition-all duration-300 shadow-lg"
        style={{
          backgroundColor: "#0F141E",
          borderColor: "rgba(255, 255, 255, 0.08)",
        }}
      >
        <div className="flex items-center justify-between gap-4">
          {/* Left: Dynamic glowing Circular Progress Ring */}
          <div className="relative flex items-center justify-center shrink-0">
            <svg className="w-20 h-20 sm:w-24 sm:h-24 transform -rotate-90 shrink-0" viewBox="0 0 96 96">
              <circle
                cx="48"
                cy="48"
                r={circleRadius}
                stroke="rgba(255, 255, 255, 0.06)"
                strokeWidth="6"
                fill="transparent"
              />
              <circle
                cx="48"
                cy="48"
                r={circleRadius}
                stroke="url(#heroNeonRingGrad)"
                strokeWidth="6"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-700 ease-out"
                style={{ filter: "drop-shadow(0 0 8px rgba(0, 245, 160, 0.45))" }}
              />
              <defs>
                <linearGradient id="heroNeonRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00F5A0" />
                  <stop offset="100%" stopColor="#00D8F6" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-base sm:text-lg font-mono font-black text-white tracking-tight">
                {progressPercent}%
              </span>
              <span className="text-[8px] sm:text-[9px] font-sans text-slate-400 font-bold uppercase tracking-wider">
                অগ্রগতি
              </span>
            </div>
          </div>

          {/* Center/Right: Consolidated Verification Status Details */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span
                  id="badge-verification-status"
                  className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold tracking-wide uppercase border inline-flex items-center gap-1.5 ${statusBadge.bg} ${statusBadge.color} ${statusBadge.border}`}
                >
                  {statusBadge.icon}
                  {statusBadge.label}
                </span>

                <span className="px-2 py-0.5 rounded-md bg-white/[0.04] text-slate-300 border border-white/[0.08] text-[11px] font-mono font-semibold">
                  {completedCount}/৪ টি ধাপ সম্পন্ন
                </span>
              </div>

              {/* Refresh Action Button */}
              <button
                type="button"
                id="btn-refresh-verification"
                onClick={handleManualRefresh}
                disabled={isRefreshing || isLoadingStats}
                className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-400 hover:text-white border border-white/[0.08] transition cursor-pointer shrink-0 disabled:opacity-50 active:scale-95"
                title="ভেরিফিকেশন স্ট্যাটাস রিফ্রেশ করুন"
              >
                <RotateCcw size={14} className={isRefreshing ? "animate-spin text-[#00F5A0]" : ""} />
              </button>
            </div>

            <h3 className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
              পরিচয় ও নিরাপত্তা যাচাই কেন্দ্র
            </h3>
            <p className="text-xs text-slate-400 truncate mt-0.5">
              অ্যাকাউন্টের সুরক্ষা ও রিওয়ার্ড উইথড্রর জন্য ৪-ধাপের ভেরিফিকেশন ব্যবস্থা
            </p>
          </div>
        </div>
      </div>

      {/* QUICK STATUS SNAPSHOT GRID (এক নজরে ৪টি ধাপের অবস্থা) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {/* Step 1 Quick Pill */}
        <div 
          onClick={() => toggleAccordion(1)}
          className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
            req1Passed 
              ? "bg-[#00F5A0]/5 border-[#00F5A0]/25 hover:border-[#00F5A0]/40" 
              : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400">ধাপ ১</span>
            {req1Passed ? (
              <CheckCircle2 size={13} className="text-[#00F5A0]" />
            ) : (
              <Clock size={13} className="text-amber-400" />
            )}
          </div>
          <div className="text-xs font-bold text-slate-200 truncate">অ্যাকাউন্ট সিকিউরিটি</div>
          <div className={`text-[10px] font-mono font-semibold ${req1Passed ? "text-[#00F5A0]" : "text-amber-400"}`}>
            {req1Passed ? "উত্তীর্ণ ✓" : "অপেক্ষমান"}
          </div>
        </div>

        {/* Step 2 Quick Pill */}
        <div 
          onClick={() => toggleAccordion(2)}
          className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
            req2Passed 
              ? "bg-[#00F5A0]/5 border-[#00F5A0]/25 hover:border-[#00F5A0]/40" 
              : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400">ধাপ ২</span>
            {req2Passed ? (
              <CheckCircle2 size={13} className="text-[#00F5A0]" />
            ) : (
              <Clock size={13} className="text-amber-400" />
            )}
          </div>
          <div className="text-xs font-bold text-slate-200 truncate">১০ দিনের স্ট্রিক</div>
          <div className={`text-[10px] font-mono font-semibold ${req2Passed ? "text-[#00F5A0]" : "text-amber-400"}`}>
            {req2Passed ? "উত্তীর্ণ ✓" : `${Math.min(currentStreak, targetDays)}/${targetDays} দিন`}
          </div>
        </div>

        {/* Step 3 Quick Pill */}
        <div 
          onClick={() => toggleAccordion(3)}
          className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
            req3Passed 
              ? "bg-[#00F5A0]/5 border-[#00F5A0]/25 hover:border-[#00F5A0]/40" 
              : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400">ধাপ ৩</span>
            {req3Passed ? (
              <CheckCircle2 size={13} className="text-[#00F5A0]" />
            ) : (
              <Clock size={13} className="text-amber-400" />
            )}
          </div>
          <div className="text-xs font-bold text-slate-200 truncate">১০০টি অ্যাকশন কোটা</div>
          <div className={`text-[10px] font-mono font-semibold ${req3Passed ? "text-[#00F5A0]" : "text-[#00D8F6]"}`}>
            {req3Passed ? "উত্তীর্ণ ✓" : `${Math.min(currentValidActions, targetTasks)}/${targetTasks}`}
          </div>
        </div>

        {/* Step 4 Quick Pill */}
        <div 
          onClick={() => toggleAccordion(4)}
          className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
            req4Passed 
              ? "bg-[#00F5A0]/5 border-[#00F5A0]/25 hover:border-[#00F5A0]/40" 
              : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold text-slate-400">ধাপ ৪</span>
            {req4Passed ? (
              <CheckCircle2 size={13} className="text-[#00F5A0]" />
            ) : (
              <Clock size={13} className="text-amber-400" />
            )}
          </div>
          <div className="text-xs font-bold text-slate-200 truncate">হিউম্যান কুইজ</div>
          <div className={`text-[10px] font-mono font-semibold ${req4Passed ? "text-[#00F5A0]" : "text-amber-400"}`}>
            {req4Passed ? "উত্তীর্ণ ✓" : "বাকি আছে"}
          </div>
        </div>
      </div>

      {/* 2. DAILY TODAY PROGRESS (Compact Card in Bengali) */}
      <div
        id="identity-today-card"
        className="rounded-3xl p-3.5 sm:p-4 border transition-all duration-300 shadow-md"
        style={{
          backgroundColor: "#0F141E",
          borderColor: "rgba(255, 255, 255, 0.08)",
        }}
      >
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-[#00F5A0]/10 border border-[#00F5A0]/30 flex items-center justify-center text-[#00F5A0]">
              <Calendar size={13} />
            </div>
            <span className="text-xs font-bold text-white tracking-wide">আজকের সক্রিয়তা লক্ষ্য (Daily Activity)</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-white/[0.04] text-slate-300 border border-white/[0.08] text-[10px] font-mono font-bold">
              স্ট্রিক: {currentStreak} দিন
            </span>
            <span
              className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold border ${
                todayEarned
                  ? "bg-[#00F5A0]/15 text-[#00F5A0] border-[#00F5A0]/30"
                  : "bg-[#FFB800]/15 text-[#FFB800] border-[#FFB800]/30"
              }`}
            >
              {todayEarned ? "আজকের দিন সফল ✓" : `আজকে ${todayCombinedPercent}% সম্পন্ন`}
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 rounded-full bg-black/50 border border-white/[0.06] overflow-hidden p-[1px] mb-2.5">
          <div
            className="h-full rounded-full transition-all duration-700 ease-out bg-gradient-to-r from-[#00F5A0] via-[#00D8F6] to-[#00F5A0] shadow-[0_0_10px_rgba(0,245,160,0.35)]"
            style={{ width: `${todayCombinedPercent}%` }}
          />
        </div>

        {/* Combined Dual-Metric Bar: Left (Tasks) & Right (Downloads) */}
        <div className="flex items-center justify-between text-xs font-mono pt-0.5">
          <div className="flex items-center gap-1.5 text-slate-300">
            <FileText size={12} className="text-[#00D8F6]" />
            <span>
              <strong className="text-white font-bold">{currentToday.tasksCompleted}</strong>/{tasksGoal} টি টাস্ক সম্পন্ন
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-slate-300">
            <Download size={12} className="text-[#00F5A0]" />
            <span>
              <strong className="text-white font-bold">{currentToday.contentCompleted}</strong>/{contentGoal} টি ডাউনলোড/ভিডিও
            </span>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 mt-2 pt-2 border-t border-white/[0.06] leading-relaxed">
          💡 <span className="text-slate-300 font-semibold">নিয়ম:</span> প্রতিদিন ১০টি টাস্ক এবং ৫টি কনটেন্ট ডাউনলোড সম্পন্ন করলে ১টি সম্পূর্ণ অ্যাক্টিভ দিন গণনা হয়।
        </p>
      </div>

      {/* 3. ACCORDION-BASED 4-PILLAR VERIFICATION FLOW (In Bengali, Organized & Polished) */}
      <div className="space-y-2.5">
        {/* Pillar 1: Account Setup & Security Status */}
        <div
          id="pillar-1-account-security"
          className="rounded-3xl border transition-all duration-200 overflow-hidden shadow-sm"
          style={{
            backgroundColor: "#0F141E",
            borderColor: req1Passed ? "rgba(0, 245, 160, 0.2)" : "rgba(255, 255, 255, 0.08)",
          }}
        >
          <button
            type="button"
            onClick={() => toggleAccordion(1)}
            className="w-full p-3.5 sm:p-4 flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border ${
                  req1Passed
                    ? "bg-[#00F5A0]/10 border-[#00F5A0]/30 text-[#00F5A0]"
                    : "bg-[#FFB800]/10 border-[#FFB800]/30 text-[#FFB800]"
                }`}
              >
                <UserCheck size={17} />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
                  ধাপ ১: অ্যাকাউন্ট ও নিরাপত্তা স্ট্যাটাস
                </h4>
                <p className="text-[11px] text-slate-400 truncate">
                  টেলিগ্রাম অথেনটিকেশন ও হার্ডওয়্যার ডিভাইস সিকিউরিটি
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                  req1Passed
                    ? "bg-[#00F5A0]/15 text-[#00F5A0] border-[#00F5A0]/30"
                    : "bg-[#FFB800]/15 text-[#FFB800] border-[#FFB800]/30"
                }`}
              >
                {req1Passed ? "উত্তীর্ণ (PASSED)" : "অপেক্ষমান"}
              </span>
              {expandedPillar === 1 ? (
                <ChevronUp size={16} className="text-slate-400" />
              ) : (
                <ChevronDown size={16} className="text-slate-400" />
              )}
            </div>
          </button>

          {expandedPillar === 1 && (
            <div className="px-4 pb-4 pt-1 border-t border-white/[0.06] text-xs text-slate-300 space-y-2.5">
              <p className="text-slate-400 leading-relaxed">
                আপনার অ্যাকাউন্টটি অফিসিয়াল সেশন ও একক ডিভাইসের সাথে সফলভাবে সংযুক্ত। এই অ্যাকাউন্টে কোনো স্ট্রাইক, ফ্রড ফ্ল্যাগ বা নিয়ম লঙ্ঘনের রেকর্ড নেই।
              </p>
              
              <div className="space-y-1.5 p-3 rounded-2xl bg-black/40 border border-white/[0.06] text-[11px] font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">টেলিগ্রাম অথেনটিকেশন:</span>
                  <span className="text-[#00F5A0] font-semibold">সক্রিয় ও অনুমোদিত</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">ডিভাইস নীতি (HWID):</span>
                  <span className="text-[#00F5A0] font-semibold">একক বৈধ ডিভাইস লকড</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">নিরাপত্তা নিরীক্ষা:</span>
                  <span className="text-[#00F5A0] font-semibold">সম্পূর্ণ নিরাপদ (Compliant)</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Pillar 2: 10-Day Active Streak Guard */}
        <div
          id="pillar-2-active-streak"
          className="rounded-3xl border transition-all duration-200 overflow-hidden shadow-sm"
          style={{
            backgroundColor: "#0F141E",
            borderColor: req2Passed ? "rgba(0, 245, 160, 0.2)" : "rgba(255, 255, 255, 0.08)",
          }}
        >
          <button
            type="button"
            onClick={() => toggleAccordion(2)}
            className="w-full p-3.5 sm:p-4 flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border ${
                  req2Passed
                    ? "bg-[#00F5A0]/10 border-[#00F5A0]/30 text-[#00F5A0]"
                    : "bg-[#FFB800]/10 border-[#FFB800]/30 text-[#FFB800]"
                }`}
              >
                <Calendar size={17} />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
                  ধাপ ২: ১০ দিনের অ্যাক্টিভ স্ট্রিক গার্ড
                </h4>
                <p className="text-[11px] text-slate-400 truncate">
                  ধারাবাহিক দৈনিক অংশগ্রহণ (প্রতিদিন ১০টি টাস্ক + ৫টি ডাউনলোড)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                  req2Passed
                    ? "bg-[#00F5A0]/15 text-[#00F5A0] border-[#00F5A0]/30"
                    : "bg-[#FFB800]/15 text-[#FFB800] border-[#FFB800]/30"
                }`}
              >
                {req2Passed ? "উত্তীর্ণ (PASSED)" : `${Math.min(currentStreak, targetDays)}/${targetDays} দিন সম্পন্ন`}
              </span>
              {expandedPillar === 2 ? (
                <ChevronUp size={16} className="text-slate-400" />
              ) : (
                <ChevronDown size={16} className="text-slate-400" />
              )}
            </div>
          </button>

          {expandedPillar === 2 && (
            <div className="px-4 pb-4 pt-1 border-t border-white/[0.06] text-xs text-slate-300 space-y-2.5">
              <p className="text-slate-400 leading-relaxed">
                প্ল্যাটফর্মে যেকোনো ১০ দিন সক্রিয় থাকুন। ২৪ ঘণ্টার মধ্যে ১০টি টাস্ক ও ৫টি ডাউনলোড সম্পন্ন করলেই ১টি সক্রিয় দিন গণনা হয়।
              </p>
              <div className="p-3 rounded-2xl bg-black/40 border border-white/[0.06] space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">বর্তমান সক্রিয় স্ট্রিক:</span>
                  <span className="text-white font-bold">{currentStreak} / {targetDays} দিন</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#FFB800] transition-all duration-500 shadow-[0_0_10px_rgba(245,158,11,0.4)]"
                    style={{ width: `${Math.min(100, Math.round((currentStreak / targetDays) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 pt-0.5">
                  <span>০ দিন</span>
                  <span>অগ্রগতি: {Math.min(100, Math.round((currentStreak / targetDays) * 100))}%</span>
                  <span>{targetDays} দিন লক্ষ্য</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Pillar 3: 100 Valid Actions Quota */}
        <div
          id="pillar-3-valid-actions"
          className="rounded-3xl border transition-all duration-200 overflow-hidden shadow-sm"
          style={{
            backgroundColor: "#0F141E",
            borderColor: req3Passed ? "rgba(0, 245, 160, 0.2)" : "rgba(255, 255, 255, 0.08)",
          }}
        >
          <button
            type="button"
            onClick={() => toggleAccordion(3)}
            className="w-full p-3.5 sm:p-4 flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border ${
                  req3Passed
                    ? "bg-[#00F5A0]/10 border-[#00F5A0]/30 text-[#00F5A0]"
                    : "bg-[#00D8F6]/10 border-[#00D8F6]/30 text-[#00D8F6]"
                }`}
              >
                <Award size={17} />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
                  ধাপ ৩: ১০০টি ভ্যালিড অ্যাকশন কোটা
                </h4>
                <p className="text-[11px] text-slate-400 truncate">
                  সর্বমোট লাইফটাইম যাচাইকৃত টাস্ক ও ডাউনলোড অ্যাকশন
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                  req3Passed
                    ? "bg-[#00F5A0]/15 text-[#00F5A0] border-[#00F5A0]/30"
                    : "bg-[#00D8F6]/15 text-[#00D8F6] border-[#00D8F6]/30"
                }`}
              >
                {req3Passed ? "উত্তীর্ণ (PASSED)" : `${Math.min(currentValidActions, targetTasks)}/${targetTasks} টি সম্পন্ন`}
              </span>
              {expandedPillar === 3 ? (
                <ChevronUp size={16} className="text-slate-400" />
              ) : (
                <ChevronDown size={16} className="text-slate-400" />
              )}
            </div>
          </button>

          {expandedPillar === 3 && (
            <div className="px-4 pb-4 pt-1 border-t border-white/[0.06] text-xs text-slate-300 space-y-2.5">
              <p className="text-slate-400 leading-relaxed">
                প্ল্যাটফর্মে সর্বমোট ১০০টি ভ্যালিড অ্যাকশন (মিশন, ভিডিও দেখা, কনটেন্ট ডাউনলোড) সম্পন্ন করুন। প্রতিটি অ্যাকশন চিরস্থায়ীভাবে সংরক্ষিত এবং কখনো কমে যাবে না।
              </p>
              <div className="p-3 rounded-2xl bg-black/40 border border-white/[0.06] space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">সর্বমোট ভ্যালিড অ্যাকশন:</span>
                  <span className="text-[#00D8F6] font-bold">{currentValidActions} / {targetTasks} টি</span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[#00D8F6] transition-all duration-500 shadow-[0_0_10px_rgba(0,216,246,0.4)]"
                    style={{ width: `${Math.min(100, Math.round((currentValidActions / targetTasks) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 pt-0.5">
                  <span>০ টি</span>
                  <span>অগ্রগতি: {Math.min(100, Math.round((currentValidActions / targetTasks) * 100))}%</span>
                  <span>{targetTasks} টি লক্ষ্য</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Pillar 4: Anti-Bot Human Quiz */}
        <div
          id="pillar-4-human-quiz"
          className="rounded-3xl border transition-all duration-200 overflow-hidden shadow-sm"
          style={{
            backgroundColor: "#0F141E",
            borderColor: req4Passed ? "rgba(0, 245, 160, 0.2)" : "rgba(255, 255, 255, 0.08)",
          }}
        >
          <button
            type="button"
            onClick={() => toggleAccordion(4)}
            className="w-full p-3.5 sm:p-4 flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border ${
                  req4Passed
                    ? "bg-[#00F5A0]/10 border-[#00F5A0]/30 text-[#00F5A0]"
                    : "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                }`}
              >
                <HelpCircle size={17} />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
                  ধাপ ৪: অ্যান্টি-বট হিউম্যান কুইজ
                </h4>
                <p className="text-[11px] text-slate-400 truncate">
                  ৩টি সহজ বুদ্ধিবৃত্তিক প্রশ্নের সঠিক উত্তরের মাধ্যমে সত্যতা যাচাই
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold border ${
                  req4Passed
                    ? "bg-[#00F5A0]/15 text-[#00F5A0] border-[#00F5A0]/30"
                    : "bg-[#FFB800]/15 text-[#FFB800] border-[#FFB800]/30"
                }`}
              >
                {req4Passed ? "উত্তীর্ণ (PASSED)" : "বাকি আছে"}
              </span>
              {expandedPillar === 4 ? (
                <ChevronUp size={16} className="text-slate-400" />
              ) : (
                <ChevronDown size={16} className="text-slate-400" />
              )}
            </div>
          </button>

          {expandedPillar === 4 && (
            <div className="px-4 pb-4 pt-1 border-t border-white/[0.06] text-xs text-slate-300 space-y-3">
              <p className="text-slate-400 leading-relaxed">
                স্বয়ংক্রিয় বট প্রতিরোধে সার্ভার কর্তৃক নির্ধারিত ৩টি সহজ সাধারণ জ্ঞান ও লজিক প্রশ্নের সঠিক উত্তর দিয়ে মানুষ হিসেবে প্রমাণ দিন।
              </p>

              {req4Passed ? (
                <div className="flex items-center gap-2.5 p-3 rounded-2xl bg-[#00F5A0]/10 border border-[#00F5A0]/30 text-[#00F5A0] text-xs font-semibold">
                  <CheckCircle2 size={16} className="shrink-0" />
                  <span>হিউম্যান ভেরিফিকেশন সফল হয়েছে। ৩/৩ স্কোর সার্ভারে রেকর্ড রয়েছে।</span>
                </div>
              ) : (
                <button
                  type="button"
                  id="btn-start-human-quiz"
                  onClick={handleOpenQuiz}
                  className="w-full py-3 px-4 rounded-2xl text-xs font-bold tracking-wider uppercase transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 active:scale-95 shadow-lg"
                  style={{
                    backgroundColor: "#00F5A0",
                    color: "#0A0D12",
                    boxShadow: "0 0 20px rgba(0, 245, 160, 0.35)",
                  }}
                >
                  <Zap size={15} className="fill-current" />
                  <span>কুইজ শুরু করুন (START VERIFICATION)</span>
                  <ChevronRight size={15} />
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 4. INACTIVITY & PURGE PROTECTION NOTICE (Minimalist Footer Banner in Bengali) */}
      <div
        id="identity-security-drawer"
        className="rounded-3xl border transition-all duration-300 overflow-hidden shadow-sm"
        style={{
          backgroundColor: "#0F141E",
          borderColor: "rgba(255, 255, 255, 0.08)",
        }}
      >
        <button
          type="button"
          onClick={() => setIsProtectionDrawerOpen((prev) => !prev)}
          className="w-full p-3.5 flex items-center justify-between gap-3 text-left cursor-pointer hover:bg-white/[0.02] transition"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {/* Glowing Amber Dot */}
            <span className="relative flex h-2 w-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FFB800] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#FFB800] shadow-[0_0_6px_#FFB800]"></span>
            </span>

            <span className="text-xs font-semibold text-slate-300 truncate">
              নিষ্ক্রিয়তা ও পার্জ প্রটেকশন গার্ড ({hoursRemaining} ঘণ্টা উইন্ডো)
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="px-2 py-0.5 rounded-md bg-white/[0.04] text-slate-300 border border-white/[0.06] text-[10px] font-mono font-bold">
              {inactivityInfo?.days_until_purge ?? 30} দিন বাকি
            </span>
            {isProtectionDrawerOpen ? (
              <ChevronUp size={14} className="text-slate-400" />
            ) : (
              <ChevronDown size={14} className="text-slate-400" />
            )}
          </div>
        </button>

        {isProtectionDrawerOpen && (
          <div className="px-4 pb-3.5 pt-1 border-t border-white/[0.06] text-[11px] text-slate-400 space-y-2.5">
            <div className="flex items-start gap-2">
              <Clock size={14} className="text-[#FFB800] shrink-0 mt-0.5" />
              <p className="leading-snug">
                <strong className="text-slate-200">৭২ ঘণ্টার নিষ্ক্রিয়তা নিয়ম:</strong> টানা ৭২ ঘণ্টা অ্যাপে কোনো কার্যক্রম না থাকলে সক্রিয় দিনের স্ট্রিক (Streak) রিসেট হয়ে যায়। তবে আপনার অর্জিত সর্বমোট অ্যাকশন বা কয়েন কখনো কাটা যায় না।
              </p>
            </div>
            <div className="flex items-start gap-2">
              <ShieldCheck size={14} className="text-[#00F5A0] shrink-0 mt-0.5" />
              <p className="leading-snug">
                <strong className="text-slate-200">৩০ দিনের পার্জ প্রটেকশন:</strong> টানা ৩০ দিন অ্যাপে কোনো প্রবেশ বা কাজ না থাকলে অ্যাকাউন্টটি নিষ্ক্রিয় তালিকায় স্থান পায়। যেকোনো একটি সাধারণ টাস্ক বা ভিডিও দেখলেই এই টাইমার পুনরায় সম্পূর্ণ নবায়ন হয়ে যায়।
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Human Verification Quiz Modal */}
      <HumanVerificationQuizModal
        isOpen={internalQuizOpen}
        onClose={() => setInternalQuizOpen(false)}
        onSuccess={handleQuizSuccess}
        userId={userId}
      />
    </div>
  );
};

export default IdentityVerificationScreen;
