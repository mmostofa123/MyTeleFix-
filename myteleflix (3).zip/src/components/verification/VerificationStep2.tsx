/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VerificationStep2 (2nd Verification Website Screen - Phase 2 Handshake)
 * Reads single-use token & contentId, enforces single-use token consumption,
 * verifies that contentId is correctly mapped to universalTelegramLink in Firestore,
 * displays content details, and provides the prominent Telegram Bot Deep-Link CTA:
 * "📥 Get File in Telegram" -> https://t.me/YourBotUsername?start=dl_{contentId}
 */

import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, Loader2, CheckCircle2, AlertOctagon, 
  Send, Film, ExternalLink, Sparkles, Lock, ArrowRight, RefreshCw, FileText
} from "lucide-react";
import { 
  validateAndConsumeVerificationToken, 
  verifySignalAndTieContentMapping, 
  getContentMapping 
} from "../../services/firebase";
import { ContentMapping } from "../../types";

export interface VerificationStep2Props {
  token?: string;
  contentId?: string;
  telegramId?: string | number;
  userEmail?: string;
  botUsername?: string;
}

export default function VerificationStep2({
  token: propToken,
  contentId: propContentId,
  telegramId: propTelegramId,
  userEmail: propUserEmail,
  botUsername: propBotUsername,
}: VerificationStep2Props) {
  const queryParams = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const effectiveToken = propToken || queryParams.get("token") || "";
  const effectiveContentId = propContentId || queryParams.get("contentId") || queryParams.get("ref") || "";
  const effectiveTelegramId = propTelegramId || queryParams.get("telegramId") || queryParams.get("tgId") || "";
  const effectiveEmail = propUserEmail || queryParams.get("email") || "";
  const effectiveUserMode: "GUEST" | "VIP" = (queryParams.get("userMode") as "GUEST" | "VIP") || "GUEST";
  const effectiveUid = queryParams.get("uid") || "";

  const [activeBotUsername, setActiveBotUsername] = useState<string>(
    propBotUsername || "myteleflix_bot"
  );

  const [isValidating, setIsValidating] = useState<boolean>(true);
  const [tokenValid, setTokenValid] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const [content, setContent] = useState<ContentMapping | null>(null);
  const [deepLink, setDeepLink] = useState<string>("");
  const [signalVerified, setSignalVerified] = useState<boolean>(false);
  const [hasOpenedTelegram, setHasOpenedTelegram] = useState<boolean>(false);

  // Fetch dynamic system settings for Telegram Bot Username
  useEffect(() => {
    fetch("/api/system-settings")
      .then((r) => r.json())
      .then((data) => {
        if (data) {
          const configuredBot = 
            data.telegramBotUsername || 
            data.botUsername || 
            data.telegaId || 
            (data.telegramBotLink ? data.telegramBotLink.replace('https://t.me/', '') : null);
          if (configuredBot && !propBotUsername) {
            setActiveBotUsername(configuredBot.replace(/^@/, ''));
          }
        }
      })
      .catch(() => {});
  }, [propBotUsername]);

  // Execute Token Validation & Signal Tie Routine
  useEffect(() => {
    let isMounted = true;

    async function processVerification() {
      setIsValidating(true);
      setValidationError(null);

      if (!effectiveContentId) {
        if (isMounted) {
          setValidationError("Missing content identifier. Invalid or corrupted verification URL.");
          setIsValidating(false);
        }
        return;
      }

      // 1. If token is present, validate & consume single-use token in Firestore
      if (effectiveToken) {
        const tokenRes = await validateAndConsumeVerificationToken(effectiveToken);
        if (!tokenRes.valid) {
          if (isMounted) {
            setValidationError(tokenRes.error || "Single-use verification token is invalid or already consumed.");
            setIsValidating(false);
          }
          return;
        }
      }

      if (!isMounted) return;
      setTokenValid(true);

      // 2. Execute Signal Data Verification Routine
      // Ensures contentId ties with universalTelegramLink in Firestore and updates download_requests to VERIFIED
      const routineRes = await verifySignalAndTieContentMapping(
        effectiveContentId,
        effectiveTelegramId,
        effectiveEmail,
        activeBotUsername,
        effectiveUserMode,
        effectiveUid
      );

      if (isMounted) {
        setContent(routineRes.mapping);
        setDeepLink(routineRes.deepLink);
        setSignalVerified(routineRes.success);
        setIsValidating(false);
      }
    }

    processVerification();

    return () => {
      isMounted = false;
    };
  }, [effectiveToken, effectiveContentId, effectiveTelegramId, effectiveEmail, activeBotUsername, effectiveUserMode, effectiveUid]);

  // Handle CTA Click: Open Telegram Deep-Link
  const handleOpenTelegram = () => {
    const finalDeepLink = deepLink || `https://t.me/${activeBotUsername.replace(/^@/, '')}?start=dl_${encodeURIComponent(effectiveContentId)}`;
    setHasOpenedTelegram(true);

    // Notify backend of download completion (strict guest block & VIP wallet rewards)
    fetch("/api/download/complete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contentId: effectiveContentId,
        telegramId: effectiveTelegramId,
        uid: effectiveUid,
        userMode: effectiveUserMode,
      }),
    }).catch(() => {});

    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg) {
        if (typeof tg.openTelegramLink === "function") {
          tg.openTelegramLink(finalDeepLink);
          return;
        }
        if (typeof tg.openLink === "function") {
          tg.openLink(finalDeepLink);
          return;
        }
      }
      
      const opened = window.open(finalDeepLink, "_blank", "noopener,noreferrer");
      if (!opened) {
        window.location.assign(finalDeepLink);
      }
    } catch {
      window.location.assign(finalDeepLink);
    }
  };

  return (
    <div 
      id="verification-step2-screen"
      className="min-h-screen w-full bg-[#090D16] text-white flex flex-col font-sans select-none overflow-x-hidden"
    >
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-[#070A12]/95 backdrop-blur-md border-b border-[#1E293B] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <ShieldCheck size={18} />
          </div>
          <div>
            <h1 className="text-xs sm:text-sm font-bold tracking-wide text-white flex items-center gap-1.5">
              <span>Secure Gateway</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 font-mono">
                FINAL STEP 2
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono">
              Signal Verification & File Delivery Routing
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-[#0F1424] border border-[#1E293B] text-slate-300">
            CID: <span className="text-emerald-400">{effectiveContentId}</span>
          </span>
        </div>
      </header>

      {/* Main Screen Content */}
      <main className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-center space-y-5">
        {isValidating ? (
          <div className="rounded-2xl sm:rounded-3xl bg-[#0C121E] border border-[#1E293B] p-8 text-center space-y-4 shadow-2xl">
            <Loader2 size={36} className="animate-spin text-cyan-400 mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm sm:text-base font-bold text-white">
                Validating Security Handshake...
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Consuming single-use token & verifying Firestore signal mapping
              </p>
            </div>
          </div>
        ) : validationError ? (
          <div className="rounded-2xl sm:rounded-3xl bg-[#140C12] border border-red-500/40 p-6 sm:p-8 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/50 flex items-center justify-center text-red-400 mx-auto">
              <AlertOctagon size={24} />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-sm sm:text-base font-bold text-white">
                Verification Handshake Failed
              </h3>
              <p className="text-xs text-red-300 font-mono max-w-sm mx-auto leading-relaxed">
                {validationError}
              </p>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => window.location.assign("/verify/step-1?contentId=" + encodeURIComponent(effectiveContentId))}
                className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs inline-flex items-center gap-2 border border-slate-700 transition"
              >
                <RefreshCw size={13} />
                <span>Restart Step 1 Verification</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl sm:rounded-3xl bg-[#0C121E] border border-[#1E293B] p-5 sm:p-6 space-y-5 shadow-2xl relative overflow-hidden animate-in fade-in duration-200">
            <div className="pointer-events-none absolute -top-20 -right-20 w-48 h-48 bg-emerald-600/10 rounded-full blur-3xl" />

            {/* Handshake Verified Banner */}
            <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-[#090D16] border border-emerald-500/40">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wide">
                    Identity & Token Verified
                  </h4>
                  <p className="text-[10px] text-slate-400 font-mono">
                    Single-use token consumed • Download signal active
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/30 shrink-0">
                READY
              </span>
            </div>

            {/* Content Details Card */}
            <div className="p-4 rounded-2xl bg-[#090D16] border border-[#1E293B] flex gap-3.5 sm:gap-4 items-start">
              <div className="w-16 h-22 sm:w-20 sm:h-28 rounded-xl bg-slate-800 border border-slate-700 overflow-hidden shrink-0 shadow-md flex items-center justify-center">
                {content?.thumbnailUrl ? (
                  <img 
                    src={content.thumbnailUrl} 
                    alt={content.title} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <Film size={26} className="text-slate-500" />
                )}
              </div>

              <div className="min-w-0 flex-1 space-y-1.5">
                <div className="inline-block px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-[9.5px] font-mono font-bold uppercase tracking-wider">
                  {content?.category?.toUpperCase() || "DIGITAL MOVIE"}
                </div>
                <h2 className="text-sm sm:text-base font-bold text-white leading-tight">
                  {content?.title || `Content #${effectiveContentId}`}
                </h2>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {content?.description || "High-speed encrypted digital download stream prepared. Fast direct delivery via Telegram bot."}
                </p>

                <div className="pt-1 flex flex-wrap items-center gap-2 text-[10px] font-mono">
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    1080p FHD
                  </span>
                  <span className="px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-300 border border-emerald-600/30">
                    Encrypted Hash Tied
                  </span>
                </div>
              </div>
            </div>

            {/* Signal Mapping Confirmation Badge */}
            <div className="p-3 rounded-xl bg-[#0F1424] border border-[#1E293B] space-y-1 text-xs">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">Telegram Bot Delivery:</span>
                <span className="text-cyan-400 font-semibold">@{activeBotUsername}</span>
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">Deep-Link Routing:</span>
                <span className="text-emerald-400 font-semibold">start=dl_{effectiveContentId}</span>
              </div>
            </div>

            {/* PROMINENT CTA BUTTON: 📥 Get File in Telegram */}
            <div className="pt-2 space-y-3">
              <button
                type="button"
                id="btn-get-file-telegram"
                onClick={handleOpenTelegram}
                className="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-sm sm:text-base tracking-wide flex items-center justify-center gap-2.5 shadow-[0_6px_25px_rgba(16,185,129,0.4)] active:scale-[0.98] transition cursor-pointer"
              >
                <span className="text-lg">📥</span>
                <span>Get File in Telegram</span>
                <ArrowRight size={18} strokeWidth={2.6} className="text-slate-950" />
              </button>

              {/* Guest Mode Banner: Prompt to Earn */}
              {effectiveUserMode === "GUEST" && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 border border-amber-500/40 space-y-2 text-center shadow-lg animate-in fade-in">
                  <div className="flex items-center justify-center gap-1.5 text-amber-300 font-bold text-xs sm:text-sm">
                    <span>🌟</span>
                    <span>Want to EARN from this download? Sign up now to unlock your VIP Wallet!</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Guest users enjoy unlimited downloads without points. Register your account to activate instant cashout rewards!
                  </p>
                  <a
                    href="/?action=signup"
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-xs hover:opacity-90 active:scale-95 transition"
                  >
                    <span>Unlock VIP Wallet & Earn</span>
                    <ArrowRight size={13} />
                  </a>
                </div>
              )}

              {/* VIP Mode Active Confirmation */}
              {effectiveUserMode === "VIP" && (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs text-emerald-300 font-mono">
                  <span className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    VIP Mode Active
                  </span>
                  <span className="text-emerald-400 font-bold">+50 Points to VIP Wallet</span>
                </div>
              )}

              <div className="text-center">
                <p className="text-[11px] font-mono text-slate-400">
                  Target Deep Link:{" "}
                  <span className="text-cyan-300 select-all">
                    https://t.me/{activeBotUsername}?start=dl_{effectiveContentId}
                  </span>
                </p>
              </div>

              {hasOpenedTelegram && (
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-1 animate-in fade-in">
                  <p className="text-xs text-emerald-300 font-semibold">
                    ✓ Telegram link opened! Check your Telegram app.
                  </p>
                  <p className="text-[10.5px] text-slate-400">
                    If Telegram did not open automatically, click the button again or paste the link directly.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1E293B] py-3 text-center text-[11px] font-mono text-slate-500">
        Phase 2 Verification Complete • High-Speed Media Delivery
      </footer>
    </div>
  );
}
