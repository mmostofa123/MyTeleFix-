/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * VerificationStep1 (1st Verification Website Screen - Phase 2 Handshake)
 * Receives traffic with contentId and telegramId.
 * Enforces a 15-second active timer and scroll check,
 * then generates a single-use token to redirect to the 2nd Website.
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  ShieldCheck, Loader2, ArrowRight, CheckCircle2, 
  MousePointer2, Clock, AlertTriangle, Sparkles, ExternalLink, Film
} from "lucide-react";
import { generateSingleUseVerificationToken, getContentMapping } from "../../services/firebase";
import { ContentMapping } from "../../types";

export interface VerificationStep1Props {
  contentId?: string;
  telegramId?: string | number;
  userEmail?: string;
  secondVerificationUrl?: string;
  onRedirectToStep2?: (token: string, contentId: string, telegramId?: string | number) => void;
}

export default function VerificationStep1({
  contentId: propContentId,
  telegramId: propTelegramId,
  userEmail: propUserEmail,
  secondVerificationUrl: propSecondUrl,
  onRedirectToStep2,
}: VerificationStep1Props) {
  // Parse query params if not passed as props
  const queryParams = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const effectiveContentId = propContentId || queryParams.get("contentId") || queryParams.get("ref") || "MOV_101";
  const effectiveTelegramId = propTelegramId || queryParams.get("telegramId") || queryParams.get("tgId") || "";
  const effectiveEmail = propUserEmail || queryParams.get("email") || "";
  const effectiveUserMode: "GUEST" | "VIP" = (queryParams.get("userMode") as "GUEST" | "VIP") || "GUEST";
  const effectiveUid = queryParams.get("uid") || "";

  const [activeSecondUrl, setActiveSecondUrl] = useState<string>(propSecondUrl || "");
  const [content, setContent] = useState<ContentMapping | null>(null);
  const [loadingContent, setLoadingContent] = useState<boolean>(true);

  // Verification requirements: 15-second active timer & scroll check
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [hasScrolled, setHasScrolled] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [isGeneratingToken, setIsGeneratingToken] = useState<boolean>(false);
  const [tokenGenerated, setTokenGenerated] = useState<string | null>(null);
  const [redirectError, setRedirectError] = useState<string | null>(null);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  // Fetch dynamic system settings for 2nd Verification Website URL
  useEffect(() => {
    fetch("/api/system-settings")
      .then((r) => r.json())
      .then((data) => {
        if (data) {
          const url = data.secondVerificationUrl || data.second_verification_url;
          if (url && !propSecondUrl) {
            setActiveSecondUrl(url);
          }
        }
      })
      .catch(() => {});
  }, [propSecondUrl]);

  // Load Content Details
  useEffect(() => {
    let isMounted = true;
    setLoadingContent(true);
    getContentMapping(effectiveContentId)
      .then((data) => {
        if (isMounted) {
          setContent(data);
          setLoadingContent(false);
        }
      })
      .catch(() => {
        if (isMounted) setLoadingContent(false);
      });

    return () => {
      isMounted = false;
    };
  }, [effectiveContentId]);

  // 15-Second Active Countdown Timer
  useEffect(() => {
    if (timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  // Scroll Check Listener
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    const currentScroll = target.scrollTop;
    const maxScroll = target.scrollHeight - target.clientHeight;
    
    if (maxScroll > 0) {
      const progress = Math.min(100, Math.round((currentScroll / maxScroll) * 100));
      setScrollProgress(progress);
      if (progress >= 75 || currentScroll >= maxScroll - 40) {
        setHasScrolled(true);
      }
    } else {
      setHasScrolled(true);
      setScrollProgress(100);
    }
  };

  // Window scroll fallback in case outer page scrolls
  useEffect(() => {
    const handleWindowScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (scrollHeight <= 0) {
        setHasScrolled(true);
        setScrollProgress(100);
        return;
      }
      const progress = Math.min(100, Math.round((window.scrollY / scrollHeight) * 100));
      setScrollProgress(progress);
      if (progress >= 60 || window.scrollY >= scrollHeight - 80) {
        setHasScrolled(true);
      }
    };

    window.addEventListener("scroll", handleWindowScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleWindowScroll);
  }, []);

  // Handshake Execution: Once 15s timer AND scroll check are complete, generate single-use token
  useEffect(() => {
    if (timeLeft === 0 && hasScrolled && !tokenGenerated && !isGeneratingToken) {
      executeTokenHandshake();
    }
  }, [timeLeft, hasScrolled, tokenGenerated, isGeneratingToken]);

  const executeTokenHandshake = async () => {
    setIsGeneratingToken(true);
    setRedirectError(null);

    try {
      const token = await generateSingleUseVerificationToken(
        effectiveContentId,
        effectiveTelegramId,
        effectiveEmail
      );
      setTokenGenerated(token);
      setIsGeneratingToken(false);

      // Construct 2nd Website Destination URL
      const base2nd = activeSecondUrl 
        ? activeSecondUrl.replace(/\/+$/, '') 
        : `${window.location.origin}/verify/step-2`;

      const delimiter = base2nd.includes('?') ? '&' : '?';
      const target2ndUrl = `${base2nd}${delimiter}token=${encodeURIComponent(token)}&contentId=${encodeURIComponent(effectiveContentId)}&telegramId=${encodeURIComponent(effectiveTelegramId)}&userMode=${encodeURIComponent(effectiveUserMode)}&uid=${encodeURIComponent(effectiveUid)}`;

      // Automatically redirect after brief visual success state
      setTimeout(() => {
        if (onRedirectToStep2) {
          onRedirectToStep2(token, effectiveContentId, effectiveTelegramId);
        } else {
          try {
            const tg = (window as any).Telegram?.WebApp;
            if (tg && typeof tg.openLink === "function") {
              tg.openLink(target2ndUrl);
            } else {
              window.location.assign(target2ndUrl);
            }
          } catch {
            window.location.assign(target2ndUrl);
          }
        }
      }, 1500);
    } catch (err: any) {
      console.error("Single-use token generation error:", err);
      setRedirectError(err.message || "Failed to generate verification token. Please retry.");
      setIsGeneratingToken(false);
    }
  };

  const timerPercent = Math.min(100, Math.max(0, ((15 - timeLeft) / 15) * 100));
  const isFullyVerified = timeLeft === 0 && hasScrolled;

  return (
    <div 
      id="verification-step1-screen"
      className="min-h-screen w-full bg-[#090D16] text-white flex flex-col font-sans select-none overflow-x-hidden"
    >
      {/* Top Security Banner */}
      <header className="sticky top-0 z-30 bg-[#070A12]/95 backdrop-blur-md border-b border-[#1E293B] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <ShieldCheck size={18} />
          </div>
          <div>
            <h1 className="text-xs sm:text-sm font-bold tracking-wide text-white flex items-center gap-1.5">
              <span>Secure Gateway</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30 font-mono">
                STEP 1 OF 2
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 font-mono">
              Identity Verification & Human Check Handshake
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-[#0F1424] border border-[#1E293B] text-slate-300">
            ID: <span className="text-cyan-400">{effectiveContentId}</span>
          </span>
        </div>
      </header>

      {/* Main Verification Content Area */}
      <main 
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 max-w-xl w-full mx-auto p-4 sm:p-6 space-y-5"
      >
        {/* Verification Progress Card */}
        <div className="rounded-2xl sm:rounded-3xl bg-[#0C121E] border border-[#1E293B] p-4 sm:p-5 space-y-4 shadow-2xl relative overflow-hidden">
          <div className="pointer-events-none absolute -top-20 -right-20 w-44 h-44 bg-cyan-600/10 rounded-full blur-3xl" />

          {/* Header */}
          <div className="flex items-center justify-between gap-2 border-b border-[#1E293B]/70 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-cyan-400" />
              <h2 className="text-xs sm:text-sm font-bold text-white uppercase tracking-wider">
                Human Activity Verification
              </h2>
            </div>
            <span className="text-xs font-mono font-bold text-cyan-300">
              {isFullyVerified ? "VERIFIED (100%)" : `${Math.round((timerPercent + scrollProgress) / 2)}%`}
            </span>
          </div>

          {/* Condition 1: 15-Second Active Timer */}
          <div className="p-3.5 rounded-xl bg-[#090D16] border border-[#1E293B] space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-2 text-slate-200 font-medium">
                <Clock size={14} className={timeLeft === 0 ? "text-emerald-400" : "text-amber-400 animate-spin"} />
                <span>1. Active Security Timer</span>
              </span>
              <span className="font-mono font-bold text-xs">
                {timeLeft > 0 ? (
                  <span className="text-amber-400">[{timeLeft}s remaining]</span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                    <CheckCircle2 size={13} /> Completed
                  </span>
                )}
              </span>
            </div>
            {/* Linear Progress */}
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-1000 ease-linear rounded-full"
                style={{ width: `${timerPercent}%` }}
              />
            </div>
          </div>

          {/* Condition 2: Scroll Down Check */}
          <div className="p-3.5 rounded-xl bg-[#090D16] border border-[#1E293B] space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-2 text-slate-200 font-medium">
                <MousePointer2 size={14} className={hasScrolled ? "text-emerald-400" : "text-cyan-400 animate-bounce"} />
                <span>2. Human Scroll Check</span>
              </span>
              <span className="font-mono font-bold text-xs">
                {hasScrolled ? (
                  <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                    <CheckCircle2 size={13} /> Verified
                  </span>
                ) : (
                  <span className="text-cyan-400">Please scroll down ↓</span>
                )}
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-300 rounded-full"
                style={{ width: `${Math.max(scrollProgress, hasScrolled ? 100 : 15)}%` }}
              />
            </div>
          </div>

          {/* Content Preview Details */}
          <div className="pt-2">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#090D16] border border-[#1E293B]">
              <div className="w-12 h-16 rounded-lg bg-slate-800 border border-slate-700 overflow-hidden shrink-0 flex items-center justify-center">
                {content?.thumbnailUrl ? (
                  <img 
                    src={content.thumbnailUrl} 
                    alt={content.title} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <Film size={20} className="text-slate-500" />
                )}
              </div>
              <div className="min-w-0 flex-1 space-y-1">
                <h3 className="text-xs sm:text-sm font-bold text-white truncate">
                  {content?.title || `Loading Content (${effectiveContentId})...`}
                </h3>
                <p className="text-[11px] text-slate-400 font-mono truncate">
                  Target: {content?.category?.toUpperCase() || "DIGITAL MOVIE"}
                </p>
                <div className="flex items-center gap-2 text-[10px] text-emerald-400 font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Encrypted Link Reserved</span>
                </div>
              </div>
            </div>
          </div>

          {/* Instructions to trigger scroll */}
          <div className="text-[11.5px] text-slate-300 leading-relaxed bg-[#090D16]/60 p-3 rounded-xl border border-slate-800/80">
            <p className="font-semibold text-cyan-300 mb-1">
              নির্দেশনা (Instructions):
            </p>
            <p>
              অনুগ্রহ করে ১৫ সেকেন্ড অপেক্ষা করুন এবং নিচে স্ক্রল করে ভেরিফিকেশন কনফার্ম করুন। উভয় শর্ত পূরণ হলে স্বয়ংক্রিয়ভাবে ২য় ধাপে (Step 2) নিয়ে যাওয়া হবে।
            </p>
          </div>
        </div>

        {/* Informative Content Block to provide natural scroll depth */}
        <div className="rounded-2xl bg-[#0C121E] border border-[#1E293B] p-4 space-y-3 text-xs text-slate-300">
          <h4 className="font-bold text-white text-xs uppercase tracking-wide flex items-center gap-2">
            <ShieldCheck size={14} className="text-cyan-400" />
            <span>Anti-Bot Shield & Token Security</span>
          </h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Our multi-tier verification protects media streaming bandwidth against automated crawler scraping. Once verified, a single-use cryptographically signed session token is minted directly for your request.
          </p>
          <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[10.5px]">
            <div className="p-2 rounded-lg bg-[#090D16] border border-slate-800 text-slate-400">
              Session: <span className="text-slate-200">SHA-256</span>
            </div>
            <div className="p-2 rounded-lg bg-[#090D16] border border-slate-800 text-slate-400">
              Protocol: <span className="text-emerald-400">Handshake v2</span>
            </div>
          </div>
        </div>

        {/* Handshake CTA & Action Trigger */}
        <div className="pt-2">
          {isGeneratingToken ? (
            <div className="w-full py-3.5 px-4 rounded-xl bg-slate-800/80 border border-slate-700 text-cyan-400 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg">
              <Loader2 size={16} className="animate-spin text-cyan-400" />
              <span>Generating Secure Single-Use Token...</span>
            </div>
          ) : tokenGenerated ? (
            <div className="space-y-2">
              <div className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(16,185,129,0.35)] animate-in zoom-in-95">
                <CheckCircle2 size={16} />
                <span>Handshake Complete! Redirecting to Step 2...</span>
              </div>
              <p className="text-center text-[10.5px] font-mono text-slate-400">
                Token: <span className="text-cyan-300">{tokenGenerated.substring(0, 16)}...</span>
              </p>
            </div>
          ) : !isFullyVerified ? (
            <button
              type="button"
              disabled
              className="w-full py-3.5 px-4 rounded-xl bg-slate-800/60 border border-slate-700/50 text-slate-500 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-not-allowed select-none"
            >
              <LockStateIndicator timeLeft={timeLeft} hasScrolled={hasScrolled} />
            </button>
          ) : (
            <button
              type="button"
              onClick={executeTokenHandshake}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(6,182,212,0.35)] active:scale-[0.98] transition cursor-pointer"
            >
              <span>Continue to 2nd Verification Website</span>
              <ArrowRight size={16} />
            </button>
          )}

          {redirectError && (
            <div className="mt-2 p-2.5 rounded-xl bg-red-950/80 border border-red-500/40 text-red-200 text-xs text-center">
              {redirectError}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1E293B] py-3 text-center text-[11px] font-mono text-slate-500">
        Phase 2 Verification Handshake • Encrypted Token System
      </footer>
    </div>
  );
}

function LockStateIndicator({ timeLeft, hasScrolled }: { timeLeft: number; hasScrolled: boolean }) {
  if (timeLeft > 0 && !hasScrolled) {
    return <span>Wait [{timeLeft}s] & Scroll Down to Unlock</span>;
  }
  if (timeLeft > 0) {
    return <span>Waiting for Security Timer... ({timeLeft}s)</span>;
  }
  return <span>Scroll Down to Complete Human Check</span>;
}
