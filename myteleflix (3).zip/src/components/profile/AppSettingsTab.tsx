/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  ShieldCheck, 
  ShieldAlert,
  Cpu, 
  Info, 
  Copy, 
  Check, 
  RefreshCw, 
  ExternalLink,
  Tv,
  X,
  Globe,
  ChevronRight,
  LogOut,
  Loader2
} from "lucide-react";
import PrivacyModal from "../PrivacyModal";
import PlatformPolicyModal from "../PlatformPolicyModal";
import { AppLanguage } from "../../types";
import { LANGUAGE_OPTIONS, getStoredLanguage, setStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../../utils/translations";

interface AppSettingsTabProps {
  isGuest: boolean;
  isAdultUnlocked: boolean;
  onToggleAdultUnlock?: (unlocked: boolean) => void;
  hwid: string;
  onOpenPrivacyModal?: () => void;
  currentLanguage?: AppLanguage;
  onLanguageChange?: (lang: AppLanguage) => void;
  onLogout?: () => void;
}

export default function AppSettingsTab({
  isGuest,
  isAdultUnlocked,
  onToggleAdultUnlock,
  hwid,
  onOpenPrivacyModal,
  currentLanguage,
  onLanguageChange,
  onLogout
}: AppSettingsTabProps) {
  const [copiedHwid, setCopiedHwid] = useState(false);
  const [cacheCleared, setCacheCleared] = useState(false);
  const [showSafeModeModal, setShowSafeModeModal] = useState(false);
  const [showPlatformPolicyModal, setShowPlatformPolicyModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return currentLanguage || getStoredLanguage();
  });

  const handleExecuteLogout = async () => {
    if (isLoggingOut) return;
    setIsLoggingOut(true);
    try {
      if (onLogout) {
        await onLogout();
      } else {
        try {
          localStorage.removeItem("myteleflix_user");
          localStorage.removeItem("myteleflix_auth_token");
          sessionStorage.clear();
          window.location.reload();
        } catch {}
      }
    } catch (err) {
      console.warn("Logout execution notice:", err);
      try {
        localStorage.removeItem("myteleflix_user");
        localStorage.removeItem("myteleflix_auth_token");
        sessionStorage.clear();
        window.location.reload();
      } catch {}
    } finally {
      setIsLoggingOut(false);
    }
  };

  useEffect(() => {
    if (currentLanguage && currentLanguage !== activeLanguage) {
      setActiveLanguage(currentLanguage);
    }
  }, [currentLanguage]);

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
  }, []);

  const handleSelectLanguage = (lang: AppLanguage) => {
    setActiveLanguage(lang);
    setStoredLanguage(lang);
    onLanguageChange?.(lang);
    setShowLanguageModal(false);
  };

  // Stream Resolution preset
  const [streamQuality, setStreamQuality] = useState<string>(() => {
    try {
      return localStorage.getItem("myteleflix_stream_quality") || "Auto (1080p)";
    } catch {
      return "Auto (1080p)";
    }
  });

  // Preferred Audio Track
  const [preferredAudio, setPreferredAudio] = useState<string>(() => {
    try {
      return localStorage.getItem("myteleflix_preferred_audio") || "Bangla";
    } catch {
      return "Bangla";
    }
  });

  // Auto-Play Next Episode
  const [autoPlayNext, setAutoPlayNext] = useState<boolean>(() => {
    try {
      return localStorage.getItem("myteleflix_autoplay_next") !== "false";
    } catch {
      return true;
    }
  });

  // Fast-Start Playback Engine
  const [fastStartEngine, setFastStartEngine] = useState<boolean>(() => {
    try {
      return localStorage.getItem("myteleflix_faststart_engine") !== "false";
    } catch {
      return true;
    }
  });

  const handleCopyHwid = () => {
    try {
      navigator.clipboard.writeText(hwid);
      setCopiedHwid(true);
      setTimeout(() => setCopiedHwid(false), 2000);
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleSafeMode = () => {
    if (!onToggleAdultUnlock) return;
    
    // If Safe Mode is currently active (adult content is locked),
    // opening/turning OFF safe mode requires agreeing to the Content Privacy & Terms modal
    if (!isAdultUnlocked) {
      setShowSafeModeModal(true);
    } else {
      // Re-enable safe mode (lock adult content immediately)
      onToggleAdultUnlock(false);
    }
  };

  const handleConfirmSafeModeUnlock = () => {
    if (onToggleAdultUnlock) {
      onToggleAdultUnlock(true);
    }
    setShowSafeModeModal(false);
  };

  const handleQualityChange = (q: string) => {
    setStreamQuality(q);
    try {
      localStorage.setItem("myteleflix_stream_quality", q);
    } catch {}
  };

  const handleAudioChange = (a: string) => {
    setPreferredAudio(a);
    try {
      localStorage.setItem("myteleflix_preferred_audio", a);
    } catch {}
  };

  const handleToggleAutoPlay = () => {
    const next = !autoPlayNext;
    setAutoPlayNext(next);
    try {
      localStorage.setItem("myteleflix_autoplay_next", String(next));
    } catch {}
  };

  const handleToggleFastStart = () => {
    const next = !fastStartEngine;
    setFastStartEngine(next);
    try {
      localStorage.setItem("myteleflix_faststart_engine", String(next));
    } catch {}
  };

  const handleClearCache = () => {
    try {
      sessionStorage.clear();
      setCacheCleared(true);
      setTimeout(() => setCacheCleared(false), 2500);
    } catch (e) {
      console.error(e);
    }
  };

  const isSafeModeActive = !isAdultUnlocked;

  return (
    <div className="space-y-4 animate-in fade-in duration-150">
      
      {/* 1. CONTENT SAFETY & PARENTAL FILTER */}
      <div className="bg-[#0e111a] border border-[#1b2234] rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl relative overflow-hidden space-y-3.5">
        <div className="flex items-center justify-between w-full mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className="p-1.5 rounded-xl bg-slate-800/90 text-slate-300 border border-slate-700/60 shrink-0">
              <ShieldCheck size={16} />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight font-sans truncate">
                Content Safety & Parental Filter
              </h4>
              <p className="text-[11px] text-slate-400 truncate">
                Family-friendly catalog protection
              </p>
            </div>
          </div>

          <span className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap shrink-0 ${
            isSafeModeActive
              ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
              : "bg-slate-800/80 text-slate-400 border border-slate-700/50"
          }`}>
            {isSafeModeActive ? "Safe Mode Active" : "Safe Mode OFF"}
          </span>
        </div>

        {/* Safe Mode Switch Box */}
        <div className="bg-[#141824] border border-[#222a3f] rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div className="space-y-1 min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs sm:text-[13px] font-bold text-white">
                Safe Mode (Parental Filter)
              </span>
              <span className={`text-[9.5px] font-mono font-semibold px-1.5 py-0.2 rounded border ${
                isSafeModeActive
                  ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"
                  : "bg-gray-900 text-slate-400 border-gray-800"
              }`}>
                {isSafeModeActive ? "Enabled" : "Disabled"}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Filters mature and age-restricted titles from catalog feeds
            </p>
          </div>

          {/* Enhanced Modern Toggle Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={isSafeModeActive}
            onClick={handleToggleSafeMode}
            className={`w-12 h-7 rounded-full transition-colors duration-300 relative cursor-pointer shrink-0 p-1 border select-none focus:outline-none ${
              isSafeModeActive 
                ? "bg-emerald-500 border-emerald-400 shadow-sm shadow-emerald-500/20" 
                : "bg-slate-800 border-slate-700/80"
            }`}
            aria-label="Toggle Safe Mode"
          >
            <span
              className={`w-5 h-5 rounded-full shadow transition-transform duration-300 ease-out block ${
                isSafeModeActive 
                  ? "translate-x-5 bg-white shadow-emerald-950/40" 
                  : "translate-x-0 bg-slate-300"
              }`}
            />
          </button>
        </div>

        {/* 1B. Multi-Language Switcher Setting Item (Directly below Safety Mode) */}
        <div 
          id="setting-item-language"
          onClick={() => setShowLanguageModal(true)}
          role="button"
          tabIndex={0}
          className="bg-[#141824] hover:bg-[#192030] active:bg-[#1f283d] border border-[#222a3f] hover:border-indigo-500/50 rounded-2xl p-3.5 flex items-center justify-between gap-3 transition-all duration-150 cursor-pointer select-none group"
        >
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="p-2 rounded-xl bg-indigo-950/70 border border-indigo-500/30 text-indigo-400 shrink-0 group-hover:scale-105 group-hover:border-indigo-400/60 transition-all">
              <Globe size={16} />
            </div>
            <div className="space-y-0.5 min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-[13px] font-bold text-white truncate">
                  Language / ভাষা
                </span>
                <span className="text-[9.5px] font-mono font-semibold px-2 py-0.5 rounded-full border bg-indigo-500/15 text-indigo-300 border-indigo-500/40 shrink-0">
                  {activeLanguage}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                {activeLanguage === 'বাংলা' ? 'অ্যাপের ভাষা নির্বাচন (English, বাংলা, हिंदी)' : activeLanguage === 'हिंदी' ? 'ऐप की भाषा चयन (English, বাংলা, हिंदी)' : 'Select app interface language (English, বাংলা, हिंदी)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 text-slate-400 group-hover:text-white">
            <span className="text-xs font-mono font-medium text-indigo-300 hidden sm:inline">
              {activeLanguage}
            </span>
            <ChevronRight size={16} className="text-slate-400 group-hover:translate-x-0.5 group-hover:text-indigo-400 transition-all" />
          </div>
        </div>

        <p className="text-[10.5px] text-slate-400 leading-relaxed pl-0.5">
          Note: Disabling Safe Mode reveals unrestricted titles and requires age acknowledgment
        </p>
      </div>

      {/* 2. PLAYER & STREAM PREFERENCES */}
      <div className="bg-[#0e111a] border border-[#1b2234] rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-slate-800/90 text-slate-300 border border-slate-700/60">
            <Tv size={16} />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight font-sans">
              Player & Stream Preferences
            </h4>
            <p className="text-[11px] text-slate-400">
              Quality, audio tracks, and playback behavior
            </p>
          </div>
        </div>

        {/* Resolution Selector */}
        <div className="space-y-2">
          <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
            Default Stream Resolution
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: "Auto (1080p)", label: "Auto (1080p)" },
              { id: "720p HD", label: "720p HD" },
              { id: "480p SD", label: "480p SD" },
              { id: "Data Saver", label: "Data Saver" }
            ].map((q) => (
              <button
                key={q.id}
                type="button"
                onClick={() => handleQualityChange(q.id)}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-medium transition duration-150 cursor-pointer text-center ${
                  streamQuality === q.id
                    ? "bg-[#1E2538] text-white border border-slate-600 shadow-sm"
                    : "bg-[#141824] hover:bg-[#1A2030] text-slate-400 border border-[#222a3f]"
                }`}
              >
                {q.label}
              </button>
            ))}
          </div>
        </div>

        {/* Preferred Audio Track */}
        <div className="space-y-2">
          <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
            Preferred Audio Track
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: "Bangla", label: "Bangla" },
              { id: "Hindi", label: "Hindi" },
              { id: "English", label: "English" }
            ].map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => handleAudioChange(a.id)}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-medium transition duration-150 cursor-pointer text-center ${
                  preferredAudio === a.id
                    ? "bg-[#1E2538] text-white border border-slate-600 shadow-sm"
                    : "bg-[#141824] hover:bg-[#1A2030] text-slate-400 border border-[#222a3f]"
                }`}
              >
                {a.label}
              </button>
            ))}
          </div>
        </div>

        {/* Auto-Play Next Episode */}
        <div className="bg-[#141824] border border-[#222a3f] rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div>
            <span className="text-xs sm:text-[13px] font-bold text-white block">
              Auto-Play Next Episode
            </span>
            <span className="text-[11px] text-slate-400">
              Automatically start subsequent series episodes
            </span>
          </div>

          {/* Organic & Dimmed Native Toggle Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={autoPlayNext}
            onClick={handleToggleAutoPlay}
            className={`w-12 h-7 rounded-full transition-colors duration-200 relative cursor-pointer shrink-0 p-1 border select-none focus:outline-none ${
              autoPlayNext 
                ? "bg-slate-700 border-slate-600/80" 
                : "bg-gray-800/80 border-gray-700/60"
            }`}
            aria-label="Toggle Auto-Play"
          >
            <span
              className={`w-5 h-5 rounded-full shadow-sm transition-transform duration-200 ease-out block ${
                autoPlayNext 
                  ? "translate-x-5 bg-slate-100" 
                  : "translate-x-0 bg-slate-400"
              }`}
            />
          </button>
        </div>

        {/* Fast-Start Engine */}
        <div className="bg-[#141824] border border-[#222a3f] rounded-2xl p-3.5 flex items-center justify-between gap-3">
          <div>
            <span className="text-xs sm:text-[13px] font-bold text-white block">
              Fast-Start Playback Engine
            </span>
            <span className="text-[11px] text-slate-400">
              Optimized chunk buffering for mobile networks
            </span>
          </div>

          {/* Organic & Dimmed Native Toggle Switch */}
          <button
            type="button"
            role="switch"
            aria-checked={fastStartEngine}
            onClick={handleToggleFastStart}
            className={`w-12 h-7 rounded-full transition-colors duration-200 relative cursor-pointer shrink-0 p-1 border select-none focus:outline-none ${
              fastStartEngine 
                ? "bg-slate-700 border-slate-600/80" 
                : "bg-gray-800/80 border-gray-700/60"
            }`}
            aria-label="Toggle Fast Start Playback"
          >
            <span
              className={`w-5 h-5 rounded-full shadow-sm transition-transform duration-200 ease-out block ${
                fastStartEngine 
                  ? "translate-x-5 bg-slate-100" 
                  : "translate-x-0 bg-slate-400"
              }`}
            />
          </button>
        </div>
      </div>

      {/* 3. HARDWARE & DEVICE SECURITY */}
      <div className="bg-[#0e111a] border border-[#1b2234] rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-slate-800/90 text-slate-300 border border-slate-700/60">
            <Cpu size={16} />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight font-sans">
              Hardware & Device Security
            </h4>
            <p className="text-[11px] text-slate-400">
              Device binding and anti-sybil enforcement
            </p>
          </div>
        </div>

        <div className="bg-[#141824] border border-[#222a3f] rounded-2xl p-3.5 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-300 font-mono">Hardware ID</span>
            <button
              type="button"
              onClick={handleCopyHwid}
              className="inline-flex items-center gap-1.5 text-xs font-mono font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 px-2 py-1 rounded-lg transition active:scale-95 cursor-pointer"
            >
              <span>{hwid.slice(0, 16)}...</span>
              {copiedHwid ? <Check size={12} className="text-emerald-400 stroke-[3]" /> : <Copy size={12} />}
            </button>
          </div>

          <div className="flex items-center justify-between text-xs pt-1 border-t border-[#1e2538]">
            <span className="text-slate-400">Anti-Sybil Engine</span>
            <span className="font-mono text-slate-300 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              Active (Hardware Bound)
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1 border-t border-[#1e2538]">
            <span className="text-slate-400">Profile Status</span>
            <span className="font-mono font-medium text-slate-300">
              {isGuest ? "Guest Mode" : "VIP Authenticated"}
            </span>
          </div>
        </div>
      </div>

      {/* 4. SYSTEM & APPLICATION INFO */}
      <div className="bg-[#0e111a] border border-[#1b2234] rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-slate-800/90 text-slate-300 border border-slate-700/60">
            <Info size={16} />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight font-sans">
              System & Application Info
            </h4>
            <p className="text-[11px] text-slate-400">
              Version, policy compliance, and cache control
            </p>
          </div>
        </div>

        <div className="bg-[#141824] border border-[#222a3f] rounded-2xl p-3.5 space-y-2.5 text-xs font-mono">
          <div className="flex items-center justify-between">
            <span className="text-slate-400">Application Core</span>
            <span className="text-slate-200 font-bold">My TeleFlix v3.2.0</span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-[#1e2538]">
            <span className="text-slate-400">Platform & Usage Policy</span>
            <button
              type="button"
              onClick={() => {
                if (onOpenPrivacyModal) {
                  onOpenPrivacyModal();
                } else {
                  setShowPlatformPolicyModal(true);
                }
              }}
              className="text-slate-300 hover:text-white underline inline-flex items-center gap-1 cursor-pointer"
            >
              <span>View Policy</span>
              <ExternalLink size={11} />
            </button>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-[#1e2538]">
            <div>
              <span className="text-slate-300 block font-sans font-bold">Local Storage Cache</span>
              <span className="text-[10px] text-slate-500 block font-sans">Clear local streaming buffer cache</span>
            </div>
            <button
              type="button"
              onClick={handleClearCache}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-mono font-medium transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              {cacheCleared ? (
                <>
                  <Check size={12} className="text-emerald-400" />
                  <span className="text-emerald-400">Cleared</span>
                </>
              ) : (
                <>
                  <RefreshCw size={12} />
                  <span>Clear Cache</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 5. ACCOUNT SIGN OUT & SESSION (DISCREET BOTTOM SECTION) */}
      {onLogout && (
        <div className="bg-[#0e111a] border border-rose-950/40 rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-rose-950/60 text-rose-400 border border-rose-800/50">
                <LogOut size={16} />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight font-sans">
                  {activeLanguage === 'বাংলা' ? 'লগ আউট ও সেশন' : activeLanguage === 'हिंदी' ? 'लॉग आउट' : 'Account Sign Out'}
                </h4>
                <p className="text-[11px] text-slate-400">
                  {activeLanguage === 'বাংলা' ? 'এই ডিভাইস থেকে সুরক্ষিতভাবে অ্যাকাউন্ট লগ আউট করুন' : activeLanguage === 'हिंदी' ? 'इस डिवाइस से सुरक्षित रूप से लॉग आउट करें' : 'Safely sign out of your account on this device'}
                </p>
              </div>
            </div>

            <button
              type="button"
              id="btn-appsettings-logout"
              disabled={isLoggingOut}
              onClick={handleExecuteLogout}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-rose-700 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold font-sans text-xs transition flex items-center gap-2 cursor-pointer active:scale-95 shadow-md shadow-rose-950/60 shrink-0 select-none border border-rose-500/50"
            >
              {isLoggingOut ? (
                <>
                  <Loader2 size={14} className="animate-spin text-white" />
                  <span>{activeLanguage === 'বাংলা' ? 'লগ আউট হচ্ছে...' : activeLanguage === 'हिंदी' ? 'लॉग आउट...' : 'Signing out...'}</span>
                </>
              ) : (
                <>
                  <LogOut size={14} className="text-white" />
                  <span>{activeLanguage === 'বাংলা' ? 'লগ আউট' : activeLanguage === 'हिंदी' ? 'लॉग आउट' : 'Sign Out'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* 1. MULTI-SECTION CONTENT PRIVACY & TERMS MODAL FOR SAFE MODE DEACTIVATION */}
      {showSafeModeModal && (
        <PrivacyModal
          isOpen={showSafeModeModal}
          onClose={() => setShowSafeModeModal(false)}
          onConfirm={handleConfirmSafeModeUnlock}
          initialTab="verify"
        />
      )}

      {/* 2. COMPREHENSIVE PLATFORM & USAGE POLICY MODAL */}
      {showPlatformPolicyModal && (
        <PlatformPolicyModal
          isOpen={showPlatformPolicyModal}
          onClose={() => setShowPlatformPolicyModal(false)}
        />
      )}

      {/* 3. SLEEK 3-LANGUAGE SELECTOR MODAL */}
      {showLanguageModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setShowLanguageModal(false)}
        >
          <div 
            className="w-full max-w-sm bg-[#0e121c] border border-[#222a3f] rounded-3xl p-5 shadow-2xl relative space-y-4 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-950/70 border border-indigo-500/40 text-indigo-400">
                  <Globe size={18} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white font-sans">
                    Language / ভাষা / भाषा
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Instant interface translation
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowLanguageModal(false)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2 pt-1">
              {LANGUAGE_OPTIONS.map((opt) => {
                const isSelected = activeLanguage === opt.code;
                return (
                  <button
                    key={opt.code}
                    type="button"
                    onClick={() => handleSelectLanguage(opt.code)}
                    className={`w-full p-3.5 rounded-2xl border flex items-center justify-between transition-all duration-150 cursor-pointer active:scale-[0.98] select-none text-left ${
                      isSelected
                        ? "bg-indigo-950/50 border-indigo-500/80 shadow-md shadow-indigo-950/50 ring-1 ring-indigo-500/50"
                        : "bg-[#141824] hover:bg-[#1a2030] border-[#222a3f] hover:border-slate-600/80"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl shrink-0" role="img" aria-label={opt.label}>
                        {opt.flag}
                      </span>
                      <div>
                        <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                          <span>{opt.label}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {opt.native}
                        </span>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                        <Check size={14} strokeWidth={2.5} />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="pt-1 text-center">
              <p className="text-[10px] text-slate-500 font-mono">
                Preference saved in local storage & synced instantly
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
