/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

export function Male3DAvatar({ className = "w-full h-full", size }: { className?: string; size?: number }) {
  return (
    <svg 
      viewBox="0 0 120 120" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      width={size}
      height={size}
    >
      <defs>
        <radialGradient id="maleBg" cx="60" cy="40" r="60" gradientUnits="userSpaceOnUse">
          <stop stopColor="#38BDF8" />
          <stop offset="0.45" stopColor="#2563EB" />
          <stop offset="1" stopColor="#0F172A" />
        </radialGradient>
        <linearGradient id="maleSkin" x1="60" y1="35" x2="60" y2="85" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FBD5B5" />
          <stop offset="0.8" stopColor="#F2A97F" />
          <stop offset="1" stopColor="#D98256" />
        </linearGradient>
        <linearGradient id="maleHair" x1="35" y1="15" x2="85" y2="55" gradientUnits="userSpaceOnUse">
          <stop stopColor="#334155" />
          <stop offset="0.5" stopColor="#1E293B" />
          <stop offset="1" stopColor="#0F172A" />
        </linearGradient>
        <linearGradient id="maleHairHighlight" x1="45" y1="18" x2="70" y2="28" gradientUnits="userSpaceOnUse">
          <stop stopColor="#64748B" />
          <stop offset="1" stopColor="#334155" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="maleTorso" x1="60" y1="82" x2="60" y2="120" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E293B" />
          <stop offset="0.5" stopColor="#0F172A" />
          <stop offset="1" stopColor="#020617" />
        </linearGradient>
        <linearGradient id="maleHoodie" x1="30" y1="85" x2="90" y2="120" gradientUnits="userSpaceOnUse">
          <stop stopColor="#2563EB" />
          <stop offset="1" stopColor="#1D4ED8" />
        </linearGradient>
        <filter id="maleShadow" x="-10%" y="-10%" width="130%" height="130%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.3" />
        </filter>
      </defs>

      {/* Background Circle / Base */}
      <rect width="120" height="120" rx="28" fill="url(#maleBg)" />

      {/* Torso & Outer Jacket */}
      <path 
        d="M20 120 C20 95 38 84 60 84 C82 84 100 95 100 120 Z" 
        fill="url(#maleHoodie)" 
      />
      {/* Inner Shirt / V-Neck */}
      <path 
        d="M48 85 L60 102 L72 85 C68 88 52 88 48 85 Z" 
        fill="url(#maleTorso)" 
      />

      {/* Neck with 3D Shadow */}
      <path d="M50 72 C50 78 70 78 70 72 L70 86 L50 86 Z" fill="#D98256" />
      <path d="M50 74 C58 79 62 79 70 74 L70 78 C62 82 58 82 50 78 Z" fill="#B8663D" opacity="0.6" />

      {/* Ears with Inner Depth */}
      <ellipse cx="37" cy="55" rx="5" ry="7" fill="#F2A97F" />
      <ellipse cx="37.5" cy="55" rx="3" ry="4" fill="#D98256" opacity="0.6" />
      <ellipse cx="83" cy="55" rx="5" ry="7" fill="#F2A97F" />
      <ellipse cx="82.5" cy="55" rx="3" ry="4" fill="#D98256" opacity="0.6" />

      {/* Head / Face Oval */}
      <g filter="url(#maleShadow)">
        <path 
          d="M38 50 C38 34 82 34 82 50 C82 66 74 76 60 76 C46 76 38 66 38 50 Z" 
          fill="url(#maleSkin)" 
        />
      </g>

      {/* Stylized Eyebrows */}
      <path d="M46 46 Q51 44 55 46" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M65 46 Q69 44 74 46" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" />

      {/* Eyes with Specular Sparkle */}
      <circle cx="50.5" cy="52" r="3" fill="#0F172A" />
      <circle cx="51.5" cy="51" r="1" fill="#FFFFFF" />
      <circle cx="69.5" cy="52" r="3" fill="#0F172A" />
      <circle cx="70.5" cy="51" r="1" fill="#FFFFFF" />

      {/* Subtle Nose */}
      <path d="M58 53 Q60 59 62 59" stroke="#D98256" strokeWidth="1.8" strokeLinecap="round" fill="none" />

      {/* Warm Confident Smile */}
      <path d="M54 64 Q60 69 66 64" stroke="#A84C27" strokeWidth="2.2" strokeLinecap="round" fill="none" />

      {/* 3D Modern Layered Haircut */}
      <path 
        d="M36 48 C34 30 45 20 60 18 C78 18 86 28 84 46 C81 37 76 32 68 32 C58 32 52 38 46 36 C42 35 38 42 36 48 Z" 
        fill="url(#maleHair)" 
      />
      {/* Top Hair Highlight Arc */}
      <path 
        d="M44 24 C50 20 66 20 74 25 C68 22 52 22 44 24 Z" 
        fill="url(#maleHairHighlight)" 
      />
    </svg>
  );
}

export function Female3DAvatar({ className = "w-full h-full", size }: { className?: string; size?: number }) {
  return (
    <svg 
      viewBox="0 0 120 120" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      width={size}
      height={size}
    >
      <defs>
        <radialGradient id="femaleBg" cx="60" cy="40" r="60" gradientUnits="userSpaceOnUse">
          <stop stopColor="#F472B6" />
          <stop offset="0.45" stopColor="#C026D3" />
          <stop offset="1" stopColor="#4A044E" />
        </radialGradient>
        <linearGradient id="femaleSkin" x1="60" y1="35" x2="60" y2="85" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFE0CC" />
          <stop offset="0.8" stopColor="#F7BFA0" />
          <stop offset="1" stopColor="#E6997A" />
        </linearGradient>
        <linearGradient id="femaleHair" x1="30" y1="15" x2="90" y2="90" gradientUnits="userSpaceOnUse">
          <stop stopColor="#4A2810" />
          <stop offset="0.6" stopColor="#2A1408" />
          <stop offset="1" stopColor="#180A04" />
        </linearGradient>
        <linearGradient id="femaleHairHighlight" x1="40" y1="16" x2="80" y2="30" gradientUnits="userSpaceOnUse">
          <stop stopColor="#8D5B3A" />
          <stop offset="1" stopColor="#4A2810" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="femaleDress" x1="60" y1="84" x2="60" y2="120" gradientUnits="userSpaceOnUse">
          <stop stopColor="#EC4899" />
          <stop offset="0.6" stopColor="#BE185D" />
          <stop offset="1" stopColor="#831843" />
        </linearGradient>
        <filter id="femaleShadow" x="-10%" y="-10%" width="130%" height="130%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.3" />
        </filter>
      </defs>

      {/* Background Base */}
      <rect width="120" height="120" rx="28" fill="url(#femaleBg)" />

      {/* Back Flowing Hair Silhouette */}
      <path 
        d="M30 46 C26 70 28 95 36 108 C38 98 42 86 42 75 L78 75 C78 86 82 98 84 108 C92 95 94 70 90 46 Z" 
        fill="url(#femaleHair)" 
      />

      {/* Torso & Elegant Dress */}
      <path 
        d="M24 120 C24 96 40 85 60 85 C80 85 96 96 96 120 Z" 
        fill="url(#femaleDress)" 
      />

      {/* Graceful Neck */}
      <path d="M52 70 C52 78 68 78 68 70 L68 85 L52 85 Z" fill="#E6997A" />
      <path d="M52 74 C58 78 62 78 68 74 L68 77 C62 80 58 80 52 77 Z" fill="#C47353" opacity="0.5" />

      {/* Golden Pendant/Necklace */}
      <path d="M54 84 Q60 90 66 84" stroke="#FBBF24" strokeWidth="1.5" fill="none" />
      <circle cx="60" cy="89" r="1.8" fill="#F59E0B" />

      {/* Delicate Earrings */}
      <circle cx="36" cy="62" r="2.5" fill="#FBBF24" />
      <circle cx="84" cy="62" r="2.5" fill="#FBBF24" />

      {/* Head / Face */}
      <g filter="url(#femaleShadow)">
        <path 
          d="M38 48 C38 34 82 34 82 48 C82 65 72 74 60 74 C48 74 38 65 38 48 Z" 
          fill="url(#femaleSkin)" 
        />
      </g>

      {/* Soft Rosy Cheeks */}
      <circle cx="44" cy="60" r="4.5" fill="#F43F5E" opacity="0.25" />
      <circle cx="76" cy="60" r="4.5" fill="#F43F5E" opacity="0.25" />

      {/* Curved Elegant Eyebrows */}
      <path d="M46 45 Q51 42 55 45" stroke="#331A0D" strokeWidth="1.8" strokeLinecap="round" fill="none" />
      <path d="M65 45 Q69 42 74 45" stroke="#331A0D" strokeWidth="1.8" strokeLinecap="round" fill="none" />

      {/* Eyes with Lashes & Specular Highlights */}
      <ellipse cx="50.5" cy="51" rx="3.2" ry="3.5" fill="#1F1008" />
      <circle cx="51.5" cy="50" r="1.2" fill="#FFFFFF" />
      <path d="M47 48 L45 46" stroke="#1F1008" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M53 47.5 L55 46" stroke="#1F1008" strokeWidth="1.2" strokeLinecap="round" />

      <ellipse cx="69.5" cy="51" rx="3.2" ry="3.5" fill="#1F1008" />
      <circle cx="70.5" cy="50" r="1.2" fill="#FFFFFF" />
      <path d="M67 47.5 L65 46" stroke="#1F1008" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M73 48 L75 46" stroke="#1F1008" strokeWidth="1.2" strokeLinecap="round" />

      {/* Delicate Nose */}
      <path d="M59 52 Q60 57 61 57" stroke="#E6997A" strokeWidth="1.5" strokeLinecap="round" fill="none" />

      {/* Sweet Lip Tint / Smile */}
      <path d="M54 63 Q60 67 66 63" stroke="#E11D48" strokeWidth="2.5" strokeLinecap="round" fill="none" />
      <path d="M56 64 Q60 66 64 64" stroke="#FDA4AF" strokeWidth="1" strokeLinecap="round" fill="none" />

      {/* Luxurious 3D Front Hairstyle with Side Parting */}
      <path 
        d="M36 46 C34 26 48 18 60 18 C76 18 86 26 84 46 C80 34 72 26 58 26 C46 26 40 34 36 46 Z" 
        fill="url(#femaleHair)" 
      />
      {/* Hair Volume Sweep */}
      <path 
        d="M36 42 C40 30 52 24 64 24 C50 25 42 34 38 46 Z" 
        fill="url(#femaleHairHighlight)" 
      />
      {/* Side Strand Wave */}
      <path 
        d="M84 44 C81 55 83 68 85 76 C87 68 87 55 84 44 Z" 
        fill="url(#femaleHair)" 
      />
    </svg>
  );
}

export function Gender3DAvatar({
  gender,
  className = "w-full h-full",
  size
}: {
  gender?: string;
  className?: string;
  size?: number;
}) {
  const isFemale = (gender || '').toLowerCase() === 'female';
  if (isFemale) {
    return <Female3DAvatar className={className} size={size} />;
  }
  return <Male3DAvatar className={className} size={size} />;
}
