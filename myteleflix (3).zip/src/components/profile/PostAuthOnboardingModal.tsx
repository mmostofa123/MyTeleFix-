/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { 
  Crown, 
  CheckCircle2, 
  Sparkles, 
  ArrowRight, 
  ArrowLeft,
  Users, 
  Loader2, 
  User as UserIcon,
  ShieldCheck,
  Send,
  Check,
  AlertCircle
} from "lucide-react";
import { User } from "../../types";
import { saveUserToFirestore } from "../../services/firebase";
import { Gender3DAvatar } from "./Gender3DAvatar";

interface PostAuthOnboardingModalProps {
  isOpen: boolean;
  user: User;
  onComplete?: (updatedData: { 
    displayName: string; 
    gender: 'Male' | 'Female' | 'male' | 'female';
    telegramUsername?: string;
    isProfileCompleted?: boolean;
  }) => Promise<void> | void;
  onClose?: () => void;
}

// Strict client-side validation for Telegram username
function validateTelegramHandle(handle: string): { valid: boolean; error?: string } {
  const trimmed = handle.trim();
  if (!trimmed || trimmed === "@") {
    return { valid: false, error: "Please enter your Telegram username (e.g., @username)." };
  }
  if (!trimmed.startsWith('@')) {
    return { valid: false, error: "Telegram username must start with '@' (e.g., @username)." };
  }
  const body = trimmed.slice(1);
  if (body.length < 3) {
    return { valid: false, error: "Telegram username must be at least 3 characters long." };
  }
  if (body.length > 32) {
    return { valid: false, error: "Telegram username cannot exceed 32 characters." };
  }
  if (!/^[a-zA-Z0-9_]+$/.test(body)) {
    return { valid: false, error: "Telegram handle can only contain letters, numbers, and underscores." };
  }
  return { valid: true };
}

export default function PostAuthOnboardingModal({
  isOpen,
  user,
  onComplete,
  onClose
}: PostAuthOnboardingModalProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [displayName, setDisplayName] = useState<string>(() => {
    return user.displayName || user.fullName || user.email?.split('@')[0] || "VIP Member";
  });
  const [gender, setGender] = useState<'male' | 'female'>(() => {
    const g = (user.gender || '').toLowerCase();
    return g === 'female' ? 'female' : 'male';
  });
  const [telegramHandle, setTelegramHandle] = useState<string>(() => {
    if (user.telegramUsername) {
      return user.telegramUsername.startsWith('@') ? user.telegramUsername : `@${user.telegramUsername}`;
    }
    if (user.username && !user.username.startsWith('user_') && !user.username.startsWith('guest_')) {
      return user.username.startsWith('@') ? user.username : `@${user.username}`;
    }
    return "@";
  });
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [step1Error, setStep1Error] = useState<string | null>(null);
  const [telegramError, setTelegramError] = useState<string | null>(null);
  const [isLocallyDismissed, setIsLocallyDismissed] = useState<boolean>(false);

  // Permanent completion check: if already completed in DB or localStorage, NEVER pop up
  const isAlreadyPermanentlyCompleted = useMemo(() => {
    if (isLocallyDismissed) return true;
    if (user?.isProfileCompleted === true) return true;
    if (typeof window !== "undefined") {
      if (localStorage.getItem("myteleflix_isProfileCompleted") === "true") return true;
      if (user?.id && localStorage.getItem(`myteleflix_profile_completed_${user.id}`) === "true") return true;
      if (user?.id && localStorage.getItem(`myteleflix_onboarding_${user.id}`) === "true") return true;
    }
    return false;
  }, [isLocallyDismissed, user?.isProfileCompleted, user?.id]);

  if (!isOpen || isAlreadyPermanentlyCompleted) return null;

  const handleTelegramInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.trim();
    // Maintain @ prefix automatically for smooth user experience
    if (val && !val.startsWith('@')) {
      val = '@' + val;
    }
    setTelegramHandle(val);

    if (val.length > 1) {
      const check = validateTelegramHandle(val);
      if (check.valid) {
        setTelegramError(null);
      }
    } else {
      setTelegramError(null);
    }
  };

  // Step 1: Validate Display Name & Advance to Step 2
  const handleProceedToStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = displayName.trim();
    if (!cleanName) {
      setStep1Error("Please enter a valid display name.");
      return;
    }
    setStep1Error(null);
    setStep(2);
  };

  // Step 2: Validate Telegram Handle & Permanently Commit to Database and LocalStorage
  const handleFinishAndSave = async (e: React.FormEvent) => {
    e.preventDefault();

    const valResult = validateTelegramHandle(telegramHandle);
    if (!valResult.valid) {
      setTelegramError(valResult.error || "Please enter a valid Telegram username starting with '@'.");
      return;
    }

    try {
      setIsSaving(true);
      setTelegramError(null);

      const cleanName = displayName.trim();
      const chosenGender = gender === 'female' ? 'Female' : 'Male';
      const cleanTelegram = telegramHandle.trim();
      const cleanUsername = cleanTelegram.startsWith('@') ? cleanTelegram.slice(1) : cleanTelegram;

      // 1. Build comprehensive user document
      const updatedUserObj: User = {
        ...user,
        displayName: cleanName,
        fullName: cleanName,
        gender: chosenGender,
        telegramUsername: cleanTelegram,
        username: cleanUsername || user.username || cleanName,
        isProfileCompleted: true,
        isOnboarded: true,
        profileInitialized: true,
        last_active_at: new Date().toISOString()
      };

      // 2. Commit directly to Firestore user database collection (users/{uid})
      try {
        await saveUserToFirestore(updatedUserObj);
      } catch (firestoreErr) {
        console.warn("Notice saving user to Firestore in onboarding modal:", firestoreErr);
      }

      // 3. Permanent Save to localStorage with one-time permanent completion flags
      try {
        localStorage.setItem("myteleflix_user", JSON.stringify(updatedUserObj));
        localStorage.setItem("myteleflix_isProfileCompleted", "true");
        localStorage.setItem("isProfileCompleted", "true");
        localStorage.setItem(`myteleflix_profile_completed_${user.id}`, "true");
        localStorage.setItem("myteleflix_onboarding_completed", "true");
        localStorage.setItem(`myteleflix_onboarding_${user.id}`, "true");
      } catch (storageErr) {
        console.warn("Notice updating localStorage in onboarding modal:", storageErr);
      }

      // 4. Sync with server backend endpoint if available
      fetch("/api/auth/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          displayName: cleanName,
          gender: chosenGender,
          telegramUsername: cleanTelegram,
          username: cleanUsername,
          isProfileCompleted: true,
          isOnboarded: true,
          profileInitialized: true
        })
      }).catch(() => {});

      // 5. Notify parent component via onComplete
      if (onComplete) {
        try {
          await onComplete({
            displayName: cleanName,
            gender: chosenGender,
            telegramUsername: cleanTelegram,
            isProfileCompleted: true
          });
        } catch (callbackErr) {
          console.warn("Notice calling onComplete in onboarding modal:", callbackErr);
        }
      }

      // 6. Dismiss modal forever
      setIsLocallyDismissed(true);
      if (onClose) {
        onClose();
      }
    } catch (err: any) {
      console.error("Failed to finalize onboarding:", err);
      setTelegramError(err.message || "Failed to save profile. Please try again.");
    } finally {
      setIsSaving(false);
    }
  };

  const isTelegramValidNow = validateTelegramHandle(telegramHandle).valid;

  return (
    <div 
      id="post-auth-onboarding-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
    >
      <div 
        id="post-auth-onboarding-card"
        className="w-full max-w-md bg-gradient-to-b from-[#131724] via-[#0E121E] to-[#0A0D15] border border-[#242C44] rounded-2xl sm:rounded-3xl shadow-2xl p-5 sm:p-6 text-white relative overflow-hidden my-auto"
      >
        {/* Subtle Ambient Glows */}
        <div className="absolute top-0 right-0 w-48 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-32 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* STEP 1: Profile Setup */}
        {step === 1 && (
          <form onSubmit={handleProceedToStep2} className="space-y-4 relative z-10">
            {/* Header */}
            <div className="text-center space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold tracking-wider uppercase">
                <Crown size={12} className="text-amber-400" />
                <span>STEP 1 / 2 • PROFILE SETUP</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Complete Your VIP Profile
              </h2>
              <p className="text-xs text-slate-300 font-normal leading-relaxed max-w-xs mx-auto">
                Customize your display identity to unlock your verified membership perks.
              </p>
            </div>

            {/* Profile Avatar Preview */}
            <div className="flex justify-center pt-1">
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-slate-900 border-2 border-amber-500/60 shadow-lg shadow-amber-950/40 flex items-center justify-center">
                  {user.photoUrl || user.photoURL ? (
                    <img 
                      src={user.photoUrl || user.photoURL} 
                      alt={displayName} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <UserIcon size={28} className="text-slate-400" />
                  )}
                </div>
                <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 rounded-full p-1 shadow">
                  <Sparkles size={10} className="fill-slate-950" />
                </div>
              </div>
            </div>

            {/* Error Message */}
            {step1Error && (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-mono flex items-center gap-2">
                <AlertCircle size={14} className="shrink-0" />
                <span>{step1Error}</span>
              </div>
            )}

            {/* Display Name Input */}
            <div className="space-y-1.5">
              <label 
                htmlFor="onboarding-display-name" 
                className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider block"
              >
                Enter Your Name
              </label>
              <div className="relative">
                <input
                  id="onboarding-display-name"
                  type="text"
                  maxLength={30}
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Enter Your Name"
                  className="w-full bg-[#161B2B] border border-[#252E47] focus:border-amber-400 rounded-xl px-3.5 py-2.5 text-sm text-white font-medium placeholder-slate-500 outline-none transition"
                  required
                />
              </div>
              <span className="text-[10.5px] text-slate-400 block font-mono">
                Your public VIP profile identity across TeleFlix.
              </span>
            </div>

            {/* Gender Selector Buttons */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider block">
                Select Gender
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  id="onboarding-gender-male"
                  onClick={() => setGender('male')}
                  className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 font-mono text-xs font-bold transition cursor-pointer active:scale-98 ${
                    gender === 'male'
                      ? "bg-blue-600/30 border-blue-500 text-blue-300 shadow-md shadow-blue-950/40"
                      : "bg-[#161B2B] border-[#252E47] text-slate-400 hover:text-slate-200 hover:border-slate-600"
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${gender === 'male' ? 'bg-blue-400' : 'bg-slate-600'}`} />
                  <span>Male</span>
                </button>

                <button
                  type="button"
                  id="onboarding-gender-female"
                  onClick={() => setGender('female')}
                  className={`py-2.5 px-3 rounded-xl border flex items-center justify-center gap-2 font-mono text-xs font-bold transition cursor-pointer active:scale-98 ${
                    gender === 'female'
                      ? "bg-pink-600/30 border-pink-500 text-pink-300 shadow-md shadow-pink-950/40"
                      : "bg-[#161B2B] border-[#252E47] text-slate-400 hover:text-slate-200 hover:border-slate-600"
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${gender === 'female' ? 'bg-pink-400' : 'bg-slate-600'}`} />
                  <span>Female</span>
                </button>
              </div>
            </div>

            {/* Next: Step 2 Button */}
            <div className="pt-2">
              <button
                id="onboarding-step1-continue-btn"
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:brightness-110 active:brightness-95 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-950/40 transition cursor-pointer"
              >
                <span>Continue to Step 2</span>
                <ArrowRight size={15} />
              </button>
            </div>
          </form>
        )}

        {/* STEP 2: Telegram Username Integration & Final Save */}
        {step === 2 && (
          <form onSubmit={handleFinishAndSave} className="space-y-4 relative z-10 animate-in fade-in slide-in-from-right-3 duration-200">
            {/* Header */}
            <div className="text-center space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold tracking-wider uppercase">
                <Send size={12} className="text-cyan-400" />
                <span>STEP 2 / 2 • TELEGRAM IDENTITY</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                Connect Telegram Identity
              </h2>
              <p className="text-xs text-slate-300 font-normal leading-relaxed max-w-xs mx-auto">
                Enter your Telegram username to connect referral rewards and verified community payouts.
              </p>
            </div>

            {/* Selected Profile Identity Badge */}
            <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-2.5 flex items-center justify-between px-3.5">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-lg overflow-hidden border border-slate-700/80 shrink-0 bg-[#0E121E]">
                  <Gender3DAvatar gender={gender} className="w-full h-full object-cover" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">{displayName}</p>
                  <p className="text-[10.5px] font-mono text-slate-400">{gender === 'female' ? 'Female' : 'Male'} VIP Member</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-[11px] font-mono text-amber-400 hover:text-amber-300 underline cursor-pointer p-1"
              >
                Edit
              </button>
            </div>

            {/* Error Message */}
            {telegramError && (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-mono flex items-center gap-2">
                <AlertCircle size={14} className="shrink-0 text-rose-400" />
                <span>{telegramError}</span>
              </div>
            )}

            {/* Telegram Username Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label 
                  htmlFor="onboarding-telegram-username" 
                  className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider block"
                >
                  Telegram Username
                </label>
                {isTelegramValidNow && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-mono text-emerald-400">
                    <Check size={12} className="stroke-[3]" />
                    <span>Valid Handle</span>
                  </span>
                )}
              </div>

              <div className="relative">
                <input
                  id="onboarding-telegram-username"
                  type="text"
                  maxLength={33}
                  value={telegramHandle}
                  onChange={handleTelegramInputChange}
                  placeholder="@username"
                  className={`w-full bg-[#161B2B] border rounded-xl px-3.5 py-2.5 text-sm text-white font-mono placeholder-slate-500 outline-none transition ${
                    isTelegramValidNow
                      ? "border-emerald-500/60 focus:border-emerald-400"
                      : telegramError
                      ? "border-rose-500/60 focus:border-rose-400"
                      : "border-[#252E47] focus:border-cyan-400"
                  }`}
                  required
                />
              </div>
              <span className="text-[10.5px] text-slate-400 block font-mono">
                Must start with @ and contain alphanumeric characters (e.g., @username).
              </span>
            </div>

            {/* Referral Connectivity Info Card */}
            <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-3 flex items-start gap-3">
              <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shrink-0 mt-0.5">
                <Users size={15} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white leading-tight">
                  Referral & Payout Connectivity
                </h4>
                <p className="text-[11px] text-slate-400 leading-tight mt-0.5 font-normal">
                  Your handle will be permanently bound to your referral code for instant affiliate tracking, automated points, and cashouts.
                </p>
              </div>
            </div>

            {/* Action Buttons: Finish / Save & Back */}
            <div className="space-y-2 pt-1">
              <button
                id="onboarding-finish-save-btn"
                type="submit"
                disabled={isSaving}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:brightness-110 active:brightness-95 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-950/40 transition cursor-pointer disabled:opacity-60"
              >
                {isSaving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    <span>Saving Profile & Identity...</span>
                  </>
                ) : (
                  <>
                    <span>Finish / Save</span>
                    <CheckCircle2 size={16} className="text-slate-950" />
                  </>
                )}
              </button>

              <button
                type="button"
                disabled={isSaving}
                onClick={() => setStep(1)}
                className="w-full py-2 text-center text-xs font-mono text-slate-400 hover:text-slate-200 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                <ArrowLeft size={13} />
                <span>Back to Step 1</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

