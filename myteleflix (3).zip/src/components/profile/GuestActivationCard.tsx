/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { 
  Lock, 
  Copy, 
  Check, 
  CreditCard, 
  Users, 
  Zap, 
  ShieldCheck, 
  Loader2,
  User as UserIcon
} from "lucide-react";

interface GuestActivationCardProps {
  onSignInClick: () => void;
  isConnectingGoogle: boolean;
  hwid: string;
  errorMessage?: string | null;
}

export default function GuestActivationCard({
  onSignInClick,
  isConnectingGoogle,
  hwid,
  errorMessage
}: GuestActivationCardProps) {
  const [copiedHwid, setCopiedHwid] = useState(false);

  const handleCopyHwid = (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      navigator.clipboard.writeText(hwid);
      setCopiedHwid(true);
      setTimeout(() => setCopiedHwid(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="bg-gradient-to-b from-[#131724] via-[#0E121E] to-[#0A0D15] border border-[#242C44] rounded-2xl sm:rounded-3xl p-4 shadow-2xl relative overflow-hidden space-y-4">
      {/* Ambient background glow */}
      <div className="absolute top-0 right-1/4 w-48 h-24 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-48 h-24 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Row */}
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-slate-800/90 border border-slate-700/60 flex items-center justify-center text-slate-300">
            <UserIcon size={16} strokeWidth={2.2} />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-[11px] font-mono font-bold tracking-wider text-amber-300 uppercase">
                GUEST SESSION
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-sans">
              Device Authenticated
            </span>
          </div>
        </div>

        <span className="text-[10px] font-mono text-slate-400 bg-slate-900/90 border border-slate-800 px-2 py-0.5 rounded-full">
          Device Bound
        </span>
      </div>

      {/* Hero Title & Pitch */}
      <div className="space-y-1 relative z-10">
        <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
          Activate Your TeleFlix Profile
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed font-normal">
          Sign in with your Google account to access instant cashouts, tiered referral commissions, and your personal reward wallet.
        </p>
      </div>

      {/* 2x2 Feature Pills Grid */}
      <div className="grid grid-cols-2 gap-2 relative z-10 pt-1">
        {/* Cashouts */}
        <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-2.5 flex items-start gap-2">
          <div className="p-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
            <CreditCard size={13} />
          </div>
          <div className="min-w-0">
            <span className="text-xs font-bold text-white block truncate leading-tight">Cashouts</span>
            <span className="text-[10px] text-slate-400 block truncate leading-tight">bKash, Nagad & Crypto</span>
          </div>
        </div>

        {/* Tiered Ref */}
        <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-2.5 flex items-start gap-2">
          <div className="p-1 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 shrink-0">
            <Users size={13} />
          </div>
          <div className="min-w-0">
            <span className="text-xs font-bold text-white block truncate leading-tight">Tiered Ref</span>
            <span className="text-[10px] text-slate-400 block truncate leading-tight">Instant team rewards</span>
          </div>
        </div>

        {/* HD Streaming */}
        <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-2.5 flex items-start gap-2">
          <div className="p-1 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
            <Zap size={13} />
          </div>
          <div className="min-w-0">
            <span className="text-xs font-bold text-white block truncate leading-tight">HD Streaming</span>
            <span className="text-[10px] text-slate-400 block truncate leading-tight">High bitrate playback</span>
          </div>
        </div>

        {/* Anti-Fraud */}
        <div className="bg-[#151A28] border border-[#252E47] rounded-xl p-2.5 flex items-start gap-2">
          <div className="p-1 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shrink-0">
            <ShieldCheck size={13} />
          </div>
          <div className="min-w-0">
            <span className="text-xs font-bold text-white block truncate leading-tight">Anti-Fraud</span>
            <span className="text-[10px] text-slate-400 block truncate leading-tight">Hardware protection</span>
          </div>
        </div>
      </div>

      {/* Error Message if Auth Fails */}
      {errorMessage && (
        <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-mono relative z-10">
          {errorMessage}
        </div>
      )}

      {/* Center-Aligned Smart "Continue with Google" Button */}
      <div className="pt-1 relative z-10">
        <button
          type="button"
          onClick={onSignInClick}
          disabled={isConnectingGoogle}
          className="w-full py-3.5 px-4 rounded-xl sm:rounded-2xl bg-white hover:bg-slate-100 active:bg-slate-200 text-slate-950 font-bold text-xs sm:text-sm flex justify-center items-center text-center gap-2.5 shadow-xl transition-all duration-100 active:scale-[0.98] cursor-pointer disabled:opacity-60"
        >
          {isConnectingGoogle ? (
            <Loader2 className="w-4.5 h-4.5 animate-spin text-slate-900 shrink-0" />
          ) : (
            <svg className="w-4.5 h-4.5 shrink-0" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/>
              <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
              <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
              <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
            </svg>
          )}
          <span className="tracking-tight">
            {isConnectingGoogle ? "Connecting..." : "Continue with Google"}
          </span>
        </button>
      </div>

      {/* Footer HWID Info */}
      <div className="flex items-center justify-between text-[10.5px] text-slate-400 font-mono pt-2 border-t border-[#1C2336] relative z-10">
        <div className="flex items-center gap-1.5">
          <Lock size={12} className="text-slate-400 shrink-0" />
          <span>Hardware Bound</span>
        </div>

        <button
          type="button"
          onClick={handleCopyHwid}
          className="text-slate-400 hover:text-slate-200 flex items-center gap-1.5 transition cursor-pointer select-none"
          title="Click to copy Hardware ID"
        >
          <span>HWID: {hwid.slice(0, 14)}...</span>
          {copiedHwid ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
        </button>
      </div>
    </div>
  );
}
