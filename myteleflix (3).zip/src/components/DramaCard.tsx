/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback } from "react";
import MovieCard, { MovieCardProps } from "./MovieCard";
import { Movie } from "../types";

export interface DramaCardProps extends Omit<MovieCardProps, "movie"> {
  drama?: Movie;
  movie?: Movie;
}

export const DramaCard: React.FC<DramaCardProps> = ({
  drama,
  movie,
  onClick,
  ...props
}) => {
  const item = drama || movie;
  if (!item) return null;

  const handleClick = useCallback(() => {
    onClick?.();
  }, [onClick]);

  return (
    <MovieCard
      {...props}
      movie={item}
      onClick={handleClick}
      sectionType="drama"
      showGetLink={props.showGetLink ?? true}
    />
  );
};

export default DramaCard;
