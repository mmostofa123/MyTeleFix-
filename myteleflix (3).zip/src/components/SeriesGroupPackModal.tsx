/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from "react";
import { 
  X, Layers, Play, Download, ChevronRight, Tv, Film, 
  Calendar, Star, Clock, CheckCircle2 
} from "lucide-react";
import { Movie, SeriesGroupPack } from "../types";
import PosterDownloadOverlay from "./PosterDownloadOverlay";
import { useLanguage } from "../context/LanguageContext";

interface SeriesGroupPackModalProps {
  pack: SeriesGroupPack;
  isOpen: boolean;
  onClose: () => void;
  onSelectEpisode: (episode: Movie) => void;
  isDrama?: boolean;
}

export const SeriesGroupPackModal: React.FC<SeriesGroupPackModalProps> = ({
  pack,
  isOpen,
  onClose,
  onSelectEpisode,
  isDrama = false,
}) => {
  const { t } = useLanguage();
  // If no pack or not open, return null
  if (!isOpen || !pack) return null;

  // Extract available seasons
  const seasonTabs = useMemo(() => {
    const list: string[] = [];
    const seen = new Set<string>();

    for (const ep of pack.episodes) {
      const s = ep.season ?? ep.season_number;
      let label = "Season 1";
      if (s) {
        label = typeof s === 'number' ? `Season ${s}` : String(s).trim();
        if (!label.toLowerCase().includes('season')) {
          label = `Season ${label}`;
        }
      }
      if (!seen.has(label)) {
        seen.add(label);
        list.push(label);
      }
    }

    // Sort seasons numerically if possible
    list.sort((a, b) => {
      const numA = parseInt(a.replace(/\D/g, ''), 10) || 1;
      const numB = parseInt(b.replace(/\D/g, ''), 10) || 1;
      return numA - numB;
    });

    return list.length > 0 ? list : ["Season 1"];
  }, [pack.episodes]);

  const [activeSeason, setActiveSeason] = useState<string>(seasonTabs[0] || "Season 1");
  const [openingEpisodeId, setOpeningEpisodeId] = useState<string | null>(null);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleEpisodeClick = (ep: Movie) => {
    // Immediately select episode without delay
    onSelectEpisode(ep);
    setOpeningEpisodeId(ep.id);

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    clickTimerRef.current = setTimeout(() => {
      setOpeningEpisodeId(null);
    }, 350);
  };

  React.useEffect(() => {
    return () => {
      if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    };
  }, []);

  // Filter episodes for active season
  const episodesForActiveSeason = useMemo(() => {
    return pack.episodes.filter(ep => {
      if (seasonTabs.length <= 1) return true;
      const s = ep.season ?? ep.season_number;
      let label = "Season 1";
      if (s) {
        label = typeof s === 'number' ? `Season ${s}` : String(s).trim();
        if (!label.toLowerCase().includes('season')) {
          label = `Season ${label}`;
        }
      }
      return label === activeSeason;
    });
  }, [pack.episodes, activeSeason, seasonTabs.length]);

  return (
    <div 
      id="series-group-pack-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        onClick={(e) => e.stopPropagation()}
        className="bg-slate-950 border border-slate-800 text-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-300 flex flex-col max-h-[92vh] sm:max-h-[88vh]"
      >
        {/* Header Hero Area */}
        <div className="relative p-4 sm:p-5 bg-gradient-to-b from-slate-900/90 via-slate-950 to-slate-950 border-b border-slate-800/80 shrink-0">
          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center border border-slate-700 transition active:scale-95 cursor-pointer z-10"
          >
            <X size={16} />
          </button>

          <div className="flex gap-3.5 items-start">
            <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-xl bg-slate-900 border border-slate-800 overflow-hidden shrink-0 shadow-lg relative">
              <img
                src={pack.masterItem.thumbnailUrl}
                alt={pack.groupTitle}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
                }}
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-1 left-1 px-1.5 py-0.5 rounded bg-black/70 backdrop-blur-xs text-[8px] font-mono font-bold text-sky-400 border border-sky-400/30">
                {isDrama ? "SERIAL" : "SERIES"}
              </div>
            </div>

            <div className="flex-1 min-w-0 pr-8 space-y-1.5">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="px-2 py-0.5 rounded-md text-[9px] font-mono font-bold bg-sky-500/15 text-sky-400 border border-sky-500/30">
                  {seasonTabs.length > 1 ? `${seasonTabs.length} Seasons` : "Full Pack"}
                </span>
                <span className="px-2 py-0.5 rounded-md text-[9px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  {pack.totalEpisodesCount} Episodes
                </span>
              </div>

              <h2 className="text-base sm:text-lg font-black text-white leading-snug truncate">
                {pack.groupTitle}
              </h2>

              <p className="text-[11px] text-slate-400 font-sans line-clamp-2 leading-relaxed">
                {pack.masterItem.description || "সকল সিজন ও পর্বের হাই-স্পিড ডাউনলোড ও ওয়াচ লিংক একসাথে পান।"}
              </p>
            </div>
          </div>

          {/* Season Tabs Selector (if more than 1 season) */}
          {seasonTabs.length > 1 && (
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-none no-scrollbar pt-3 mt-1 border-t border-slate-800/60">
              {seasonTabs.map((sTab) => {
                const isActive = activeSeason === sTab;
                return (
                  <button
                    key={sTab}
                    type="button"
                    onClick={() => setActiveSeason(sTab)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold whitespace-nowrap transition cursor-pointer select-none active:scale-95 ${
                      isActive
                        ? "bg-sky-600 text-white border border-sky-500 shadow-sm"
                        : "bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800"
                    }`}
                  >
                    {sTab}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Scrollable Episodes List */}
        <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 no-scrollbar pb-8 bg-slate-950 flex-1 min-h-0">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Layers size={13} className="text-sky-400" />
              <span>Episodes List ({episodesForActiveSeason.length})</span>
            </span>
            <span className="text-[10px] font-mono text-slate-500">
              Select episode to get download link
            </span>
          </div>

          <div className="space-y-2">
            {episodesForActiveSeason.map((ep, idx) => {
              const epNum = ep.episode ?? ep.episode_number ?? idx + 1;
              const isEpOpening = openingEpisodeId === ep.id;
              return (
                <div
                  key={`ep-item-${ep.id}`}
                  onClick={() => handleEpisodeClick(ep)}
                  className={`group bg-slate-900/90 hover:bg-slate-850 active:bg-slate-800 border rounded-xl p-2.5 flex items-center justify-between gap-3 transition-all duration-150 cursor-pointer select-none active:scale-[0.985] shadow-sm ${
                    isEpOpening ? "border-emerald-500/80 bg-slate-800/90" : "border-slate-800 hover:border-slate-700"
                  }`}
                >
                  {/* Left: Thumbnail & Episode Number */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-12 h-14 rounded-lg bg-slate-950 border border-slate-800 overflow-hidden shrink-0 relative flex items-center justify-center">
                      <img
                        src={ep.thumbnailUrl || pack.masterItem.thumbnailUrl}
                        alt={ep.title}
                        className={`w-full h-full object-cover transition-all duration-200 ${
                          isEpOpening ? "filter blur-xs brightness-75 scale-105" : ""
                        }`}
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
                        }}
                        referrerPolicy="no-referrer"
                      />
                      {isEpOpening ? (
                        <PosterDownloadOverlay size="sm" />
                      ) : (
                        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                          <Play size={14} className="text-white fill-white/80 opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-transform" />
                        </div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[9.5px] font-mono font-bold text-sky-400 bg-sky-950/80 px-1.5 py-0.2 rounded border border-sky-800/60">
                          EP {epNum}
                        </span>
                        {ep.duration && (
                          <span className="text-[9px] font-mono text-slate-400">
                            {ep.duration}
                          </span>
                        )}
                        {ep.languages && ep.languages.length > 0 && (
                          <span className="text-[8.5px] font-mono text-emerald-400 bg-emerald-950/60 px-1 rounded">
                            {ep.languages.join(", ")}
                          </span>
                        )}
                      </div>

                      <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-sky-300 transition-colors truncate">
                        {ep.title}
                      </h4>

                      {ep.description && (
                        <p className="text-[10.5px] text-slate-400 truncate line-clamp-1">
                          {ep.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right Action: Download button with section styling */}
                  <div className="shrink-0 flex items-center gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEpisodeClick(ep);
                      }}
                      className={`py-1.5 px-2.5 rounded-lg text-white font-black text-xs uppercase tracking-wider border shadow-md transition-all duration-75 ease-out shrink-0 cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 ${
                        isEpOpening 
                          ? isDrama ? "bg-emerald-700 border-emerald-400 text-white ring-1.5 ring-emerald-400" : "bg-sky-700 border-sky-400 text-white ring-1.5 ring-sky-400"
                          : isDrama ? "bg-[#059669] hover:bg-[#047857] active:bg-[#065F46] border-emerald-400/90 shadow-emerald-950/60" : "bg-[#0284C7] hover:bg-[#0369A1] active:bg-[#075985] border-sky-400/90 shadow-sky-950/60"
                      }`}
                    >
                      {isEpOpening ? (
                        <>
                          <div className="w-3 h-3 rounded-full border-[1.5px] border-white border-t-transparent animate-spin shrink-0" />
                          <span className="text-[11px] text-white font-bold">{t('action.opening', 'OPENING...')}</span>
                        </>
                      ) : (
                        <>
                          <Download size={11} strokeWidth={2.4} className="shrink-0 text-white" />
                          <span>{t('action.download', 'DOWNLOAD')}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SeriesGroupPackModal;
