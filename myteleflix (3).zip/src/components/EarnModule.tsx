/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { default } from "./Earn";
export type { EarnProps as EarnModuleProps } from "./Earn";
