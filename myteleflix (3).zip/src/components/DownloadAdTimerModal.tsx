/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * DownloadAdTimerModal: High-CPM Video Ad & 15-Second Timer Modal (Phase 1)
 * Displays a 15-second countdown timer while rendering a VAST/Outstream Video Ad space.
 * Generates a 'PENDING' download signal in Firestore 'download_requests' via transaction and
 * automatically redirects to the 1st Verification Website.
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  X, Loader2, Play, Pause, Volume2, VolumeX, ShieldCheck, 
  ArrowRight, CheckCircle2, Film
} from "lucide-react";
import { Movie, Video } from "../types";
import { auth, db } from "../services/firebase";
import { runTransaction, doc, serverTimestamp, getDoc } from "firebase/firestore";

export interface DownloadAdTimerModalProps {
  isOpen: boolean;
  item: Movie | Video;
  selectedOption: {
    id: string;
    title: string;
    targetUrl: string;
  };
  firstVerificationUrl?: string;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function DownloadAdTimerModal({
  isOpen,
  item,
  selectedOption,
  firstVerificationUrl: propVerificationUrl,
  onClose,
  onSuccess
}: DownloadAdTimerModalProps) {
  const [activeVerificationUrl, setActiveVerificationUrl] = useState<string>(
    propVerificationUrl || "https://your-1st-website.com"
  );
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isSavingSignal, setIsSavingSignal] = useState<boolean>(false);
  const [signalSaved, setSignalSaved] = useState<boolean>(false);
  const [redirectUrl, setRedirectUrl] = useState<string>("");
  const [saveError, setSaveError] = useState<string | null>(null);

  // Video Ad player state
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // High-CPM fallback demo creative in case VAST network tag is loading
  const adVideoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4";

  // Dynamic admin config resolution for 1st Verification Website URL
  useEffect(() => {
    let isMounted = true;

    // 1. Check system settings API
    fetch("/api/system-settings")
      .then((res) => res.json())
      .then((data) => {
        if (!isMounted || !data) return;
        const configUrl = 
          data.firstVerificationUrl || 
          data.first_verification_url || 
          data.verificationSettings?.firstVerificationUrl ||
          data.adSettings?.firstVerificationUrl;
        if (configUrl) {
          setActiveVerificationUrl(configUrl);
        }
      })
      .catch(() => {});

    // 2. Fallback check to Firestore system_configs collection
    getDoc(doc(db, "system_configs", "verification_settings"))
      .then((snap) => {
        if (!isMounted || !snap.exists()) return;
        const data = snap.data();
        if (data?.firstVerificationUrl || data?.first_verification_url) {
          setActiveVerificationUrl(data.firstVerificationUrl || data.first_verification_url);
        }
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  // Update computed redirect URL when activeVerificationUrl or item.id changes
  useEffect(() => {
    const savedUserStr = typeof window !== "undefined" ? localStorage.getItem("myteleflix_user") : null;
    const parsedSavedUser = savedUserStr ? JSON.parse(savedUserStr) : null;
    const tgId = parsedSavedUser?.telegramId || "";
    const isDefaultSite = activeVerificationUrl.includes("your-1st-website.com");
    const base = isDefaultSite ? `${window.location.origin}/verify/step-1` : activeVerificationUrl.replace(/\/+$/, '');
    const delim = base.includes('?') ? '&' : '?';
    const computedRedirect = `${base}${delim}contentId=${encodeURIComponent(item.id)}&ref=${encodeURIComponent(item.id)}&telegramId=${encodeURIComponent(String(tgId))}`;
    setRedirectUrl(computedRedirect);
  }, [activeVerificationUrl, item.id]);

  // Reset state whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setTimeLeft(15);
      setIsCompleted(false);
      setIsSavingSignal(false);
      setSignalSaved(false);
      setSaveError(null);
      setIsPlaying(true);
      setIsMuted(true);

      const savedUserStr = typeof window !== "undefined" ? localStorage.getItem("myteleflix_user") : null;
      const parsedSavedUser = savedUserStr ? JSON.parse(savedUserStr) : null;
      const tgId = parsedSavedUser?.telegramId || "";
      const isDefaultSite = activeVerificationUrl.includes("your-1st-website.com");
      const base = isDefaultSite ? `${window.location.origin}/verify/step-1` : activeVerificationUrl.replace(/\/+$/, '');
      const delim = base.includes('?') ? '&' : '?';
      const computedRedirect = `${base}${delim}contentId=${encodeURIComponent(item.id)}&ref=${encodeURIComponent(item.id)}&telegramId=${encodeURIComponent(String(tgId))}`;
      setRedirectUrl(computedRedirect);
    }
  }, [isOpen, item.id, activeVerificationUrl]);

  // 15-Second Countdown Timer
  useEffect(() => {
    if (!isOpen || isCompleted) return;

    if (timeLeft <= 0) {
      setIsCompleted(true);
      handleGeneratePendingSignal();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen, timeLeft, isCompleted]);

  // Execute Firestore transaction write in 'download_requests' collection
  const handleGeneratePendingSignal = async () => {
    setIsSavingSignal(true);
    setSaveError(null);

    try {
      // 1. Resolve user identity: Google Auth UID or Telegram ID
      const currentUser = auth.currentUser;
      const savedUserStr = typeof window !== "undefined" ? localStorage.getItem("myteleflix_user") : null;
      const parsedSavedUser = savedUserStr ? JSON.parse(savedUserStr) : null;

      const isRegisteredVip = Boolean(currentUser && !currentUser.isAnonymous);
      const userMode: "GUEST" | "VIP" = isRegisteredVip ? "VIP" : "GUEST";

      const userEmail = currentUser?.email || parsedSavedUser?.email || "";
      const rawTelegramId = parsedSavedUser?.telegramId || (currentUser as any)?.telegramId;
      const userTelegramId = rawTelegramId 
        ? (typeof rawTelegramId === 'number' ? rawTelegramId : Number(rawTelegramId) || rawTelegramId)
        : "";
      const effectiveUid = isRegisteredVip 
        ? currentUser!.uid 
        : (userTelegramId ? String(userTelegramId) : (parsedSavedUser?.id || "guest_request"));

      // Target Document ID: auth.currentUser.uid or telegramId
      const targetDocId = currentUser?.uid || (userTelegramId ? String(userTelegramId) : effectiveUid);

      const universalLink = selectedOption.targetUrl || 
                            item.videoUrl || 
                            (item as any).originalLink || 
                            (item as any).banglaLink || 
                            `https://t.me/myteleflix?start=${item.id}`;

      // 2. Exact Payload to Save in 'download_requests' via Firestore Transaction
      const docRef = doc(db, 'download_requests', targetDocId);
      await runTransaction(db, async (transaction) => {
        const payload = {
          telegramId: userTelegramId,
          userEmail: currentUser?.email || userEmail || "",
          uid: isRegisteredVip ? currentUser!.uid : null,
          userMode,
          contentId: item.id,
          contentTitle: item.title,
          universalLink: universalLink,
          status: "PENDING",
          createdAt: serverTimestamp()
        };
        transaction.set(docRef, payload, { merge: true });
      });

      setSignalSaved(true);
      setIsSavingSignal(false);

      // 3. Automatically redirect user to 1st Verification Website (configured or default)
      const isDefaultSite = activeVerificationUrl.includes("your-1st-website.com");
      const base = isDefaultSite ? `${window.location.origin}/verify/step-1` : activeVerificationUrl.replace(/\/+$/, '');
      const delim = base.includes('?') ? '&' : '?';
      const targetRedirect = `${base}${delim}contentId=${encodeURIComponent(item.id)}&ref=${encodeURIComponent(item.id)}&telegramId=${encodeURIComponent(String(userTelegramId || ""))}&userMode=${userMode}&uid=${encodeURIComponent(currentUser?.uid || "")}`;

      setTimeout(() => {
        try {
          const tg = (window as any).Telegram?.WebApp;
          if (tg && typeof tg.openLink === 'function') {
            tg.openLink(targetRedirect);
          } else {
            const opened = window.open(targetRedirect, "_blank", "noopener,noreferrer");
            if (!opened) {
              window.location.assign(targetRedirect);
            }
          }
        } catch {
          window.location.assign(targetRedirect);
        }

        if (onSuccess) {
          onSuccess();
        }
      }, 1000);
    } catch (err: any) {
      console.error("Firestore pending download signal transaction error:", err);
      setSaveError(err.message || "Failed to record download request. Please retry.");
      setIsSavingSignal(false);
    }
  };

  const handleManualRedirect = () => {
    if (!redirectUrl) return;
    try {
      const tg = (window as any).Telegram?.WebApp;
      if (tg && typeof tg.openLink === 'function') {
        tg.openLink(redirectUrl);
      } else {
        const opened = window.open(redirectUrl, "_blank", "noopener,noreferrer");
        if (!opened) {
          window.location.assign(redirectUrl);
        }
      }
    } catch {
      window.location.assign(redirectUrl);
    }
  };

  if (!isOpen) return null;

  const progressPercent = Math.min(100, Math.max(0, ((15 - timeLeft) / 15) * 100));

  return (
    <div 
      id="download-ad-timer-modal"
      className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none font-sans animate-in fade-in duration-200"
    >
      {/* Modal Surface: Deep minimal dark theme #090D16 with #1E293B border */}
      <div 
        id="download-ad-timer-card"
        className="relative w-full max-w-[460px] bg-[#090D16] border border-[#1E293B] rounded-2xl sm:rounded-3xl p-4 sm:p-5 text-white shadow-2xl overflow-hidden flex flex-col space-y-4 my-auto animate-in zoom-in-95 duration-200"
      >
        {/* Ambient background glow */}
        <div className="pointer-events-none absolute -top-16 -right-16 w-48 h-48 bg-gradient-to-br from-cyan-600/15 via-blue-600/10 to-transparent rounded-full blur-3xl" />
        <div className="pointer-events-none absolute -bottom-16 -left-16 w-44 h-44 bg-gradient-to-tr from-amber-600/15 via-red-600/10 to-transparent rounded-full blur-3xl" />

        {/* Modal Top Header */}
        <div className="relative z-10 flex items-center justify-between gap-3 border-b border-[#1E293B]/70 pb-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
              <Film size={16} />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs sm:text-sm font-bold text-white truncate">
                {item.title}
              </h4>
              <p className="text-[11px] text-cyan-300 font-mono truncate">
                Track: {selectedOption.title}
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-ad-modal"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700/60 flex items-center justify-center transition active:scale-95 cursor-pointer shrink-0"
            title="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* Guest Mode Banner: Want to EARN from this download? */}
        {!(auth.currentUser && !auth.currentUser.isAnonymous) ? (
          <div className="relative z-10 p-2.5 rounded-xl bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 border border-amber-500/40 flex items-center justify-between gap-2 shadow-md">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-base shrink-0">🌟</span>
              <p className="text-[11px] sm:text-xs text-amber-200 font-medium leading-tight">
                Want to EARN from this download? Sign up now to unlock your VIP Wallet!
              </p>
            </div>
            <a
              href="/?action=signup"
              className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] tracking-wide shrink-0 transition"
            >
              Sign Up
            </a>
          </div>
        ) : (
          <div className="relative z-10 px-3 py-1.5 rounded-xl bg-emerald-950/50 border border-emerald-500/30 flex items-center justify-between text-[11px] text-emerald-300 font-mono">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              VIP Mode Active
            </span>
            <span className="text-emerald-400 font-bold">+50 Pts on completion</span>
          </div>
        )}

        {/* 15-Second Countdown Timer Display */}
        <div className="relative z-10 bg-[#0F1424] border border-[#1E293B] rounded-xl p-3 sm:p-3.5 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs sm:text-[13px] font-semibold text-slate-200">
              {timeLeft > 0 ? (
                <>Preparing your download link... Please wait <span className="text-cyan-400 font-bold font-mono">[{timeLeft}]s</span></>
              ) : isSavingSignal ? (
                <span className="text-amber-300 flex items-center gap-1.5">
                  <Loader2 size={13} className="animate-spin text-amber-400" />
                  Generating secure verification signal...
                </span>
              ) : signalSaved ? (
                <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  Signal generated! Redirecting to verification...
                </span>
              ) : (
                <span className="text-cyan-300">Link prepared!</span>
              )}
            </span>

            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-500/30 shrink-0">
              {timeLeft > 0 ? `${timeLeft}s` : "READY"}
            </span>
          </div>

          {/* Smooth Linear Progress Bar */}
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden relative">
            <div 
              className={`h-full transition-all duration-1000 ease-linear rounded-full ${
                timeLeft === 0 
                  ? "bg-gradient-to-r from-emerald-500 to-teal-400" 
                  : "bg-gradient-to-r from-blue-600 via-cyan-500 to-sky-400"
              }`}
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* VAST / Outstream Video Ad Placement Container */}
        <div 
          id="vast-ad-container"
          className="relative z-10 w-full aspect-video rounded-xl bg-black border border-[#1E293B] overflow-hidden flex flex-col justify-between group shadow-lg"
        >
          {/* Ad Label / Sponsor Indicator */}
          <div className="absolute top-2 left-2 z-20 flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md border border-slate-700 text-[10px] font-mono text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="uppercase font-semibold tracking-wider">SPONSORED AD</span>
          </div>

          {/* Video Ad Canvas */}
          <video
            ref={videoRef}
            src={adVideoUrl}
            autoPlay
            loop
            muted={isMuted}
            playsInline
            className="w-full h-full object-cover"
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
          />

          {/* Video Ad Controls Overlay */}
          <div className="absolute bottom-2 right-2 z-20 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                if (!videoRef.current) return;
                if (isPlaying) {
                  videoRef.current.pause();
                  setIsPlaying(false);
                } else {
                  videoRef.current.play().catch(() => {});
                  setIsPlaying(true);
                }
              }}
              className="p-1.5 rounded-lg bg-black/70 hover:bg-black/90 text-white border border-slate-700/60 transition active:scale-95 cursor-pointer"
            >
              {isPlaying ? <Pause size={13} /> : <Play size={13} />}
            </button>
            <button
              type="button"
              onClick={() => {
                if (!videoRef.current) return;
                videoRef.current.muted = !isMuted;
                setIsMuted(!isMuted);
              }}
              className="p-1.5 rounded-lg bg-black/70 hover:bg-black/90 text-white border border-slate-700/60 transition active:scale-95 cursor-pointer"
            >
              {isMuted ? <VolumeX size={13} /> : <Volume2 size={13} />}
            </button>
          </div>

          {/* Dedicated Outstream Injection Point: Adsterra / Monetag / HilltopAds */}
          <div 
            id="outstream-video-placement"
            data-ad-network="adsterra-monetag-hilltopads"
            className="hidden"
          >
            {/* Script tags can be mounted or injected here dynamically */}
          </div>
        </div>

        {/* Error message */}
        {saveError && (
          <div className="relative z-10 p-2.5 rounded-xl bg-red-950/70 border border-red-500/40 text-red-200 text-xs">
            {saveError}
          </div>
        )}

        {/* Action Button: Visible when countdown completes */}
        <div className="relative z-10 pt-1">
          {timeLeft > 0 ? (
            <div className="w-full py-3 px-4 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-400 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-not-allowed">
              <Loader2 size={15} className="animate-spin text-cyan-400" />
              <span>Verifying High-Speed Download Slot... ({timeLeft}s)</span>
            </div>
          ) : (
            <button
              type="button"
              id="btn-goto-verification-step1"
              onClick={handleManualRedirect}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(16,185,129,0.35)] transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>Go to 1st Verification Website</span>
              <ArrowRight size={15} />
            </button>
          )}
        </div>

        {/* Security & Anti-Fraud Footer */}
        <div className="relative z-10 flex items-center justify-center gap-1.5 text-[10.5px] font-mono text-slate-400 text-center">
          <ShieldCheck size={12} className="text-emerald-400 shrink-0" />
          <span>Encrypted Pending Signal • Step 1 Verification</span>
        </div>
      </div>
    </div>
  );
}
