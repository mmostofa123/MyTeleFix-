/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { Search, Layers, Download } from "lucide-react";
import { Movie, User, AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import { getSeriesGroupPacks, SeriesGroupPack } from "../db";
import GroupPackCard from "./GroupPackCard";
import SeriesGroupPackModal from "./SeriesGroupPackModal";
import LinkUnlockModal from "./LinkUnlockModal";
import MovieCard from "./MovieCard";
import { sortMediaNewestFirst } from "../utils/sorting";
import { prefetchImages } from "../utils/imageCache";

export interface SeriesScreenProps {
  movies: Movie[];
  user?: User;
  onViewedMovie?: (id: string, isMovie: boolean) => Promise<void>;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  onBackToAll?: () => void;
  showSearchBar?: boolean;
  currentLanguage?: AppLanguage;
}

// 2. SERIES SCREEN DYNAMIC SUB-FILTERS:
// Labels: ["ALL", "বাংলা সিরিজ", "হিন্দি সিরিজ", "ফরেন / ইংলিশ", "কে-ড্রামা & অ্যানিমে"]
export type SeriesSubFilter = "ALL" | "বাংলা সিরিজ" | "হিন্দি সিরিজ" | "ফরেন / ইংলিশ" | "কে-ড্রামা & অ্যানিমে";

export const SERIES_SUB_FILTERS: SeriesSubFilter[] = [
  "ALL",
  "বাংলা সিরিজ",
  "হিন্দি সিরিজ",
  "ফরেন / ইংলিশ",
  "কে-ড্রামা & অ্যানিমে"
];

function SeriesScreenComponent({
  movies,
  user,
  onViewedMovie,
  guideVideoUrl,
  guideVideoLogoUrl,
  onBackToAll,
  showSearchBar = false,
  currentLanguage: propLanguage,
}: SeriesScreenProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
  }, []);

  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<SeriesSubFilter>("ALL");

  // State for Group Pack Episode Launcher Modal
  const [selectedPack, setSelectedPack] = useState<SeriesGroupPack | null>(null);

  // State for Link Unlock Modal (individual episode or standalone series)
  const [selectedEpisode, setSelectedEpisode] = useState<Movie | null>(null);

  // Helper to identify series items
  const isSeriesItem = (m: Movie) => {
    if (m.contentType === 'series' || Boolean(m.totalEpisodes)) return true;
    if (m.groupTitle || m.series_group_title) return true;
    const g = (m.genre || '').toLowerCase();
    const t = (m.title || '').toLowerCase();
    return g.includes('series') || g.includes('season') || t.includes('season') || t.includes('pack');
  };

  // Base list of all web series items
  const allSeriesItems = useMemo(() => {
    return movies.filter(isSeriesItem);
  }, [movies]);

  // Aggregate into Group Packs using db.ts helper
  const allGroupPacks = useMemo(() => {
    return getSeriesGroupPacks(allSeriesItems);
  }, [allSeriesItems]);

  // Map of item IDs that belong to a multi-episode group pack
  const groupedItemIds = useMemo(() => {
    const ids = new Set<string>();
    for (const pack of allGroupPacks) {
      for (const ep of pack.episodes) {
        ids.add(ep.id);
      }
    }
    return ids;
  }, [allGroupPacks]);

  // Standalone series items (not part of any group pack)
  const standaloneSeriesItems = useMemo(() => {
    return allSeriesItems.filter(item => !groupedItemIds.has(item.id));
  }, [allSeriesItems, groupedItemIds]);

  // Helper function to check if a series matches a sub-filter
  const matchesSubFilter = (item: Movie, filter: SeriesSubFilter): boolean => {
    if (filter === "ALL") return true;

    const rawLangs = (item.languages || []).map(l => (l || '').toLowerCase().trim());
    const originLabels = (item.languageOriginLabels || item.language_origin_labels || []).map(l => (l || '').toLowerCase().trim());
    const allText = `${item.title} ${item.genre || ''} ${item.description || ''}`.toLowerCase();

    if (filter === "বাংলা সিরিজ") {
      return (
        Boolean(item.banglaLink?.trim()) ||
        Boolean(item.banglaDubbedUrl?.trim()) ||
        rawLangs.some(l => l.includes('bangla') || l.includes('bn') || l.includes('bengali')) ||
        originLabels.some(l => l.includes('bangla') || l.includes('বাংলা') || l.includes('bd')) ||
        allText.includes('bangla') ||
        allText.includes('bengali') ||
        allText.includes('hoichoi') ||
        allText.includes('chorki')
      );
    }

    if (filter === "হিন্দি সিরিজ") {
      return (
        Boolean(item.hindiLink?.trim()) ||
        Boolean(item.hindiDubbedUrl?.trim()) ||
        rawLangs.some(l => l.includes('hindi') || l.includes('hi')) ||
        originLabels.some(l => l.includes('hindi') || l.includes('হিন্দি')) ||
        allText.includes('hindi') ||
        allText.includes('হিন্দি')
      );
    }

    if (filter === "ফরেন / ইংলিশ") {
      return (
        Boolean(item.englishLink?.trim()) ||
        Boolean(item.englishDubbedUrl?.trim()) ||
        rawLangs.some(l => l.includes('english') || l.includes('en') || l.includes('foreign') || l.includes('spanish') || l.includes('french')) ||
        originLabels.some(l => l.includes('english') || l.includes('foreign') || l.includes('ইংলিশ') || l.includes('ফরেন')) ||
        allText.includes('english') ||
        allText.includes('hollywood') ||
        allText.includes('netflix') ||
        allText.includes('foreign')
      );
    }

    if (filter === "কে-ড্রামা & অ্যানিমে") {
      return (
        rawLangs.some(l => l.includes('korean') || l.includes('anime') || l.includes('japanese') || l.includes('kdrama')) ||
        originLabels.some(l => l.includes('k-drama') || l.includes('anime') || l.includes('অ্যানিমে') || l.includes('কে-ড্রামা')) ||
        allText.includes('kdrama') ||
        allText.includes('k-drama') ||
        allText.includes('korean') ||
        allText.includes('anime') ||
        allText.includes('japan')
      );
    }

    return true;
  };

  // Filter Group Packs based on sub-filter & search
  const filteredGroupPacks = useMemo(() => {
    let packs = allGroupPacks;

    // Filter by sub-filter
    if (activeFilter !== "ALL") {
      packs = packs.filter(p => {
        // If master item matches, or any episode matches
        return matchesSubFilter(p.masterItem, activeFilter) || p.episodes.some(ep => matchesSubFilter(ep, activeFilter));
      });
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      packs = packs.filter(p => {
        const matchTitle = p.groupTitle.toLowerCase().includes(q);
        const matchMaster = p.masterItem.title.toLowerCase().includes(q) ||
          Boolean(p.masterItem.genre && p.masterItem.genre.toLowerCase().includes(q)) ||
          Boolean(p.masterItem.description && p.masterItem.description.toLowerCase().includes(q));
        const matchEpisodes = p.episodes.some(ep => ep.title.toLowerCase().includes(q));
        return matchTitle || matchMaster || matchEpisodes;
      });
    }

    return packs;
  }, [allGroupPacks, activeFilter, searchQuery]);

  // Filter Standalone Series based on sub-filter & search
  const filteredStandaloneSeries = useMemo(() => {
    let list = standaloneSeriesItems;

    // Filter by sub-filter
    if (activeFilter !== "ALL") {
      list = list.filter(item => matchesSubFilter(item, activeFilter));
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(item => {
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchGenre = Boolean(item.genre && item.genre.toLowerCase().includes(q));
        const matchDesc = Boolean(item.description && item.description.toLowerCase().includes(q));
        const matchLangs = Boolean(item.languages && item.languages.some(l => l.toLowerCase().includes(q)));
        return matchTitle || matchGenre || matchDesc || matchLangs;
      });
    }

    return sortMediaNewestFirst(list);
  }, [standaloneSeriesItems, activeFilter, searchQuery]);

  // Pre-fetch thumbnails
  useEffect(() => {
    const thumbsToPreload = [
      ...filteredGroupPacks.map(p => p.masterItem.thumbnailUrl),
      ...filteredStandaloneSeries.map(s => s.thumbnailUrl)
    ].filter(Boolean);
    if (thumbsToPreload.length > 0) {
      prefetchImages(thumbsToPreload.slice(0, 30));
    }
  }, [filteredGroupPacks, filteredStandaloneSeries]);

  const totalDisplayedCount = filteredGroupPacks.length + filteredStandaloneSeries.length;

  const handleOpenEpisodeUnlock = (episode: Movie, e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setSelectedEpisode(episode);
    onViewedMovie?.(episode.id, true).catch(() => {});
  };

  return (
    <div id="series-screen" className="space-y-3.5 animate-in fade-in duration-150 relative w-full max-w-full overflow-x-hidden">
      {/* 1. Search Bar at the very top (Only shown when explicitly enabled, hidden in category views) */}
      {showSearchBar && (
        <div className="px-4 pt-1 search-bar-container">
          <div className="relative bg-slate-900 border border-slate-800 focus-within:border-sky-500/80 rounded-xl flex items-center px-3.5 py-1 transition duration-150 shadow-sm">
            <div className="mr-2.5 shrink-0 text-slate-400">
              <Search size={15} />
            </div>
            <input
              id="series-screen-search"
              type="text"
              placeholder={t("search_series_placeholder", activeLanguage, "Search web series by title, season, episodes...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-white placeholder-slate-400 text-xs sm:text-sm py-2 outline-none font-sans font-normal"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="text-[10px] text-slate-300 hover:text-white font-mono font-semibold bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg cursor-pointer shrink-0 ml-2 border border-slate-700/60 active:scale-95 transition-transform duration-75"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. DYNAMIC SUB-FILTERS: ["ALL", "বাংলা সিরিজ", "হিন্দি সিরিজ", "ফরেন / ইংলিশ", "কে-ড্রামা & অ্যানিমে"] */}
      <div className="w-full overflow-hidden">
        <div 
          id="series-sub-filter-bar" 
          className="flex items-center gap-2 overflow-x-auto scrollbar-none px-4 py-1 no-scrollbar scroll-smooth"
        >
          {SERIES_SUB_FILTERS.map((label) => {
            const isActive = activeFilter === label;
            return (
              <button
                key={label}
                id={`series-filter-btn-${label}`}
                onClick={() => setActiveFilter(label)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono tracking-wide active:scale-95 transition-all duration-75 whitespace-nowrap cursor-pointer flex items-center gap-1.5 select-none shrink-0 border h-8 ${
                  isActive
                    ? "bg-[#0284C7] text-white font-bold border border-[#0284C7] shadow-md shadow-sky-950/40"
                    : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E] font-medium"
                }`}
              >
                <span className="whitespace-nowrap">{t(label, activeLanguage, label)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Group Pack & Standalone Series Cards Grid */}
      <div id="series-grid" className="px-4 pt-1">
        {totalDisplayedCount > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Master Group Pack Cards (Aggregated multi-episode series) */}
            {filteredGroupPacks.map((pack) => (
              <GroupPackCard
                key={`pack-${pack.groupTitle}`}
                pack={pack}
                layout="grid"
                onClick={() => setSelectedPack(pack)}
              />
            ))}

            {/* Standalone Series Cards */}
            {filteredStandaloneSeries.map((item) => (
              <MovieCard
                key={`single-series-${item.id}`}
                movie={item}
                layout="grid"
                showGetLink={true}
                showBadges={false}
                sectionType="series"
                onClick={() => handleOpenEpisodeUnlock(item)}
              />
            ))}
          </div>
        ) : (
          <div className="py-12 text-center bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 text-slate-400 flex items-center justify-center">
              <Layers size={22} />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-white">
                {t("no_series_found", activeLanguage, "No Web Series Found")}
              </h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                {searchQuery.trim()
                  ? `"${searchQuery}" এর সাথে কোন ওয়েব সিরিজ মেলেনি।`
                  : activeFilter !== "ALL"
                  ? `বর্তমানে "${activeFilter}" ক্যাটাগরিতে কোন সিরিজ নেই।`
                  : `বর্তমানে কোন ওয়েব সিরিজ পাওয়া যায়নি।`}
              </p>
            </div>
            {(searchQuery || activeFilter !== "ALL") && (
              <button
                onClick={() => {
                  setSearchQuery("");
                  setActiveFilter("ALL");
                }}
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-xl transition-all duration-75 ease-out shadow-md cursor-pointer active:scale-95 inline-flex items-center gap-1.5 select-none"
              >
                <span>{t("see_all_series", activeLanguage, "View All Series")}</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* ACCORDION/TAB MODAL VIEW: Dedicated Episode Launcher Modal */}
      {selectedPack && (
        <SeriesGroupPackModal
          pack={selectedPack}
          isOpen={Boolean(selectedPack)}
          onClose={() => setSelectedPack(null)}
          onSelectEpisode={(ep) => {
            handleOpenEpisodeUnlock(ep);
          }}
        />
      )}

      {/* MODAL: GET-LINK UNLOCK & AUDIO DUB MODAL */}
      {selectedEpisode && (
        <LinkUnlockModal
          item={selectedEpisode}
          type="movie"
          userId={user?.id}
          guideVideoUrl={guideVideoUrl}
          guideVideoLogoUrl={guideVideoLogoUrl}
          onClose={() => setSelectedEpisode(null)}
        />
      )}
    </div>
  );
}

const SeriesScreen = React.memo(SeriesScreenComponent);
export default SeriesScreen;
