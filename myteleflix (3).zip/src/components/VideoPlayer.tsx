/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from "react";
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, 
  RotateCcw, RotateCw, X, Clock, 
  Film, AlertCircle, Loader2, PictureInPicture,
  Zap, Cloud, RefreshCw, Settings
} from "lucide-react";
import Hls from "hls.js";
import { Movie, Video } from "../types";

export interface VideoPlayerProps {
  media: Movie | Video;
  type?: 'movie' | 'video';
  userId?: string;
  onClose: () => void;
  onWatchTimeUpdate?: (totalSecondsWatched: number) => void;
  onActivityHeartbeat?: () => void;
}

export default function VideoPlayer({
  media,
  type = 'movie',
  userId = "guest",
  onClose,
  onWatchTimeUpdate,
  onActivityHeartbeat,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const hlsRef = useRef<Hls | null>(null);

  // Playback states
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [bufferedPercent, setBufferedPercent] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [playbackError, setPlaybackError] = useState<string | null>(null);
  const [showControls, setShowControls] = useState(true);

  // Adaptive Quality & CDN States
  const [availableLevels, setAvailableLevels] = useState<{ id: number; height: number; bitrate: number }[]>([]);
  const [currentLevel, setCurrentLevel] = useState<number>(-1); // -1 = Auto
  const [showQualityMenu, setShowQualityMenu] = useState(false);
  const [isCdnAccelerated, setIsCdnAccelerated] = useState(false);
  const [streamQualityLabel, setStreamQualityLabel] = useState<string>("AUTO");

  // Continuous Watch Time & Inactivity Purge Protection Tracker
  const [secondsWatchedInSession, setSecondsWatchedInSession] = useState(0);
  const heartbeatActive = isPlaying && !playbackError;

  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Resolve best stream URL with high-speed CDN and dub support
  const rawStreamUrl = media.videoUrl || (media as any).originalLink || (media as any).banglaLink || (media as any).hindiLink || "";
  
  // Detect if stream is Cloud CDN accelerated
  useEffect(() => {
    if (rawStreamUrl) {
      const isCloud = 
        rawStreamUrl.includes("firebasestorage.googleapis.com") ||
        rawStreamUrl.includes("cloudflare") ||
        rawStreamUrl.includes("r2.") ||
        rawStreamUrl.includes("fastly") ||
        rawStreamUrl.includes("bunny") ||
        rawStreamUrl.includes("cdn");
      setIsCdnAccelerated(isCloud);
    }
  }, [rawStreamUrl]);

  // Hide controls after 3.5 seconds of inactivity
  const resetControlsTimeout = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
        setShowQualityMenu(false);
      }, 3500);
    }
  }, [isPlaying]);

  // Format seconds to mm:ss or hh:mm:ss
  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return "00:00";
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hrs > 0) {
      return `${hrs}:${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
    }
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Heartbeat function: sends watch-time to server and updates last_active_at
  const sendHeartbeatPing = useCallback(async (secondsCount: number) => {
    try {
      const res = await fetch("/api/user/heartbeat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          watchTimeSeconds: secondsCount,
          mediaId: media.id,
          mediaType: type,
          title: media.title,
        }),
      });
      if (res.ok) {
        await res.json();
        onActivityHeartbeat?.();
      }
    } catch (err) {
      console.warn("Heartbeat ping failure:", err);
    }
  }, [userId, media.id, media.title, type, onActivityHeartbeat]);

  // HLS & Direct CDN Stream Engine Initialization
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !rawStreamUrl) return;

    setPlaybackError(null);
    setIsLoading(true);

    const isHlsUrl = rawStreamUrl.includes(".m3u8");

    if (isHlsUrl && Hls.isSupported()) {
      // Initialize high performance Hls.js instance with buffer optimization
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 60,
        maxBufferLength: 30,
        maxMaxBufferLength: 120,
        maxBufferSize: 60 * 1000 * 1000, // 60MB buffer
      });

      hls.attachMedia(video);
      hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        hls.loadSource(rawStreamUrl);
      });

      hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
        setIsLoading(false);
        const levels = data.levels.map((lvl, index) => ({
          id: index,
          height: lvl.height || 720,
          bitrate: lvl.bitrate || 0,
        }));
        setAvailableLevels(levels);
      });

      hls.on(Hls.Events.LEVEL_SWITCHED, (_event, data) => {
        const lvl = hls.levels[data.level];
        if (lvl) {
          setStreamQualityLabel(`${lvl.height}p`);
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        console.warn("[HLS Streaming Error]", data);
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              hls.destroy();
              // Fallback to direct native browser video
              video.src = rawStreamUrl;
              break;
          }
        }
      });

      hlsRef.current = hls;

      return () => {
        hls.destroy();
        hlsRef.current = null;
      };
    } else {
      // Direct high-speed CDN MP4 / WebM / Native HLS stream
      video.src = rawStreamUrl;
      if (video.canPlayType('application/vnd.apple.mpegurl')) {
        // Native Apple Safari HLS
        setStreamQualityLabel("1080P MASTER");
      } else {
        setStreamQualityLabel("DIRECT CDN");
      }
    }
  }, [rawStreamUrl]);

  // Quality Level Switching
  const handleSelectQuality = (levelIndex: number) => {
    if (!hlsRef.current) return;
    hlsRef.current.currentLevel = levelIndex;
    setCurrentLevel(levelIndex);
    if (levelIndex === -1) {
      setStreamQualityLabel("AUTO");
    } else {
      const lvl = availableLevels[levelIndex];
      setStreamQualityLabel(lvl ? `${lvl.height}p` : "HD");
    }
    setShowQualityMenu(false);
  };

  // Continuous watch time interval: runs while video is actively playing
  useEffect(() => {
    let watchTimer: NodeJS.Timeout | null = null;
    let accumulatedSeconds = 0;

    if (isPlaying && !playbackError) {
      watchTimer = setInterval(() => {
        setSecondsWatchedInSession(prev => {
          const updated = prev + 1;
          onWatchTimeUpdate?.(updated);
          return updated;
        });

        accumulatedSeconds += 1;

        // Send a background activity heartbeat every 20 seconds of continuous watching
        if (accumulatedSeconds >= 20) {
          sendHeartbeatPing(accumulatedSeconds);
          accumulatedSeconds = 0;
        }
      }, 1000);
    }

    return () => {
      if (watchTimer) clearInterval(watchTimer);
      // Flush any remaining accumulated seconds when unmounted or paused
      if (accumulatedSeconds > 0) {
        sendHeartbeatPing(accumulatedSeconds);
      }
    };
  }, [isPlaying, playbackError, sendHeartbeatPing, onWatchTimeUpdate]);

  // Initial immediate heartbeat on player mount to refresh last_active_at instantly
  useEffect(() => {
    sendHeartbeatPing(1);
  }, [sendHeartbeatPing]);

  // Video element event listeners
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      // Calculate buffer progress
      if (videoRef.current.buffered.length > 0 && videoRef.current.duration > 0) {
        const bufferedEnd = videoRef.current.buffered.end(videoRef.current.buffered.length - 1);
        setBufferedPercent((bufferedEnd / videoRef.current.duration) * 100);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      setIsLoading(false);
    }
  };

  const handlePlayPause = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
        resetControlsTimeout();
      }).catch(err => {
        console.warn("Autoplay / play prevented:", err);
      });
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = Number(e.target.value);
    setCurrentTime(targetTime);
    if (videoRef.current) {
      videoRef.current.currentTime = targetTime;
    }
    resetControlsTimeout();
  };

  const handleSkip = (seconds: number) => {
    if (videoRef.current) {
      const nextTime = Math.min(Math.max(0, videoRef.current.currentTime + seconds), duration);
      videoRef.current.currentTime = nextTime;
      setCurrentTime(nextTime);
      resetControlsTimeout();
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
      setIsMuted(val === 0);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      const nextMuted = !isMuted;
      videoRef.current.muted = nextMuted;
      setIsMuted(nextMuted);
      if (nextMuted) {
        setVolume(0);
      } else {
        setVolume(1);
        videoRef.current.volume = 1;
      }
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const togglePictureInPicture = async () => {
    if (videoRef.current) {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else if (document.pictureInPictureEnabled) {
          await videoRef.current.requestPictureInPicture();
        }
      } catch (err) {
        console.warn("Picture in picture unavailable", err);
      }
    }
  };

  // Keyboard accessibility shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        handlePlayPause();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        handleSkip(-10);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        handleSkip(10);
      } else if (e.key === "m" || e.key === "M") {
        e.preventDefault();
        toggleMute();
      } else if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        toggleFullscreen();
      } else if (e.key === "Escape") {
        if (!document.fullscreenElement) {
          onClose();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isPlaying, isMuted]);

  return (
    <div 
      id="video-player-modal"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200 select-none overflow-hidden"
      onClick={onClose}
    >
      <div 
        ref={containerRef}
        className="relative w-full max-w-4xl h-full sm:h-auto sm:max-h-[90vh] aspect-video bg-[#0A0A0C] border sm:border-slate-800/80 rounded-none sm:rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
        onMouseMove={resetControlsTimeout}
        onTouchStart={resetControlsTimeout}
      >
        {/* TOP OVERLAY HEADER */}
        <div 
          className={`absolute top-0 left-0 right-0 z-30 bg-gradient-to-b from-black/90 via-black/50 to-transparent p-4 flex items-center justify-between transition-opacity duration-300 ${
            showControls ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
          }`}
        >
          <div className="flex items-center gap-3 min-w-0 pr-4">
            <div className="p-2 bg-red-600/20 text-[#E50914] rounded-xl border border-red-500/30 shrink-0">
              <Film size={18} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[9px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded bg-red-600 text-white shadow-sm flex items-center gap-1">
                  {isCdnAccelerated ? <Cloud size={10} className="shrink-0" /> : <Zap size={10} className="shrink-0" />}
                  {streamQualityLabel}
                </span>
                <span className="text-[10px] font-mono font-bold text-slate-400">
                  {media.genre || "HD Feature"}
                </span>
                {isCdnAccelerated && (
                  <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                    <Zap size={9} /> CDN FAST
                  </span>
                )}
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-white font-sans truncate leading-snug">
                {media.title}
              </h3>
            </div>
          </div>

          {/* Activity Protection & Close Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Live Streaming Activity Protection Pill */}
            <div 
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-xl text-[10px] font-mono font-bold border transition-colors ${
                heartbeatActive 
                  ? "bg-emerald-950/80 border-emerald-400 text-emerald-300 shadow-lg shadow-emerald-500/20" 
                  : "bg-slate-900/80 border-slate-700 text-slate-300"
              }`}
              title="Continuous streaming keeps your account active and shields you from the 30-day inactivity purge."
            >
              <span className={`w-2 h-2 rounded-full ${heartbeatActive ? "bg-emerald-400 animate-ping" : "bg-emerald-500"}`} />
              <span>{heartbeatActive ? "Pulse Synced" : "Purge Protected"}</span>
            </div>

            <button
              id="close-stream-player-btn"
              type="button"
              onClick={onClose}
              className="p-2 rounded-full bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition cursor-pointer active:scale-95"
              title="Close Player"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* MAIN VIDEO CANVAS */}
        <div className="relative flex-1 w-full h-full flex items-center justify-center bg-black overflow-hidden group">
          {rawStreamUrl ? (
            <video
              ref={videoRef}
              poster={media.thumbnailUrl}
              playsInline
              preload="auto"
              crossOrigin="anonymous"
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onWaiting={() => setIsLoading(true)}
              onPlaying={() => {
                setIsLoading(false);
                setIsPlaying(true);
              }}
              onPause={() => setIsPlaying(false)}
              onError={(e) => {
                console.warn("Video playback native error:", e);
                setIsLoading(false);
                setPlaybackError("Online stream unavailable or format not supported directly. You can use the high-speed download link!");
              }}
              onClick={handlePlayPause}
              className="w-full h-full object-contain cursor-pointer"
            />
          ) : (
            <div className="p-8 text-center space-y-3">
              <AlertCircle size={40} className="text-amber-400 mx-auto" />
              <h4 className="text-sm font-bold text-white font-mono">Stream Link Processing</h4>
              <p className="text-xs text-slate-400 max-w-sm">
                This media file is currently queued on our content delivery network. Please use the direct download option or retry shortly.
              </p>
            </div>
          )}

          {/* Loading Spinner Indicator */}
          {isLoading && !playbackError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 pointer-events-none">
              <Loader2 size={44} className="text-[#E50914] animate-spin" />
              <span className="text-[11px] font-mono text-slate-300 font-bold mt-2 flex items-center gap-1.5">
                <Zap size={12} className="text-amber-400 animate-pulse" /> Fast Buffering...
              </span>
            </div>
          )}

          {/* Playback Error Fallback Card */}
          {playbackError && (
            <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-6 text-center space-y-3 z-20">
              <div className="p-3 bg-red-600/20 text-red-400 rounded-2xl border border-red-500/30">
                <AlertCircle size={32} />
              </div>
              <h4 className="text-sm font-bold text-white font-mono">Direct Streaming Notice</h4>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                {playbackError}
              </p>
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setPlaybackError(null);
                    setIsLoading(true);
                    if (videoRef.current) {
                      videoRef.current.load();
                      videoRef.current.play().catch(() => {});
                    }
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-mono font-bold transition flex items-center gap-1.5"
                >
                  <RefreshCw size={12} /> Retry Stream
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-mono font-bold transition"
                >
                  Close Player
                </button>
              </div>
            </div>
          )}

          {/* Quick Center Tap Feedback Icons */}
          {!isLoading && !playbackError && (
            <button
              type="button"
              onClick={handlePlayPause}
              className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-5 rounded-full bg-black/60 backdrop-blur-md text-white border border-white/20 transition-all duration-300 hover:scale-110 active:scale-95 cursor-pointer shadow-2xl ${
                showControls ? "opacity-90 pointer-events-auto" : "opacity-0 pointer-events-none"
              }`}
            >
              {isPlaying ? <Pause size={32} /> : <Play size={32} className="translate-x-0.5 fill-current" />}
            </button>
          )}

          {/* Quality Selector Overlay Menu */}
          {showQualityMenu && availableLevels.length > 0 && (
            <div className="absolute right-4 bottom-16 z-40 bg-slate-900/95 border border-slate-700/80 backdrop-blur-xl rounded-2xl p-2 shadow-2xl space-y-1 min-w-[130px] animate-in fade-in zoom-in-95">
              <div className="text-[10px] font-mono font-bold text-slate-400 px-2 py-1 border-b border-slate-800 flex items-center gap-1">
                <Settings size={11} /> Quality Settings
              </div>
              <button
                type="button"
                onClick={() => handleSelectQuality(-1)}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center justify-between ${
                  currentLevel === -1 ? "bg-red-600 text-white" : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                <span>Auto</span>
                {currentLevel === -1 && <span className="text-[9px]">✓</span>}
              </button>
              {availableLevels.map((lvl) => (
                <button
                  key={lvl.id}
                  type="button"
                  onClick={() => handleSelectQuality(lvl.id)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center justify-between ${
                    currentLevel === lvl.id ? "bg-red-600 text-white" : "text-slate-300 hover:bg-slate-800"
                  }`}
                >
                  <span>{lvl.height}p HD</span>
                  {currentLevel === lvl.id && <span className="text-[9px]">✓</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* BOTTOM OVERLAY CONTROLS */}
        <div 
          className={`absolute bottom-0 left-0 right-0 z-30 bg-gradient-to-t from-black/95 via-black/70 to-transparent p-3 sm:p-4 space-y-2 transition-opacity duration-300 ${
            showControls ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
          }`}
        >
          {/* Seek Progress Bar */}
          <div className="relative group/progress flex items-center">
            {/* Background Track */}
            <div className="w-full h-1.5 bg-slate-800/80 rounded-full overflow-hidden relative group-hover/progress:h-2 transition-all">
              {/* Buffered Bar */}
              <div 
                className="absolute top-0 left-0 bottom-0 bg-slate-600/60 transition-all duration-300"
                style={{ width: `${bufferedPercent}%` }}
              />
              {/* Played Bar */}
              <div 
                className="absolute top-0 left-0 bottom-0 bg-[#E50914] transition-all"
                style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
              />
            </div>

            {/* Range Input slider */}
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
          </div>

          {/* Controls Bottom Row */}
          <div className="flex items-center justify-between gap-2 pt-1">
            {/* Left Controls: Play/Pause, Skips, Timer */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={handlePlayPause}
                className="p-2 rounded-xl text-white hover:bg-white/10 transition cursor-pointer active:scale-95"
                title={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? <Pause size={18} /> : <Play size={18} className="fill-current" />}
              </button>

              <button
                type="button"
                onClick={() => handleSkip(-10)}
                className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="Rewind 10s"
              >
                <RotateCcw size={16} />
              </button>

              <button
                type="button"
                onClick={() => handleSkip(10)}
                className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="Forward 10s"
              >
                <RotateCw size={16} />
              </button>

              {/* Volume Slider & Toggle */}
              <div className="hidden sm:flex items-center gap-1.5 group/vol">
                <button
                  type="button"
                  onClick={toggleMute}
                  className="p-1.5 rounded-xl text-slate-300 hover:text-white transition cursor-pointer"
                >
                  {isMuted || volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-16 h-1 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-[#E50914]"
                />
              </div>

              {/* Elapsed / Duration Time */}
              <span className="text-[11px] font-mono text-slate-300 font-bold whitespace-nowrap ml-1">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            {/* Right Controls: Quality Menu, Watch Time HUD, PiP, Fullscreen */}
            <div className="flex items-center gap-2">
              {/* Quality Settings Selector (when HLS is active) */}
              {availableLevels.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowQualityMenu(prev => !prev)}
                  className="p-1.5 px-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition cursor-pointer flex items-center gap-1 text-[10px] font-mono font-bold"
                  title="Stream Quality"
                >
                  <Settings size={13} />
                  <span>{streamQualityLabel}</span>
                </button>
              )}

              {/* Live Session Watch Time Metric Display */}
              <div 
                className="bg-slate-900/90 border border-slate-700/80 px-2.5 py-1 rounded-xl flex items-center gap-1.5 text-[10px] font-mono font-black text-amber-300 shadow-inner"
                title="Continuous session watch time recorded for this video."
              >
                <Clock size={12} className="text-amber-400" />
                <span>{formatTime(secondsWatchedInSession)} Watched</span>
              </div>

              {/* Picture In Picture */}
              <button
                type="button"
                onClick={togglePictureInPicture}
                className="hidden sm:inline-flex p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="Picture in Picture"
              >
                <PictureInPicture size={16} />
              </button>

              {/* Fullscreen Toggle */}
              <button
                type="button"
                onClick={toggleFullscreen}
                className="p-1.5 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
              >
                {isFullscreen ? <Minimize size={16} /> : <Maximize size={16} />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
