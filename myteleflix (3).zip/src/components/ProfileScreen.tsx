/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { 
  Shield, 
  Copy, 
  Check, 
  Crown, 
  LogOut, 
  Loader2,
  User as UserIcon,
  Settings as SettingsIcon,
  Pencil,
  X,
  Send,
  Zap,
  CheckCircle2,
  Gift,
  Headphones,
  ChevronRight,
  ShieldCheck,
  Lock,
  Wallet,
  ArrowRight
} from "lucide-react";
import { User, Transaction, SystemSettings } from "../types";
import { useAuth, isSuperAdminEmail } from "../context/AuthContext";
import { getRandomAvatar, logoutUser, MALE_AVATARS, FEMALE_AVATARS, checkDevicePolicy } from "../services/auth";
import { getDiceBearAvatar, isUnsplashOrBrokenPhoto } from "../utils/avatar";
import { ADMIN_EMAILS, MASTER_ADMIN_EMAIL, isEmailInAdminWhitelist } from "../constants";
import { getCachedDeviceFingerprint, getDeviceFingerprint, getGuestDeviceId } from "../utils/fingerprint";
import { 
  auth, 
  googleProvider, 
  saveUserToFirestore, 
  getUserFromFirestore, 
  isUserInAdminWhitelist, 
  ensureSuperAdminExists
} from "../services/firebase";
import { signInWithPopup, signInWithRedirect, getRedirectResult, signOut } from "firebase/auth";
import { 
  checkDeviceLock, 
  bindDeviceLock, 
  restorePrimaryAccount, 
  clearSecondaryDraftSession,
  generateCrossBrowserHardwareId,
  getCrossBrowserHardwareTraits
} from "../SecurityManager";
import { bindHardwareDevice, generateDeviceHardwareUUID } from "../SecurityGuard";
import PlatformPolicyModal from "./PlatformPolicyModal";
import PolicyViolationModal from "./PolicyViolationModal";
import AppSettingsTab from "./profile/AppSettingsTab";
import GuestActivationCard from "./profile/GuestActivationCard";
import OnboardingFlow from "./OnboardingFlow";
import { Gender3DAvatar } from "./profile/Gender3DAvatar";
import TaskStatusModal from "./modals/TaskStatusModal";
import LiveSupportModal from "./modals/LiveSupportModal";
import { CoreHub } from "./CoreHub";
import WalletScreen from "./WalletScreen";
import { useCommunitySettings } from "../hooks/useCommunitySettings";
import IdentityVerificationScreen from "./IdentityVerificationScreen";
import IdentityVerifyModal, { shouldShowSecurityNotice } from "./IdentityVerifyModal";
import EditProfileModal from "./EditProfileModal";
import { UserProfileData } from "../db";

// Crisp Community SVGs Matching Authentic Brand Assets
const TelegramIcon: React.FC = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white" aria-hidden="true">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.19-.08-.05-.19-.02-.27 0-.12.03-1.99 1.27-5.63 3.72-.53.36-1.01.54-1.44.53-.47-.01-1.38-.27-2.06-.49-.83-.27-1.49-.42-1.43-.88.03-.24.38-.49 1.03-.75 4.04-1.76 6.74-2.92 8.09-3.48 3.85-1.6 4.65-1.88 5.17-1.89.11 0 .37.03.54.17.14.12.18.28.2.45-.02.07-.02.13-.03.22z"/>
  </svg>
);

const WhatsAppIcon: React.FC = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white" aria-hidden="true">
    {/* Crisp centered official vector phone handset receiver */}
    <path d="M6.62 10.79a15.053 15.053 0 0 0 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
  </svg>
);

const YouTubeIcon: React.FC = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white" aria-hidden="true">
    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
  </svg>
);

const FacebookIcon: React.FC = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white" aria-hidden="true">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
  </svg>
);

export { MASTER_ADMIN_EMAIL, ADMIN_EMAILS };

interface ProfileScreenProps {
  user: User;
  transactions?: Transaction[];
  minimumWithdrawal?: number;
  tokenRateBdt?: number;
  tokenRateUsd?: number;
  settings?: SystemSettings;
  onWithdraw?: (
    amount: number, 
    destination: string, 
    paymentMethod?: string, 
    email?: string, 
    accountNumber?: string
  ) => Promise<{ success: boolean; error?: string }>;
  onOpenAdmin?: () => void;
  onSecretAdminTrigger?: () => void;
  onOpenWallet?: () => void;
  onNavigate?: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
  isAdultUnlocked?: boolean;
  onToggleAdultUnlock?: (unlocked: boolean) => void;
  onTriggerAuth?: (action: 'withdraw' | 'referral' | 'adult_unlock' | 'earn' | 'generic') => void;
  onLoginSuccess?: (user: User) => void;
  onLogout?: () => void;
}

function ProfileScreenComponent({ 
  user, 
  transactions = [],
  minimumWithdrawal = 1000,
  tokenRateBdt = 100,
  tokenRateUsd = 0.85,
  settings,
  onWithdraw,
  onOpenAdmin,
  onSecretAdminTrigger,
  onOpenWallet,
  onNavigate,
  isAdultUnlocked = false,
  onToggleAdultUnlock,
  onTriggerAuth,
  onLoginSuccess,
  onLogout
}: ProfileScreenProps) {
  const { logout, updateGender, updateUserProfile, role } = useAuth();
  const [showWalletModal, setShowWalletModal] = useState<boolean>(false);
  const [profileAvatarImgError, setProfileAvatarImgError] = useState<boolean>(false);

  useEffect(() => {
    setProfileAvatarImgError(false);
  }, [user?.photoURL, user?.photoUrl, user?.gender]);

  const handleOpenWallet = useCallback(() => {
    if (onOpenWallet) {
      onOpenWallet();
    } else if (onNavigate) {
      onNavigate('wallet');
    } else {
      setShowWalletModal(true);
    }
  }, [onOpenWallet, onNavigate]);
  
  // 1. Navigation Tab: [ ACCOUNT & REWARDS ] vs [ VERIFY IDENTITY ] vs [ APP SETTINGS ]
  const [dualTab, setDualTab] = useState<'account' | 'verify' | 'settings'>('account');
  const [showSecurityNotice, setShowSecurityNotice] = useState<boolean>(false);

  const tabsContainerRef = useRef<HTMLDivElement>(null);
  const tabAccountRef = useRef<HTMLButtonElement>(null);
  const tabVerifyRef = useRef<HTMLButtonElement>(null);
  const tabSettingsRef = useRef<HTMLButtonElement>(null);

  const scrollToTab = useCallback((tab: 'account' | 'verify' | 'settings') => {
    const container = tabsContainerRef.current;
    if (!container) return;

    let targetButton: HTMLButtonElement | null = null;
    if (tab === 'account') {
      targetButton = tabAccountRef.current;
    } else if (tab === 'verify') {
      targetButton = tabVerifyRef.current;
    } else if (tab === 'settings') {
      targetButton = tabSettingsRef.current;
    }

    if (!targetButton) return;

    if (tab === 'account') {
      container.scrollTo({ left: 0, behavior: 'smooth' });
    } else {
      // When clicking right-side options ('verify' or 'settings'), automatically shift them smoothly to the left
      const targetOffset = targetButton.offsetLeft - container.offsetLeft - 8;
      container.scrollTo({
        left: Math.max(0, targetOffset),
        behavior: 'smooth'
      });
    }
  }, []);

  useEffect(() => {
    const timeout = setTimeout(() => {
      scrollToTab(dualTab);
    }, 60);
    return () => clearTimeout(timeout);
  }, [dualTab, scrollToTab]);

  // Auth & Role Resolution
  const isGuest = !user || user.role === 'guest' || user.id?.startsWith('guest_') || user.id === 'tg-guest';

  // STRICT GUEST POLICY ENFORCEMENT:
  // Guest mode must ONLY have access to 'account' and 'settings'.
  // 'verify' (Identity Verification) is strictly reserved for VIP Users after registration.
  useEffect(() => {
    if (isGuest && dualTab === 'verify') {
      setDualTab('account');
    }
  }, [isGuest, dualTab]);

  const handleOpenVerifyTab = () => {
    if (isGuest) {
      if (onTriggerAuth) {
        onTriggerAuth('generic');
      }
      return;
    }
    // Strict One-Time Account Verification notice per account lifecycle:
    // If account_verification_notice_seen is 'true', navigate directly to the verification form.
    const alreadySeen = typeof window !== "undefined" && localStorage.getItem('account_verification_notice_seen') === 'true';
    if (!alreadySeen && shouldShowSecurityNotice(settings?.verificationSettings?.noticeFrequencyHours)) {
      setShowSecurityNotice(true);
    } else {
      setDualTab('verify');
    }
  };

  // Authenticated Sub-Tabs
  const [accountSubTab, setAccountSubTab] = useState<'referral' | 'ledger'>('referral');

  // Secret Multi-Tap Tracker for Master Admin Gateway
  const profileTapTimestampsRef = useRef<number[]>([]);
  const handleProfileAvatarClick = () => {
    const now = Date.now();
    profileTapTimestampsRef.current = profileTapTimestampsRef.current.filter((t: number) => now - t <= 2000);
    profileTapTimestampsRef.current.push(now);

    if (profileTapTimestampsRef.current.length >= 5) {
      profileTapTimestampsRef.current = [];
      if (onSecretAdminTrigger) {
        onSecretAdminTrigger();
      }
    }
  };
  
  // Strict Zero-Trust Admin Isolation:
  // Render the Admin Panel Entry Banner ONLY if verified in ADMIN_WHITELIST. Hide it completely for normal users.
  const currentUserEmail = (user?.email || "").toLowerCase().trim();
  const isMasterAdmin = Boolean(
    currentUserEmail && 
    isEmailInAdminWhitelist(currentUserEmail) &&
    (role === 'ADMIN' || user?.role === 'ADMIN' || role === 'admin' || user?.role === 'admin')
  );
  const isSuperAdminUser = isMasterAdmin;
  
  // Authentication & Loading States
  const [isConnectingGoogle, setIsConnectingGoogle] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Modals State (NO AUTOMATIC POPUPS)
  const [showPlatformPolicyModal, setShowPlatformPolicyModal] = useState<boolean>(false);
  const [showOnboarding, setShowOnboarding] = useState<boolean>(false);
  const [showTaskStatusModal, setShowTaskStatusModal] = useState<boolean>(false);
  const [showLiveSupportModal, setShowLiveSupportModal] = useState<boolean>(false);
  const [policyViolationModalState, setPolicyViolationModalState] = useState<{
    isOpen: boolean;
    error?: string;
    existingAccount?: any;
    deviceFingerprint?: string;
    ipAddress?: string;
  }>({ isOpen: false });

  // Task Review Detailed Statistics State
  const [userTasksList, setUserTasksList] = useState<any[]>([]);
  const [taskReviewStats, setTaskReviewStats] = useState<{
    completed: number;
    pending: number;
    rejected: number;
    total: number;
  }>({ completed: 0, pending: 0, rejected: 0, total: 0 });

  // Load and calculate user task statistics (Completed, Pending, Rejected, by category)
  useEffect(() => {
    if (!user?.id) return;
    fetch(`/api/tasks?userId=${encodeURIComponent(user.id)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.tasks)) {
          const mappedTasks = data.tasks.map((t: any) => ({
            id: t.task_id || t.id,
            title: t.title || "Earn Task",
            type: t.task_type || "EARNING",
            rewardPoints: t.reward_points || 500,
            status: t.is_completed_today ? "completed" : t.status === "EXPIRED" ? "rejected" : "pending",
            timestamp: new Date().toISOString()
          }));
          setUserTasksList(mappedTasks);
          
          const completedCount = mappedTasks.filter((t: any) => t.status === "completed").length + (user.taskStats?.missionsCompleted || 0);
          const pendingCount = mappedTasks.filter((t: any) => t.status === "pending").length;
          const rejectedCount = mappedTasks.filter((t: any) => t.status === "rejected").length;
          
          setTaskReviewStats({
            completed: completedCount,
            pending: pendingCount,
            rejected: rejectedCount,
            total: completedCount + pendingCount + rejectedCount
          });
        }
      })
      .catch(() => {
        // Fallback to user.taskStats if network fails
        const completed = (user.taskStats?.missionsCompleted || 0) + (user.taskStats?.videosWatched || 0);
        setTaskReviewStats({
          completed,
          pending: 0,
          rejected: 0,
          total: completed
        });
      });
  }, [user?.id, user?.taskStats]);

  // Dynamic Community & Support Links from Firestore /system_configs/community_settings
  const { settings: communitySettings } = useCommunitySettings();
  
  // Edit Profile Modal States (Pencil Icon Trigger)
  const [showEditProfileModal, setShowEditProfileModal] = useState<boolean>(false);
  
  // Filters & State
  const [copiedUid, setCopiedUid] = useState<boolean>(false);
  const [isUpdatingGender, setIsUpdatingGender] = useState<boolean>(false);

  // Hardware ID state
  const [hwid, setHwid] = useState<string>(() => {
    return getCachedDeviceFingerprint() || "fp_d0870c0b68934aa1b";
  });

  useEffect(() => {
    getDeviceFingerprint().then((fp: string) => {
      if (fp) setHwid(fp);
    }).catch(() => {});
  }, []);

  // Direct Firebase Google Authentication Flow
  const handleDirectGoogleSignIn = async () => {
    try {
      setIsConnectingGoogle(true);
      setAuthError(null);

      // 1. Direct Firebase Google Popup
      let fbUser;
      try {
        const result = await signInWithPopup(auth, googleProvider);
        fbUser = result.user;
      } catch (popupErr: any) {
        if (popupErr.code === 'auth/popup-blocked') {
          console.warn("Popup blocked by browser, falling back to signInWithRedirect");
          await signInWithRedirect(auth, googleProvider);
          return;
        }
        throw popupErr;
      }

      if (!fbUser) {
        throw new Error("No user returned from Google authentication.");
      }

      const email = (fbUser.email || "").toLowerCase().trim();
      const isSuper = email === MASTER_ADMIN_EMAIL.toLowerCase() || ADMIN_EMAILS.includes(email);
      // Strictly enforce: only whitelisted ADMIN_EMAILS receive admin role, all other new or existing sign-ups default strictly to 'user' (VIP USER)
      const assignedRole: 'admin' | 'user' = isSuper ? 'admin' : 'user';

      const fp = hwid || getCachedDeviceFingerprint();

      // STRICT 1-DEVICE = 1-ACCOUNT HARDWARE LOCK ENFORCEMENT:
      if (!isSuper) {
        const lockCheck = await checkDeviceLock(fp, email);
        if (lockCheck.isBlocked) {
          await signOut(auth).catch(() => {});
          clearSecondaryDraftSession();
          setIsConnectingGoogle(false);
          setPolicyViolationModalState({
            isOpen: true,
            error: "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
            existingAccount: { email: lockCheck.primaryEmail },
            deviceFingerprint: fp,
            ipAddress: ''
          });
          return;
        }
      }

      // STRICT 1-DEVICE = 1-ACCOUNT POLICY ENFORCEMENT:
      const deviceCheck = await checkDevicePolicy({
        deviceFingerprint: fp,
        clientIp: '',
        userId: fbUser.uid,
        email
      });

      if (!deviceCheck.allowed) {
        await signOut(auth).catch(() => {});
        clearSecondaryDraftSession();
        setIsConnectingGoogle(false);
        setPolicyViolationModalState({
          isOpen: true,
          error: deviceCheck.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          existingAccount: deviceCheck.existingAccount,
          deviceFingerprint: fp,
          ipAddress: deviceCheck.ipAddress
        });
        return;
      }

      if (isSuper) {
        await ensureSuperAdminExists(email, fbUser.displayName || undefined);
      }

      // 2. Fetch existing Firestore user document to preserve existing points and stats
      const existingDoc = await getUserFromFirestore(fbUser.uid);
      const gId = getGuestDeviceId(fp);

      // Check isOnboarded boolean field from Firestore (users/{uid})
      const isAlreadyOnboarded = Boolean((existingDoc as any)?.onboardingCompleted === true || existingDoc?.isOnboarded === true || existingDoc?.profileInitialized === true);

      // If already onboarded, preserve their customized display name & gender from Firestore
      const resolvedDisplayName = (isAlreadyOnboarded && (existingDoc?.displayName || existingDoc?.fullName))
        ? (existingDoc.displayName || existingDoc.fullName)
        : (fbUser.displayName || existingDoc?.displayName || existingDoc?.fullName || email.split('@')[0] || "Google Member");
      const resolvedPhoto = fbUser.photoURL || existingDoc?.photoURL || existingDoc?.photoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80";
      const resolvedGender: 'Male' | 'Female' = (existingDoc?.gender?.toLowerCase() === 'female') ? 'Female' : 'Male';

      const authenticatedUser: User = {
        id: fbUser.uid,
        googleId: fbUser.uid,
        telegramId: existingDoc?.telegramId || "",
        username: existingDoc?.username || email.split('@')[0] || "member",
        fullName: resolvedDisplayName,
        displayName: resolvedDisplayName,
        email,
        photoUrl: resolvedPhoto,
        photoURL: resolvedPhoto,
        gender: resolvedGender,
        points: existingDoc?.points ?? 100,
        createdAt: existingDoc?.createdAt || new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        device_fingerprint: fp,
        guest_device_id: gId,
        isPremium: existingDoc?.isPremium || false,
        role: assignedRole,
        authProvider: 'google',
        onboardingCompleted: isAlreadyOnboarded,
        isOnboarded: isAlreadyOnboarded,
        profileInitialized: isAlreadyOnboarded,
        status: 'active'
      };

      // 3. Register & verify on Server backend
      const crossHwid = await generateCrossBrowserHardwareId();
      const traits = getCrossBrowserHardwareTraits();
      const hwUUID = await generateDeviceHardwareUUID();

      const serverRes = await fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: authenticatedUser.email,
          fullName: authenticatedUser.fullName,
          displayName: authenticatedUser.displayName,
          photoUrl: authenticatedUser.photoUrl,
          photoURL: authenticatedUser.photoURL,
          googleId: authenticatedUser.id,
          role: assignedRole,
          device_fingerprint: fp,
          hwid,
          cross_browser_hwid: crossHwid,
          hardware_uuid: hwUUID,
          gpu_renderer: traits.gpu_renderer,
          gpu_chipset: traits.gpu_chipset,
          screen_resolution: traits.screen_resolution,
          physical_screen: traits.physical_screen,
          hardware_concurrency: traits.hardware_concurrency,
          cpu_cores: traits.cpu_cores,
          timezone: traits.timezone,
          platform: traits.platform,
          platform_family: traits.platform_family,
          guest_device_id: gId
        })
      });

      if (serverRes.status === 403) {
        const errData = await serverRes.json();
        await signOut(auth).catch(() => {});
        clearSecondaryDraftSession();
        setIsConnectingGoogle(false);
        setPolicyViolationModalState({
          isOpen: true,
          error: errData.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          existingAccount: errData.existingAccount || { email: errData.primaryEmail },
          deviceFingerprint: fp,
          ipAddress: errData.ip
        });
        return;
      }

      if (serverRes.ok) {
        const serverData = await serverRes.json();
        if (serverData.user) {
          authenticatedUser.points = serverData.user.wallet?.points ?? serverData.user.points ?? authenticatedUser.points;
          if (serverData.user.taskStats) authenticatedUser.taskStats = serverData.user.taskStats;
        }
      }

      // 4. Save/update user profile document in Firestore (users/{uid})
      await saveUserToFirestore(authenticatedUser);

      // Bind hardware device and device lock permanently across browsers
      if (email) {
        await bindDeviceLock(email, authenticatedUser.id, fp);
        await bindHardwareDevice(email);
      }

      // 5. Update localStorage
      localStorage.setItem("myteleflix_user", JSON.stringify(authenticatedUser));

      // 5. Swap Guest onboarding card with Authenticated Dashboard
      if (onLoginSuccess) {
        onLoginSuccess(authenticatedUser);
      }

      // 6. Conditional Onboarding State Check:
      // If isOnboarded === true: Bypass modal completely and load VIP Profile Dashboard directly.
      // If isOnboarded is undefined or false: Display 2-Step Onboarding Modal.
      if (isAlreadyOnboarded) {
        setShowOnboarding(false);
      } else {
        setShowOnboarding(true);
      }
    } catch (err: any) {
      console.warn("Direct Firebase Google Sign-In error:", err);
      if (err.code === 'auth/popup-closed-by-user') {
        // User closed the popup
      } else if (err.code === 'auth/cancelled-popup-request') {
        // Ignored
      } else {
        setAuthError(err.message || "Google authentication failed. Please try again.");
      }
    } finally {
      setIsConnectingGoogle(false);
    }
  };

  // Check for any redirect result (if popup was blocked and fallback used)
  useEffect(() => {
    getRedirectResult(auth).then(async (result) => {
      if (result?.user) {
        const fbUser = result.user;
        const email = (fbUser.email || "").toLowerCase().trim();
        const isSuper = ADMIN_EMAILS.includes(email);
        // Strictly enforce: only whitelisted ADMIN_EMAILS receive admin role, all other new or existing sign-ups default strictly to 'user' (VIP USER)
        const assignedRole: 'admin' | 'user' = isSuper ? 'admin' : 'user';

        const fp = hwid || getCachedDeviceFingerprint();

        if (!isSuper) {
          const lockCheck = await checkDeviceLock(fp, email);
          if (lockCheck.isBlocked) {
            await signOut(auth).catch(() => {});
            clearSecondaryDraftSession();
            setPolicyViolationModalState({
              isOpen: true,
              error: "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
              existingAccount: { email: lockCheck.primaryEmail },
              deviceFingerprint: fp,
              ipAddress: ''
            });
            return;
          }
        }

        const deviceCheck = await checkDevicePolicy({
          deviceFingerprint: fp,
          clientIp: '',
          userId: fbUser.uid,
          email
        });

        if (!deviceCheck.allowed) {
          await signOut(auth).catch(() => {});
          clearSecondaryDraftSession();
          setPolicyViolationModalState({
            isOpen: true,
            error: deviceCheck.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
            existingAccount: deviceCheck.existingAccount,
            deviceFingerprint: fp,
            ipAddress: deviceCheck.ipAddress
          });
          return;
        }

        if (isSuper) {
          await ensureSuperAdminExists(email, fbUser.displayName || undefined);
        }

        const existingDoc = await getUserFromFirestore(fbUser.uid);
        const gId = getGuestDeviceId(fp);

        const isAlreadyOnboarded = Boolean(existingDoc?.isOnboarded === true || existingDoc?.profileInitialized === true);
        const resolvedDisplayName = (isAlreadyOnboarded && (existingDoc?.displayName || existingDoc?.fullName))
          ? (existingDoc.displayName || existingDoc.fullName)
          : (fbUser.displayName || existingDoc?.displayName || existingDoc?.fullName || email.split('@')[0] || "Google Member");
        const resolvedPhoto = fbUser.photoURL || existingDoc?.photoURL || existingDoc?.photoUrl || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80";
        const resolvedGender: 'Male' | 'Female' = (existingDoc?.gender?.toLowerCase() === 'female') ? 'Female' : 'Male';

        const authenticatedUser: User = {
          id: fbUser.uid,
          googleId: fbUser.uid,
          telegramId: existingDoc?.telegramId || "",
          username: existingDoc?.username || email.split('@')[0] || "member",
          fullName: resolvedDisplayName,
          displayName: resolvedDisplayName,
          email,
          photoUrl: resolvedPhoto,
          photoURL: resolvedPhoto,
          gender: resolvedGender,
          points: existingDoc?.points ?? 100,
          createdAt: existingDoc?.createdAt || new Date().toISOString(),
          last_active_at: new Date().toISOString(),
          device_fingerprint: fp,
          guest_device_id: gId,
          isPremium: existingDoc?.isPremium || false,
          role: assignedRole,
          authProvider: 'google',
          isOnboarded: isAlreadyOnboarded,
          profileInitialized: isAlreadyOnboarded,
          status: 'active'
        };

        const crossHwid = await generateCrossBrowserHardwareId();
        const traits = getCrossBrowserHardwareTraits();
        const hwUUID = await generateDeviceHardwareUUID();

        const serverRes = await fetch("/api/auth/google", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: authenticatedUser.email,
            fullName: authenticatedUser.fullName,
            displayName: authenticatedUser.displayName,
            photoUrl: authenticatedUser.photoUrl,
            photoURL: authenticatedUser.photoURL,
            googleId: authenticatedUser.id,
            role: assignedRole,
            device_fingerprint: fp,
            hwid,
            cross_browser_hwid: crossHwid,
            hardware_uuid: hwUUID,
            gpu_renderer: traits.gpu_renderer,
            gpu_chipset: traits.gpu_chipset,
            screen_resolution: traits.screen_resolution,
            physical_screen: traits.physical_screen,
            hardware_concurrency: traits.hardware_concurrency,
            cpu_cores: traits.cpu_cores,
            timezone: traits.timezone,
            platform: traits.platform,
            platform_family: traits.platform_family,
            guest_device_id: gId
          })
        });

        if (serverRes.status === 403) {
          const errData = await serverRes.json();
          await signOut(auth).catch(() => {});
          clearSecondaryDraftSession();
          setPolicyViolationModalState({
            isOpen: true,
            error: errData.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
            existingAccount: errData.existingAccount || { email: errData.primaryEmail },
            deviceFingerprint: fp,
            ipAddress: errData.ip
          });
          return;
        }

        if (serverRes.ok) {
          const serverData = await serverRes.json();
          if (serverData.user) {
            authenticatedUser.points = serverData.user.wallet?.points ?? serverData.user.points ?? authenticatedUser.points;
            if (serverData.user.taskStats) authenticatedUser.taskStats = serverData.user.taskStats;
          }
        }

        await saveUserToFirestore(authenticatedUser);
        if (email) {
          await bindDeviceLock(email, authenticatedUser.id, fp);
          await bindHardwareDevice(email);
        }
        localStorage.setItem("myteleflix_user", JSON.stringify(authenticatedUser));
        if (onLoginSuccess) {
          onLoginSuccess(authenticatedUser);
        }

        if (isAlreadyOnboarded) {
          setShowOnboarding(false);
        } else {
          setShowOnboarding(true);
        }
      }
    }).catch((err) => {
      console.warn("Redirect auth check:", err);
    });
  }, [hwid, onLoginSuccess]);

  // FIRESTORE ONBOARDING STATE CHECK (PERSISTENT & ACCURATE):
  // Check if the signed-in user has completed onboarding in Firestore (users/{uid})
  useEffect(() => {
    let isCancelled = false;
    if (isGuest || !user || !user.id) {
      setShowOnboarding(false);
      return;
    }

    // Fast-path: If user document already marked onboardingCompleted in active memory or required profile fields are present, ensure modal is closed
    const hasRequiredFields = Boolean((user as any).onboardingCompleted === true || user.isOnboarded === true || user.profileInitialized === true || user.isProfileCompleted === true || (user.gender && (user.displayName || user.fullName)));
    if (hasRequiredFields) {
      setShowOnboarding(false);
      return;
    }

    // Read Firestore user document (users/{uid}) to verify single source of truth
    getUserFromFirestore(user.id).then((freshDoc) => {
      if (isCancelled) return;
      if (freshDoc) {
        const isDocOnboarded = (freshDoc as any).onboardingCompleted === true || freshDoc.isOnboarded === true || freshDoc.profileInitialized === true;
        if (isDocOnboarded) {
          // Bypass onboarding modal completely and load VIP Profile Dashboard directly
          setShowOnboarding(false);
          const formattedGender: 'Male' | 'Female' = (freshDoc.gender?.toLowerCase() === 'female') ? 'Female' : 'Male';
          const syncedUser: User = {
            ...user,
            ...freshDoc,
            displayName: freshDoc.displayName || freshDoc.fullName || user.displayName,
            fullName: freshDoc.displayName || freshDoc.fullName || user.fullName,
            gender: formattedGender,
            onboardingCompleted: true,
            isOnboarded: true,
            profileInitialized: true
          };
          localStorage.setItem("myteleflix_user", JSON.stringify(syncedUser));
          if (onLoginSuccess) {
            onLoginSuccess(syncedUser);
          }
        } else {
          // isOnboarded is undefined or false: Display Onboarding Screen
          setShowOnboarding(true);
        }
      } else {
        // Document not found in Firestore yet -> Display Onboarding Screen
        setShowOnboarding(true);
      }
    }).catch((err) => {
      console.warn("Notice checking Firestore onboarding state:", err);
      if ((user as any).onboardingCompleted !== true && user.isOnboarded === false) {
        setShowOnboarding(true);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [isGuest, user?.id, user?.isOnboarded, user?.profileInitialized, onLoginSuccess]);

  // PERMANENT DATA COMMITMENT TO FIRESTORE & LOCAL STORAGE:
  // When user finishes onboarding (Gender, Name, Telegram Handle)
  const handleCompleteOnboarding = async (updatedData: Partial<User>) => {
    const rawGender = updatedData.gender || user.gender || 'male';
    const formattedGender: 'Male' | 'Female' = (rawGender.toLowerCase() === 'female') ? 'Female' : 'Male';
    const cleanName = (updatedData.displayName || updatedData.fullName || user.displayName || user.fullName || "TeleFlix Member").trim();
    const dynamicAvatar = updatedData.photoUrl || updatedData.photoURL || getRandomAvatar(formattedGender.toLowerCase() as 'male' | 'female');
    const cleanTelegram = updatedData.telegramUsername?.trim();

    const updatedUser: User = {
      ...user,
      ...updatedData,
      displayName: cleanName,
      fullName: cleanName,
      gender: formattedGender.toLowerCase() as 'male' | 'female',
      photoUrl: dynamicAvatar,
      photoURL: dynamicAvatar,
      telegramUsername: cleanTelegram || user.telegramUsername,
      isProfileCompleted: true,
      isOnboarded: true,
      profileInitialized: true,
      last_active_at: new Date().toISOString()
    };

    // 1. Commit to Firestore
    try {
      await saveUserToFirestore(updatedUser);
    } catch (fsErr) {
      console.warn("Firestore save notice:", fsErr);
    }

    // 2. Commit to localStorage with permanent flags
    if (typeof window !== "undefined") {
      localStorage.setItem("myteleflix_user", JSON.stringify(updatedUser));
      localStorage.setItem("myteleflix_isProfileCompleted", "true");
      localStorage.setItem("isProfileCompleted", "true");
      if (user?.id) {
        localStorage.setItem(`myteleflix_profile_completed_${user.id}`, "true");
        localStorage.setItem(`myteleflix_onboarding_${user.id}`, "true");
      }
    }

    // 3. Notify backend API
    try {
      await fetch("/api/auth/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          uid: user.id,
          displayName: cleanName,
          fullName: cleanName,
          gender: formattedGender.toLowerCase(),
          telegramUsername: cleanTelegram || user.telegramUsername,
          photoUrl: dynamicAvatar,
          photoURL: dynamicAvatar,
          isProfileCompleted: true,
          isOnboarded: true
        })
      });
    } catch (apiErr) {
      console.warn("Backend API update notice:", apiErr);
    }

    // 4. Update AuthContext & Global state
    try {
      await updateUserProfile(updatedUser);
    } catch (ctxErr) {
      console.warn("AuthContext update notice:", ctxErr);
    }

    if (onLoginSuccess) {
      onLoginSuccess(updatedUser);
    }
  };

  // Format Unique UID
  const uniqueUserId = `#TF-${(user.id || "MEMBER").replace(/^g-/, "").slice(-6).toUpperCase()}`;

  const handleCopyUid = () => {
    try {
      if (navigator?.clipboard?.writeText) {
        navigator.clipboard.writeText(uniqueUserId).catch(() => {
          fallbackCopyText(uniqueUserId);
        });
      } else {
        fallbackCopyText(uniqueUserId);
      }
    } catch (e) {
      console.error("Copy UID error:", e);
      fallbackCopyText(uniqueUserId);
    }
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  const fallbackCopyText = (text: string) => {
    try {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.opacity = "0";
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
    } catch {}
  };

  // Logout handler with resilient failover to guarantee session termination
  const handleLogout = async () => {
    try {
      if (onLogout) {
        onLogout();
      }
    } catch (e) {
      console.warn("onLogout execution warning:", e);
    }
    try {
      await logout();
    } catch (e) {
      console.warn("AuthContext logout warning:", e);
    }
    try {
      await logoutUser();
    } catch (e) {
      console.warn("logoutUser warning:", e);
    }
    setDualTab('account');
  };

  // Gender change handler
  const handleSelectGender = async (gender: 'male' | 'female') => {
    setIsUpdatingGender(true);
    try {
      const dynamicAvatar = getRandomAvatar(gender);
      await updateGender(gender);
      if (onLoginSuccess) {
        onLoginSuccess({
          ...user,
          gender,
          photoUrl: dynamicAvatar,
          profileInitialized: true
        });
      }
    } catch (e) {
      console.error("Gender update error:", e);
    } finally {
      setIsUpdatingGender(false);
    }
  };

  // Dynamic Gender Avatar & Telegram Identity Resolution
  const isFemale = (user?.gender || '').toLowerCase() === 'female';

  const resolvedAvatar = useMemo(() => {
    const rawPhoto = user?.photoUrl || user?.photoURL || "";
    if (rawPhoto && !isUnsplashOrBrokenPhoto(rawPhoto)) {
      return rawPhoto;
    }
    return getDiceBearAvatar(user?.gender, user?.uid || user?.id || user?.telegramId || user?.email);
  }, [user?.photoUrl, user?.photoURL, user?.gender, user?.uid, user?.id, user?.telegramId, user?.email]);

  const formattedTelegramUsername = useMemo(() => {
    const tg = user?.telegramUsername?.trim() || (user?.username && !user.username.startsWith('user_') && !user.username.startsWith('guest_') ? user.username : "");
    if (!tg || tg === "@") return "@teleflix_vip";
    return tg.startsWith('@') ? tg : `@${tg}`;
  }, [user?.telegramUsername, user?.username]);

  // Open Edit Profile Modal
  const handleOpenEditModal = () => {
    setShowEditProfileModal(true);
  };

  // Profile updated callback from EditProfileModal
  const handleProfileUpdated = (updatedProfile: UserProfileData) => {
    const updatedUser: User = {
      ...user,
      displayName: updatedProfile.displayName,
      fullName: updatedProfile.displayName,
      gender: (updatedProfile.gender.toLowerCase() as 'male' | 'female'),
      telegramUsername: updatedProfile.telegramHandle,
      photoUrl: updatedProfile.photoURL || user.photoUrl,
      photoURL: updatedProfile.photoURL || user.photoURL,
      isProfileCompleted: true,
      isOnboarded: true,
      profileInitialized: true,
      last_active_at: new Date().toISOString()
    };

    updateUserProfile(updatedUser);
    if (onLoginSuccess) {
      onLoginSuccess(updatedUser);
    }
  };

  return (
    <div 
      id="profile-screen-container" 
      className="max-w-xl mx-auto px-2.5 sm:px-0 pb-28 space-y-4 animate-in fade-in duration-200"
    >
      {/* ============================================================ */}
      {/* 1. TOP NAVIGATION SWITCHER (ACCOUNT & SETTINGS for Guest; ALL 4 for VIP) */}
      {/* ============================================================ */}
      <div 
        ref={tabsContainerRef}
        id="profile-tabs-scroll-container"
        className={`p-1.5 bg-[#0A0D12] border border-[#1E2638] rounded-2xl gap-2 shadow-lg ${
          isGuest 
            ? "grid grid-cols-2" 
            : "flex items-center overflow-x-auto whitespace-nowrap scrollbar-none scroll-smooth"
        }`}
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {/* Tab 1: Account & Profile */}
        <button
          ref={tabAccountRef}
          type="button"
          id="tab-account-profile"
          onClick={() => {
            setDualTab('account');
            scrollToTab('account');
          }}
          className={`${isGuest ? "w-full" : "shrink-0"} py-2.5 px-4 rounded-xl font-medium text-xs sm:text-[13px] transition-all flex items-center justify-center gap-2 cursor-pointer select-none whitespace-nowrap ${
            dualTab === 'account'
              ? "bg-[#131924] text-white border border-[#1E2638] shadow-[0_0_15px_rgba(0,0,0,0.6)]"
              : "text-slate-400 hover:text-white hover:bg-[#131924]/60 border border-transparent"
          }`}
        >
          <UserIcon size={14} className={dualTab === 'account' ? "text-rose-400 shrink-0" : "text-slate-400 shrink-0"} />
          <span>{isGuest ? "Account" : "Account & Profile"}</span>
        </button>

        {/* Tab 2: Account Verification (VIP Users Only - Hidden in Guest Mode) */}
        {!isGuest && (
          <button
            ref={tabVerifyRef}
            type="button"
            id="tab-verify-identity"
            onClick={() => {
              handleOpenVerifyTab();
              scrollToTab('verify');
            }}
            className={`shrink-0 py-2.5 px-4 rounded-xl font-medium text-xs sm:text-[13px] transition-all flex items-center justify-center gap-2 cursor-pointer select-none whitespace-nowrap ${
              dualTab === 'verify'
                ? "bg-[#131924] text-emerald-300 border border-[#059669]/60 shadow-[0_0_15px_rgba(5,150,105,0.25)]"
                : "text-slate-400 hover:text-emerald-300 hover:bg-[#131924]/60 border border-transparent"
            }`}
          >
            <ShieldCheck size={14} className={dualTab === 'verify' ? "text-[#059669] shrink-0" : "text-slate-400 shrink-0"} />
            <span>Account Verification</span>
          </button>
        )}

        {/* Tab 3: App Settings */}
        <button
          ref={tabSettingsRef}
          type="button"
          id="tab-app-settings"
          onClick={() => {
            setDualTab('settings');
            scrollToTab('settings');
          }}
          className={`${isGuest ? "w-full" : "shrink-0"} py-2.5 px-4 rounded-xl font-medium text-xs sm:text-[13px] transition-all flex items-center justify-center gap-2 cursor-pointer select-none whitespace-nowrap ${
            dualTab === 'settings'
              ? "bg-[#131924] text-white border border-[#1E2638] shadow-[0_0_15px_rgba(0,0,0,0.6)]"
              : "text-slate-400 hover:text-white hover:bg-[#131924]/60 border border-transparent"
          }`}
          title="App Settings"
        >
          <SettingsIcon size={14} className={dualTab === 'settings' ? "text-slate-200 shrink-0" : "text-slate-400 shrink-0"} />
          <span>App Settings</span>
        </button>
      </div>

      {/* ============================================================ */}
      {/* 2. TAB CONTENT: [ APP SETTINGS ]                              */}
      {/* ============================================================ */}
      {dualTab === 'settings' && (
        <AppSettingsTab
          isGuest={isGuest}
          isAdultUnlocked={isAdultUnlocked}
          onToggleAdultUnlock={onToggleAdultUnlock}
          hwid={hwid}
          onOpenPrivacyModal={() => setShowPlatformPolicyModal(true)}
          onLogout={handleLogout}
        />
      )}

      {/* ============================================================ */}
      {/* 2B. TAB CONTENT: [ VERIFY IDENTITY (VIP ONLY) ]              */}
      {/* ============================================================ */}
      {!isGuest && dualTab === 'verify' && (
        <IdentityVerificationScreen
          userId={user?.id}
          activeDays={user?.activeDaysCount || user?.activeDaysList?.length || 0}
          activeDayStreak={user?.active_day_streak ?? user?.activeDaysCount ?? 0}
          validActionCount={
            user?.valid_action_count ??
            ((user?.taskStats?.missionsCompleted || 0) +
              (user?.taskStats?.videosWatched || 0) +
              (user?.taskStats?.moviesWatched || 0) +
              (user?.downloadsCount || 0))
          }
          lastActiveAt={user?.last_active_at || user?.lastActiveAt}
          todayActivity={user?.today_activity}
          completedTasksCount={
            user?.valid_action_count ??
            ((user?.taskStats?.missionsCompleted || 0) +
              (user?.taskStats?.videosWatched || 0) +
              (user?.taskStats?.moviesWatched || 0) +
              (user?.downloadsCount || 0))
          }
          isAccountCreated={!isGuest}
          isQuizPassed={Boolean(user?.isQuizPassed || user?.isHumanVerified)}
          verificationSettings={settings?.verificationSettings}
          requiredActiveDays={settings?.verificationSettings?.requiredActiveDays}
          requiredTasks={settings?.verificationSettings?.requiredTasks}
          onQuizSuccess={async () => {
            await updateUserProfile({ isQuizPassed: true, isHumanVerified: true });
          }}
        />
      )}

      {/* ============================================================ */}
      {/* 3. TAB CONTENT: [ ACCOUNT & REWARDS ]                         */}
      {/* ============================================================ */}
      {dualTab === 'account' && (
        <>
          {/* ======================================================== */}
          {/* 3A. GUEST (UNAUTHENTICATED) STATE: ONLY ACTIVATION CARD   */}
          {/* ======================================================== */}
          {isGuest ? (
            <GuestActivationCard
              onSignInClick={handleDirectGoogleSignIn}
              isConnectingGoogle={isConnectingGoogle}
              hwid={hwid}
              errorMessage={authError}
            />
          ) : (
            /* ====================================================== */
            /* 3B. AUTHENTICATED STATE: FULL USER DASHBOARD           */
            /* ====================================================== */
            <div className="space-y-3 sm:space-y-3.5">
              
              {/* Refined VIP Profile Header Card */}
              <div 
                id="vip-profile-header-card"
                className="relative overflow-hidden bg-gradient-to-b from-[#131724] via-[#0E121E] to-[#0A0D15] border border-[#242C44] rounded-2xl p-3.5 sm:p-4 shadow-xl"
              >
                {/* Top Section: Avatar, Identity Info & Logout */}
                <div className="flex items-center justify-between gap-3">
                  
                  {/* Left: Avatar + Details */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Dynamic 3D Gender Avatar with Clean Accent Border & Secret Admin Multi-Tap Trigger */}
                    <div 
                      onClick={handleProfileAvatarClick}
                      className="relative shrink-0 group cursor-pointer select-none active:scale-95 transition-transform duration-75"
                      title="Profile Avatar"
                    >
                      {/* Outer Ring Container */}
                      <div 
                        className={`relative p-[1.5px] rounded-2xl transition-transform duration-200 ${
                          isFemale
                            ? "bg-gradient-to-tr from-pink-500 to-purple-500"
                            : "bg-gradient-to-tr from-cyan-500 to-indigo-500"
                        }`}
                      >
                        {/* Inner Avatar Frame */}
                        <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-[14px] overflow-hidden bg-[#0A0D15] flex items-center justify-center relative">
                          {(user?.photoURL || user?.photoUrl) && !isUnsplashOrBrokenPhoto(user?.photoURL || user?.photoUrl) && !profileAvatarImgError ? (
                            <img
                              id="profile-user-avatar"
                              src={user.photoURL || user.photoUrl}
                              alt={user.displayName || user.fullName || "User Avatar"}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                              onError={() => setProfileAvatarImgError(true)}
                            />
                          ) : (
                            <img
                              id="profile-user-avatar"
                              src={getDiceBearAvatar(user?.gender, user?.uid || user?.id || user?.telegramId || user?.email)}
                              alt={user?.displayName || user?.fullName || "User Avatar"}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                              loading="eager"
                            />
                          )}
                        </div>
                      </div>
                      
                      {/* Gender Indicator Badge */}
                      <span 
                        className={`absolute -bottom-1 -right-1 text-[8.5px] font-mono font-bold rounded px-1 py-0.2 shadow border ${
                          isFemale 
                            ? 'bg-pink-950/95 text-pink-300 border-pink-500/50' 
                            : 'bg-blue-950/95 text-cyan-300 border-cyan-500/50'
                        }`}
                        title={isFemale ? "Female Persona" : "Male Persona"}
                      >
                        {isFemale ? "♀ F" : "♂ M"}
                      </span>
                    </div>

                    {/* Horizontal Inline Layout for User Details: Name, Edit Pencil, Gender Badge, Role Badge */}
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-row items-center flex-wrap gap-2">
                        <h3 className="text-sm sm:text-base font-bold text-white tracking-tight leading-snug truncate">
                          {user.displayName || user.fullName || "TeleFlix Member"}
                        </h3>

                        {/* Sleek Pencil Edit Icon Button directly beside full name */}
                        <button
                          type="button"
                          id="btn-edit-profile-pencil"
                          onClick={handleOpenEditModal}
                          className="p-1 rounded-lg bg-[#161B2B] hover:bg-[#1E2538] text-slate-300 hover:text-amber-300 border border-[#252E47] hover:border-amber-500/50 transition cursor-pointer shadow-sm active:scale-95 shrink-0"
                          title="Edit Profile Details"
                        >
                          <Pencil size={11} className="text-amber-400" />
                        </button>

                        {/* Gender Chip */}
                        <span className={`px-2 py-0.5 rounded-md text-[10.5px] font-mono font-semibold shrink-0 flex items-center gap-1 border ${
                          isFemale
                            ? "bg-pink-500/15 text-pink-300 border-pink-500/30"
                            : "bg-blue-500/15 text-blue-300 border-blue-500/30"
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${isFemale ? 'bg-pink-400' : 'bg-blue-400'}`} />
                          <span>{isFemale ? 'Female' : 'Male'}</span>
                        </span>
                        
                        {/* Role Pill Badge */}
                        <span className="px-2.5 py-0.5 rounded-md text-[10.5px] font-mono font-bold bg-[#062E1E] text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 shrink-0 shadow-sm">
                          <span className="text-amber-400">★</span>
                          <span className="text-emerald-200">VIP USER</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Horizontal Inline Layout: Telegram Handle & UID Badge side-by-side horizontally in a single row */}
                <div className="mt-2.5 pt-2 border-t border-[#1C2337] flex flex-row items-center flex-wrap gap-2">
                  {/* Telegram Identity Display with High-Contrast Telegram Cyan Accents */}
                  <div 
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-cyan-950/70 border border-cyan-400/40 text-cyan-300 text-xs font-mono font-bold shadow-sm"
                    title="Connected Telegram Identity for Referral Rewards"
                  >
                    <Send size={12} className="text-cyan-400 shrink-0" />
                    <span className="tracking-wide">{formattedTelegramUsername}</span>
                  </div>

                  {/* Responsive UID Copy Button */}
                  <button
                    type="button"
                    id="btn-copy-uid"
                    onClick={handleCopyUid}
                    className="inline-flex items-center gap-2 py-1 px-2.5 rounded-lg bg-[#121624] hover:bg-[#1A2033] border border-[#242C44] hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 cursor-pointer transition active:scale-95 shadow-sm select-none"
                    title="Click to copy unique ID"
                  >
                    <span className="font-mono text-xs font-semibold text-cyan-300">
                      UID: {uniqueUserId}
                    </span>
                    {copiedUid ? (
                      <span className="inline-flex items-center gap-1 text-emerald-400 font-bold text-[10px] bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-500/40 animate-in fade-in zoom-in duration-150">
                        <Check size={10} className="text-emerald-400" />
                        <span>Copied!</span>
                      </span>
                    ) : (
                      <Copy size={12} className="text-cyan-400/80 hover:text-cyan-200 transition" />
                    )}
                  </button>
                </div>
              </div>

              {/* Dedicated Admin Control Panel Banner for Master Admin (Global Premium UI/UX Directives) */}
              {isMasterAdmin && (
                <div 
                  id="profile-master-admin-banner" 
                  className="relative overflow-hidden rounded-2xl p-4 sm:p-5 bg-gradient-to-br from-[#1C0912] via-[#0E121B] to-[#160810] border border-rose-500/40 hover:border-rose-400/60 shadow-[0_12px_36px_-6px_rgba(225,29,72,0.28),inset_0_1px_1px_rgba(255,255,255,0.12)] transition-all duration-300 group"
                >
                  {/* Strategic Atmospheric Glows & Edge Highlights */}
                  <div className="pointer-events-none absolute -top-14 -right-14 w-44 h-44 bg-gradient-to-br from-rose-600/20 via-red-600/10 to-transparent rounded-full blur-3xl group-hover:from-rose-600/30 transition-all duration-500" />
                  <div className="pointer-events-none absolute -bottom-10 -left-10 w-36 h-36 bg-red-950/40 rounded-full blur-2xl" />
                  <div className="pointer-events-none absolute top-0 inset-x-0 h-[1.5px] bg-gradient-to-r from-transparent via-rose-500/70 to-transparent" />

                  <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    {/* Left: Security Icon & High-Contrast Typography Hierarchy */}
                    <div className="flex items-center gap-3.5 min-w-0">
                      {/* Layered Security Shield Icon Container */}
                      <div className="relative w-12 h-12 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-br from-rose-950/90 via-red-900/50 to-[#0A0D14] border border-rose-500/40 p-0.5 flex items-center justify-center shrink-0 shadow-[0_0_20px_rgba(244,63,94,0.3)] ring-1 ring-white/10 group-hover:border-rose-400/70 group-hover:shadow-[0_0_25px_rgba(244,63,94,0.45)] transition-all duration-300">
                        <ShieldCheck size={26} className="text-rose-400 drop-shadow-[0_2px_10px_rgba(244,63,94,0.6)]" />
                        {/* Active Security Pulse Indicator */}
                        <span className="absolute -top-1 -right-1 flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 ring-2 ring-[#0E121B]" />
                        </span>
                      </div>

                      {/* Text Details with Strong Contrast and Depth */}
                      <div className="min-w-0">
                        <div className="flex items-center flex-wrap gap-2">
                          <h4 className="text-sm sm:text-base font-extrabold text-white tracking-tight drop-shadow-sm font-sans">
                            এডমিন কন্ট্রোল প্যানেল
                          </h4>
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10.5px] font-mono font-bold tracking-wider uppercase bg-gradient-to-r from-rose-500/25 to-amber-500/20 text-rose-300 border border-rose-400/40 shadow-sm">
                            <Crown size={11} className="text-amber-400 shrink-0" />
                            <span>MASTER ACCESS</span>
                          </span>
                        </div>
                        <p className="text-xs sm:text-[13px] text-slate-300 font-medium mt-1 leading-snug truncate">
                          ইউজার ডাটাবেস, কনটেন্ট ও সিস্টেম ম্যানেজমেন্ট
                        </p>
                        <div className="flex items-center gap-2 mt-1.5 text-[11px] font-mono text-emerald-400/90 font-medium">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
                          <span>সিকিউরিটি ক্লিয়ারেন্স ভেরিফায়েড • অ্যাক্সেস সক্রিয়</span>
                        </div>
                      </div>
                    </div>

                    {/* Right / Bottom Action: Action-Oriented Primary "প্রবেশ করুন" Button */}
                    <button
                      type="button"
                      id="profile-open-admin-banner-btn"
                      onClick={() => {
                        if (onOpenAdmin) onOpenAdmin();
                        else if (onSecretAdminTrigger) onSecretAdminTrigger();
                      }}
                      className="relative overflow-hidden w-full sm:w-auto px-5 sm:px-6 py-2.5 sm:py-3 rounded-xl bg-gradient-to-r from-[#E50914] via-[#F43F5E] to-[#BE123C] hover:from-[#FF1E28] hover:via-[#FB7185] hover:to-[#E11D48] text-white text-xs sm:text-sm font-bold tracking-wide transition-all duration-200 shadow-[0_4px_22px_rgba(229,9,20,0.5),inset_0_1px_1px_rgba(255,255,255,0.35)] hover:shadow-[0_6px_28px_rgba(244,63,94,0.7),inset_0_1px_1px_rgba(255,255,255,0.45)] active:scale-[0.97] border border-rose-300/40 hover:border-white/60 flex items-center justify-center gap-2 cursor-pointer shrink-0 group/btn select-none"
                    >
                      {/* Specular Flare Animation on Hover */}
                      <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover/btn:translate-x-full transition-transform duration-700 pointer-events-none" />
                      <span className="relative z-10 flex items-center gap-2">
                        <span>প্রবেশ করুন</span>
                        <ArrowRight size={15} className="group-hover/btn:translate-x-1 transition-transform duration-200 text-white shrink-0" />
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* ============================================================ */}
              {/* ACCOUNT SETTINGS: CORE HUB, COMMUNITIES & SECURITY MATRIX    */}
              {/* ============================================================ */}
              <div id="account-settings-container" className="space-y-4 pt-1">
                <div className="flex items-center justify-between px-1">
                  <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider font-mono">
                    ACCOUNT SETTINGS
                  </h2>
                </div>

                {/* SUB-SECTION 1: CORE HUB (Important Section) */}
                <CoreHub
                  onOpenWallet={handleOpenWallet}
                  onOpenTaskStatus={() => setShowTaskStatusModal(true)}
                  onOpenLiveSupport={() => setShowLiveSupportModal(true)}
                  telegramSupportLink={communitySettings.telegramChannelLink || "https://t.me/myteleflix"}
                  userPoints={user.points || 0}
                  pendingTaskCount={taskReviewStats.pending}
                />

                {/* SUB-SECTION 2: OUR COMMUNITIES */}
                <div id="profile-communities-section" className="space-y-2.5 pt-1">
                  <h3 className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase px-1">
                    OUR COMMUNITIES
                  </h3>

                  <div className="grid grid-cols-4 gap-2 sm:gap-3">
                    {/* 1. Telegram */}
                    <a
                      href={communitySettings.telegramChannelLink || "https://t.me/myteleflix"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#0B132B]/90 hover:bg-[#101C3D] border border-cyan-500/30 hover:border-cyan-400/70 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center text-center transition-all duration-200 group active:scale-95 shadow-md hover:shadow-[0_0_20px_rgba(0,136,204,0.45)]"
                    >
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#0088cc] flex items-center justify-center text-white mb-2 shadow-md shadow-[#0088cc]/40 group-hover:scale-105 transition-transform duration-200">
                        <TelegramIcon />
                      </div>
                      <span className="text-[10px] sm:text-xs font-mono font-bold text-cyan-300 tracking-wider">
                        TELEGRAM
                      </span>
                    </a>

                    {/* 2. WhatsApp */}
                    <a
                      href={
                        communitySettings.whatsappSupportLink?.startsWith("http") 
                          ? communitySettings.whatsappSupportLink 
                          : communitySettings.whatsappSupportLink 
                            ? `https://wa.me/${communitySettings.whatsappSupportLink.replace(/[^0-9]/g, "")}?text=Hello%20MyTeleFlix` 
                            : "https://wa.me/?text=Hello%20MyTeleFlix"
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#0B201A]/90 hover:bg-[#102D24] border border-emerald-500/30 hover:border-emerald-400/70 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center text-center transition-all duration-200 group active:scale-95 shadow-md hover:shadow-[0_0_20px_rgba(37,211,102,0.45)]"
                    >
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#25D366] flex items-center justify-center text-white mb-2 shadow-md shadow-[#25D366]/40 group-hover:scale-105 transition-transform duration-200">
                        <WhatsAppIcon />
                      </div>
                      <span className="text-[10px] sm:text-xs font-mono font-bold text-emerald-300 tracking-wider">
                        WHATSAPP
                      </span>
                    </a>

                    {/* 3. YouTube */}
                    <a
                      href={communitySettings.youtubeChannelLink || "https://youtube.com/@myteleflix"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#240F13]/90 hover:bg-[#33151B] border border-red-500/30 hover:border-red-400/70 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center text-center transition-all duration-200 group active:scale-95 shadow-md hover:shadow-[0_0_20px_rgba(255,0,0,0.45)]"
                    >
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#FF0000] flex items-center justify-center text-white mb-2 shadow-md shadow-[#FF0000]/40 group-hover:scale-105 transition-transform duration-200">
                        <YouTubeIcon />
                      </div>
                      <span className="text-[10px] sm:text-xs font-mono font-bold text-red-400 tracking-wider">
                        YOUTUBE
                      </span>
                    </a>

                    {/* 4. Facebook */}
                    <a
                      href={communitySettings.facebookLink || "https://facebook.com/myteleflix"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#0D1730]/90 hover:bg-[#122245] border border-blue-500/30 hover:border-blue-400/70 rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center text-center transition-all duration-200 group active:scale-95 shadow-md hover:shadow-[0_0_20px_rgba(24,119,242,0.45)]"
                    >
                      <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-[#1877F2] flex items-center justify-center text-white mb-2 shadow-md shadow-[#1877F2]/40 group-hover:scale-105 transition-transform duration-200">
                        <FacebookIcon />
                      </div>
                      <span className="text-[10px] sm:text-xs font-mono font-bold text-blue-300 tracking-wider">
                        FACEBOOK
                      </span>
                    </a>
                  </div>
                </div>

                {/* SUB-SECTION 3: SECURITY MATRIX */}
                <div id="profile-security-matrix" className="space-y-2 pt-1">
                  <div className="px-1">
                    <h3 className="text-xs font-mono font-bold tracking-wider text-slate-200 uppercase">
                      SECURITY MATRIX
                    </h3>
                    <p className="text-[10px] font-mono text-slate-500 font-semibold tracking-wider uppercase">
                      AUTHENTICATION & ENCRYPTION
                    </p>
                  </div>

                  <div className="relative overflow-hidden bg-gradient-to-b from-[#101422] via-[#0A0D17] to-[#070910] border border-[#1E273F] rounded-2xl p-3.5 sm:p-4 shadow-xl">
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 shadow-inner">
                          <ShieldCheck size={18} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white tracking-wide">
                              Hardware Device Binding
                            </span>
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400" />
                          </div>
                          <span className="text-[10px] font-mono text-cyan-300/80 block mt-0.5">
                            SHA-256 Encrypted Session Token
                          </span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                          <Lock size={10} />
                          <span>PROTECTED</span>
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <span className="text-cyan-400">●</span>
                        <span>TLS 1.3 / HTTPS Active</span>
                      </div>
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-emerald-400">●</span>
                        <span>Anti-Cheat Protected</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Note: Admin Control Room card completely hidden in Stealth Mode - accessed only via Secret Avatar Multi-Tap & Master PIN */}
            </div>
          )}
        </>
      )}

      {/* ============================================================ */}
      {/* 4. MODALS (TRIGGERED ONLY BY EXPLICIT USER CLICKS)            */}
      {/* ============================================================ */}

      {/* Platform & Usage Policy Modal */}
      {showPlatformPolicyModal && (
        <PlatformPolicyModal
          isOpen={showPlatformPolicyModal}
          onClose={() => setShowPlatformPolicyModal(false)}
        />
      )}

      {/* First-Time User Onboarding Modal (VIP Profile Setup & Platform Benefits) */}
      <OnboardingFlow
        isOpen={showOnboarding}
        user={user}
        onComplete={(updatedUser) => {
          handleCompleteOnboarding(updatedUser);
          setShowOnboarding(false);
          if (onNavigate) {
            onNavigate('home');
          }
        }}
        onClose={() => setShowOnboarding(false)}
      />

      {/* Enterprise Edit Profile Modal (Frozen Gmail & Immutable Join Date, DB Synced) */}
      <EditProfileModal
        isOpen={showEditProfileModal}
        onClose={() => setShowEditProfileModal(false)}
        currentUser={user}
        onProfileUpdated={handleProfileUpdated}
      />

      {/* Core Hub: Task Status Modal */}
      <TaskStatusModal
        isOpen={showTaskStatusModal}
        onClose={() => setShowTaskStatusModal(false)}
        pendingCount={taskReviewStats.pending}
        approvedCount={taskReviewStats.completed}
        rejectedCount={taskReviewStats.rejected}
        totalCount={taskReviewStats.total}
        tasks={userTasksList}
        onNavigateToEarn={() => {
          if (onNavigate) {
            onNavigate('earn');
          }
        }}
      />

      {/* Core Hub: Wallet Modal Fallback (When not navigating to tab) */}
      {showWalletModal && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
          onClick={() => setShowWalletModal(false)}
        >
          <div 
            className="relative w-full max-w-2xl bg-[#090C12] border border-white/[0.1] rounded-2xl p-4 sm:p-5 shadow-2xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3 mb-4">
              <h2 className="text-sm sm:text-base font-black text-white font-mono uppercase tracking-wider">
                My Wallet & Cashout Center
              </h2>
              <button
                onClick={() => setShowWalletModal(false)}
                className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer select-none font-bold"
              >
                ✕
              </button>
            </div>
            <WalletScreen
              userPoints={user.points || 0}
              transactions={transactions}
              minimumWithdrawal={minimumWithdrawal}
              tokenRateBdt={tokenRateBdt}
              tokenRateUsd={tokenRateUsd}
              userId={user.id}
              userEmail={user.email}
              username={user.username || user.fullName}
              isBanned={user.isBanned || user.status === 'banned'}
              banReason={user.banReason}
              onWithdraw={onWithdraw}
            />
          </div>
        </div>
      )}

      {/* Core Hub: Live Support Modal */}
      <LiveSupportModal
        isOpen={showLiveSupportModal}
        onClose={() => setShowLiveSupportModal(false)}
        communitySettings={communitySettings}
      />

      {/* Streamlined Identity Verification Modal */}
      <IdentityVerifyModal
        isOpen={showSecurityNotice}
        onClose={() => setShowSecurityNotice(false)}
        onProceed={() => {
          setShowSecurityNotice(false);
          setDualTab('verify');
          scrollToTab('verify');
        }}
        frequencyHours={settings?.verificationSettings?.noticeFrequencyHours}
      />

      {/* 1-Device 1-Account Anti-Fraud Warning Notice Modal */}
      <PolicyViolationModal
        isOpen={policyViolationModalState.isOpen}
        errorMessage={policyViolationModalState.error}
        existingAccount={policyViolationModalState.existingAccount}
        deviceFingerprint={policyViolationModalState.deviceFingerprint}
        ipAddress={policyViolationModalState.ipAddress}
        onClose={() => setPolicyViolationModalState({ isOpen: false })}
        onRestoreOriginalAccount={async () => {
          setPolicyViolationModalState({ isOpen: false });
          const target = policyViolationModalState.existingAccount?.email || 
            (typeof policyViolationModalState.existingAccount === 'string' ? policyViolationModalState.existingAccount : undefined);
          try {
            const primaryUser = await restorePrimaryAccount(target);
            if (primaryUser && onLoginSuccess) {
              onLoginSuccess(primaryUser);
            }
          } catch (e) {
            console.warn("restorePrimaryAccount notice:", e);
          }
        }}
      />

    </div>
  );
}

const ProfileScreen = React.memo(ProfileScreenComponent);
export default ProfileScreen;
