/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Lock, ShieldCheck, AlertTriangle, X, Delete, CheckCircle2, KeyRound } from "lucide-react";
import { useAuth, MASTER_ADMIN_EMAIL, MASTER_ADMIN_PIN } from "../context/AuthContext";

interface MasterPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  targetEmail?: string;
}

export function MasterPinModal({
  isOpen,
  onClose,
  onSuccess,
  targetEmail = MASTER_ADMIN_EMAIL,
}: MasterPinModalProps) {
  const { verifyMasterPin } = useAuth();
  const [pin, setPin] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto focus input when modal opens
  useEffect(() => {
    if (isOpen) {
      setPin("");
      setError(null);
      setIsSuccess(false);
      setIsShaking(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === "Escape") {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const triggerError = (msg: string) => {
    setError(msg);
    setIsShaking(true);
    setTimeout(() => setIsShaking(false), 500);
    setPin("");
    inputRef.current?.focus();
  };

  const handleVerify = (passcodeToTest: string) => {
    if (!passcodeToTest || passcodeToTest.length === 0) {
      triggerError("Please enter your Master Security PIN.");
      return;
    }

    const isValid = verifyMasterPin ? verifyMasterPin(passcodeToTest) : passcodeToTest.trim() === MASTER_ADMIN_PIN;

    if (isValid) {
      setError(null);
      setIsSuccess(true);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 400);
    } else {
      triggerError("Invalid Security Passcode. Access Denied.");
    }
  };

  const handleNumberClick = (digit: string) => {
    if (isSuccess) return;
    setError(null);
    if (pin.length < 6) {
      const nextPin = pin + digit;
      setPin(nextPin);
      if (nextPin.length === 4) {
        handleVerify(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    if (isSuccess) return;
    setError(null);
    setPin(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    if (isSuccess) return;
    setError(null);
    setPin("");
    inputRef.current?.focus();
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleVerify(pin);
  };

  return (
    <div 
      className="fixed inset-0 z-[100] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div 
        className={`relative w-full max-w-[340px] sm:max-w-sm rounded-3xl bg-gradient-to-b from-[#111624] to-[#0A0D15] border border-slate-800 shadow-2xl p-5 sm:p-6 text-white text-center transition-transform duration-200 ${
          isShaking ? "animate-shake ring-2 ring-rose-500/50" : ""
        } ${isSuccess ? "ring-2 ring-emerald-500/60 shadow-emerald-950/50" : ""}`}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-slate-500 hover:text-white hover:bg-slate-800/80 transition cursor-pointer"
          title="Close Gateway"
        >
          <X size={16} />
        </button>

        {/* Shield Icon Badge */}
        <div className={`w-13 h-13 sm:w-14 sm:h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg transition-colors duration-300 ${
          isSuccess 
            ? "bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 shadow-emerald-950/50"
            : error
            ? "bg-rose-950/80 border border-rose-500/50 text-rose-400 shadow-rose-950/50"
            : "bg-indigo-950/70 border border-indigo-500/40 text-indigo-300 shadow-indigo-950/40"
        }`}>
          {isSuccess ? (
            <ShieldCheck size={26} className="text-emerald-400 animate-in zoom-in" />
          ) : (
            <KeyRound size={24} className="text-indigo-300" />
          )}
        </div>

        {/* Title & Description */}
        <h3 className="text-base sm:text-lg font-black tracking-tight font-sans text-white">
          Master Security Gateway
        </h3>
        <p className="text-[11px] sm:text-xs text-slate-400 font-sans mt-0.5">
          Restricted Access • Master Administrator Verification
        </p>

        {/* User Identity Pill */}
        <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800 text-[11px] font-mono text-slate-300 max-w-full">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0"></span>
          <span className="truncate">{targetEmail}</span>
        </div>

        {/* PIN Indicators */}
        <div className="my-4 flex items-center justify-center gap-3">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pin.length > index;
            return (
              <div
                key={index}
                className={`w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? isSuccess
                      ? "bg-emerald-400 ring-4 ring-emerald-500/30 scale-110"
                      : "bg-indigo-400 ring-4 ring-indigo-500/30 scale-110"
                    : "bg-slate-800 border border-slate-700"
                }`}
              />
            );
          })}
        </div>

        {/* Hidden / Keyboard Input for Accessibility & Desktop typing */}
        <form onSubmit={handleFormSubmit} className="mb-2">
          <input
            ref={inputRef}
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            value={pin}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, "");
              setPin(val);
              setError(null);
              if (val.length === 4) {
                handleVerify(val);
              }
            }}
            placeholder="••••"
            className="w-full text-center tracking-[0.6em] text-lg font-mono font-bold bg-slate-950/80 border border-slate-800/80 rounded-xl py-2 px-4 text-indigo-300 placeholder-slate-600 focus:outline-none focus:border-indigo-500/60 transition"
          />
        </form>

        {/* Feedback Message */}
        {error ? (
          <div className="text-[11px] font-mono text-rose-400 font-semibold flex items-center justify-center gap-1 my-1.5 animate-in fade-in">
            <AlertTriangle size={12} className="shrink-0" />
            <span>{error}</span>
          </div>
        ) : isSuccess ? (
          <div className="text-[11px] font-mono text-emerald-400 font-semibold flex items-center justify-center gap-1 my-1.5 animate-in fade-in">
            <CheckCircle2 size={12} className="shrink-0" />
            <span>Passcode Verified. Unlocking...</span>
          </div>
        ) : (
          <p className="text-[10.5px] font-mono text-slate-500 my-1.5">
            Enter 4-digit Master Security Key
          </p>
        )}

        {/* Tactile Keypad */}
        <div className="grid grid-cols-3 gap-1.5 sm:gap-2 mt-2 font-mono">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
            <button
              key={num}
              type="button"
              onClick={() => handleNumberClick(num)}
              disabled={isSuccess}
              className="py-2.5 sm:py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:bg-slate-700 text-white font-bold text-sm sm:text-base transition border border-slate-800/80 hover:border-slate-700 active:scale-95 cursor-pointer disabled:opacity-50 select-none shadow-sm"
            >
              {num}
            </button>
          ))}

          {/* Clear Button */}
          <button
            type="button"
            onClick={handleClear}
            disabled={isSuccess}
            className="py-2.5 sm:py-3 rounded-xl bg-slate-950 hover:bg-slate-900 active:bg-slate-800 text-slate-400 hover:text-white font-bold text-xs sm:text-sm transition border border-slate-800/60 active:scale-95 cursor-pointer disabled:opacity-50 select-none"
          >
            Clear
          </button>

          {/* Zero Button */}
          <button
            type="button"
            onClick={() => handleNumberClick("0")}
            disabled={isSuccess}
            className="py-2.5 sm:py-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 active:bg-slate-700 text-white font-bold text-sm sm:text-base transition border border-slate-800/80 hover:border-slate-700 active:scale-95 cursor-pointer disabled:opacity-50 select-none shadow-sm"
          >
            0
          </button>

          {/* Backspace Button */}
          <button
            type="button"
            onClick={handleBackspace}
            disabled={isSuccess}
            className="py-2.5 sm:py-3 rounded-xl bg-slate-950 hover:bg-slate-900 active:bg-slate-800 text-slate-400 hover:text-white font-bold text-xs sm:text-sm transition border border-slate-800/60 flex items-center justify-center active:scale-95 cursor-pointer disabled:opacity-50 select-none"
            title="Backspace"
          >
            <Delete size={16} />
          </button>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 space-y-2">
          <button
            type="button"
            onClick={() => handleVerify(pin)}
            disabled={isSuccess || pin.length === 0}
            className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-mono font-bold text-xs sm:text-sm transition cursor-pointer flex items-center justify-center gap-2 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-indigo-600/30"
          >
            <Lock size={14} />
            <span>Unlock Admin Room</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2 px-4 rounded-xl text-slate-400 hover:text-white text-xs font-mono transition cursor-pointer"
          >
            Cancel & Return
          </button>
        </div>
      </div>
    </div>
  );
}

export default MasterPinModal;
