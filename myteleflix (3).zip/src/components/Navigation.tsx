/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Home as HomeIcon, Film, MonitorPlay, User as UserIcon } from "lucide-react";
import DoubleBanknoteIcon from "./DoubleBanknoteIcon";
import { useLanguage } from "../context/LanguageContext";

export type NavTabType = 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet';

interface NavigationProps {
  activeTab: NavTabType;
  onSelectTab: (tab: NavTabType) => void;
  onHomeClick?: () => void;
  isAdultUnlocked?: boolean;
}

function NavigationComponent({
  activeTab,
  onSelectTab,
  onHomeClick,
  isAdultUnlocked = false,
}: NavigationProps) {
  const { t, language } = useLanguage();

  const handleHomePress = () => {
    if (onHomeClick) {
      onHomeClick();
    } else {
      onSelectTab('home');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <nav 
      id="bottom-sticky-nav" 
      className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800/80 px-3 py-2 flex justify-around items-center max-w-md mx-auto"
    >
      {/* Tab 1: Home */}
      <button
        id="nav-btn-home"
        type="button"
        onClick={handleHomePress}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl active:scale-95 transition-transform duration-75 cursor-pointer select-none ${
          activeTab === 'home' ? 'text-[#E50914] font-bold' : 'text-slate-400 hover:text-white'
        }`}
      >
        <HomeIcon size={20} className={`w-5 h-5 transition-colors ${activeTab === 'home' ? 'text-[#E50914]' : 'text-slate-400'}`} />
        <span className="text-[9px] uppercase tracking-wider font-mono font-medium">
          {t('nav.home', 'Home')}
        </span>
      </button>

      {/* Tab 2: Movies */}
      <button
        id="nav-btn-movies"
        type="button"
        onClick={() => onSelectTab('movies')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl active:scale-95 transition-transform duration-75 cursor-pointer select-none ${
          activeTab === 'movies' ? 'text-[#E50914] font-bold' : 'text-slate-400 hover:text-white'
        }`}
      >
        <Film size={20} className={`w-5 h-5 transition-colors ${activeTab === 'movies' ? 'text-[#E50914]' : 'text-slate-400'}`} />
        <span className="text-[9px] uppercase tracking-wider font-mono font-medium">
          {t('nav.movies', 'Movies')}
        </span>
      </button>

      {/* Tab 3: Videos (Visible ONLY when 18+ content access is unlocked) */}
      {isAdultUnlocked && (
        <button
          id="nav-btn-videos"
          type="button"
          onClick={() => onSelectTab('videos')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl active:scale-95 transition-transform duration-75 cursor-pointer select-none ${
            activeTab === 'videos' ? 'text-[#E50914] font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <MonitorPlay size={20} className={`w-5 h-5 transition-colors ${activeTab === 'videos' ? 'text-[#E50914]' : 'text-slate-400'}`} />
          <span className="text-[9px] uppercase tracking-wider font-mono font-medium">
            {t('nav.videos', 'Videos')}
          </span>
        </button>
      )}

      {/* Tab 4: Earn / Income Site (Custom Animated Dual-Banknote Currency Vector Icon with Floating Effect) */}
      <button
        id="nav-btn-earn"
        type="button"
        onClick={() => onSelectTab('earn')}
        className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl active:scale-95 transition-transform duration-75 cursor-pointer select-none ${
          activeTab === 'earn' ? 'text-emerald-400 font-bold' : 'text-slate-400 hover:text-emerald-300'
        }`}
      >
        <div className="w-6 h-5 flex items-center justify-center animate-float-bob">
          <DoubleBanknoteIcon 
            size={24}
            isActive={activeTab === 'earn'}
            className={`transition-all duration-200 ${
              activeTab === 'earn' 
                ? 'drop-shadow-[0_0_8px_rgba(34,197,94,0.6)] brightness-110 scale-105' 
                : 'opacity-85 hover:opacity-100 hover:drop-shadow-[0_0_5px_rgba(34,197,94,0.4)]'
            }`} 
          />
        </div>
        <span className={`text-[9.5px] leading-tight font-sans font-medium whitespace-nowrap tracking-tight transition-colors ${
          activeTab === 'earn' 
            ? 'text-emerald-400 font-bold drop-shadow-[0_0_6px_rgba(34,197,94,0.4)]' 
            : 'text-slate-400'
        }`}>
          {language === 'bn' ? 'ইনকাম সাইট' : language === 'hi' ? 'कमाई' : t('nav.earn', 'Earn')}
        </span>
      </button>

      {/* Tab 5: Profile */}
      <button
        id="nav-btn-profile"
        type="button"
        onClick={() => onSelectTab('profile')}
        className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl active:scale-95 transition-transform duration-75 cursor-pointer select-none ${
          activeTab === 'profile' ? 'text-[#E50914] font-bold' : 'text-slate-400 hover:text-white'
        }`}
      >
        <UserIcon size={20} className={`w-5 h-5 transition-colors ${activeTab === 'profile' ? 'text-[#E50914]' : 'text-slate-400'}`} />
        <span className="text-[9px] uppercase tracking-wider font-mono font-medium">
          {t('nav.profile', 'Profile')}
        </span>
      </button>
    </nav>
  );
}

const Navigation = React.memo(NavigationComponent);
export default Navigation;
