/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { Play, ShieldAlert, Sparkles, X, CheckCircle2, Volume2, VolumeX, Eye } from "lucide-react";
import TokenIcon from "./TokenIcon";

interface TelegramAdModalProps {
  taskTitle?: string;
  rewardPoints?: number;
  onAdCompleted: () => void;
  onAdDismissed: (reason: string) => void;
}

declare global {
  interface Window {
    Adsgram?: {
      init: (params: { blockId: string }) => {
        show: () => Promise<{ done: boolean }>;
      };
    };
    Monetag?: {
      showRewarded: () => Promise<boolean>;
    };
  }
}

export default function TelegramAdModal({
  taskTitle = "Sponsored Mission Task",
  rewardPoints = 150,
  onAdCompleted,
  onAdDismissed,
}: TelegramAdModalProps) {
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [canClaim, setCanClaim] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [adStarted, setAdStarted] = useState<boolean>(false);

  // Attempt real Adsgram or Monetag Telegram SDK trigger if present
  useEffect(() => {
    if (window.Adsgram) {
      try {
        window.Adsgram.init({ blockId: "adsgram-teleflix-rewarded" })
          .show()
          .then((res) => {
            if (res.done) {
              onAdCompleted();
            } else {
              onAdDismissed("User closed Adsgram ad early.");
            }
          })
          .catch((err) => {
            console.warn("Adsgram execution fallback to native container", err);
          });
      } catch (e) {
        // Fallback
      }
    } else if (window.Monetag) {
      try {
        window.Monetag.showRewarded().then((completed) => {
          if (completed) {
            onAdCompleted();
          } else {
            onAdDismissed("User closed Monetag ad early.");
          }
        }).catch(() => {});
      } catch (e) {
        // Fallback
      }
    }

    // Interactive fallback countdown simulation if SDK isn't available in iframe
    setAdStarted(true);
  }, []);

  useEffect(() => {
    if (!adStarted) return;

    if (timeLeft <= 0) {
      setCanClaim(true);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, adStarted]);

  const handleCloseEarly = () => {
    if (!canClaim) {
      onAdDismissed("Please watch the full ad to start this task.");
    } else {
      onAdCompleted();
    }
  };

  const handleClaimReward = () => {
    onAdCompleted();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#0f172a] border-2 border-indigo-500/50 w-full max-w-md rounded-3xl overflow-hidden shadow-2xl relative text-white flex flex-col">
        
        {/* Top Header Tag */}
        <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 px-4 py-3 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-amber-400 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full font-mono uppercase tracking-wider animate-pulse flex items-center gap-1">
              <Sparkles size={11} className="fill-current" /> SPONSORED AD
            </span>
            <span className="text-xs font-bold text-slate-300 font-mono">
              Telegram Network
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 rounded-lg transition"
              title="Toggle Audio"
            >
              {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <button
              onClick={handleCloseEarly}
              className="p-1.5 bg-slate-800/80 hover:bg-red-500/20 hover:text-red-400 text-slate-400 rounded-lg transition cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Video / Ad Viewport */}
        <div className="p-4 space-y-4">
          <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-950 border border-indigo-500/30 shadow-inner flex flex-col justify-between p-3">
            
            {/* Simulated Video Player Graphic / Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/60 via-slate-900 to-purple-950/80 flex items-center justify-center">
              <div className="text-center space-y-2 p-4">
                <div className="h-12 w-12 rounded-2xl bg-gradient-to-tr from-amber-400 to-yellow-300 text-slate-950 flex items-center justify-center mx-auto shadow-lg shadow-amber-400/20 font-black animate-bounce">
                  <Play size={24} className="fill-current ml-0.5" />
                </div>
                <h4 className="text-sm font-black text-white tracking-wide">
                  My TeleFlix Sponsor Video
                </h4>
                <p className="text-[11px] text-indigo-200 font-mono">
                  Watch full video to unlock: <span className="text-amber-300 font-bold">{taskTitle}</span>
                </p>
              </div>
            </div>

            {/* Top Bar inside Ad Video */}
            <div className="relative z-10 flex items-center justify-between">
              <span className="text-[10px] bg-slate-950/80 border border-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-mono flex items-center gap-1">
                <Eye size={12} className="text-indigo-400" /> Rewarded Ad
              </span>

              {/* Progress Countdown Badge */}
              <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-full border shadow-md ${
                canClaim 
                  ? "bg-emerald-500 text-slate-950 border-emerald-400" 
                  : "bg-indigo-950/90 text-amber-300 border-indigo-400 animate-pulse"
              }`}>
                {canClaim ? "✓ AD REWARD UNLOCKED" : `⏳ ${timeLeft}s REMAINING`}
              </span>
            </div>

            {/* Bottom Progress Bar */}
            <div className="relative z-10 space-y-1">
              <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div 
                  className="h-full bg-gradient-to-r from-amber-400 via-indigo-500 to-emerald-400 transition-all duration-1000 ease-linear"
                  style={{ width: `${((15 - timeLeft) / 15) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Details & Reward Card */}
          <div className="bg-[#151D30] border border-slate-800 rounded-2xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">
                Target Task Reward:
              </span>
              <span className="text-xs font-mono font-black text-amber-400 bg-amber-400/10 border border-amber-400/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                <TokenIcon size={12} />
                +{rewardPoints}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              Telegram Ad Policy requires full ad playback before issuing shortener task verification tokens. Closing early will invalidate your session token request.
            </p>
          </div>

          {/* Action CTAs */}
          {canClaim ? (
            <button
              onClick={handleClaimReward}
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-98 cursor-pointer transition"
            >
              <CheckCircle2 size={16} className="fill-current text-slate-950" />
              <span className="flex items-center gap-1.5">
                <TokenIcon size={14} />
                <span>PROCEED TO SHORTENER TASK (+{rewardPoints})</span>
              </span>
            </button>
          ) : (
            <button
              onClick={handleCloseEarly}
              className="w-full py-3 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 active:scale-98 cursor-pointer transition"
            >
              <ShieldAlert size={15} className="text-amber-400" />
              <span>Close Ad (Will Cancel Task Session)</span>
            </button>
          )}

        </div>
      </div>
    </div>
  );
}
