/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { default } from "./modals/PromotionModal";
export * from "./modals/PromotionModal";
