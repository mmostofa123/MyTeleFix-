/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ActivateProfileScreen: Mandatory Onboarding Profile Activation Screen
 * Ultra-Premium Minimalist Native Mobile Design.
 */

import React, { useState, useEffect } from "react";
import { Loader2, CheckCircle2 } from "lucide-react";
import { User } from "../types";
import { activateUserProfile, getRandomAvatar } from "../services/auth";
import { auth, db } from "../services/firebase";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import TelegramIdHelpModal from "./TelegramIdHelpModal";

export interface ActivateProfileScreenProps {
  user: User;
  onComplete: (activatedUser: User) => void | Promise<void>;
  onLogout?: () => void;
}

export default function ActivateProfileScreen({
  user,
  onComplete,
  onLogout
}: ActivateProfileScreenProps) {
  // Input 1: Full Name - Pre-filled, editable
  const [displayName, setDisplayName] = useState<string>(() => {
    return user.displayName || user.fullName || (user.email ? user.email.split("@")[0] : "");
  });

  // Input 2: Telegram Username
  const [telegramUsername, setTelegramUsername] = useState<string>(() => {
    if (user.telegramUsername) {
      return user.telegramUsername.startsWith("@") ? user.telegramUsername : `@${user.telegramUsername}`;
    }
    if (user.username && !user.username.startsWith("user_") && !user.username.startsWith("guest_") && !user.username.startsWith("tg_")) {
      return user.username.startsWith("@") ? user.username : `@${user.username}`;
    }
    return "";
  });

  // Input 3: Telegram Numeric ID
  const [telegramId, setTelegramId] = useState<string>(() => {
    return user.telegramId && /^\d+$/.test(String(user.telegramId)) ? String(user.telegramId) : "";
  });

  // Input 4: Gender Selection [ Male | Female | Other ]
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(() => {
    const raw = (user.gender || "").toLowerCase();
    if (raw === "female") return "Female";
    if (raw === "other") return "Other";
    return "Male";
  });

  // Modal State
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);

  // Status States
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<boolean>(false);

  // Prevent keyboard escape or closing
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && showHelpModal) {
        setShowHelpModal(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [showHelpModal]);

  // Handle Telegram Username with clean '@' formatting
  const handleTelegramUsernameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.trim();
    if (val && !val.startsWith("@")) {
      val = "@" + val.replace(/@/g, "");
    }
    setTelegramUsername(val);
    if (formError) setFormError(null);
  };

  // Handle Telegram ID with strict numbers only
  const handleTelegramIdChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, "");
    setTelegramId(val);
    if (formError) setFormError(null);
  };

  const isFormValid = Boolean(
    displayName.trim() &&
    telegramUsername.trim() &&
    telegramUsername.trim().length >= 3 &&
    telegramId.trim() &&
    telegramId.trim().length >= 5 &&
    gender
  );

  const currentUser = auth.currentUser;
  const userGoogleEmail = currentUser?.email || user.email || "Google Verified";
  const userGoogleUid = currentUser?.uid || user.id || user.uid || user.googleId || "UID_UNKNOWN";

  // Form Submission Handler: Saves directly to Firestore under Google UID
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanName = displayName.trim();
    if (!cleanName) {
      setFormError("Please enter your full name.");
      return;
    }

    let cleanTgUser = telegramUsername.trim();
    if (!cleanTgUser.startsWith("@")) {
      cleanTgUser = `@${cleanTgUser}`;
    }
    if (cleanTgUser === "@" || cleanTgUser.length < 4) {
      setFormError("Please enter a valid Telegram username (e.g. @username).");
      return;
    }

    const cleanId = telegramId.trim();
    if (!cleanId || !/^\d{5,16}$/.test(cleanId)) {
      setFormError("Please enter a valid numeric Telegram ID (at least 5 digits).");
      return;
    }

    // Resolve Google UID: strictly auth.currentUser.uid with user.id fallback
    const targetUid = auth.currentUser?.uid || user.id || user.uid || user.googleId;
    if (!targetUid) {
      setFormError("Unable to detect authenticated user UID. Please try signing in again.");
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Direct write/update to Firestore 'users' collection with Document ID = auth.currentUser.uid
      const userDocRef = doc(db, 'users', targetUid);
      const existingSnap = await getDoc(userDocRef);
      const existingData = existingSnap.exists() ? existingSnap.data() : {};

      const firestorePayload = {
        uid: targetUid,
        fullName: cleanName,
        telegramUsername: cleanTgUser,
        telegramId: Number(cleanId), // strictly numeric ID
        gender: gender,
        email: auth.currentUser?.email || user.email || userGoogleEmail,
        createdAt: existingData?.createdAt || serverTimestamp(),
        updatedAt: serverTimestamp(),
        status: "ACTIVE",
        onboardingCompleted: true,
        // Supporting backward-compatibility attributes for complete subsystem cohesion
        id: targetUid,
        displayName: cleanName,
        isOnboarded: true,
        profileInitialized: true,
        isProfileCompleted: true,
        profileStatus: "ACTIVE",
        last_active_at: new Date().toISOString()
      };

      await setDoc(userDocRef, firestorePayload, { merge: true });

      // 2. Auth service synchronization & local state updates
      const activatedUser = await activateUserProfile(user, {
        telegramId: cleanId,
        telegramUsername: cleanTgUser,
        gender,
        displayName: cleanName
      });

      const finalUser: User = {
        ...activatedUser,
        id: targetUid,
        uid: targetUid,
        googleId: targetUid,
        fullName: cleanName,
        displayName: cleanName,
        telegramUsername: cleanTgUser,
        telegramId: cleanId,
        gender,
        email: auth.currentUser?.email || user.email || userGoogleEmail,
        status: 'active',
        onboardingCompleted: true,
        isOnboarded: true,
        isProfileCompleted: true,
        profileInitialized: true,
        profileStatus: 'active'
      };

      // Set localStorage flags so app skips onboarding permanently
      if (typeof window !== "undefined") {
        localStorage.setItem("myteleflix_user", JSON.stringify(finalUser));
        localStorage.setItem(`myteleflix_onboarding_${targetUid}`, "true");
        localStorage.setItem("myteleflix_onboarding_completed", "true");
        localStorage.setItem("isProfileCompleted", "true");
      }

      setIsSuccess(true);
      setShowToast(true);

      // 3. Post-save navigation: Redirect immediately to Main Dashboard / Home screen
      setTimeout(async () => {
        await onComplete(finalUser);
      }, 700);
    } catch (err: any) {
      console.error("Profile activation error:", err);
      setFormError(err.message || "Failed to activate profile. Please try again.");
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      id="activate-profile-screen-container"
      className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-[#090D16] overflow-y-auto select-none font-sans"
    >
      {/* Card Container: 20px padding, 16px radius, #1E293B border */}
      <div 
        id="activate-profile-card"
        className="w-full max-w-[440px] bg-[#0F1422] border border-[#1E293B] rounded-[16px] p-5 sm:p-6 text-white shadow-2xl my-auto space-y-5"
      >
        {/* Screen Title & Subtitle */}
        <div className="space-y-1 text-left">
          <h1 className="text-xl font-bold text-white tracking-tight">
            Complete Profile
          </h1>
          <p className="text-xs text-slate-400 font-normal leading-relaxed">
            Enter your telegram details to activate your TeleFlix account.
          </p>
        </div>

        {/* Error message */}
        {formError && (
          <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs leading-relaxed animate-in fade-in">
            {formError}
          </div>
        )}

        {/* Clean Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          
          {/* Input 1: Full Name */}
          <div className="space-y-1.5">
            <label htmlFor="input-full-name" className="block text-xs font-medium text-slate-300">
              Full Name
            </label>
            <input
              id="input-full-name"
              type="text"
              value={displayName}
              onChange={(e) => {
                setDisplayName(e.target.value);
                if (formError) setFormError(null);
              }}
              placeholder="Your Full Name"
              required
              className="w-full h-11 px-3.5 rounded-xl bg-[#141A29] border border-[#1E293B] focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7]/30 text-white text-sm outline-none transition placeholder:text-slate-600"
            />
          </div>

          {/* Input 2: Telegram Username */}
          <div className="space-y-1.5">
            <label htmlFor="input-telegram-username" className="block text-xs font-medium text-slate-300">
              Telegram Username
            </label>
            <input
              id="input-telegram-username"
              type="text"
              value={telegramUsername}
              onChange={handleTelegramUsernameChange}
              placeholder="@username"
              required
              className="w-full h-11 px-3.5 rounded-xl bg-[#141A29] border border-[#1E293B] focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7]/30 text-white text-sm font-mono outline-none transition placeholder:text-slate-600"
            />
          </div>

          {/* Input 3: Telegram ID */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label htmlFor="input-telegram-id" className="text-xs font-medium text-slate-300">
                Telegram ID
              </label>
              <button
                type="button"
                id="btn-how-to-get-tg-id"
                onClick={() => setShowHelpModal(true)}
                className="text-[11px] font-medium text-[#38BDF8] hover:text-[#7DD3FC] hover:underline transition cursor-pointer"
              >
                How to get ID?
              </button>
            </div>
            <input
              id="input-telegram-id"
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              value={telegramId}
              onChange={handleTelegramIdChange}
              placeholder="e.g. 7031193156"
              required
              className="w-full h-11 px-3.5 rounded-xl bg-[#141A29] border border-[#1E293B] focus:border-[#0284C7] focus:ring-1 focus:ring-[#0284C7]/30 text-white text-sm font-mono outline-none transition placeholder:text-slate-600"
            />
          </div>

          {/* Input 4: Gender */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-slate-300">
              Gender
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Male', 'Female', 'Other'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  id={`radio-gender-${g.toLowerCase()}`}
                  onClick={() => setGender(g)}
                  className={`h-10 rounded-xl text-xs font-medium transition cursor-pointer select-none flex items-center justify-center border ${
                    gender === g
                      ? "bg-[#0284C7]/15 border-[#0284C7] text-white font-semibold shadow-sm"
                      : "bg-[#141A29] border-[#1E293B] text-slate-400 hover:text-slate-200 hover:border-slate-700"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Primary Button: Full width, #2563EB to #0284C7 gradient, 12px height padding */}
          <div className="pt-2">
            <button
              type="submit"
              id="btn-save-profile-continue"
              disabled={!isFormValid || isSubmitting || isSuccess}
              className={`w-full py-3 px-4 rounded-xl font-semibold text-sm text-white flex items-center justify-center gap-2 transition-all shadow-lg active:scale-[0.98] select-none ${
                isSuccess
                  ? "bg-emerald-600 shadow-emerald-950/60"
                  : isFormValid && !isSubmitting
                  ? "bg-gradient-to-r from-[#2563EB] to-[#0284C7] hover:from-[#1D4ED8] hover:to-[#0369A1] shadow-sky-950/60 cursor-pointer"
                  : "bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed"
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 size={16} className="animate-spin text-white" />
                  <span>Activating Account...</span>
                </>
              ) : isSuccess ? (
                <>
                  <CheckCircle2 size={16} className="text-white" />
                  <span>Account Activated!</span>
                </>
              ) : (
                <span>Activate Account →</span>
              )}
            </button>
          </div>

          {/* Bottom Meta Badge */}
          <div className="text-center pt-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#141A29]/80 border border-[#1E293B] text-[11px] text-slate-400 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block shrink-0" />
              <span className="truncate max-w-[210px] sm:max-w-[260px]">Registered Email: {userGoogleEmail}</span>
              <span className="text-slate-600">•</span>
              <span className="text-emerald-400 font-sans font-medium">Verified Account</span>
            </div>
          </div>

          {/* Subtle sign out link */}
          {onLogout && (
            <div className="text-center pt-0.5">
              <button
                type="button"
                onClick={onLogout}
                className="text-[11px] text-slate-500 hover:text-slate-300 transition underline underline-offset-2 cursor-pointer"
              >
                Sign out of Google
              </button>
            </div>
          )}
        </form>
      </div>

      {/* Sleek Toast Notification on Success */}
      {showToast && (
        <div 
          id="toast-profile-activated"
          className="fixed top-5 left-1/2 -translate-x-1/2 z-[300] flex items-center gap-2.5 px-5 py-3 rounded-2xl bg-[#091122]/95 border border-emerald-500/60 text-white shadow-[0_12px_36px_rgba(16,185,129,0.35)] backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-300 pointer-events-none"
        >
          <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-400 shrink-0">
            <CheckCircle2 size={16} />
          </div>
          <span className="text-xs sm:text-sm font-semibold text-emerald-100 font-sans tracking-wide">
            Profile Activated Successfully!
          </span>
        </div>
      )}

      {/* Telegram ID Help Modal */}
      <TelegramIdHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />
    </div>
  );
}
