/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Download } from "lucide-react";

export interface PosterDownloadOverlayProps {
  /** Size variant */
  size?: "sm" | "md" | "lg";
  /** Optional loading text or badge */
  statusText?: string;
  /** Custom class for wrapping overlay */
  className?: string;
}

/**
 * Premium Organic Circular Download Animation Overlay
 * Rendered when user taps a poster or "GET LINK" button.
 * Delivers an ultra-fast, smooth, high-fidelity circular glow & arrow flow animation
 * accompanied by background poster blur before seamlessly revealing the download details page.
 */
export const PosterDownloadOverlay: React.FC<PosterDownloadOverlayProps> = ({
  size = "md",
  statusText = "",
  className = "",
}) => {
  const isSmall = size === "sm";
  const isLarge = size === "lg";

  // Refined, subtle, and proportional dimensions that fit neatly inside posters
  const outerDim = isSmall ? "w-8 h-8" : isLarge ? "w-11 h-11" : "w-9 h-9";
  const iconSize = isSmall ? 13 : isLarge ? 18 : 15;

  return (
    <div
      className={`absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm transition-all duration-200 select-none pointer-events-none rounded-[inherit] overflow-hidden ${className}`}
      aria-hidden="true"
    >
      {/* Deep organic radial ambient bloom behind circular badge - compact & subtle */}
      <div className="absolute w-16 h-16 rounded-full bg-emerald-500/20 blur-md animate-pulse pointer-events-none" />

      {/* Main Circular Animation Unit */}
      <div className="relative flex items-center justify-center">
        {/* Expanding Organic Ripple Wave */}
        <div className="absolute -inset-1.5 rounded-full border border-emerald-400/40 animate-ping opacity-35 pointer-events-none" />
        <div className="absolute -inset-0.5 rounded-full border border-emerald-500/30 animate-pulse pointer-events-none" />

        {/* Continuous Rotating Organic Gradient Conic Ring */}
        <div className={`${outerDim} rounded-full p-[2px] relative flex items-center justify-center shadow-[0_0_16px_rgba(16,185,129,0.55)]`}>
          {/* Animated spinning conic ring */}
          <div className="absolute inset-0 rounded-full animate-spin bg-[conic-gradient(from_0deg,#10B981,#064E3B,#10B981,#34D399,#a7f3d0,#10B981)]" style={{ animationDuration: '0.8s' }} />

          {/* Deep dark circular core container */}
          <div className="relative w-full h-full rounded-full bg-slate-950/95 backdrop-blur-md border border-emerald-400/50 flex items-center justify-center overflow-hidden">
            {/* Ambient inner soft glow ring */}
            <div className="absolute inset-0.5 rounded-full bg-emerald-500/15 animate-ping opacity-25" />

            {/* Downward Cascading Particle / Arrow Flow */}
            <div className="relative z-10 flex flex-col items-center justify-center">
              <Download
                size={iconSize}
                strokeWidth={2.6}
                className="text-emerald-400 drop-shadow-[0_0_6px_rgba(52,211,153,0.9)] animate-bounce"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Micro Status Text (only when specified) */}
      {statusText && (
        <span className="mt-1.5 text-[8px] sm:text-[9px] font-mono font-bold text-emerald-300 tracking-wider uppercase bg-slate-950/80 px-1.5 py-0.5 rounded-full border border-emerald-500/30 shadow-sm animate-pulse">
          {statusText}
        </span>
      )}
    </div>
  );
};

export default PosterDownloadOverlay;
