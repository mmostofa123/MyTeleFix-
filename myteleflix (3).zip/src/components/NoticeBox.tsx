export { default } from "../NoticeBox";
export * from "../NoticeBox";
