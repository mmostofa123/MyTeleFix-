/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import AdminDashboard from "./AdminDashboard";

export default AdminDashboard;
export { AdminDashboard as AdminPanel };
export * from "./AdminDashboard";
