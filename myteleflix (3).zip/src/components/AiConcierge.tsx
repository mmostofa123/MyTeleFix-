/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Search, Sparkles, Send, Clock, CheckCircle2, XCircle, Film, History, BrainCircuit } from "lucide-react";
import { MovieRequest } from "../types";

interface AiConciergeProps {
  requests: MovieRequest[];
  onSearchAi: (query: string, notes?: string) => Promise<{ success: boolean; responseText: string; request: MovieRequest }>;
  isSyncing: boolean;
}

export default function AiConcierge({
  requests,
  onSearchAi,
  isSyncing: _isSyncing,
}: AiConciergeProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [customNotes, setCustomNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [latestResponse, setLatestResponse] = useState<string | null>(null);

  const handleSearchRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setLatestResponse(null);
    try {
      const res = await onSearchAi(searchQuery, customNotes);
      if (res.success) {
        setLatestResponse(res.responseText);
        setSearchQuery("");
        setCustomNotes("");
      }
    } catch (err) {
      console.error("AI Concierge request failed", err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full font-bold border border-emerald-150 uppercase font-mono">
            <CheckCircle2 size={10} />
            Approved
          </span>
        );
      case "rejected":
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-rose-50 text-rose-700 px-2.5 py-0.5 rounded-full font-bold border border-rose-150 uppercase font-mono">
            <XCircle size={10} />
            Declined
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] bg-amber-50 text-amber-700 px-2.5 py-0.5 rounded-full font-bold border border-amber-150 uppercase font-mono animate-pulse">
            <Clock size={10} />
            In Review
          </span>
        );
    }
  };

  return (
    <div id="ai-concierge-module" className="space-y-6">
      
      {/* 1. Dynamic Header Banner */}
      <div className="bg-gradient-to-br from-indigo-600 via-indigo-500 to-indigo-700 rounded-2xl p-6 relative overflow-hidden shadow-md">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <BrainCircuit size={120} className="text-white animate-pulse" />
        </div>
        <div className="relative z-10 max-w-xl text-white">
          <span className="text-[10px] bg-white/20 text-white font-mono font-extrabold px-3 py-1 rounded-full uppercase tracking-widest inline-flex items-center gap-1">
            <Sparkles size={11} fill="currentColor" className="animate-spin text-white" />
            Gemini AI Assistant
          </span>
          <h2 className="text-lg font-bold mt-4 tracking-wide">
            Smart Cinema Concierge & Movie Requests
          </h2>
          <p className="text-[11px] text-indigo-100 mt-2 leading-relaxed">
            Search catalog records or request any cinema masterpiece ever filmed! The client handles validations and queries the official Gemini-2.5-Flash model server-side. Newly approved movies will trigger custom notification cards in real-time.
          </p>
        </div>
      </div>

      {/* 2. Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Request Form Panel */}
        <div className="lg:col-span-5 bg-white border border-indigo-50 rounded-2xl p-5 shadow-sm flex flex-col justify-between h-fit">
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-2 font-mono pb-2 border-b border-slate-100">
              <Search size={14} className="text-indigo-600" />
              Request New Release
            </h4>

            <form id="ai-search-form" onSubmit={handleSearchRequest} className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-500 uppercase font-mono block mb-1.5 font-bold">
                  Movie Title or Keyword
                </label>
                <div className="relative">
                  <input
                    id="ai-search-query-input"
                    type="text"
                    placeholder="e.g., Interstellar, Avatar, Dune..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition"
                    required
                  />
                  <span className="absolute inset-y-0 left-3.5 flex items-center text-slate-400">
                    <Film size={14} />
                  </span>
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-500 uppercase font-mono block mb-1.5 font-bold">
                  Additional Notes or Genre Preferences (Optional)
                </label>
                <textarea
                  id="ai-search-notes-input"
                  placeholder="e.g., I love Christopher Nolan movies, please upload this in high quality!"
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 placeholder-slate-400 outline-none transition h-24 resize-none"
                />
              </div>

              <button
                id="ai-search-submit-btn"
                type="submit"
                disabled={loading}
                className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all duration-300 flex items-center justify-center gap-1.5 ${
                  loading
                    ? "bg-slate-100 text-slate-450 border border-slate-250 cursor-not-allowed"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer active:scale-97 shadow-sm"
                }`}
              >
                {loading ? (
                  <>
                    <div className="h-3.5 w-3.5 rounded-full border-2 border-white border-t-indigo-600 animate-spin"></div>
                    Querying Gemini SDK...
                  </>
                ) : (
                  <>
                    <Send size={12} />
                    Consult AI Concierge
                  </>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Dynamic AI Response Card */}
        <div className="lg:col-span-7 bg-white border border-indigo-50 rounded-2xl p-5 shadow-sm flex flex-col min-h-[300px] justify-between">
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-2 pb-2 border-b border-slate-100 font-mono">
              <Sparkles size={14} className="text-indigo-600 animate-pulse" />
              AI Assistant Response
            </h4>

            {loading ? (
              <div className="space-y-4 py-12 text-center">
                <div className="relative inline-block">
                  <div className="h-12 w-12 rounded-full border-4 border-slate-100 border-t-indigo-600 animate-spin"></div>
                </div>
                <p className="text-xs text-indigo-600 font-mono tracking-widest animate-pulse uppercase font-black">
                  Gemini-2.5-Flash validating request...
                </p>
              </div>
            ) : latestResponse ? (
              <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200 animate-in fade-in duration-300 shadow-inner">
                <div className="flex items-center gap-1.5">
                  <div className="h-2 w-2 rounded-full bg-indigo-600 animate-ping"></div>
                  <span className="text-[9px] text-indigo-600 font-mono uppercase font-black tracking-wider">Gemini Concierge:</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-sans italic">
                  "{latestResponse}"
                </p>
                <div className="text-[10px] text-slate-400 pt-1 flex items-center gap-2">
                  <span>Registered in secure ledger</span>
                  <span>•</span>
                  <span>Confidence: High</span>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-xs text-slate-400 italic space-y-2">
                <p className="font-semibold text-slate-500">The AI Concierge is listening.</p>
                <p className="text-[10px] text-slate-400 max-w-xs mx-auto leading-relaxed">
                  Submit a query or request on the left to consult Gemini.
                </p>
              </div>
            )}
          </div>

          <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 text-[10px] text-slate-500 flex items-center justify-between mt-4 font-mono">
            <span>Powered by @google/genai SDK</span>
            <span className="text-indigo-600 font-bold">Real-time Validation</span>
          </div>
        </div>
      </div>

      {/* 3. Requests logs section */}
      <div className="bg-white border border-indigo-50 rounded-2xl overflow-hidden shadow-sm">
        <div className="px-5 py-4 border-b border-indigo-50 bg-slate-50/50 flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-2 font-mono">
            <History size={14} className="text-indigo-600 animate-pulse" />
            Approved Request Registry
          </h4>
          <span className="text-[10px] text-indigo-600 font-mono bg-indigo-50 px-2 py-0.5 rounded border border-indigo-150">{requests.length} total</span>
        </div>

        {requests.length === 0 ? (
          <div className="p-10 text-center text-xs text-slate-400 italic leading-relaxed">
            No movie requests registered yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
            {requests.map((req) => (
              <div key={req.id} id={`request-log-item-${req.id}`} className="p-5 hover:bg-slate-50/50 transition-all duration-200">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-800 text-xs">{req.title}</span>
                    <span className="text-[10px] text-indigo-600 font-mono font-bold">@{req.username}</span>
                  </div>
                  {getStatusBadge(req.status)}
                </div>
                {req.notes && (
                  <p className="text-[11px] text-slate-500 mt-2 italic pl-2 border-l-2 border-slate-250">
                    "Notes: {req.notes}"
                  </p>
                )}
                {req.aiRecommendation && (
                  <div className="mt-3 bg-indigo-50/50 border border-indigo-100/50 rounded-lg p-3">
                    <span className="text-[9px] text-indigo-600 font-mono font-extrabold block uppercase tracking-wider">AI Recommendation & Fact:</span>
                    <p className="text-[11px] text-slate-700 mt-1 leading-relaxed italic">{req.aiRecommendation}</p>
                  </div>
                )}
                <span className="text-[9px] text-slate-400 block mt-3 font-mono uppercase tracking-wide">
                  Submitted: {new Date(req.timestamp).toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
