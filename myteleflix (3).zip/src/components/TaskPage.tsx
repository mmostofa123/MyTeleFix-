/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Radio, Globe, Sparkles, CheckCircle2, Clock, 
  ExternalLink, PlayCircle, Loader2, ShieldCheck, 
  AlertCircle, Zap, Gift, Check, Flame, Share2
} from "lucide-react";
import { Mission, MissionLog, User, SystemSettings } from "../types";
import { 
  getAdNetworkConfig, 
  openAdImpressionWindow, 
  claimAdRewardApi 
} from "../services/adNetwork";
import { saveUserToFirestore } from "../services/firebase";
import TokenIcon from "./TokenIcon";

export interface TaskPageProps {
  missions: Mission[];
  missionLogs: MissionLog[];
  onVerifyMission: (missionId: string) => Promise<{ success: boolean; error?: string; pointsEarned?: number }>;
  userId: string;
  user?: User;
  settings?: SystemSettings;
  onUpdateUser?: (u: User) => void;
  onTriggerAuth?: (action: 'earn') => void;
}

export default function TaskPage({
  missions,
  missionLogs,
  onVerifyMission,
  userId,
  user,
  settings,
  onUpdateUser,
  onTriggerAuth,
}: TaskPageProps) {
  const adConfig = getAdNetworkConfig(settings);

  // Active Real Ad Network Verification State
  const [activeAdMission, setActiveAdMission] = useState<{
    id: string;
    title: string;
    network: 'adsterra' | 'monetag' | 'adsense' | 'direct';
    url: string;
    rewardPoints: number;
    impressionId?: string;
  } | null>(null);

  const [adCountdown, setAdCountdown] = useState<number>(0);
  const [isVerifyingAd, setIsVerifyingAd] = useState<boolean>(false);
  const [adSuccessMessage, setAdSuccessMessage] = useState<string | null>(null);
  const [adErrorMessage, setAdErrorMessage] = useState<string | null>(null);
  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Local completed tracker
  const [completedAdTasks, setCompletedAdTasks] = useState<Set<string>>(new Set());

  useEffect(() => {
    return () => {
      if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    };
  }, []);

  // Built-in Real Ad Network Missions dynamically populated from Admin Controller Room
  const realAdNetworkMissions = [
    {
      id: "ad-task-monetag",
      title: "Monetag Direct Impression Sponsor",
      description: "Engage with Monetag verified sponsor creative to earn cinematic tokens.",
      network: "monetag" as const,
      url: adConfig.monetagDirectTag,
      rewardPoints: adConfig.adRewardPoints,
      badge: "Monetag Ads",
      badgeColor: "bg-indigo-500/20 text-indigo-300 border-indigo-500/40",
    },
    {
      id: "ad-task-adsterra",
      title: "Adsterra High-CPM Smartlink",
      description: "Discover featured partner offers through our verified Adsterra network.",
      network: "adsterra" as const,
      url: adConfig.adsterraDirectLink,
      rewardPoints: adConfig.adRewardPoints,
      badge: "Adsterra Smartlink",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/40",
    },
    {
      id: "ad-task-adsense",
      title: "Google AdSense Partner Discovery",
      description: "View verified Google network display & video sponsor opportunities.",
      network: "adsense" as const,
      url: adConfig.directImpressionUrl || "https://www.google.com",
      rewardPoints: adConfig.adRewardPoints,
      badge: "Google Ads",
      badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
    },
    {
      id: "ad-task-direct",
      title: "Direct Advertiser Sponsor Portal",
      description: "Direct official channel sponsorship with guaranteed token payout.",
      network: "direct" as const,
      url: adConfig.directImpressionUrl,
      rewardPoints: adConfig.adRewardPoints,
      badge: "Direct Sponsor",
      badgeColor: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
    },
  ];

  /**
   * Starts a real ad network mission:
   * 1. Opens official ad window (Adsterra / Monetag / Sponsor URL)
   * 2. Starts anti-fraud verification timer (15 seconds)
   * 3. Prevents early claims
   */
  const handleStartRealAdMission = (task: typeof realAdNetworkMissions[0]) => {
    if (userId === "guest" || !user) {
      onTriggerAuth?.('earn');
      return;
    }

    setAdErrorMessage(null);
    setAdSuccessMessage(null);

    // Open real ad impression window safely
    const { impressionId } = openAdImpressionWindow(task.url);

    setActiveAdMission({
      id: task.id,
      title: task.title,
      network: task.network,
      url: task.url,
      rewardPoints: task.rewardPoints,
      impressionId,
    });

    setAdCountdown(15);

    if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    countdownTimerRef.current = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  /**
   * Finalizes the ad mission:
   * Calls secure Bearer API guard (/api/rewards/claim) and synchronizes to Firestore
   */
  const handleClaimAdReward = async () => {
    if (!activeAdMission || !user) return;

    if (adCountdown > 0) {
      setAdErrorMessage(`Please stay on the sponsor page for ${adCountdown} more seconds.`);
      return;
    }

    setIsVerifyingAd(true);
    setAdErrorMessage(null);

    try {
      const claimResult = await claimAdRewardApi({
        userId: user.id,
        missionId: activeAdMission.id,
        adNetwork: activeAdMission.network,
        impressionId: activeAdMission.impressionId || `imp-${Date.now()}`,
        adTitle: activeAdMission.title,
        rewardPoints: activeAdMission.rewardPoints,
      });

      // Update local completed set
      setCompletedAdTasks((prev) => new Set(prev).add(activeAdMission.id));

      // Update client user state
      if (user && onUpdateUser) {
        const updated: User = {
          ...user,
          points: claimResult.newPointsTotal || (user.points + activeAdMission.rewardPoints),
          last_active_at: new Date().toISOString(),
          active_day_streak: claimResult.activeDayNewlyAwarded
            ? (user.active_day_streak || 0) + 1
            : (user.active_day_streak || 0),
          valid_action_count: (user.valid_action_count || 0) + 1,
          today_activity: claimResult.activityStats || user.today_activity,
          taskStats: {
            missionsCompleted: (user.taskStats?.missionsCompleted || 0) + 1,
            totalPointsEarned: (user.taskStats?.totalPointsEarned || 0) + activeAdMission.rewardPoints,
            moviesWatched: user.taskStats?.moviesWatched || 0,
            videosWatched: user.taskStats?.videosWatched || 0,
          },
        };
        onUpdateUser(updated);
        // Sync to Firestore
        await saveUserToFirestore(updated);
      }

      const streakNote = claimResult.activeDayNewlyAwarded
        ? " | 1 Active Day Earned!"
        : "";
      setAdSuccessMessage(`+${activeAdMission.rewardPoints} Verified & Added to Wallet!${streakNote}`);
      setTimeout(() => {
        setActiveAdMission(null);
        setAdSuccessMessage(null);
      }, 3000);
    } catch (err: any) {
      setAdErrorMessage(err.message || "Failed to claim reward. Please try again.");
    } finally {
      setIsVerifyingAd(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Real Ad Network Header */}
      <div className="bg-gradient-to-r from-indigo-950/80 via-slate-900/90 to-purple-950/80 border border-indigo-500/30 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-black uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck size={11} /> Real Ad Monetization Active
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                Network: {adConfig.networkType.toUpperCase()}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white font-sans tracking-tight">
              Sponsored Ad Network Missions
            </h2>
            <p className="text-xs text-slate-400 max-w-xl mt-0.5">
              Earn high-value cinematic points by engaging with certified partner networks (Adsterra, Monetag, Google AdSense). Points are guarded with atomic idempotency locks.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-indigo-500/40 rounded-2xl px-4 py-2.5 text-center shrink-0">
            <span className="text-[10px] font-mono text-indigo-300 block uppercase font-bold">Reward per Ad</span>
            <span className="text-lg font-black text-white font-mono flex items-center justify-center gap-1.5"><TokenIcon size={18} /> +{adConfig.adRewardPoints}</span>
          </div>
        </div>
      </div>

      {/* Real Ad Missions Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {realAdNetworkMissions.map((task) => {
          const isDone = completedAdTasks.has(task.id);

          return (
            <div
              key={task.id}
              className={`p-4 rounded-2xl border transition-all duration-200 flex flex-col justify-between space-y-3 ${
                isDone 
                  ? 'bg-slate-950/40 border-slate-800/50 opacity-75' 
                  : 'bg-slate-900/90 border-slate-800/80 hover:border-indigo-500/40 hover:shadow-lg'
              }`}
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-full border uppercase ${task.badgeColor}`}>
                    {task.badge}
                  </span>
                  <span className="text-xs font-black text-white font-mono flex items-center gap-1">
                    <TokenIcon size={12} />
                    +{task.rewardPoints}
                  </span>
                </div>

                <h4 className="text-sm font-bold text-white font-sans leading-snug">
                  {task.title}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {task.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2">
                <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                  <Clock size={11} /> 15s Verification
                </span>

                {isDone ? (
                  <span className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 size={13} /> Completed
                  </span>
                ) : (
                  <button
                    onClick={() => handleStartRealAdMission(task)}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-mono font-bold text-xs shadow-md shadow-indigo-600/30 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <span>Start Ad</span>
                    <ExternalLink size={12} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Ad Verification Modal */}
      {activeAdMission && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-400 flex items-center justify-center mx-auto mb-2">
                <Radio size={24} className="animate-pulse" />
              </div>
              <h3 className="text-base font-bold text-white">
                Verifying Sponsor Impression
              </h3>
              <p className="text-xs text-slate-400 font-sans">
                {activeAdMission.title}
              </p>
            </div>

            {/* Countdown / Verification Progress */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800/80 text-center space-y-2">
              {adCountdown > 0 ? (
                <div>
                  <span className="text-3xl font-mono font-black text-amber-400 block animate-bounce">
                    {adCountdown}s
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    Sponsor engagement countdown active...
                  </span>
                </div>
              ) : (
                <div className="text-emerald-400 flex flex-col items-center gap-1">
                  <CheckCircle2 size={32} />
                  <span className="text-xs font-mono font-bold">
                    Ad Impression Verified! Click Claim below.
                  </span>
                </div>
              )}
            </div>

            {adErrorMessage && (
              <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-mono flex items-center gap-2">
                <AlertCircle size={14} className="shrink-0" />
                <span>{adErrorMessage}</span>
              </div>
            )}

            {adSuccessMessage && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2">
                <Check size={14} className="shrink-0" />
                <span>{adSuccessMessage}</span>
              </div>
            )}

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveAdMission(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                disabled={adCountdown > 0 || isVerifyingAd}
                onClick={handleClaimAdReward}
                className={`flex-1 py-2.5 rounded-xl font-mono text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1.5 shadow-lg ${
                  adCountdown > 0 || isVerifyingAd
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                }`}
              >
                {isVerifyingAd ? (
                  <>
                    <Loader2 size={14} className="animate-spin" />
                    <span>Claiming...</span>
                  </>
                ) : (
                  <>
                    <Sparkles size={14} />
                    <span className="flex items-center gap-1.5"><TokenIcon size={13} /> Claim +{activeAdMission.rewardPoints}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
