/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";

interface TokenIconProps {
  size?: number;
  className?: string;
}

/**
 * Natural Organic Metallic Token Icon
 * Clean, tactile, solid coin design without neon rays or washed-out lighting.
 * Universally represents platform "Token".
 */
export const TokenIcon: React.FC<TokenIconProps> = ({
  size = 18,
  className = ""
}) => {
  return (
    <span
      className={`inline-flex items-center justify-center shrink-0 select-none align-middle ${className}`}
      style={{ width: size, height: size }}
      title="Token"
      role="img"
      aria-label="Token"
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full"
      >
        <defs>
          {/* Natural Gold Rim Gradient */}
          <linearGradient id="tokenCoinRim" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#F59E0B" />
            <stop offset="50%" stopColor="#D97706" />
            <stop offset="100%" stopColor="#92400E" />
          </linearGradient>
          {/* Coin Inner Face Gradient - Deep & Solid */}
          <linearGradient id="tokenCoinFace" x1="4" y1="4" x2="20" y2="20" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#241B08" />
            <stop offset="100%" stopColor="#120E04" />
          </linearGradient>
        </defs>

        {/* Outer Solid Coin Rim */}
        <circle cx="12" cy="12" r="10.5" fill="url(#tokenCoinRim)" />
        
        {/* Crisp Inner Inset Border */}
        <circle cx="12" cy="12" r="9.2" fill="none" stroke="#FDE68A" strokeWidth="0.6" strokeOpacity="0.4" />

        {/* Deep Solid Coin Core */}
        <circle cx="12" cy="12" r="8.2" fill="url(#tokenCoinFace)" />

        {/* Natural Coin Edge Serration / Bevel Ring */}
        <circle
          cx="12"
          cy="12"
          r="7.2"
          stroke="#D97706"
          strokeWidth="0.75"
          strokeDasharray="2 1.2"
          strokeOpacity="0.8"
        />

        {/* Solid Embossed "T" (Token) Emblem */}
        <path
          d="M7.8 8.2H16.2M12 8.2V16.2M9.4 16.2H14.6"
          stroke="#FBBF24"
          strokeWidth="2.1"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </span>
  );
};

export default TokenIcon;

