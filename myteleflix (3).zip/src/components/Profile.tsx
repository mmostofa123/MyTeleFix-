/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export { default } from "./ProfileScreen";
export * from "./ProfileScreen";
