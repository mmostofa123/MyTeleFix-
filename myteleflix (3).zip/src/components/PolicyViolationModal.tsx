/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, Lock, ArrowRight, X, LogOut, Loader2, Mail } from "lucide-react";
import { clearSecondaryDraftSession, restorePrimaryAccount } from "../SecurityManager";

interface PolicyViolationModalProps {
  isOpen: boolean;
  errorMessage?: string;
  existingAccount?: {
    id?: string;
    email?: string;
    username?: string;
  } | string;
  deviceFingerprint?: string;
  ipAddress?: string;
  onClose: () => void;
  onRestoreOriginalAccount?: () => void | Promise<void>;
}

export default function PolicyViolationModal({
  isOpen,
  errorMessage,
  existingAccount,
  deviceFingerprint,
  ipAddress,
  onClose,
  onRestoreOriginalAccount
}: PolicyViolationModalProps) {
  const [isRestoring, setIsRestoring] = useState(false);

  if (!isOpen) return null;

  const displayEmail = typeof existingAccount === 'string' ? existingAccount : existingAccount?.email;

  const handleDismiss = () => {
    clearSecondaryDraftSession();
    try {
      localStorage.removeItem("myteleflix_user");
      localStorage.removeItem("myteleflix_auth_token");
    } catch (e) {}
    onClose();
  };

  const handleRestore = async () => {
    if (isRestoring) return;
    setIsRestoring(true);
    clearSecondaryDraftSession();
    try {
      if (onRestoreOriginalAccount) {
        await onRestoreOriginalAccount();
      } else if (displayEmail) {
        const u = await restorePrimaryAccount(displayEmail);
        if (u) {
          window.location.reload();
        }
      } else {
        const u = await restorePrimaryAccount();
        if (u) {
          window.location.reload();
        }
      }
    } catch (e) {
      console.warn("handleRestore error:", e);
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        id="policy-violation-overlay"
        className="fixed inset-0 z-[250] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm select-none overflow-hidden"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="policy-violation-title"
      >
        <motion.div
          id="policy-violation-modal-card"
          initial={{ opacity: 0, scale: 0.96, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 12 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          className="relative w-full max-w-md w-[94%] bg-[#0B0F17] border border-rose-900/60 rounded-3xl p-5 sm:p-6 text-left overflow-hidden max-h-[90vh] flex flex-col shadow-2xl"
        >
          {/* Close button */}
          <button
            id="policy-violation-close-btn"
            onClick={handleDismiss}
            className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition active:scale-95 cursor-pointer z-10"
            aria-label="Close Notice"
          >
            <X size={16} />
          </button>

          <div className="overflow-y-auto pr-0.5 space-y-3.5">
            {/* Header Badge */}
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/70 border border-rose-700/50 text-rose-300 text-[10.5px] font-mono font-bold uppercase tracking-wider">
                <AlertTriangle size={12} className="text-rose-400" />
                <span>SECURITY ALERT • ডিভাইস লক সতর্কতা</span>
              </span>
            </div>

            {/* Main Warning Title in Bengali */}
            <div className="space-y-1.5">
              <h2 
                id="policy-violation-title"
                className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug"
              >
                এই ডিভাইসে নতুন বা একাধিক একাউন্ট খোলা সম্পূর্ণ নিষিদ্ধ
              </h2>
              <div className="text-[10px] font-mono text-rose-400 font-bold uppercase tracking-wider">
                1 Device = 1 Account Security Policy
              </div>
              <p className="text-xs sm:text-[12.5px] text-slate-300 font-normal leading-relaxed">
                {errorMessage || "আমাদের প্ল্যাটফর্মের সুরক্ষা ও ফেয়ার রিওয়ার্ড বজায় রাখতে একটি ফিজিক্যাল ডিভাইসের জন্য শুধুমাত্র একটি মূল অ্যাকাউন্ট বরাদ্দ। আপনি এই ডিভাইসে নতুন বা ভিন্ন কোনো অ্যাকাউন্টে প্রবেশ করতে পারবেন না। আপনার এই প্রচেষ্টা অবিলম্বে ব্লক করা হয়েছে এবং আপনাকে লগআউট অবস্থায় রাখা হয়েছে।"}
              </p>
            </div>

            {/* Hardware & Account Details Card */}
            <div className="bg-[#111722] border border-[#1E293B] rounded-2xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between text-[11px] font-mono font-semibold uppercase tracking-wider">
                <span className="text-slate-400">নিবন্ধিত মূল অ্যাকাউন্ট</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9.5px] font-bold flex items-center gap-1">
                  <Lock size={9} />
                  BOUND & LOCKED
                </span>
              </div>

              {displayEmail && (
                <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-[#080C13] border border-[#1F293D]">
                  <Mail size={14} className="text-amber-400 shrink-0" />
                  <span className="text-amber-200 font-mono font-bold text-xs sm:text-sm tracking-tight truncate select-text">
                    {displayEmail}
                  </span>
                </div>
              )}

              {deviceFingerprint && (
                <div className="flex justify-between items-center text-[11px] font-mono text-slate-300 pt-1 border-t border-[#1E293B]/70">
                  <span className="text-slate-400">ডিভাইস ফিঙ্গারপ্রিন্ট:</span>
                  <span className="text-slate-200 font-semibold">{deviceFingerprint.slice(0, 16)}...</span>
                </div>
              )}

              {ipAddress && (
                <div className="flex justify-between items-center text-[11px] font-mono text-slate-300">
                  <span className="text-slate-400">নেটওয়ার্ক আইপি:</span>
                  <span className="text-slate-300">{ipAddress}</span>
                </div>
              )}

              <p className="text-[11px] text-amber-300/90 leading-relaxed font-sans pt-1">
                ⚠️ এই ডিভাইসে শুধুমাত্র ওপরের অনুমোদিত মূল অ্যাকাউন্টটি দিয়েই লগইন করা যাবে। নতুন কোনো অ্যাকাউন্ট তৈরির সুযোগ নেই।
              </p>
            </div>

            {/* Action Buttons */}
            <div className="pt-1.5 space-y-2">
              <button
                type="button"
                id="policy-violation-restore-btn"
                onClick={handleRestore}
                disabled={isRestoring}
                className="w-full py-2.5 sm:py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 disabled:opacity-60 text-[#0A0E15] font-black text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 transition duration-150 cursor-pointer active:scale-[0.99] shadow-sm"
              >
                {isRestoring ? (
                  <>
                    <Loader2 size={16} className="animate-spin shrink-0 text-[#0A0E15]" />
                    <span>মূল অ্যাকাউন্টে লগইন হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <span>মূল অ্যাকাউন্টে ফিরে যান</span>
                    <span className="text-[11px] opacity-85 font-mono">(Return to Primary)</span>
                    <ArrowRight size={14} />
                  </>
                )}
              </button>

              <button
                type="button"
                id="policy-violation-ack-btn"
                onClick={handleDismiss}
                className="w-full py-2 px-3 rounded-xl bg-[#141A24] hover:bg-[#1A2230] text-slate-300 hover:text-white border border-[#243042] text-xs font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 active:scale-[0.99]"
              >
                <LogOut size={13} className="text-slate-400" />
                <span>লগআউট থাকুন / বন্ধ করুন (Stay Logged Out)</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
