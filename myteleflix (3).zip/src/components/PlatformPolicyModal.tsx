/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Tv, 
  Users, 
  Wallet, 
  FileText, 
  ShieldCheck, 
  X, 
  CheckCircle2, 
  AlertTriangle,
  Lock,
  Scale,
  Cpu
} from "lucide-react";
import TokenIcon from "./TokenIcon";

interface PlatformPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type PolicySection = 'streaming' | 'referrals' | 'wallet' | 'compliance';

export default function PlatformPolicyModal({ isOpen, onClose }: PlatformPolicyModalProps) {
  const [activeSection, setActiveSection] = useState<PolicySection>('streaming');

  const navItems = [
    { id: 'streaming' as PolicySection, label: 'Streaming Rules', icon: Tv },
    { id: 'referrals' as PolicySection, label: 'Referral Terms', icon: Users },
    { id: 'wallet' as PolicySection, label: 'Payout & Wallet', icon: Wallet },
    { id: 'compliance' as PolicySection, label: 'Compliance & TOS', icon: Scale }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          id="platform-usage-policy-modal" 
          className="fixed inset-0 z-[170] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="bg-[#0E121E] text-slate-100 w-full max-w-lg rounded-2xl sm:rounded-3xl overflow-hidden shadow-2xl border border-[#1E263D] relative my-auto flex flex-col max-h-[90vh]"
          >
            {/* Modal Header */}
            <div className="px-4 py-3.5 border-b border-[#1A2236] bg-[#0A0D15]/95 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 bg-slate-800 text-cyan-400 border border-slate-700/80 rounded-xl shrink-0">
                  <ShieldCheck size={18} />
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm sm:text-base font-bold text-white tracking-tight leading-snug truncate">
                    Platform & Usage Policy
                  </h4>
                  <p className="text-[11px] text-slate-400 truncate">
                    Terms of service, referral standards, and wallet integrity
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-xl transition cursor-pointer shrink-0"
                aria-label="Close modal"
              >
                <X size={16} />
              </button>
            </div>

            {/* Navigation Switcher Pills */}
            <div className="px-3.5 pt-2.5 pb-2 bg-[#090C14] border-b border-[#1A2236] shrink-0">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-[#121726] p-1 rounded-xl border border-[#1E273F]">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setActiveSection(item.id)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-medium transition cursor-pointer flex items-center justify-center gap-1.5 truncate ${
                        isActive
                          ? 'bg-[#1F273D] text-white border border-slate-600 shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Icon size={13} className="shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Scrollable Policy Body */}
            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1 text-slate-200 font-sans text-xs leading-relaxed">
              
              {/* SECTION 1: APP FEATURES & STREAMING USAGE RULES */}
              {activeSection === 'streaming' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center gap-2 pb-1 border-b border-[#1A2236]">
                    <Tv size={16} className="text-cyan-400" />
                    <h5 className="font-bold text-white text-sm">
                      App Features & Streaming Usage Rules
                    </h5>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      1. Permitted Use & Fair Bandwidth
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      My TeleFlix provides on-demand streaming access to Natok, regional drama series, and full cinema titles for individual, personal, and non-commercial entertainment. Automated scraping, batch ripping, or circumventing CDN streams via bot scripts is strictly forbidden and subject to automated IP rate-limiting.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      2. Adaptive Bitrate & Quality Selector
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Streams support Auto (1080p), 720p HD, 480p SD, and low-data modes. Users on cellular networks are encouraged to enable the Data Saver profile and Fast-Start Playback Engine in App Settings for smooth playback over variable mobile connections.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      3. Offline Download & External Links
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Download links provided inside catalog item cards redirect through verified high-speed server mirrors. Users must comply with host download regulations and avoid executing unauthorized parallel multi-connection threads that degrade shared server resources.
                    </p>
                  </div>
                </div>
              )}

              {/* SECTION 2: TIERED REFERRAL PROGRAM & ANTI-ABUSE */}
              {activeSection === 'referrals' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center gap-2 pb-1 border-b border-[#1A2236]">
                    <Users size={16} className="text-purple-400" />
                    <h5 className="font-bold text-white text-sm">
                      Referral Program & Anti-Abuse Regulations
                    </h5>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">1. Hardware ID (HWID) Anti-Sybil Binding</span>
                      <span className="text-[10px] font-mono bg-purple-950/60 text-purple-300 border border-purple-800/60 px-1.5 py-0.5 rounded">
                        1 Device = 1 Profile
                      </span>
                    </div>
                    <p className="text-[11.5px] text-slate-300">
                      To safeguard the rewards pool against sybil attacks, each registered profile is cryptographically tied to the unique hardware fingerprint (HWID) of the client device. Creating multiple accounts on a single physical phone or desktop will trigger automated fraud flags and referral disqualification.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      2. Tiered Commissions & Verification Criteria
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Referral bonuses are disbursed in tiers upon genuine peer onboarding:
                    </p>
                    <ul className="list-disc pl-4 space-y-1 text-[11px] text-slate-300">
                      <li><strong>Tier 1 (Direct Invite):</strong> Earn reward points once your referee signs in via Google OAuth and completes device authentication.</li>
                      <li><strong>Tier 2 (Network Expansion):</strong> Secondary reward points credited as referred peers actively stream or complete tasks.</li>
                      <li><strong>Tier 3 (Ambassador Status):</strong> Bonus multipliers unlocked for verified content creators with community channels.</li>
                    </ul>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
                      <AlertTriangle size={13} className="shrink-0" />
                      <span>3. Zero-Tolerance Fraud Policy</span>
                    </div>
                    <p className="text-[11.5px] text-slate-300">
                      The use of Android emulators (Bluestacks, LDPlayer), virtual machines, residential proxy chains, automated auto-clickers, or self-referral loops is strictly prohibited. Offending accounts are instantly frozen, and all accumulated coin balances are permanently forfeited.
                    </p>
                  </div>
                </div>
              )}

              {/* SECTION 3: REWARD PAYOUT REQUIREMENTS & WALLET INTEGRITY */}
              {activeSection === 'wallet' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center gap-2 pb-1 border-b border-[#1A2236]">
                    <Wallet size={16} className="text-emerald-400" />
                    <h5 className="font-bold text-white text-sm">
                      Reward Payouts & Wallet Integrity Policy
                    </h5>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      1. Minimum Cashout Thresholds & Rails
                    </span>
                    <div className="grid grid-cols-3 gap-1.5 text-center text-[10.5px] font-mono pt-1">
                      <div className="bg-[#0D111D] p-2 rounded-lg border border-[#1D253A]">
                        <span className="text-emerald-400 font-bold block">bKash</span>
                        <span className="text-slate-300">50 BDT</span>
                        <span className="text-slate-400 text-[9.5px] flex items-center justify-center gap-0.5"><TokenIcon size={10} /> 5,000</span>
                      </div>
                      <div className="bg-[#0D111D] p-2 rounded-lg border border-[#1D253A]">
                        <span className="text-orange-400 font-bold block">Nagad</span>
                        <span className="text-slate-300">50 BDT</span>
                        <span className="text-slate-400 text-[9.5px] flex items-center justify-center gap-0.5"><TokenIcon size={10} /> 5,000</span>
                      </div>
                      <div className="bg-[#0D111D] p-2 rounded-lg border border-[#1D253A]">
                        <span className="text-cyan-400 font-bold block">TRC-20 USDT</span>
                        <span className="text-slate-300">$1.00 USD</span>
                        <span className="text-slate-400 text-[9.5px] flex items-center justify-center gap-0.5"><TokenIcon size={10} /> 10,000</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      2. Verification & Review Timeline
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Payout requests are audited through our automated transaction pipeline followed by manual compliance checks to ensure all earned points derive from legitimate streaming and referrals. Approvals typically finalize within 24–48 business hours.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      3. Non-Transferable Balances
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Points represent platform loyalty credits and cannot be traded, sold, or transferred across accounts. Only the registered profile owner is permitted to submit withdrawal claims to their own verified personal mobile wallet or cryptocurrency address.
                    </p>
                  </div>
                </div>
              )}

              {/* SECTION 4: GENERAL TERMS OF SERVICE & COMPLIANCE */}
              {activeSection === 'compliance' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center gap-2 pb-1 border-b border-[#1A2236]">
                    <Scale size={16} className="text-blue-400" />
                    <h5 className="font-bold text-white text-sm">
                      General Terms of Service & Technical Compliance
                    </h5>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      1. Distributed CDN & Safe Harbor Disclaimer
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      My TeleFlix functions as an entertainment catalog indexer routing video playback via distributed public content delivery networks. We respect intellectual property rights. Legitimate digital copyright inquiries or DMCA takedown notices should be submitted to the administration desk for immediate processing.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      2. User Data Privacy & SSO Security
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Authentication is facilitated exclusively through official Google OAuth SSO protocols. We never access, store, or sell personal contact lists, browsing history outside our application, or confidential financial credentials.
                    </p>
                  </div>

                  <div className="bg-[#131828] border border-[#1F273E] rounded-xl p-3 space-y-2">
                    <span className="font-bold text-white block text-xs">
                      3. Local Cache & Session Storage
                    </span>
                    <p className="text-[11.5px] text-slate-300">
                      Local caching stores streaming buffer preferences and theme options directly on your device. Clearing application cache inside App Settings resets temporary buffers without affecting your server-persisted point balance or authenticated VIP status.
                    </p>
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="px-4 py-3 border-t border-[#1A2236] bg-[#0A0D15] flex items-center justify-between gap-3 shrink-0">
              <span className="text-[10.5px] font-mono text-slate-400">
                Compliance Ver 3.2 • TeleFlix Legal
              </span>
              <button
                type="button"
                onClick={onClose}
                className="py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer"
              >
                Close Policy
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
