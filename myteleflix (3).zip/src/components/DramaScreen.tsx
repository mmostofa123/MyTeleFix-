/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { Search, Tv, Download } from "lucide-react";
import { Movie, User, AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import { getSeriesGroupPacks, SeriesGroupPack } from "../db";
import GroupPackCard from "./GroupPackCard";
import SeriesGroupPackModal from "./SeriesGroupPackModal";
import LinkUnlockModal from "./LinkUnlockModal";
import MovieCard from "./MovieCard";
import { sortMediaNewestFirst } from "../utils/sorting";
import { prefetchImages } from "../utils/imageCache";

export interface DramaScreenProps {
  movies: Movie[];
  user?: User;
  onViewedMovie?: (id: string, isMovie: boolean) => Promise<void>;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  onBackToAll?: () => void;
  showSearchBar?: boolean;
  currentLanguage?: AppLanguage;
}

// 3. DRAMA SCREEN DYNAMIC SUB-FILTERS & MEGA SERIAL SUPPORT:
// Labels: ["ALL", "বাংলা নাটক", "হিন্দি ড্রামা", "মেগা সিরিয়াল", "টেলিফিল্ম"]
export type DramaSubFilter = "ALL" | "বাংলা নাটক" | "হিন্দি ড্রামা" | "মেগা সিরিয়াল" | "টেলিফিল্ম";

export const DRAMA_SUB_FILTERS: DramaSubFilter[] = [
  "ALL",
  "বাংলা নাটক",
  "হিন্দি ড্রামা",
  "মেগা সিরিয়াল",
  "টেলিফিল্ম"
];

function DramaScreenComponent({
  movies,
  user,
  onViewedMovie,
  guideVideoUrl,
  guideVideoLogoUrl,
  onBackToAll,
  showSearchBar = false,
  currentLanguage: propLanguage,
}: DramaScreenProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
  }, []);

  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<DramaSubFilter>("ALL");

  // State for Mega Serial / Drama Pack Episode Launcher Modal
  const [selectedPack, setSelectedPack] = useState<SeriesGroupPack | null>(null);

  // State for Link Unlock Modal
  const [selectedItem, setSelectedItem] = useState<Movie | null>(null);

  // Helper to identify drama / natok / mega serial items
  const isDramaItem = (m: Movie) => {
    if (m.contentType === 'drama') return true;
    const g = (m.genre || '').toLowerCase();
    const t = (m.title || '').toLowerCase();
    return g.includes('natok') || g.includes('drama') || g.includes('telefilm') || g.includes('serial') ||
           t.includes('natok') || t.includes('নাটক') || t.includes('সিরিয়াল');
  };

  // Base list of all drama / natok items
  const allDramaItems = useMemo(() => {
    return movies.filter(isDramaItem);
  }, [movies]);

  // Aggregate multi-episode Mega Serials / drama packs using db.ts helper
  const allGroupPacks = useMemo(() => {
    return getSeriesGroupPacks(allDramaItems);
  }, [allDramaItems]);

  // Map of item IDs that belong to a multi-episode group pack
  const groupedItemIds = useMemo(() => {
    const ids = new Set<string>();
    for (const pack of allGroupPacks) {
      for (const ep of pack.episodes) {
        ids.add(ep.id);
      }
    }
    return ids;
  }, [allGroupPacks]);

  // Standalone single drama / natok items
  const standaloneDramaItems = useMemo(() => {
    return allDramaItems.filter(item => !groupedItemIds.has(item.id));
  }, [allDramaItems, groupedItemIds]);

  // Helper function to check if a drama matches a sub-filter
  const matchesSubFilter = (item: Movie, filter: DramaSubFilter): boolean => {
    if (filter === "ALL") return true;

    const rawLangs = (item.languages || []).map(l => (l || '').toLowerCase().trim());
    const dramaLabels = (item.dramaClassificationLabels || item.drama_classification_labels || []).map(l => (l || '').toLowerCase().trim());
    const allText = `${item.title} ${item.genre || ''} ${item.description || ''} ${item.category || ''}`.toLowerCase();

    if (filter === "বাংলা নাটক") {
      return (
        Boolean(item.banglaLink?.trim()) ||
        Boolean(item.banglaDubbedUrl?.trim()) ||
        rawLangs.some(l => l.includes('bangla') || l.includes('bn') || l.includes('bengali')) ||
        dramaLabels.some(l => l.includes('bangla') || l.includes('বাংলা') || l.includes('natok') || l.includes('drama')) ||
        allText.includes('bangla') ||
        allText.includes('natok') ||
        allText.includes('নাটক')
      );
    }

    if (filter === "হিন্দি ড্রামা") {
      return (
        Boolean(item.hindiLink?.trim()) ||
        Boolean(item.hindiDubbedUrl?.trim()) ||
        rawLangs.some(l => l.includes('hindi') || l.includes('hi')) ||
        dramaLabels.some(l => l.includes('hindi') || l.includes('হিন্দি')) ||
        allText.includes('hindi') ||
        allText.includes('হিন্দি')
      );
    }

    if (filter === "মেগা সিরিয়াল") {
      return (
        Boolean(item.groupTitle || item.series_group_title) ||
        Boolean(item.totalEpisodes) ||
        dramaLabels.some(l => l.includes('serial') || l.includes('mega') || l.includes('সিরিয়াল')) ||
        allText.includes('mega serial') ||
        allText.includes('serial') ||
        allText.includes('সিরিয়াল') ||
        allText.includes('ধারাবাহিক')
      );
    }

    if (filter === "টেলিফিল্ম") {
      return (
        dramaLabels.some(l => l.includes('telefilm') || l.includes('টেলিফিল্ম')) ||
        allText.includes('telefilm') ||
        allText.includes('টেলিফিল্ম')
      );
    }

    return true;
  };

  // Filter Group Packs based on sub-filter & search
  const filteredGroupPacks = useMemo(() => {
    let packs = allGroupPacks;

    // Filter by sub-filter
    if (activeFilter !== "ALL") {
      packs = packs.filter(p => {
        // If master item matches, or any episode matches, or filter is "মেগা সিরিয়াল" and pack has multiple episodes
        if (activeFilter === "মেগা সিরিয়াল" && p.totalEpisodesCount >= 2) return true;
        return matchesSubFilter(p.masterItem, activeFilter) || p.episodes.some(ep => matchesSubFilter(ep, activeFilter));
      });
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      packs = packs.filter(p => {
        const matchTitle = p.groupTitle.toLowerCase().includes(q);
        const matchMaster = p.masterItem.title.toLowerCase().includes(q) ||
          Boolean(p.masterItem.genre && p.masterItem.genre.toLowerCase().includes(q)) ||
          Boolean(p.masterItem.description && p.masterItem.description.toLowerCase().includes(q));
        const matchEpisodes = p.episodes.some(ep => ep.title.toLowerCase().includes(q));
        return matchTitle || matchMaster || matchEpisodes;
      });
    }

    return packs;
  }, [allGroupPacks, activeFilter, searchQuery]);

  // Filter Standalone Dramas based on sub-filter & search
  const filteredStandaloneDramas = useMemo(() => {
    let list = standaloneDramaItems;

    // Filter by sub-filter
    if (activeFilter !== "ALL") {
      list = list.filter(item => matchesSubFilter(item, activeFilter));
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(item => {
        const matchTitle = item.title.toLowerCase().includes(q);
        const matchGenre = Boolean(item.genre && item.genre.toLowerCase().includes(q));
        const matchDesc = Boolean(item.description && item.description.toLowerCase().includes(q));
        const matchLangs = Boolean(item.languages && item.languages.some(l => l.toLowerCase().includes(q)));
        return matchTitle || matchGenre || matchDesc || matchLangs;
      });
    }

    return sortMediaNewestFirst(list);
  }, [standaloneDramaItems, activeFilter, searchQuery]);

  // Pre-fetch thumbnails
  useEffect(() => {
    const thumbsToPreload = [
      ...filteredGroupPacks.map(p => p.masterItem.thumbnailUrl),
      ...filteredStandaloneDramas.map(d => d.thumbnailUrl)
    ].filter(Boolean);
    if (thumbsToPreload.length > 0) {
      prefetchImages(thumbsToPreload.slice(0, 30));
    }
  }, [filteredGroupPacks, filteredStandaloneDramas]);

  const totalDisplayedCount = filteredGroupPacks.length + filteredStandaloneDramas.length;

  const handleOpenItemUnlock = (item: Movie, e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setSelectedItem(item);
    onViewedMovie?.(item.id, true).catch(() => {});
  };

  return (
    <div id="drama-screen" className="space-y-3.5 animate-in fade-in duration-150 relative w-full max-w-full overflow-x-hidden">
      {/* 1. Search Bar at the very top (Only shown when explicitly enabled, hidden in category views) */}
      {showSearchBar && (
        <div className="px-4 pt-1 search-bar-container">
          <div className="relative bg-slate-900 border border-slate-800 focus-within:border-emerald-500/80 rounded-xl flex items-center px-3.5 py-1 transition duration-150 shadow-sm">
            <div className="mr-2.5 shrink-0 text-slate-400">
              <Search size={15} />
            </div>
            <input
              id="drama-screen-search"
              type="text"
              placeholder={t("search_drama_placeholder", activeLanguage, "Filter drama & natok by title, actors, genre...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-white placeholder-slate-400 text-xs sm:text-sm py-2 outline-none font-sans font-normal"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="text-[10px] text-slate-300 hover:text-white font-mono font-semibold bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg cursor-pointer shrink-0 ml-2 border border-slate-700/60 active:scale-95 transition-transform duration-75"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. DYNAMIC SUB-FILTERS: ["ALL", "বাংলা নাটক", "হিন্দি ড্রামা", "মেগা সিরিয়াল", "টেলিফিল্ম"] */}
      <div className="w-full overflow-hidden">
        <div 
          id="drama-sub-filter-bar" 
          className="flex items-center gap-2 overflow-x-auto scrollbar-none px-4 py-1 no-scrollbar scroll-smooth"
        >
          {DRAMA_SUB_FILTERS.map((label) => {
            const isActive = activeFilter === label;
            return (
              <button
                key={label}
                id={`drama-filter-btn-${label}`}
                onClick={() => setActiveFilter(label)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono tracking-wide active:scale-95 transition-all duration-75 whitespace-nowrap cursor-pointer flex items-center gap-1.5 select-none shrink-0 border h-8 ${
                  isActive
                    ? "bg-[#059669] text-white font-bold border border-[#059669] shadow-md shadow-emerald-950/40"
                    : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E] font-medium"
                }`}
              >
                <span className="whitespace-nowrap">{t(label, activeLanguage, label)}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Mega Serials Group Packs & Standalone Drama Cards Grid */}
      <div id="drama-grid" className="px-4 pt-1">
        {totalDisplayedCount > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Master Group Pack Cards (Aggregated multi-episode mega serials) */}
            {filteredGroupPacks.map((pack) => (
              <GroupPackCard
                key={`drama-pack-${pack.groupTitle}`}
                pack={pack}
                layout="grid"
                isDrama={true}
                onClick={() => setSelectedPack(pack)}
              />
            ))}

            {/* Standalone Drama / Natok Cards */}
            {filteredStandaloneDramas.map((item) => (
              <MovieCard
                key={`single-drama-${item.id}`}
                movie={item}
                layout="grid"
                showGetLink={true}
                showBadges={false}
                sectionType="drama"
                onClick={() => handleOpenItemUnlock(item)}
              />
            ))}
          </div>
        ) : (
          <div className="py-12 text-center bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 text-slate-400 flex items-center justify-center">
              <Tv size={22} />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-white">
                {t("no_drama_found", activeLanguage, "No Drama Found")}
              </h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                {searchQuery.trim()
                  ? `"${searchQuery}" এর সাথে কোন নাটক মেলেনি।`
                  : activeFilter !== "ALL"
                  ? `বর্তমানে "${activeFilter}" ক্যাটাগরিতে কোন নাটক নেই।`
                  : `বর্তমানে কোন নাটক পাওয়া যায়নি।`}
              </p>
            </div>
            {(searchQuery || activeFilter !== "ALL") && (
              <button
                onClick={() => {
                  setSearchQuery("");
                  setActiveFilter("ALL");
                }}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-xl transition-all duration-75 ease-out shadow-md cursor-pointer active:scale-95 inline-flex items-center gap-1.5 select-none"
              >
                <span>{t("see_all_drama", activeLanguage, "View All Drama")}</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* ACCORDION/TAB MODAL VIEW: Mega Serial Launcher Modal */}
      {selectedPack && (
        <SeriesGroupPackModal
          pack={selectedPack}
          isOpen={Boolean(selectedPack)}
          isDrama={true}
          onClose={() => setSelectedPack(null)}
          onSelectEpisode={(ep) => {
            handleOpenItemUnlock(ep);
          }}
        />
      )}

      {/* MODAL: GET-LINK UNLOCK & AUDIO DUB MODAL */}
      {selectedItem && (
        <LinkUnlockModal
          item={selectedItem}
          type="movie"
          userId={user?.id}
          guideVideoUrl={guideVideoUrl}
          guideVideoLogoUrl={guideVideoLogoUrl}
          onClose={() => setSelectedItem(null)}
        />
      )}
    </div>
  );
}

const DramaScreen = React.memo(DramaScreenComponent);
export default DramaScreen;
