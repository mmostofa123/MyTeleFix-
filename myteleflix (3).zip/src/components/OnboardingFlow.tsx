/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * OnboardingFlow: Mandatory Activate Profile Screen Wrapper
 * Directs all post-Google Sign-In onboarding to ActivateProfileScreen.
 */

import React from "react";
import { User } from "../types";
import ActivateProfileScreen from "./ActivateProfileScreen";

export interface OnboardingFlowProps {
  isOpen: boolean;
  user: User;
  onComplete: (updatedUser: User) => Promise<void> | void;
  onClose?: () => void;
  onLogout?: () => void;
}

export default function OnboardingFlow({
  isOpen,
  user,
  onComplete,
  onLogout
}: OnboardingFlowProps) {
  if (!isOpen || !user) return null;

  return (
    <ActivateProfileScreen
      user={user}
      onComplete={onComplete}
      onLogout={onLogout}
    />
  );
}
