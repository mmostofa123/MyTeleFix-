/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback } from "react";
import MovieCard, { MovieCardProps } from "./MovieCard";
import { Movie } from "../types";

export interface SeriesCardProps extends Omit<MovieCardProps, "movie"> {
  series?: Movie;
  movie?: Movie;
}

export const SeriesCard: React.FC<SeriesCardProps> = ({
  series,
  movie,
  onClick,
  ...props
}) => {
  const item = series || movie;
  if (!item) return null;

  const handleClick = useCallback(() => {
    onClick?.();
  }, [onClick]);

  return (
    <MovieCard
      {...props}
      movie={item}
      onClick={handleClick}
      sectionType="series"
      showGetLink={props.showGetLink ?? true}
    />
  );
};

export default SeriesCard;
