/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { Film, Search, Download, Tv, Layers, Flame } from "lucide-react";
import { Movie, Mission, MovieRequest, User, AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import LinkUnlockModal from "./LinkUnlockModal";
import MovieCard from "./MovieCard";
import { sortMediaNewestFirst } from "../utils/sorting";
import { prefetchImages } from "../utils/imageCache";

export interface MoviesScreenProps {
  movies: Movie[];
  completedMissionIds?: string[];
  userIsPremium?: boolean;
  onViewedMovie?: (id: string, isMovie: boolean) => Promise<void>;
  missions?: Mission[];
  requests?: MovieRequest[];
  onSearchAi?: (query: string, notes?: string) => Promise<{ success: boolean; responseText: string; request: MovieRequest }>;
  isSyncing?: boolean;
  isAdultUnlocked?: boolean;
  onNavigate?: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
  onCategoryChange?: (cat: string) => void;
  user?: User;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  onBackToAll?: () => void;
  showSearchBar?: boolean;
  currentLanguage?: AppLanguage;
}

// Unified continuous category & dubbing filter options
export type MovieUnifiedFilter = 
  | "ALL" 
  | "বাংলা ডাবড" 
  | "হিন্দি ডাবড" 
  | "ইংলিশ ডাবড" 
  | "Drama" 
  | "Series" 
  | "AdultMovies";

function MoviesScreenComponent({
  movies,
  onViewedMovie,
  isAdultUnlocked = false,
  user,
  guideVideoUrl,
  guideVideoLogoUrl,
  onBackToAll,
  showSearchBar = true,
  currentLanguage: propLanguage,
}: MoviesScreenProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
  }, []);

  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<MovieUnifiedFilter>("ALL");
  
  // Selection state for unlock modal
  const [selectedPost, setSelectedPost] = useState<Movie | null>(null);
  const [showFreeUnlockModal, setShowFreeUnlockModal] = useState(false);

  // Single continuous chronological unified category & dubbing bar:
  // First: Dubbing options ["ALL", "বাংলা ডাবড", "হিন্দি ডাবড", "ইংলিশ ডাবড"]
  // Then seamlessly follows: ["Drama", "Series", ...(isAdultUnlocked ? ["AdultMovies"] : [])]
  const unifiedFilterTabs = useMemo(() => {
    const tabs: { id: MovieUnifiedFilter; label: string; icon: any }[] = [
      { id: "ALL", label: t("ALL", activeLanguage, "ALL"), icon: Film },
      { id: "বাংলা ডাবড", label: t("বাংলা ডাবড", activeLanguage, "বাংলা ডাবড"), icon: null },
      { id: "হিন্দি ডাবড", label: t("হিন্দি ডাবড", activeLanguage, "হিন্দি ডাবড"), icon: null },
      { id: "ইংলিশ ডাবড", label: t("ইংলিশ ডাবড", activeLanguage, "ইংলিশ ডাবড"), icon: null },
      { id: "Drama", label: t("Drama / Natok", activeLanguage, "Drama / Natok"), icon: Tv },
      { id: "Series", label: t("Web Series", activeLanguage, "Web Series"), icon: Layers },
    ];
    if (isAdultUnlocked) {
      tabs.push({ id: "AdultMovies", label: t("Adult Movies", activeLanguage, "Adult Movies (18+)"), icon: Flame });
    }
    return tabs;
  }, [isAdultUnlocked, activeLanguage]);

  const isAdultItem = (movie: Movie) => {
    return (
      movie.contentType === 'adult_movie' ||
      movie.category === 'Adult Movies' ||
      Boolean(movie.genre && (movie.genre.toLowerCase().includes('adult') || movie.genre.toLowerCase().includes('18+'))) ||
      Boolean(movie.title && (movie.title.toLowerCase().includes('adult') || movie.title.toLowerCase().includes('18+')))
    );
  };

  // Helper to check if item is purely a cinema movie (NOT a web series and NOT a drama/natok)
  const isCinemaMovie = (movie: Movie) => {
    if (movie.contentType === 'series' || Boolean(movie.totalEpisodes)) return false;
    if (movie.genre && movie.genre.toLowerCase().includes('series')) return false;
    if (movie.contentType === 'drama' || (movie.genre && movie.genre.toLowerCase().includes('natok'))) return false;
    if (isAdultItem(movie)) return false;
    return true;
  };

  // Filtered movies list with instant client-side dub filtering and category loading
  const filteredMovies = useMemo(() => {
    let list: Movie[] = [];

    if (activeFilter === "Drama") {
      list = movies.filter(m => 
        !isAdultItem(m) && (
          m.contentType === 'drama' || 
          (m.category && m.category.toLowerCase().includes('drama')) ||
          (m.genre && (m.genre.toLowerCase().includes('drama') || m.genre.toLowerCase().includes('natok'))) ||
          (m.title && m.title.toLowerCase().includes('natok'))
        )
      );
    } else if (activeFilter === "Series") {
      list = movies.filter(m => 
        !isAdultItem(m) && (
          m.contentType === 'series' || 
          Boolean(m.totalEpisodes) || 
          (m.category && m.category.toLowerCase().includes('series')) ||
          (m.genre && m.genre.toLowerCase().includes('series')) ||
          (m.title && m.title.toLowerCase().includes('series'))
        )
      );
    } else if (activeFilter === "AdultMovies") {
      list = isAdultUnlocked ? movies.filter(isAdultItem) : [];
    } else {
      // Base cinema movies
      const cinemaList = movies.filter(isCinemaMovie);

      if (activeFilter === "বাংলা ডাবড") {
        list = cinemaList.filter((m) => {
          const rawLangs = (m.languages || []).map(l => (l || '').toLowerCase().trim());
          const dubLabels = (m.dubbingLabels || m.dubbing_labels || []).map(l => (l || '').toLowerCase().trim());
          const allText = `${m.title} ${m.genre || ''} ${m.description || ''}`.toLowerCase();
          return (
            Boolean(m.banglaLink?.trim()) ||
            Boolean(m.banglaDubbedUrl?.trim()) ||
            rawLangs.some(l => l.includes('bangla') || l.includes('bn') || l.includes('bengali')) ||
            dubLabels.some(l => l.includes('bangla') || l.includes('বাংলা')) ||
            allText.includes('bangla dubbed') ||
            allText.includes('বাংলা ডাব')
          );
        });
      } else if (activeFilter === "হিন্দি ডাবড") {
        list = cinemaList.filter((m) => {
          const rawLangs = (m.languages || []).map(l => (l || '').toLowerCase().trim());
          const dubLabels = (m.dubbingLabels || m.dubbing_labels || []).map(l => (l || '').toLowerCase().trim());
          const allText = `${m.title} ${m.genre || ''} ${m.description || ''}`.toLowerCase();
          return (
            Boolean(m.hindiLink?.trim()) ||
            Boolean(m.hindiDubbedUrl?.trim()) ||
            rawLangs.some(l => l.includes('hindi') || l.includes('hi')) ||
            dubLabels.some(l => l.includes('hindi') || l.includes('হিন্দি')) ||
            allText.includes('hindi dubbed') ||
            allText.includes('হিন্দি ডাব')
          );
        });
      } else if (activeFilter === "ইংলিশ ডাবড") {
        list = cinemaList.filter((m) => {
          const rawLangs = (m.languages || []).map(l => (l || '').toLowerCase().trim());
          const dubLabels = (m.dubbingLabels || m.dubbing_labels || []).map(l => (l || '').toLowerCase().trim());
          const allText = `${m.title} ${m.genre || ''} ${m.description || ''}`.toLowerCase();
          return (
            Boolean(m.englishLink?.trim()) ||
            Boolean(m.englishDubbedUrl?.trim()) ||
            rawLangs.some(l => l.includes('english') || l.includes('en')) ||
            dubLabels.some(l => l.includes('english') || l.includes('ইংলিশ')) ||
            allText.includes('english dubbed') ||
            allText.includes('ইংলিশ ডাব')
          );
        });
      } else {
        // "ALL"
        list = cinemaList;
      }
    }

    // Real-time search query filtering
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(m => {
        const matchTitle = m.title.toLowerCase().includes(q);
        const matchGenre = Boolean(m.genre && m.genre.toLowerCase().includes(q));
        const matchDesc = Boolean(m.description && m.description.toLowerCase().includes(q));
        const matchLangs = Boolean(m.languages && m.languages.some(l => l.toLowerCase().includes(q)));
        return matchTitle || matchGenre || matchDesc || matchLangs;
      });
    }

    return sortMediaNewestFirst(list);
  }, [movies, activeFilter, searchQuery, isAdultUnlocked]);

  // Silent Background Pre-fetching for Movie Catalog
  useEffect(() => {
    if (filteredMovies.length > 0) {
      prefetchImages(filteredMovies.slice(0, 30).map((m) => m.thumbnailUrl));
    }
  }, [filteredMovies]);

  const handleOpenFreeUnlock = (movie: Movie, e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setSelectedPost(movie);
    setShowFreeUnlockModal(true);
    onViewedMovie?.(movie.id, true).catch(() => {});
  };

  return (
    <div id="movies-screen" className="space-y-3.5 animate-in fade-in duration-150 relative w-full max-w-full overflow-x-hidden">
      {/* 1. DYNAMIC UNIFIED CONTINUOUS FILTER BAR: ["ALL", "বাংলা ডাবড", "হিন্দি ডাবড", "ইংলিশ ডাবড", "Drama", "Series", "AdultMovies"] (At the very TOP) */}
      <div className="w-full overflow-hidden pt-1">
        <div 
          id="movies-unified-filter-bar" 
          className="flex items-center gap-2 overflow-x-auto scrollbar-none px-4 py-1 no-scrollbar scroll-smooth"
        >
          {unifiedFilterTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                id={`movies-filter-btn-${tab.id}`}
                onClick={(e) => {
                  setActiveFilter(tab.id);
                  e.currentTarget.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono tracking-wide active:scale-95 transition-all duration-75 whitespace-nowrap cursor-pointer flex items-center gap-1.5 select-none shrink-0 border h-8 ${
                  isActive
                    ? "bg-[#E50914] text-white font-bold border border-[#E50914] shadow-md shadow-red-950/40"
                    : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E] font-medium"
                }`}
              >
                {Icon && <Icon size={12} className={isActive ? "text-white stroke-[2.5]" : "text-[#A0A0A0]"} />}
                <span className="whitespace-nowrap">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Single Search Box (In the MIDDLE, directly below Filter Bar) */}
      {showSearchBar && (
        <div className="px-4 pt-0.5 search-bar-container">
          <div className="relative bg-slate-900 border border-slate-800 focus-within:border-emerald-500/80 rounded-xl flex items-center px-3.5 py-1 transition duration-150 shadow-sm">
            <div className="mr-2.5 shrink-0 text-slate-400">
              <Search size={15} />
            </div>
            <input
              id="movies-screen-search"
              type="text"
              placeholder={t("search_movies_placeholder", activeLanguage, "Search movies by title, genre...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-white placeholder-slate-400 text-xs sm:text-sm py-2 outline-none font-sans font-normal"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="text-[10px] text-slate-300 hover:text-white font-mono font-semibold bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg cursor-pointer shrink-0 ml-2 border border-slate-700/60 active:scale-95 transition-transform duration-75"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. Movies Catalog Grid */}
      <div id="movies-grid" className="px-4 pt-1">
        {filteredMovies.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {filteredMovies.map((movie) => (
              <MovieCard
                key={`screen-movie-${movie.id}`}
                movie={movie}
                layout="grid"
                isAdult={isAdultItem(movie)}
                showGetLink={true}
                showBadges={false}
                onClick={() => handleOpenFreeUnlock(movie)}
              />
            ))}
          </div>
        ) : (
          <div className="py-12 text-center bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-3">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-800 text-slate-400 flex items-center justify-center">
              <Film size={22} />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-white">
                {t("no_movies_found", activeLanguage, "No Movies Found")}
              </h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                {searchQuery.trim()
                  ? `"${searchQuery}" এর সাথে কোন কন্টেন্ট মেলেনি।`
                  : activeFilter !== "ALL"
                  ? `বর্তমানে "${activeFilter}" ক্যাটাগরিতে কোন কন্টেন্ট নেই।`
                  : `বর্তমানে কোন কন্টেন্ট পাওয়া যায়নি।`}
              </p>
            </div>
            {(searchQuery || activeFilter !== "ALL") && (
              <button
                onClick={() => {
                  setSearchQuery("");
                  setActiveFilter("ALL");
                }}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase px-4 py-2 rounded-xl transition-all duration-75 ease-out shadow-md cursor-pointer active:scale-95 inline-flex items-center gap-1.5 select-none"
              >
                <span>{t("see_all_movies", activeLanguage, "View All Content")}</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* MODAL: GET-LINK UNLOCK & AUDIO DUB MODAL */}
      {showFreeUnlockModal && selectedPost && (
        <LinkUnlockModal
          item={selectedPost}
          type="movie"
          userId={user?.id}
          guideVideoUrl={guideVideoUrl}
          guideVideoLogoUrl={guideVideoLogoUrl}
          onClose={() => {
            setShowFreeUnlockModal(false);
            setSelectedPost(null);
          }}
        />
      )}
    </div>
  );
}

const MoviesScreen = React.memo(MoviesScreenComponent);
export default MoviesScreen;
