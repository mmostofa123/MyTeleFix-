/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { Notification } from "../types";
import { 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Trophy, 
  Coins, 
  Bell, 
  X 
} from "lucide-react";

interface NotificationToastProps {
  notification: Notification | null;
  onDismiss: () => void;
  onClickView?: (notification: Notification) => void;
}

export const NotificationToast: React.FC<NotificationToastProps> = ({
  notification,
  onDismiss,
  onClickView,
}) => {
  const [isSwiping, setIsSwiping] = useState(false);
  const [offsetY, setOffsetY] = useState(0);
  const [offsetX, setOffsetX] = useState(0);
  const touchStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-dismiss after 3 seconds (as requested in strict execution steps)
  useEffect(() => {
    if (!notification) return;

    setOffsetY(0);
    setOffsetX(0);

    timerRef.current = setTimeout(() => {
      onDismiss();
    }, 3000);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [notification, onDismiss]);

  if (!notification) return null;

  // Touch handlers for swipe to dismiss (upwards or sideways)
  const handleTouchStart = (e: React.TouchEvent) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
    setIsSwiping(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping) return;
    const touch = e.touches[0];
    const diffX = touch.clientX - touchStartRef.current.x;
    const diffY = touch.clientY - touchStartRef.current.y;

    // Allow dragging up or horizontal
    if (diffY < 0) {
      setOffsetY(diffY);
    }
    setOffsetX(diffX);
  };

  const handleTouchEnd = () => {
    setIsSwiping(false);
    // Dismiss if swiped up > 40px or sideways > 80px
    if (offsetY < -40 || Math.abs(offsetX) > 80) {
      onDismiss();
    } else {
      // Snap back
      setOffsetY(0);
      setOffsetX(0);
      // Restart 3s timer
      timerRef.current = setTimeout(() => {
        onDismiss();
      }, 3000);
    }
  };

  const getTypeStyle = () => {
    const type = (notification.type || '').toUpperCase();
    if (type === 'VERIFICATION') {
      return {
        icon: <CheckCircle2 size={18} className="text-emerald-400 shrink-0" />,
        border: "border-emerald-500/40",
        glow: "shadow-[0_4px_24px_rgba(16,185,129,0.2)]",
        badge: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
        label: "VERIFICATION"
      };
    }
    if (type === 'SALARY') {
      return {
        icon: <Coins size={18} className="text-amber-400 shrink-0" />,
        border: "border-amber-500/40",
        glow: "shadow-[0_4px_24px_rgba(245,158,11,0.2)]",
        badge: "bg-amber-500/10 text-amber-400 border-amber-500/30",
        label: "SALARY"
      };
    }
    if (type === 'SECURITY') {
      return {
        icon: <ShieldAlert size={18} className="text-rose-400 shrink-0" />,
        border: "border-rose-500/40",
        glow: "shadow-[0_4px_24px_rgba(244,63,94,0.2)]",
        badge: "bg-rose-500/10 text-rose-400 border-rose-500/30",
        label: "SECURITY"
      };
    }
    if (type === 'MILESTONE') {
      return {
        icon: <Trophy size={18} className="text-cyan-400 shrink-0" />,
        border: "border-cyan-500/40",
        glow: "shadow-[0_4px_24px_rgba(6,182,212,0.2)]",
        badge: "bg-cyan-500/10 text-cyan-400 border-cyan-500/30",
        label: "MILESTONE"
      };
    }
    return {
      icon: <Bell size={18} className="text-indigo-400 shrink-0" />,
      border: "border-indigo-500/40",
      glow: "shadow-[0_4px_24px_rgba(99,102,241,0.2)]",
      badge: "bg-indigo-500/10 text-indigo-400 border-indigo-500/30",
      label: "SYSTEM"
    };
  };

  const style = getTypeStyle();

  return (
    <div 
      id="floating-notification-toast"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        transform: `translate(${offsetX}px, ${offsetY}px)`,
        transition: isSwiping ? 'none' : 'transform 0.2s ease-out, opacity 0.2s ease-out'
      }}
      className={`fixed top-3 left-3 right-3 max-w-sm mx-auto z-[9999] pointer-events-auto select-none transition-all duration-300 animate-in slide-in-from-top-4`}
    >
      <div 
        onClick={() => {
          if (onClickView) onClickView(notification);
          onDismiss();
        }}
        className={`relative overflow-hidden rounded-2xl bg-[#121318]/95 backdrop-blur-xl border ${style.border} ${style.glow} p-3.5 flex items-start gap-3 cursor-pointer group active:scale-[0.99]`}
      >
        {/* Type Icon */}
        <div className="mt-0.5 p-2 rounded-xl bg-white/[0.04] border border-white/[0.08]">
          {style.icon}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pr-5">
          <div className="flex items-center gap-1.5 mb-1">
            <span className={`text-[9px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${style.badge}`}>
              {style.label}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Just now
            </span>
          </div>
          <h4 className="text-xs font-semibold text-white truncate leading-snug">
            {notification.title}
          </h4>
          <p className="text-[11px] text-slate-300 line-clamp-2 mt-0.5 leading-relaxed">
            {notification.message}
          </p>
          <span className="text-[10px] text-cyan-400 font-medium mt-1 inline-block group-hover:underline">
            Tap to view in Notification Center →
          </span>
        </div>

        {/* Manual Dismiss Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDismiss();
          }}
          className="absolute top-2.5 right-2.5 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
          aria-label="Dismiss alert"
        >
          <X size={14} />
        </button>

        {/* 3s Auto-dismiss progress bar animation */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/10 overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-amber-400 via-cyan-400 to-emerald-400 animate-pulse"
            style={{
              animation: "toastProgress 3s linear forwards"
            }}
          />
        </div>
      </div>

      <style>{`
        @keyframes toastProgress {
          from { width: 100%; }
          to { width: 0%; }
        }
      `}</style>
    </div>
  );
};
