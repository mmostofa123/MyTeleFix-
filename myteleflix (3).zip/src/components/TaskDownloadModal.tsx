/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  MonitorPlay, Download, AlertTriangle, Loader2, ArrowRight, X, ShieldCheck, Coins
} from "lucide-react";
import { Movie, Video } from "../types";
import TelegramAdModal from "./TelegramAdModal";

export const STATIC_GUIDE_POSTER = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&h=675&q=85";

interface TaskDownloadModalProps {
  item: Movie | Video;
  type: 'movie' | 'video';
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  userId?: string;
  onClose: () => void;
}

export default function TaskDownloadModal({
  item,
  type: _type,
  guideVideoUrl = "https://www.w3schools.com/html/mov_bbb.mp4",
  guideVideoLogoUrl = STATIC_GUIDE_POSTER,
  userId = "guest",
  onClose
}: TaskDownloadModalProps) {
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [showAd, setShowAd] = useState(false);
  const [pendingForceChrome, setPendingForceChrome] = useState(false);

  // Dynamic system parameters state
  const [dynamicGuideUrl, setDynamicGuideUrl] = useState(guideVideoUrl);
  const [dynamicLogoUrl, setDynamicLogoUrl] = useState(guideVideoLogoUrl);
  const [dynamicRewardPts, setDynamicRewardPts] = useState(item.pointsReward || 500);

  useEffect(() => {
    fetch("/api/system-settings")
      .then(r => r.json())
      .then(data => {
        if (data) {
          if (data.guide_video_url || data.guideVideoUrl) {
            setDynamicGuideUrl(data.guide_video_url || data.guideVideoUrl);
          }
          if (data.guideVideoLogoUrl) {
            setDynamicLogoUrl(data.guideVideoLogoUrl);
          }
          if (data.default_reward_pts) {
            setDynamicRewardPts(data.default_reward_pts);
          }
        }
      })
      .catch(err => console.warn("TaskDownloadModal settings sync error", err));
  }, []);

  const genre = String('genre' in item ? item.genre : "Clip");
  const points = dynamicRewardPts;
  const rating = 'rating' in item ? item.rating : 4.8;
  const quality = String('quality' in item ? item.quality : "4K Ultra HD");

  const initiateAdFlow = (forceChrome: boolean) => {
    setErrorMsg("");
    setPendingForceChrome(forceChrome);
    setShowAd(true);
  };

  const handleAdDismissed = () => {
    setShowAd(false);
    setErrorMsg("Please watch the full ad to start this task.");
  };

  const executeSessionCreation = async () => {
    setShowAd(false);
    setLoading(true);
    setErrorMsg("");
    const forceChrome = pendingForceChrome;

    try {
      const res = await fetch("/api/tasks/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          taskId: item.id,
        }),
      });

      const data = await res.json();
      if (data.success && data.redirectUrl) {
        setSuccessMsg("Ad Verification Complete! Redirecting to Download Stream...");
        
        let finalUrl = data.redirectUrl;
        if (forceChrome) {
          const cleanUrl = data.redirectUrl.replace(/^https?:\/\//, "");
          const intentUrl = `intent://${cleanUrl}#Intent;scheme=https;package=com.android.chrome;end`;
          
          try {
            window.location.href = intentUrl;
          } catch (e) {
            console.log("Intent launch fallback", e);
          }
          
          setTimeout(() => {
            window.open(finalUrl, "_blank", "noopener,noreferrer");
            setLoading(false);
            onClose();
          }, 800);
        } else {
          setTimeout(() => {
            window.open(finalUrl, "_blank", "noopener,noreferrer");
            setLoading(false);
            onClose();
          }, 1000);
        }
      } else {
        setErrorMsg(data.error || "Failed to generate task session. Please try again.");
        setLoading(false);
      }
    } catch (err) {
      console.error("Error creating download task session", err);
      setErrorMsg("Network error connecting to verification server.");
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4 transition-all duration-300 ease-out animate-in fade-in">
      {showAd && (
        <TelegramAdModal
          taskTitle={item.title}
          rewardPoints={points}
          onAdCompleted={executeSessionCreation}
          onAdDismissed={handleAdDismissed}
        />
      )}

      <div className="bg-[#111827] border border-slate-800 w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-300 text-white flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 flex items-center justify-between bg-[#131C2E]">
          <div className="flex items-center gap-2.5">
            <span className="p-2 bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 rounded-xl">
              <Download size={18} />
            </span>
            <div>
              <h3 className="text-sm font-bold font-mono tracking-wide">
                Free Download Task & Tutorial
              </h3>
              <p className="text-[11px] text-slate-400">
                Single-use task verification session
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700 transition-transform duration-75 active:scale-95 cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          
          {/* Item Poster & Details with Non-Cropped Dynamic Aspect Ratio Container */}
          <div className="bg-[#162032] border border-slate-800 rounded-2xl p-3.5 flex gap-3.5 items-center transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 cursor-pointer">
            
            {/* Poster Container - Dynamic Aspect Ratio Poster */}
            <div className="w-24 aspect-[2/3] sm:w-28 rounded-xl bg-slate-950 border border-slate-800/90 relative overflow-hidden shrink-0 shadow-inner">
              <img 
                src={item.thumbnailUrl} 
                alt={item.title} 
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&h=350&q=80";
                }}
                className="w-full h-full object-cover contrast-105 saturate-110 drop-shadow-md rounded-xl"
                referrerPolicy="no-referrer"
              />
              <span className="absolute top-1 left-1 bg-amber-500 text-slate-950 font-black text-[9px] px-1.5 py-0.5 rounded shadow font-mono">
                {quality}
              </span>
            </div>

            {/* Media Information */}
            <div className="flex-1 min-w-0 space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded-md">
                  {genre}
                </span>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Coins size={10} className="fill-amber-400/20" /> +{points}
                </span>
              </div>

              <h4 className="text-sm font-bold text-white line-clamp-2 leading-tight">
                {item.title}
              </h4>

              <p className="text-[11px] text-slate-400 line-clamp-2 leading-snug font-sans">
                {item.description || "High definition release available via task download."}
              </p>

              <div className="flex items-center gap-3 text-[10px] text-slate-400 pt-1 font-mono">
                <span className="text-emerald-400 flex items-center gap-1 font-bold">
                  <ShieldCheck size={12} /> Verified Media
                </span>
                <span>★ {rating}</span>
              </div>
            </div>
          </div>

          {/* Auto-Aspect Ratio Tutorial Guide Video Header */}
          <div className="bg-[#151D30] border border-indigo-500/30 rounded-2xl p-3.5 space-y-2.5 shadow-md relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-300 font-bold text-xs uppercase font-mono tracking-wider">
                <MonitorPlay size={16} className="text-indigo-400 animate-pulse" />
                <span>Tutorial Guide Video</span>
              </div>
              <span className="text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 px-2 py-0.5 rounded-md font-mono">
                Auto Aspect Ratio
              </span>
            </div>

            {/* Guide Video Container with Dynamic Aspect Ratio */}
            <div className="relative w-full rounded-xl bg-black border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner">
              {dynamicGuideUrl.includes("embed") || dynamicGuideUrl.includes("iframe") ? (
                <iframe
                  src={dynamicGuideUrl}
                  title="Tutorial Guide Video"
                  className="w-full aspect-video rounded-xl border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video 
                  src={dynamicGuideUrl} 
                  controls 
                  playsInline
                  preload="metadata"
                  className="w-full h-auto max-h-[45vh] object-contain rounded-xl"
                  poster={dynamicLogoUrl || STATIC_GUIDE_POSTER}
                />
              )}
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed font-sans bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80">
              💡 <span className="font-semibold text-white">How it works:</span> Watch the video above to see how to pass battery verification sites and retrieve your high-speed download link.
            </p>
          </div>

          {/* Feedback messages */}
          {errorMsg && (
            <div className="bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-3 rounded-xl flex items-center gap-2">
              <AlertTriangle size={15} className="shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs p-3 rounded-xl flex items-center gap-2">
              <ShieldCheck size={15} className="shrink-0 animate-bounce" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Action Buttons: Primary START TASK & GET LINK Action */}
          <div className="pt-1 space-y-2.5">
            <button
              onClick={() => initiateAdFlow(true)}
              disabled={loading}
              className="w-full py-3.5 px-5 rounded-2xl text-xs font-bold uppercase tracking-wide transition-all duration-75 ease-out flex items-center justify-center gap-2.5 cursor-pointer bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-600 hover:from-amber-500 hover:to-amber-700 text-slate-950 shadow-lg shadow-amber-950/40 border border-amber-400/30 active:scale-95 active:brightness-125 active:ring-2 active:ring-emerald-400/80 active:shadow-lg active:shadow-emerald-900/50 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 size={16} className="animate-spin text-slate-950" />
                  <span>Redirecting to Battery Site...</span>
                </>
              ) : (
                <>
                  <ArrowRight size={16} className="text-slate-950 stroke-[2.5]" />
                  <span>START TASK & GET LINK</span>
                </>
              )}
            </button>

            <button
              onClick={() => initiateAdFlow(false)}
              disabled={loading}
              className="w-full py-3 px-4 rounded-2xl text-[11px] font-bold uppercase tracking-wider transition-transform duration-75 flex items-center justify-center gap-2 cursor-pointer bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700/60 active:scale-95 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 size={14} className="animate-spin text-indigo-400" />
                  <span>Initiating Session...</span>
                </>
              ) : (
                <>
                  <ArrowRight size={14} className="text-indigo-400" />
                  <span>Standard Task Session Launch</span>
                </>
              )}
            </button>

            <p className="text-[10px] text-center text-slate-400 font-mono">
              ⚡ Chrome Redirect unlocks 100% ad rendering speed & high-speed downloads.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
