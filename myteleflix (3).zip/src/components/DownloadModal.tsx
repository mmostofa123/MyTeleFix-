/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from "react";
import { 
  ArrowLeft, Download, Play, Pause, Volume2, VolumeX, 
  Loader2, Mic, Clapperboard, ArrowRight, ShieldCheck
} from "lucide-react";
import { Movie, Video, AppLanguage } from "../types";
import { getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import DownloadAdTimerModal from "./DownloadAdTimerModal";
import { auth } from "../services/firebase";

export type ContentSectionType = 'movie' | 'adult' | 'series' | 'drama' | 'video';

export interface DownloadModalProps {
  item: Movie | Video;
  type: 'movie' | 'video';
  sectionType?: ContentSectionType;
  userId?: string;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  onClose: () => void;
}

interface DubOption {
  id: 'original' | 'hindi' | 'bangla' | 'english' | 'video_direct';
  titleBn: string;
  titleEn: string;
  titleHi: string;
  flagNode: React.ReactNode;
  badgeText: string;
  fileSize: string;
  targetUrl: string;
}

export default function DownloadModal({
  item,
  type,
  sectionType,
  userId = "guest",
  guideVideoUrl = "https://t.me/MrMovieBox_bot?start=guide",
  guideVideoLogoUrl: _guideVideoLogoUrl,
  onClose,
}: DownloadModalProps) {
  const [activeLang, setActiveLang] = useState<AppLanguage>(getStoredLanguage);

  useEffect(() => {
    const handleLangChange = (e: any) => {
      if (e.detail) {
        setActiveLang(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
  }, []);

  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [redirectStatus, setRedirectStatus] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // Phase 1: High-CPM Custom Video Ad & 15-Second Timer Modal state
  const [adModalOpen, setAdModalOpen] = useState(false);
  const [selectedAdOption, setSelectedAdOption] = useState<{ id: string; title: string; targetUrl: string } | null>(null);
  
  // Permanent Static Guide Video / Bot Link, Voice Audio & Static Poster Artwork
  const [dynamicGuideUrl, setDynamicGuideUrl] = useState(
    item.tutorialVideoUrl || guideVideoUrl
  );
  const [dynamicAudioUrl, setDynamicAudioUrl] = useState(
    item.audioUrl || ""
  );
  
  // Voice Audio State
  const [isPlayingAudio, setIsPlayingAudio] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Fetch dynamic system settings for guide video & voice audio fallback
  useEffect(() => {
    fetch("/api/system-settings")
      .then(r => r.json())
      .then(data => {
        if (data) {
          if (!item.tutorialVideoUrl && (data.guide_video_url || data.guideVideoUrl)) {
            setDynamicGuideUrl(data.guide_video_url || data.guideVideoUrl);
          }
          if (!item.audioUrl && (data.guide_audio_url || data.guideAudioUrl)) {
            setDynamicAudioUrl(data.guide_audio_url || data.guideAudioUrl);
          }
        }
      })
      .catch(err => console.warn("DownloadModal settings sync error", err));
  }, [item.tutorialVideoUrl, item.audioUrl]);

  // Audio Voice Guide Engine
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        console.warn("Speech cancel error", e);
      }
    }

    if (dynamicAudioUrl) {
      const audio = new Audio(dynamicAudioUrl);
      audioRef.current = audio;
      audio.autoplay = true;
      audio.loop = false;

      const handleAudioEnded = () => {
        setIsPlayingAudio(false);
      };

      audio.addEventListener('ended', handleAudioEnded);

      audio.play().then(() => {
        setIsPlayingAudio(true);
      }).catch(err => {
        console.warn("Audio autoplay blocked:", err);
        setIsPlayingAudio(false);
      });

      return () => {
        audio.removeEventListener('ended', handleAudioEnded);
        audio.pause();
        audio.src = '';
      };
    }
  }, [dynamicAudioUrl]);

  const toggleAudioPlayback = () => {
    if (!audioRef.current) return;
    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlayingAudio(true);
      }).catch(() => {});
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    audioRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  // Determine Content Section Theme
  const effectiveSectionType: ContentSectionType = useMemo(() => {
    if (sectionType) return sectionType;
    if (type === 'video' || (item as any).contentType === 'video' || (item as any).category === 'video') return 'video';
    if ((item as any).isAdult || (item as any).genre?.toLowerCase()?.includes('18+') || (item as any).category === 'adult') return 'adult';
    if ((item as any).category === 'series' || (item as any).type === 'series' || (item as any).isSeries) return 'series';
    if ((item as any).category === 'drama' || (item as any).type === 'drama' || (item as any).isDrama) return 'drama';
    return 'movie';
  }, [sectionType, type, item]);

  // Section Color Palette & Badge Definitions
  const sectionTheme = useMemo(() => {
    switch (effectiveSectionType) {
      case 'adult':
        return {
          badgeText: 'ADULT MOVIE DOWNLOAD',
          badgeClass: 'bg-rose-950/60 border border-rose-500/60 text-rose-400',
          shieldColor: 'text-rose-400',
          headerTextColor: 'text-rose-300',
          buttonClass: 'bg-[#DC2626] hover:bg-[#B91C1C] active:bg-[#991B1B] text-white font-black shadow-lg shadow-rose-950/60 border border-red-500/90',
        };
      case 'series':
        return {
          badgeText: 'WEB SERIES DOWNLOAD',
          badgeClass: 'bg-sky-950/60 border border-sky-500/60 text-sky-400',
          shieldColor: 'text-sky-400',
          headerTextColor: 'text-sky-300',
          buttonClass: 'bg-[#0284C7] hover:bg-[#0369A1] active:bg-[#075985] text-white font-black shadow-lg shadow-sky-950/60 border border-sky-400/90',
        };
      case 'drama':
        return {
          badgeText: 'BANGLA DRAMA DOWNLOAD',
          badgeClass: 'bg-emerald-950/60 border border-emerald-500/60 text-emerald-400',
          shieldColor: 'text-emerald-400',
          headerTextColor: 'text-emerald-300',
          buttonClass: 'bg-[#059669] hover:bg-[#047857] active:bg-[#065F46] text-white font-black shadow-lg shadow-emerald-950/60 border border-emerald-400/90',
        };
      case 'video':
        return {
          badgeText: 'VIRAL VIDEO DOWNLOAD',
          badgeClass: 'bg-purple-950/60 border border-purple-500/60 text-purple-400',
          shieldColor: 'text-purple-400',
          headerTextColor: 'text-purple-300',
          buttonClass: 'bg-[#7C3AED] hover:bg-[#6D28D9] active:bg-[#5B21B6] text-white font-black shadow-lg shadow-purple-950/60 border border-purple-400/90',
        };
      case 'movie':
      default:
        return {
          badgeText: 'CINEMA MOVIE DOWNLOAD',
          badgeClass: 'bg-amber-950/60 border border-amber-500/60 text-amber-400',
          shieldColor: 'text-amber-400',
          headerTextColor: 'text-amber-300',
          buttonClass: 'bg-[#E5A00D] hover:bg-[#D97706] active:bg-[#B45309] text-black font-black shadow-lg shadow-amber-950/60 border border-amber-400/90',
        };
    }
  }, [effectiveSectionType]);

  // Localized texts based on activeLang
  const localizedTexts = useMemo(() => {
    if (activeLang === 'English') {
      return {
        back: 'Back',
        tutorialPrompt: 'Having trouble downloading? Tap the picture below to watch the guide video. Learn to download easily in 1 minute!',
        watchGuide: 'Tap here to watch guide video',
        voiceGuide: 'Voice Guide',
        availableDubs: 'Available Language Dubs',
        directVideo: 'Direct Video Download',
        preparing: 'PREPARING...',
        download: 'DOWNLOAD',
        statusVerifying: 'Verifying secure download link...',
        statusSuccess: 'Link ready! Redirecting...',
        noLinkError: 'Download link not configured. Please try another language track.'
      };
    }
    if (activeLang === 'हिंदी') {
      return {
        back: 'वापस',
        tutorialPrompt: 'डाउनलोड करने में समस्या? गाइड वीडियो देखने के लिए नीचे दिए गए चित्र पर टैप करें। 1 मिनट में आसानी से डाउनलोड सीखें!',
        watchGuide: 'गाइड वीडियो देखने के लिए यहां टैप करें',
        voiceGuide: 'वॉयस गाइड (Voice Guide)',
        availableDubs: 'उपलब्ध भाषा डब',
        directVideo: 'सीधा वीडियो डाउनलोड',
        preparing: 'लोड हो रहा है...',
        download: 'DOWNLOAD',
        statusVerifying: 'सुरक्षित डाउनलोड लिंक सत्यापित किया जा रहा है...',
        statusSuccess: 'लिंक तैयार! रीडायरेक्ट हो रहा है...',
        noLinkError: 'डाउनलोड लिंक कॉन्फ़िगर नहीं है। कृपया दूसरा ट्रैक आज़माएं।'
      };
    }
    // Default: বাংলা
    return {
      back: 'Back',
      tutorialPrompt: 'ডাউনলোড করতে সমস্যা? নিচের ছবিতে ট্যাপ করে গাইড ভিডিওটি দেখুন। ১ মিনিটেই সহজে ডাউনলোড শিখুন!',
      watchGuide: 'গাইড ভিডিও দেখতে এখানে ট্যাপ করুন',
      voiceGuide: 'ভয়েস গাইড (Voice Guide)',
      availableDubs: 'উপলভ্য ভাষার ডাবসমূহ',
      directVideo: 'সরাসরি ভিডিও ডাউনলোড',
      preparing: 'প্রস্তুত হচ্ছে...',
      download: 'DOWNLOAD',
      statusVerifying: 'সিকিউর ডাউনলোড লিংক যাচাই করা হচ্ছে...',
      statusSuccess: 'লিংক প্রস্তুত! নিয়ে যাওয়া হচ্ছে...',
      noLinkError: 'ডাউনলোড লিংক কনফিগার করা নেই। অনুগ্রহ করে অন্য ট্র্যাক নির্বাচন করুন।'
    };
  }, [activeLang]);

  // Icons
  const OriginalFilmIcon = (
    <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 shadow-sm">
      <Clapperboard size={16} className="text-slate-300" />
    </div>
  );

  const HindiFlagIcon = (
    <div className="w-8 h-8 rounded-lg border border-slate-700 bg-white relative flex flex-col shrink-0 shadow-sm overflow-hidden">
      <div className="h-1/3 bg-[#FF9933]" />
      <div className="h-1/3 bg-white flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full border border-[#000080] flex items-center justify-center">
          <div className="w-0.5 h-0.5 rounded-full bg-[#000080]" />
        </div>
      </div>
      <div className="h-1/3 bg-[#138808]" />
    </div>
  );

  const BanglaFlagIcon = (
    <div className="w-8 h-8 rounded-lg border border-slate-700 bg-[#006A4E] relative flex items-center justify-center shrink-0 shadow-sm overflow-hidden">
      <div className="w-3.5 h-3.5 rounded-full bg-[#F42A41] -translate-x-0.5" />
    </div>
  );

  const EnglishFlagIcon = (
    <div className="w-8 h-8 rounded-lg border border-slate-700 bg-[#012169] relative flex items-center justify-center shrink-0 shadow-sm overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-full h-1 bg-white flex items-center justify-center">
          <div className="w-full h-0.5 bg-[#C8102E]" />
        </div>
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="h-full w-1 bg-white flex items-center justify-center">
          <div className="h-full w-0.5 bg-[#C8102E]" />
        </div>
      </div>
    </div>
  );

  const movieItem = item as Movie;
  const isVideo = type === 'video' || (item as any).contentType === 'video';

  // Multi-Language Dubbing Options Configuration
  const dubOptions: DubOption[] = useMemo(() => {
    const opts: DubOption[] = [];

    if (isVideo) {
      opts.push({
        id: 'video_direct',
        titleBn: 'সরাসরি ভিডিও ডাউনলোড',
        titleEn: 'Direct Video Download',
        titleHi: 'सीधा वीडियो डाउनलोड',
        flagNode: OriginalFilmIcon,
        badgeText: 'DIRECT FAST LINK',
        fileSize: '720p / 1080p Full HD',
        targetUrl: item.videoUrl || ''
      });
    } else {
      const originalUrl = movieItem.originalLanguageUrl || movieItem.originalLink || movieItem.videoUrl || '';
      const hindiUrl = movieItem.hindiDubbedUrl || movieItem.hindiLink || originalUrl;
      const banglaUrl = movieItem.banglaDubbedUrl || movieItem.banglaLink || originalUrl;
      const englishUrl = movieItem.englishDubbedUrl || movieItem.englishLink || originalUrl;

      // 1. Original
      opts.push({
        id: 'original',
        titleBn: 'অরিজিনাল',
        titleEn: 'Original',
        titleHi: 'मूल (Original)',
        flagNode: OriginalFilmIcon,
        badgeText: 'ORIGINAL PRINT',
        fileSize: '1080p HD (1.4 GB)',
        targetUrl: originalUrl
      });

      // 2. Hindi Dub
      opts.push({
        id: 'hindi',
        titleBn: 'হিন্দি ডাব',
        titleEn: 'Hindi Dub',
        titleHi: 'हिंदी डब',
        flagNode: HindiFlagIcon,
        badgeText: 'HINDI DUBBED',
        fileSize: '1080p FHD (1.5 GB)',
        targetUrl: hindiUrl
      });

      // 3. Bangla Dubbing
      opts.push({
        id: 'bangla',
        titleBn: 'বাংলা ডাবিং',
        titleEn: 'Bangla Dubbing',
        titleHi: 'बांग्ला डबिंग',
        flagNode: BanglaFlagIcon,
        badgeText: 'BANGLA DUBBED',
        fileSize: '1080p FHD (1.4 GB)',
        targetUrl: banglaUrl
      });

      // 4. English Dub
      opts.push({
        id: 'english',
        titleBn: 'ইংলিশ ডাব',
        titleEn: 'English Dub',
        titleHi: 'इंग्लिश डब',
        flagNode: EnglishFlagIcon,
        badgeText: 'ENGLISH DUBBED',
        fileSize: '1080p FHD (1.6 GB)',
        targetUrl: englishUrl
      });
    }
    return opts;
  }, [isVideo, item.videoUrl, movieItem.originalLanguageUrl, movieItem.originalLink, movieItem.hindiDubbedUrl, movieItem.hindiLink, movieItem.banglaDubbedUrl, movieItem.banglaLink, movieItem.englishDubbedUrl, movieItem.englishLink]);

  // Handle Download / Redirection (Phase 1 Ad Trigger)
  const handleSelectTrack = async (option: DubOption) => {
    setSelectedTrackId(option.id);

    const title = activeLang === 'English' ? optTitleEn(option) : (activeLang === 'हिंदी' ? option.titleHi : option.titleBn);
    const destination = option.targetUrl || item.videoUrl || (item as any).originalLink || `https://t.me/myteleflix`;

    setSelectedAdOption({
      id: option.id,
      title: title || option.id,
      targetUrl: destination,
    });
    setAdModalOpen(true);
  };

  const optTitleEn = (option: DubOption) => {
    if (option.id === 'original') return 'Original Audio';
    if (option.id === 'hindi') return 'Hindi Dubbed';
    if (option.id === 'bangla') return 'Bengali Dubbed';
    if (option.id === 'english') return 'English Dubbed';
    return option.titleEn || option.titleBn;
  };

  const handleOpenTelegramGuide = () => {
    const url = dynamicGuideUrl || "https://t.me/MrMovieBox_bot?start=guide";
    const tg = (window as any).Telegram?.WebApp;
    if (tg && typeof tg.openLink === 'function') {
      tg.openLink(url);
    } else {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <div 
      id="download-modal" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200 font-sans"
    >
      {/* Main Modal Container with deep organic dark styling matching Screenshot */}
      <div className="bg-[#0C1019] border border-slate-800 text-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom-6 sm:zoom-in-95 duration-300 flex flex-col max-h-[94vh] sm:max-h-[90vh]">
        
        {/* Header Bar matching Screenshot */}
        <div className="px-4 sm:px-5 py-3.5 border-b border-slate-800/90 bg-[#070A12] flex items-center justify-between shrink-0 relative">
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white bg-slate-800/90 hover:bg-slate-700 border border-slate-700/80 px-3.5 py-1.5 rounded-xl cursor-pointer transition active:scale-95 shrink-0 shadow-sm z-10"
          >
            <ArrowLeft size={14} />
            <span>{localizedTexts.back}</span>
          </button>

          <div className="text-center truncate px-2 flex-1 min-w-0 pr-12 sm:pr-14 space-y-1">
            <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider truncate font-mono">
              {item.title}
            </h3>
            {/* Section Badge with Distinct Section Color */}
            <span className={`text-[10px] sm:text-[11px] font-mono tracking-widest font-black uppercase px-3 py-0.5 rounded-full border inline-block ${sectionTheme.badgeClass}`}>
              {sectionTheme.badgeText}
            </span>
          </div>
        </div>

        {/* Scrollable Content Body with Clean Margins */}
        <div className="p-3 sm:p-5 overflow-y-auto space-y-4 no-scrollbar pb-12 sm:pb-16 bg-[#0A0E1A]">

          {/* Guest Mode Earning Prompt Banner */}
          {(!auth.currentUser || auth.currentUser.isAnonymous) && (
            <div className="mx-1 sm:mx-2 p-3 rounded-2xl bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 border border-amber-500/40 flex items-center justify-between gap-2 shadow-lg">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-base shrink-0">🌟</span>
                <p className="text-[11px] text-amber-200 font-medium leading-tight">
                  Want to EARN from this download? Sign up now to unlock your VIP Wallet!
                </p>
              </div>
              <a
                href="/?action=signup"
                className="px-2.5 py-1 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] tracking-wide shrink-0 transition"
              >
                Sign Up
              </a>
            </div>
          )}

          {/* 1. CINEMA TUTORIAL GUIDE VIDEO PLAYER (RESTORED SLEEK DARK CINEMATIC DESIGN) */}
          <div 
            onClick={handleOpenTelegramGuide}
            className="mx-1 sm:mx-2 rounded-2xl border-2 border-red-500/80 bg-[#070A12] p-2.5 sm:p-4 relative overflow-hidden group cursor-pointer transition-all duration-150 ease-out active:scale-[0.98] hover:border-red-400 shadow-2xl"
          >
            {/* Top Prompt Text */}
            <p className="text-slate-100 text-[11px] sm:text-xs font-bold text-center leading-snug px-1 mb-2.5 drop-shadow-sm">
              {localizedTexts.tutorialPrompt}
            </p>

            {/* Deep Dark Cinematic 16:9 Cinema Tutorial Video Screen Backdrop with Poster & Expanding Animations */}
            <div className="rounded-2xl overflow-hidden border border-red-500/40 shadow-2xl relative aspect-[16/9] w-full bg-[#070A12] flex items-center justify-center group/poster">
              {/* Actual Cinematic Backdrop Poster Image with Ambient Hover Zoom */}
              <img 
                src={
                  (item as any).poster || 
                  (item as any).thumbnailUrl || 
                  (item as any).posterUrl || 
                  _guideVideoLogoUrl || 
                  "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&h=675&q=85"
                }
                alt="Tutorial Guide Video Poster"
                className="absolute inset-0 w-full h-full object-cover opacity-55 group-hover/poster:scale-105 transition-transform duration-500 ease-out"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=1200&h=675&q=85";
                }}
              />
              
              {/* Dark Cinema Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#070A12] via-black/60 to-black/40" />

              {/* Minimal Clean Top-Left Live Tutorial Video Text */}
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10 pointer-events-none bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-red-500/40 shadow-md">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
                </span>
                <span className="text-[9px] sm:text-[10px] uppercase tracking-wider font-bold text-slate-200 leading-none">
                  TUTORIAL VIDEO
                </span>
              </div>

              {/* Centered High-Contrast Red Play Icon with Expanding Radar Pulse Rings */}
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center pointer-events-none p-2">
                <div className="relative flex items-center justify-center mb-2 sm:mb-2.5">
                  {/* Expanding Radar Wave Pulse Rings */}
                  <span className="absolute w-14 h-14 sm:w-18 sm:h-18 rounded-full bg-red-600/30 animate-ping pointer-events-none" />
                  <span className="absolute w-18 h-18 sm:w-22 sm:h-22 rounded-full bg-red-500/20 animate-pulse pointer-events-none" />

                  {/* Embedded Glowing Red Play Button */}
                  <div className="relative w-12 h-12 sm:w-15 sm:h-15 rounded-full bg-[#E51E2B] text-white flex items-center justify-center shadow-[0_0_30px_rgba(229,30,43,0.8)] group-hover/poster:scale-110 transition-transform duration-200 border-2 border-white ring-4 ring-[#E51E2B]/40">
                    <Play size={22} className="fill-white translate-x-0.5" />
                  </div>
                </div>
                
                {/* Central Action Prompt Bar with Converging Directional Arrow Animations */}
                <div className="flex items-center gap-2 bg-[#0C121E]/90 backdrop-blur-md text-slate-100 font-bold text-[11px] sm:text-xs px-4 py-1.5 rounded-full border border-red-500/40 shadow-xl group-hover/poster:border-red-400 transition-colors">
                  <ArrowRight size={13} className="text-red-400 animate-pulse shrink-0" />
                  <span className="tracking-wide whitespace-nowrap text-white font-semibold">
                    {localizedTexts.watchGuide}
                  </span>
                  <ArrowLeft size={13} className="text-red-400 animate-pulse shrink-0" />
                </div>
              </div>

            </div>
          </div>

          {/* Voice Audio Options - Sleek Organic Bar */}
          {dynamicAudioUrl && (
            <div className="mx-1 sm:mx-2 rounded-2xl py-2.5 px-3.5 bg-[#070A12] border border-[#1A2333] flex items-center justify-between gap-2 shadow-md">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-7 h-7 rounded-lg bg-slate-800 text-white border border-slate-700 flex items-center justify-center shrink-0">
                  <Mic size={14} className={isPlayingAudio ? "text-red-500" : "text-slate-400"} />
                </div>
                <span className="text-xs font-bold text-white truncate">
                  {localizedTexts.voiceGuide}
                </span>
                {isPlayingAudio && (
                  <span className="w-2 h-2 rounded-full bg-red-500 shrink-0 animate-ping" />
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={toggleAudioPlayback}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-xl border border-slate-700 text-[10px] font-mono font-bold transition flex items-center gap-1 cursor-pointer whitespace-nowrap active:scale-95 shadow-sm"
                >
                  {isPlayingAudio ? <Pause size={11} /> : <Play size={11} />}
                  <span>{isPlayingAudio ? "PAUSE" : "PLAY"}</span>
                </button>
                <button
                  type="button"
                  onClick={toggleMute}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 hover:text-white transition cursor-pointer shrink-0 active:scale-95"
                  title={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <VolumeX size={13} /> : <Volume2 size={13} />}
                </button>
              </div>
            </div>
          )}

          {/* 2. AVAILABLE LANGUAGE DUBS LIST WITH SECTION-COLORED DOWNLOAD BUTTONS */}
          <div className="space-y-3 pt-1 w-full mx-auto relative">
            
            {/* Header: Shield Check + Title */}
            <div className="flex items-center gap-2 px-2 mb-1">
              <ShieldCheck size={16} className={sectionTheme.shieldColor} />
              <span className={`text-xs sm:text-[13px] font-bold tracking-wide ${sectionTheme.headerTextColor}`}>
                {localizedTexts.availableDubs}
              </span>
            </div>

            {/* List of Dub Cards */}
            {dubOptions.map((opt) => {
              const isSelected = selectedTrackId === opt.id && isRedirecting;
              const title = activeLang === 'English' ? opt.titleEn : (activeLang === 'हिंदी' ? opt.titleHi : opt.titleBn);

              return (
                <div
                  key={opt.id}
                  onClick={() => !isRedirecting && handleSelectTrack(opt)}
                  className="mx-1 sm:mx-2 rounded-xl border border-slate-800/80 hover:border-slate-700 bg-[#0B101D] py-2.5 px-3.5 sm:px-4 transition-all duration-150 ease-out flex items-center justify-between gap-3 group cursor-pointer active:scale-[0.98] shadow-md"
                >
                  {/* Left Flag Emblem Icon */}
                  <div className="shrink-0 flex items-center justify-center">
                    {opt.flagNode}
                  </div>

                  {/* Middle Info Column */}
                  <div className="flex-1 min-w-0 space-y-0.5">
                    <h4 className="text-xs sm:text-sm font-bold text-white group-hover:text-slate-100 transition truncate">
                      {title}
                    </h4>
                  </div>

                  {/* Right Download CTA Button with Section Color */}
                  <div className="shrink-0">
                    <button
                      type="button"
                      disabled={isRedirecting}
                      className={`py-2 px-3.5 sm:px-4 rounded-lg font-black text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md active:scale-95 transition-all select-none cursor-pointer ${sectionTheme.buttonClass}`}
                    >
                      {isSelected ? (
                        <>
                          <Loader2 size={13} className="animate-spin" />
                          <span className="text-[10px]">{localizedTexts.preparing}</span>
                        </>
                      ) : (
                        <>
                          <Download size={13} strokeWidth={2.5} />
                          <span>{localizedTexts.download}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Feedback / Status Alert */}
          {redirectStatus && (
            <div className="mx-1 sm:mx-2 rounded-xl p-3 bg-slate-900/90 border border-slate-800 text-center space-y-1 animate-in fade-in">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-200 font-mono">
                <Loader2 size={13} className="animate-spin text-red-500" />
                <span>{redirectStatus}</span>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="mx-1 sm:mx-2 rounded-xl p-3 bg-red-950/50 border border-red-800/80 text-center text-xs text-red-300 font-mono">
              {errorMsg}
            </div>
          )}

        </div>
      </div>

      {/* Phase 1: High-CPM Custom Video Ad & 15-Second Timer Modal */}
      {adModalOpen && selectedAdOption && (
        <DownloadAdTimerModal
          isOpen={adModalOpen}
          item={item}
          selectedOption={selectedAdOption}
          onClose={() => setAdModalOpen(false)}
          onSuccess={() => {
            setAdModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
