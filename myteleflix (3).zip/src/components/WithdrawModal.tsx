/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, CheckCircle2, AlertCircle, ShieldCheck, Clock, Wallet, ArrowRight, ArrowLeft, ChevronLeft 
} from "lucide-react";
import { TokenIcon } from "./TokenIcon";
import { WithdrawalRequest } from "../types";
import { saveWithdrawalToFirestore } from "../services/firebase";

export type PaymentMethodType = 'bKash' | 'Nagad' | 'TRC-20';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  userPoints: number;
  minimumWithdrawal?: number;
  tokenRateBdt?: number;
  tokenRateUsd?: number;
  initialMethod?: PaymentMethodType;
  userEmail?: string;
  userId?: string;
  username?: string;
  isBanned?: boolean;
  banReason?: string;
  onWithdraw: (
    amount: number, 
    destination: string, 
    paymentMethod: string, 
    email?: string, 
    accountNumber?: string
  ) => Promise<{ success: boolean; error?: string }>;
}

export default function WithdrawModal({
  isOpen,
  onClose,
  userPoints,
  minimumWithdrawal = 1000,
  tokenRateBdt = 100,
  tokenRateUsd = 0.85,
  initialMethod = 'bKash',
  userEmail = "",
  userId = "",
  username = "User",
  isBanned = false,
  banReason = "",
  onWithdraw,
}: WithdrawModalProps) {
  // Method selection strictly: bKash, Nagad, TRC-20 (USDT)
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodType>(initialMethod);
  const [accountType, setAccountType] = useState<'Personal' | 'Agent'>('Personal');
  
  // Form values
  const [amountStr, setAmountStr] = useState<string>("");
  const [accountNumber, setAccountNumber] = useState<string>("");
  const [applicantEmail, setApplicantEmail] = useState<string>(userEmail);
  
  // UI states
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successData, setSuccessData] = useState<{
    amount: number;
    destination: string;
    method: string;
    fiatEst: string;
  } | null>(null);

  useEffect(() => {
    if (initialMethod) {
      setSelectedMethod(initialMethod);
    }
  }, [initialMethod, isOpen]);

  const amountNum = parseInt(amountStr, 10) || 0;
  const bdtPer1000 = tokenRateBdt || 100;
  const usdPer1000 = tokenRateUsd || 0.85;

  // Real-time conversion estimates based on Admin rates
  const conversionEstimate = useMemo(() => {
    if (!amountNum || amountNum <= 0) return { bdt: "0.00", usd: "0.00" };
    const bdt = ((amountNum / 1000) * bdtPer1000).toFixed(2);
    const usd = ((amountNum / 1000) * usdPer1000).toFixed(2);
    return { bdt, usd };
  }, [amountNum, bdtPer1000, usdPer1000]);

  // Validation logic
  const handleAmountChange = (val: string) => {
    setErrorMessage(null);
    setAmountStr(val);
  };

  const handleSetQuickAmount = (val: number) => {
    setErrorMessage(null);
    setAmountStr(val.toString());
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // 1. Enforce minimum point balance threshold check
    if (isNaN(amountNum) || amountNum <= 0) {
      setErrorMessage("Please enter a valid amount to cash out.");
      return;
    }

    if (amountNum < minimumWithdrawal) {
      setErrorMessage(`Minimum withdrawal threshold is ${minimumWithdrawal.toLocaleString()}.`);
      return;
    }

    if (amountNum > userPoints) {
      setErrorMessage(`Insufficient balance: You currently have ${userPoints.toLocaleString()}.`);
      return;
    }

    // 2. Validate destination input
    const cleanAccount = accountNumber.trim();
    if (!cleanAccount) {
      if (selectedMethod === 'TRC-20') {
        setErrorMessage("Please provide your TRC-20 (USDT) receiving address (e.g. starts with T).");
      } else {
        setErrorMessage(`Please provide your 11-digit ${selectedMethod} phone number.`);
      }
      return;
    }

    if (selectedMethod === 'bKash' || selectedMethod === 'Nagad') {
      const phoneRegex = /^(\+8801|01)[3-9]\d{8}$/;
      if (!phoneRegex.test(cleanAccount.replace(/\s+/g, ''))) {
        setErrorMessage("Please enter a valid 11-digit Bangladeshi mobile number (e.g. 017XXXXXXXX).");
        return;
      }
    } else {
      if (cleanAccount.length < 25 || !cleanAccount.startsWith('T')) {
        setErrorMessage("Invalid Tron TRC-20 address. TRC-20 USDT addresses start with 'T' and are ~34 characters long.");
        return;
      }
    }

    const resolvedMethod = selectedMethod === 'TRC-20'
      ? "TRC-20 (USDT)"
      : `${selectedMethod} (${accountType})`;

    setIsSubmitting(true);
    try {
      const withdrawalId = `wth-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

      // Direct submission to Firestore /withdrawals collection with 'Pending' status
      const firestoreRecord: WithdrawalRequest = {
        id: withdrawalId,
        userId: userId || "anonymous",
        username: username || "User",
        email: applicantEmail || userEmail,
        userEmail: applicantEmail || userEmail,
        amount: amountNum,
        paymentMethod: resolvedMethod,
        walletAddress: cleanAccount,
        accountNumber: cleanAccount,
        status: 'pending',
        timestamp: new Date().toISOString()
      };

      await saveWithdrawalToFirestore(firestoreRecord);

      // Instantly call withdrawal handler which deducts points immediately
      const result = await onWithdraw(
        amountNum,
        cleanAccount,
        resolvedMethod,
        applicantEmail || userEmail,
        cleanAccount
      );

      if (result && !result.success) {
        setErrorMessage(result.error || "Cashout request failed. Please try again.");
        setIsSubmitting(false);
        return;
      }

      // Success screen
      setSuccessData({
        amount: amountNum,
        destination: cleanAccount,
        method: resolvedMethod,
        fiatEst: (selectedMethod === 'bKash' || selectedMethod === 'Nagad')
          ? `৳ ${conversionEstimate.bdt} BDT`
          : `$ ${conversionEstimate.usd} USDT`
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to submit cashout request.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetAndClose = () => {
    setSuccessData(null);
    setAmountStr("");
    setAccountNumber("");
    setErrorMessage(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-md"
        onClick={handleResetAndClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.2 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-md max-h-[92vh] sm:max-h-[90vh] bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        >
          {/* Header with Back Button and Close */}
          <div className="px-4 py-3 sm:p-4 border-b border-slate-800/90 flex items-center justify-between shrink-0 bg-slate-900/95">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="p-1.5 -ml-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition flex items-center gap-1 text-xs font-mono font-medium cursor-pointer"
                title="Back / Close"
              >
                <ArrowLeft size={16} />
                <span className="text-[11px] hidden sm:inline">Back</span>
              </button>

              <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <TokenIcon size={16} />
              </div>
              <div className="leading-tight">
                <h3 className="text-xs sm:text-sm font-black text-white font-mono uppercase tracking-wide">
                  Cashout Payment Hub
                </h3>
                <p className="text-[10px] text-slate-400 font-sans truncate flex items-center gap-1">
                  <TokenIcon size={11} /> 1,000 = ৳{bdtPer1000} BDT / ${usdPer1000} USD
                </p>
              </div>
            </div>

            <button
              onClick={handleResetAndClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800/80 rounded-xl transition cursor-pointer"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body Content - Scrollable on mobile so nothing is cut off */}
          <div className="overflow-y-auto flex-1 overscroll-contain">
          {successData ? (
            /* SUCCESS CONFIRMATION RECEIPT */
            <div className="p-4 sm:p-6 text-center space-y-3.5 animate-in fade-in zoom-in duration-200">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shadow-lg shadow-emerald-500/10">
                <CheckCircle2 size={28} />
              </div>

              <div className="space-y-0.5">
                <h4 className="text-sm sm:text-base font-black text-white font-mono uppercase tracking-wide">
                  Withdrawal Filed Securely!
                </h4>
                <p className="text-xs text-slate-400 font-sans">
                  Your payout has been placed in the pending approval queue.
                </p>
              </div>

              {/* Receipt Summary Card */}
              <div className="bg-slate-950/90 border border-slate-800/90 rounded-2xl p-3.5 text-left font-mono space-y-2">
                <div className="flex justify-between items-center text-xs pb-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">Status</span>
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold text-[9.5px] uppercase flex items-center gap-1">
                    <Clock size={10} className="animate-spin" />
                    <span>Pending Approval</span>
                  </span>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Deducted Amount</span>
                  <span className="text-white font-extrabold flex items-center gap-1">
                    <TokenIcon size={12} />
                    {successData.amount.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Estimated Value</span>
                  <span className="text-emerald-400 font-bold">{successData.fiatEst}</span>
                </div>

                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">Payment Gateway</span>
                  <span className="text-slate-200 font-bold">{successData.method}</span>
                </div>

                <div className="flex justify-between items-center text-xs pt-1.5 border-t border-slate-800/60">
                  <span className="text-slate-400">Recipient Account</span>
                  <span className="text-white font-bold truncate max-w-[160px] select-all">
                    {successData.destination}
                  </span>
                </div>
              </div>

              <p className="text-[10px] text-slate-400 font-sans">
                Balance has been deducted immediately. If admin rejects the payout, your balance will be instantly refunded to your wallet ledger.
              </p>

              <button
                onClick={handleResetAndClose}
                className="w-full py-2.5 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition hover:brightness-110 active:scale-98 cursor-pointer font-mono shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5"
              >
                <ArrowLeft size={14} />
                <span>Return to Profile</span>
              </button>
            </div>
          ) : (
            /* CASHOUT FORM */
            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-3.5">
              {/* Balance & Threshold Banner */}
              <div className="bg-slate-950/70 border border-slate-800/90 rounded-2xl p-2.5 sm:p-3 flex items-center justify-between gap-3">
                <div>
                  <span className="text-[9.5px] text-slate-400 uppercase font-mono tracking-wider block font-semibold">
                    Current Balance
                  </span>
                  <div className="flex items-center gap-1 mt-0.5">
                    <TokenIcon size={16} />
                    <span className="text-base sm:text-lg font-black text-emerald-400 font-mono">
                      {userPoints.toLocaleString()}
                    </span>
                    <span className="text-[9.5px] text-amber-400 font-mono font-bold">Token</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[9.5px] text-slate-400 uppercase font-mono tracking-wider block font-semibold">
                    Min Threshold
                  </span>
                  <span className="text-xs font-bold text-amber-400 font-mono flex items-center justify-end gap-1">
                    <TokenIcon size={12} />
                    {minimumWithdrawal.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Account Restriction Notice */}
              {isBanned && (
                <div className="bg-rose-500/10 border border-rose-500/25 text-rose-300 text-xs p-3 rounded-2xl flex items-start gap-2 animate-in fade-in duration-150">
                  <AlertCircle size={15} className="text-rose-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="font-bold text-rose-200">Cashouts Paused</p>
                    <p className="text-[10.5px] text-rose-300/80 font-sans leading-relaxed">
                      {banReason || "Your account has been restricted from cashout requests due to policy enforcement. Please reach out to support."}
                    </p>
                  </div>
                </div>
              )}

              {/* Error Callout */}
              {errorMessage && (
                <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-2.5 rounded-xl flex items-center gap-2 animate-in fade-in duration-150">
                  <AlertCircle size={15} className="text-rose-400 shrink-0" />
                  <span className="font-medium font-sans text-[11px]">{errorMessage}</span>
                </div>
              )}

              {/* 1. Payment Method Selection (Strictly 3 Methods) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] text-slate-300 uppercase font-mono tracking-wider font-bold block">
                    1. Select Payout Gateway
                  </label>
                  <span className="text-[9.5px] text-slate-400 font-mono">
                    Zero gateway processing fee
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {/* bKash */}
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMethod('bKash');
                      setErrorMessage(null);
                    }}
                    className={`p-2.5 sm:p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all duration-200 cursor-pointer font-mono relative overflow-hidden ${
                      selectedMethod === 'bKash'
                        ? "bg-gradient-to-b from-pink-500/20 to-pink-950/30 border-pink-500 text-pink-300 shadow-lg shadow-pink-500/20 ring-1 ring-pink-500"
                        : "bg-[#111624] border-[#1E2538] text-slate-400 hover:text-white hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-black tracking-tight">bKash</span>
                      <span className="text-[8px] px-1 py-0.2 rounded bg-pink-500/25 text-pink-300 font-mono font-bold">BDT</span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-sans">
                      Mobile Wallet
                    </span>
                    {selectedMethod === 'bKash' && (
                      <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-pink-400" />
                    )}
                  </button>

                  {/* Nagad */}
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMethod('Nagad');
                      setErrorMessage(null);
                    }}
                    className={`p-2.5 sm:p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all duration-200 cursor-pointer font-mono relative overflow-hidden ${
                      selectedMethod === 'Nagad'
                        ? "bg-gradient-to-b from-orange-500/20 to-orange-950/30 border-orange-500 text-orange-300 shadow-lg shadow-orange-500/20 ring-1 ring-orange-500"
                        : "bg-[#111624] border-[#1E2538] text-slate-400 hover:text-white hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-black tracking-tight">Nagad</span>
                      <span className="text-[8px] px-1 py-0.2 rounded bg-orange-500/25 text-orange-300 font-mono font-bold">BDT</span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-sans">
                      Postal Cash
                    </span>
                    {selectedMethod === 'Nagad' && (
                      <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-orange-400" />
                    )}
                  </button>

                  {/* TRC-20 (USDT) */}
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMethod('TRC-20');
                      setErrorMessage(null);
                    }}
                    className={`p-2.5 sm:p-3 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all duration-200 cursor-pointer font-mono relative overflow-hidden ${
                      selectedMethod === 'TRC-20'
                        ? "bg-gradient-to-b from-teal-500/20 to-teal-950/30 border-teal-500 text-teal-300 shadow-lg shadow-teal-500/20 ring-1 ring-teal-500"
                        : "bg-[#111624] border-[#1E2538] text-slate-400 hover:text-white hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      <span className="text-xs font-black tracking-tight">TRC-20</span>
                      <span className="text-[8px] px-1 py-0.2 rounded bg-teal-500/25 text-teal-300 font-mono font-bold">USDT</span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-sans">
                      Tron Network
                    </span>
                    {selectedMethod === 'TRC-20' && (
                      <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-teal-400" />
                    )}
                  </button>
                </div>
              </div>

              {/* Dynamic Gateway Information Badge */}
              <div className={`p-2 rounded-xl border text-xs font-mono flex items-center justify-between gap-2 ${
                selectedMethod === 'bKash' 
                  ? 'bg-pink-500/10 border-pink-500/25 text-pink-300'
                  : selectedMethod === 'Nagad'
                  ? 'bg-orange-500/10 border-orange-500/25 text-orange-300'
                  : 'bg-teal-500/10 border-teal-500/25 text-teal-300'
              }`}>
                <div className="flex items-center gap-1.5">
                  <span className="font-bold uppercase tracking-wider text-[10.5px]">
                    {selectedMethod === 'bKash' ? 'bKash Payout' : selectedMethod === 'Nagad' ? 'Nagad Payout' : 'TRC-20 (USDT) Payout'}
                  </span>
                </div>
                <span className="text-[9.5px] text-slate-400">
                  {selectedMethod === 'TRC-20' ? 'Min $1.00 USDT' : 'Standard 24h Queue'}
                </span>
              </div>

              {/* 2. Amount to Cash Out */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] text-slate-300 uppercase font-mono tracking-wider font-bold">
                    2. Amount to Cash Out
                  </label>
                  <span className="text-[10.5px] text-emerald-400 font-mono font-bold">
                    {selectedMethod === 'TRC-20'
                      ? `≈ $ ${conversionEstimate.usd} USDT`
                      : `≈ ৳ ${conversionEstimate.bdt} BDT`}
                  </span>
                </div>

                <div className="relative">
                  <input
                    type="number"
                    value={amountStr}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    placeholder={`Min. ${minimumWithdrawal.toLocaleString()}`}
                    className="w-full bg-[#0B0E17] border border-[#1E2538] focus:border-emerald-500/80 rounded-xl sm:rounded-2xl pl-3.5 pr-10 py-2.5 text-xs text-white placeholder-slate-500 font-mono outline-none transition shadow-inner"
                    min={minimumWithdrawal}
                    required
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-400 flex items-center select-none">
                    <TokenIcon size={15} />
                  </div>
                </div>

                {/* Quick Preset Buttons */}
                <div className="grid grid-cols-4 gap-1.5 pt-0.5">
                  <button
                    type="button"
                    onClick={() => handleSetQuickAmount(minimumWithdrawal)}
                    className="py-1 px-1 rounded-lg bg-[#111624] border border-[#1E2538] hover:border-slate-600 text-[9.5px] font-mono text-slate-300 hover:text-white transition active:scale-95 cursor-pointer text-center"
                  >
                    Min ({minimumWithdrawal})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickAmount(2500)}
                    className="py-1 px-1 rounded-lg bg-[#111624] border border-[#1E2538] hover:border-slate-600 text-[9.5px] font-mono text-slate-300 hover:text-white transition active:scale-95 cursor-pointer text-center"
                  >
                    2,500
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickAmount(5000)}
                    className="py-1 px-1 rounded-lg bg-[#111624] border border-[#1E2538] hover:border-slate-600 text-[9.5px] font-mono text-slate-300 hover:text-white transition active:scale-95 cursor-pointer text-center"
                  >
                    5,000
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetQuickAmount(userPoints)}
                    disabled={userPoints < minimumWithdrawal}
                    className="py-1 px-1 rounded-lg bg-[#111624] border border-[#1E2538] hover:border-emerald-500/40 text-[9.5px] font-mono text-emerald-400 hover:text-emerald-300 disabled:opacity-40 transition active:scale-95 cursor-pointer text-center font-bold truncate"
                  >
                    Max ({userPoints.toLocaleString()})
                  </button>
                </div>
              </div>

              {/* 3. Recipient Account Number / Wallet Address */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] text-slate-300 uppercase font-mono tracking-wider font-bold">
                    {selectedMethod === 'bKash' ? "3. bKash Mobile Number" :
                     selectedMethod === 'Nagad' ? "3. Nagad Mobile Number" :
                     "3. TRC-20 (USDT) Wallet Address"}
                  </label>
                  {(selectedMethod === 'bKash' || selectedMethod === 'Nagad') && (
                    <div className="flex items-center gap-1 text-[9.5px] font-mono bg-[#0B0E17] p-0.5 rounded-lg border border-[#1E2538]">
                      <button
                        type="button"
                        onClick={() => setAccountType('Personal')}
                        className={`px-1.5 py-0.5 rounded-md transition ${accountType === 'Personal' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                      >
                        Personal
                      </button>
                      <button
                        type="button"
                        onClick={() => setAccountType('Agent')}
                        className={`px-1.5 py-0.5 rounded-md transition ${accountType === 'Agent' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                      >
                        Agent
                      </button>
                    </div>
                  )}
                </div>

                <input
                  type="text"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder={
                    selectedMethod === 'bKash' || selectedMethod === 'Nagad'
                      ? "e.g. 01700000000 (11 digits)"
                      : "e.g. TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
                  }
                  className="w-full bg-[#0B0E17] border border-[#1E2538] focus:border-emerald-500/80 rounded-xl sm:rounded-2xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 font-mono outline-none transition shadow-inner"
                  required
                />
                <p className="text-[9.5px] text-slate-400 font-mono">
                  {selectedMethod === 'TRC-20' 
                    ? "Network: TRON (TRC-20) only. Ensure address is accurate."
                    : `Active ${selectedMethod} ${accountType} account for instant credit.`}
                </p>
              </div>

              {/* 4. Applicant Contact Email */}
              <div className="space-y-1">
                <label className="text-[10px] text-slate-300 uppercase font-mono tracking-wider font-bold block">
                  4. Confirmation Email (For Receipts)
                </label>
                <input
                  type="email"
                  value={applicantEmail}
                  onChange={(e) => setApplicantEmail(e.target.value)}
                  placeholder="e.g. yourname@gmail.com"
                  className="w-full bg-[#0B0E17] border border-[#1E2538] focus:border-emerald-500/80 rounded-xl sm:rounded-2xl px-3.5 py-2 text-xs text-white placeholder-slate-500 font-mono outline-none transition shadow-inner"
                />
              </div>

              {/* Action Buttons: Request Cashout + Cancel/Back Button */}
              <div className="space-y-2 pt-1">
                <button
                  type="submit"
                  disabled={isSubmitting || isBanned || userPoints < minimumWithdrawal}
                  className="w-full py-3 px-4 bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-600 hover:from-amber-500 hover:to-amber-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold rounded-xl sm:rounded-2xl text-xs uppercase tracking-wide transition-all duration-200 active:scale-[0.98] shadow-lg shadow-amber-950/40 border border-amber-400/30 flex items-center justify-center gap-2 font-mono cursor-pointer"
                >
                  {isSubmitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>Deducting & Submitting to Firestore...</span>
                    </span>
                  ) : isBanned ? (
                    <span className="flex items-center gap-2 text-slate-900 font-bold">
                      <AlertCircle size={15} />
                      <span>Cashout Restricted</span>
                    </span>
                  ) : (
                    <>
                      <CheckCircle2 size={15} />
                      <span>REQUEST CASHOUT</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="w-full py-2 px-3 rounded-xl bg-slate-950/60 hover:bg-slate-800 border border-slate-800/80 text-slate-400 hover:text-slate-200 font-mono text-[11px] font-medium flex items-center justify-center gap-1.5 transition active:scale-98 cursor-pointer"
                >
                  <ArrowLeft size={13} />
                  <span>Cancel / Back to Wallet</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 font-sans text-center pb-1">
                <ShieldCheck size={12} className="text-emerald-400" />
                <span>Zero fees • Instant Firestore submission • Protected rewards</span>
              </div>
            </form>
          )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
