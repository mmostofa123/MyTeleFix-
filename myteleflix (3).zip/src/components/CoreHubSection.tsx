/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Backward compatibility wrapper: points directly to CoreHub.tsx
 */

import React from "react";
import { CoreHub, CoreHubProps } from "./CoreHub";

export type CoreHubSectionProps = CoreHubProps;

export const CoreHubSection: React.FC<CoreHubSectionProps> = (props) => {
  return <CoreHub {...props} />;
};

export default CoreHubSection;
