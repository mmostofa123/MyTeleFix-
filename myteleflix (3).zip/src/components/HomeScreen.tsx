/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, Film, MonitorPlay, ChevronRight, Play, Star, Download, ShieldAlert, Zap, Tv, Layers, Flame
} from "lucide-react";
import { User, Movie, Video, Mission, AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import LinkUnlockModal from "./LinkUnlockModal";
import MovieCard from "./MovieCard";
import PosterDownloadOverlay from "./PosterDownloadOverlay";
import MoviesScreen from "./MoviesScreen";
import SeriesScreen from "./SeriesScreen";
import DramaScreen from "./DramaScreen";
import { sortMediaNewestFirst } from "../utils/sorting";
import { prefetchImages } from "../utils/imageCache";

interface HomeScreenProps {
  user: User;
  onNavigate: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
  movies: Movie[];
  videos: Video[];
  missions: Mission[];
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  isAdultUnlocked?: boolean;
  resetTrigger?: number;
  activeCategory?: string;
  onCategoryChange?: (category: string) => void;
  onViewedMovie?: (id: string, isMovie: boolean) => Promise<void>;
  currentLanguage?: AppLanguage;
}

function HomeScreenComponent({ 
  user, 
  onNavigate: _onNavigate, 
  movies, 
  videos, 
  guideVideoUrl,
  guideVideoLogoUrl,
  isAdultUnlocked = false,
  resetTrigger,
  activeCategory = "All",
  onCategoryChange,
  onViewedMovie,
  currentLanguage: propLanguage,
}: HomeScreenProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleLangChange = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
  }, []);

  const [searchQuery, setSearchQuery] = useState("");
  const [categorySearchQuery, setCategorySearchQuery] = useState("");
  const [videoSubCategory, setVideoSubCategory] = useState<string>("All");
  const [activeFilterTab, setActiveFilterTab] = useState<string>(activeCategory || "All");
  const [searchResults, setSearchResults] = useState<{ movies: Movie[]; videos: Video[] }>({ movies: [], videos: [] });
  const [isSearching, setIsSearching] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [videoSlideIndex, setVideoSlideIndex] = useState(0);

  // Sync with parent activeCategory prop
  useEffect(() => {
    if (activeCategory && activeCategory !== activeFilterTab) {
      setActiveFilterTab(activeCategory);
      setCategorySearchQuery("");
      setVideoSubCategory("All");
    }
  }, [activeCategory]);

  // Selected item for TaskDownloadModal / LinkUnlockModal
  const [selectedTaskItem, setSelectedTaskItem] = useState<{ item: Movie | Video; type: 'movie' | 'video' } | null>(null);
  const [openingItemId, setOpeningItemId] = useState<string | null>(null);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Smooth click animation dispatch handler with visual feedback
  const handleOpenItem = (item: Movie | Video, type: 'movie' | 'video', e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setOpeningItemId(item.id);

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    clickTimerRef.current = setTimeout(() => {
      setSelectedTaskItem({ item, type });
      setOpeningItemId(null);
    }, 180);
  };

  useEffect(() => {
    return () => {
      if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    };
  }, []);

  // Live real-time Media Vault instant zero-delay search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults({ movies: [], videos: [] });
      setIsSearching(false);
      return;
    }
    const q = searchQuery.toLowerCase().trim();
    const localMovies = movies.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        (m.genre && m.genre.toLowerCase().includes(q)) ||
        (m.description && m.description.toLowerCase().includes(q)) ||
        (m.languages && m.languages.some((l) => l.toLowerCase().includes(q)))
    );
    const localVideos = videos.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        (v.genre && v.genre.toLowerCase().includes(q)) ||
        (v.description && v.description.toLowerCase().includes(q)) ||
        (v.category && v.category.toLowerCase().includes(q))
    );
    setSearchResults({ movies: localMovies, videos: localVideos });
    setIsSearching(false);
  }, [searchQuery, movies, videos]);

  // Combined search results
  const totalResultsCount = searchResults.movies.length + searchResults.videos.length;

  const isAdultMovieItem = (m: Movie) => {
    return (
      m.contentType === 'adult_movie' ||
      m.category === 'Adult Movies' ||
      Boolean(m.genre && (m.genre.toLowerCase().includes('adult') || m.genre.toLowerCase().includes('18+'))) ||
      Boolean(m.title && (m.title.toLowerCase().includes('adult') || m.title.toLowerCase().includes('18+')))
    );
  };

  const adultMovies = useMemo(() => {
    return sortMediaNewestFirst(movies.filter(isAdultMovieItem));
  }, [movies]);

  // Separate media by content types
  const seriesItems = useMemo(() => {
    return sortMediaNewestFirst(movies.filter(m => 
      !isAdultMovieItem(m) && (
        m.contentType === 'series' || 
        (!m.contentType && (
          m.genre?.toLowerCase().includes('series') || 
          m.genre?.toLowerCase().includes('season') ||
          m.title?.toLowerCase().includes('season') ||
          m.title?.toLowerCase().includes('series') ||
          m.title?.toLowerCase().includes('pack') ||
          Boolean(m.totalEpisodes)
        ))
      )
    ));
  }, [movies]);

  const dramaItems = useMemo(() => {
    return sortMediaNewestFirst(movies.filter(m => 
      !isAdultMovieItem(m) && (
        m.contentType === 'drama' || 
        (!m.contentType && (
          m.genre?.toLowerCase().includes('natok') || 
          m.genre?.toLowerCase().includes('drama') || 
          m.title?.toLowerCase().includes('natok')
        ))
      )
    ));
  }, [movies]);

  const cinemaMovies = useMemo(() => {
    return sortMediaNewestFirst(movies.filter(m => 
      !isAdultMovieItem(m) && (
        m.contentType === 'movie' || 
        (!m.contentType && 
          !seriesItems.some(s => s.id === m.id) && 
          !dramaItems.some(d => d.id === m.id))
      )
    ));
  }, [movies, seriesItems, dramaItems]);

  // 1. DYNAMIC INTERLEAVED TOP HERO SLIDER (2 Movies -> [2 Adult Movies if unlocked] -> 2 Series -> 2 Dramas rotation)
  const interleavedHeroPool = useMemo(() => {
    const pool: Movie[] = [];
    const maxRounds = Math.max(
      Math.ceil(cinemaMovies.length / 2),
      Math.ceil(adultMovies.length / 2),
      Math.ceil(seriesItems.length / 2),
      Math.ceil(dramaItems.length / 2),
      1
    );

    for (let r = 0; r < maxRounds; r++) {
      // 1. 2 Cinema Movies
      if (cinemaMovies.length > 0) {
        const m1 = cinemaMovies[(r * 2) % cinemaMovies.length];
        const m2 = cinemaMovies[(r * 2 + 1) % cinemaMovies.length];
        if (m1 && !pool.some(p => p.id === m1.id)) pool.push(m1);
        if (m2 && m2.id !== m1?.id && !pool.some(p => p.id === m2.id)) pool.push(m2);
      }

      // 2. 2 Adult Movies (if unlocked)
      if (isAdultUnlocked && adultMovies.length > 0) {
        const a1 = adultMovies[(r * 2) % adultMovies.length];
        const a2 = adultMovies[(r * 2 + 1) % adultMovies.length];
        if (a1 && !pool.some(p => p.id === a1.id)) pool.push(a1);
        if (a2 && a2.id !== a1?.id && !pool.some(p => p.id === a2.id)) pool.push(a2);
      }

      // 3. 2 Web Series
      if (seriesItems.length > 0) {
        const s1 = seriesItems[(r * 2) % seriesItems.length];
        const s2 = seriesItems[(r * 2 + 1) % seriesItems.length];
        if (s1 && !pool.some(p => p.id === s1.id)) pool.push(s1);
        if (s2 && s2.id !== s1?.id && !pool.some(p => p.id === s2.id)) pool.push(s2);
      }

      // 4. 2 Drama / Natok
      if (dramaItems.length > 0) {
        const d1 = dramaItems[(r * 2) % dramaItems.length];
        const d2 = dramaItems[(r * 2 + 1) % dramaItems.length];
        if (d1 && !pool.some(p => p.id === d1.id)) pool.push(d1);
        if (d2 && d2.id !== d1?.id && !pool.some(p => p.id === d2.id)) pool.push(d2);
      }
    }

    if (pool.length === 0) {
      return movies.slice(0, 6);
    }
    return pool;
  }, [cinemaMovies, adultMovies, seriesItems, dramaItems, isAdultUnlocked, movies]);

  // Universal MovieBox Posters Collection (All Posters: Movies, Series, Dramas, Natok, Adult Movies if unlocked - strictly excluding Videos)
  // Sorted strictly by Newest First as requested
  const movieBoxAllPosters = useMemo(() => {
    const seen = new Set<string>();
    const list = movies.filter((m) => {
      if (!m || !m.id || seen.has(m.id)) return false;
      seen.add(m.id);
      if (isAdultMovieItem(m) && !isAdultUnlocked) return false;
      return true;
    });
    return sortMediaNewestFirst(list);
  }, [movies, isAdultUnlocked]);

  // Interleave video content by country tags sequentially (Deshi -> Indian -> English -> Russian -> repeat)
  const interleavedVideos = useMemo(() => {
    if (!videos || videos.length === 0) return [];
    
    const groups: { [key: string]: Video[] } = {};
    videos.forEach(v => {
      const cat = (v.category || "General").trim();
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(v);
    });

    const categoryKeys = Object.keys(groups);
    if (categoryKeys.length <= 1) return videos;

    const priorityOrder = ["Deshi", "Indian", "English", "Russian", "Pakistani", "Viral"];
    categoryKeys.sort((a, b) => {
      const idxA = priorityOrder.findIndex(p => a.toLowerCase().includes(p.toLowerCase()));
      const idxB = priorityOrder.findIndex(p => b.toLowerCase().includes(p.toLowerCase()));
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.localeCompare(b);
    });

    const result: Video[] = [];
    const maxLen = Math.max(...categoryKeys.map(k => groups[k].length));

    for (let i = 0; i < maxLen; i++) {
      for (const cat of categoryKeys) {
        if (groups[cat][i]) {
          result.push(groups[cat][i]);
        }
      }
    }
    return result;
  }, [videos]);

  // Reset current slide if out of bounds
  useEffect(() => {
    if (currentSlide >= interleavedHeroPool.length) {
      setCurrentSlide(0);
    }
  }, [interleavedHeroPool.length, currentSlide]);

  // Filter viral videos based on unlock status: Completely hidden when 18+ is off
  const spotlightVideos = useMemo(() => {
    if (!isAdultUnlocked) return [];
    if (!interleavedVideos || interleavedVideos.length === 0) return [];
    return interleavedVideos;
  }, [isAdultUnlocked, interleavedVideos]);

  // Keep video slide index within bounds
  useEffect(() => {
    if (videoSlideIndex >= spotlightVideos.length && spotlightVideos.length > 0) {
      setVideoSlideIndex(0);
    }
  }, [spotlightVideos.length, videoSlideIndex]);

  // Preload upcoming slides' images so transitions are instant with zero load delay
  useEffect(() => {
    if (spotlightVideos.length > 1) {
      const nextIdx = (videoSlideIndex + 1) % spotlightVideos.length;
      const nextUrl = spotlightVideos[nextIdx]?.thumbnailUrl;
      if (nextUrl) {
        const img = new Image();
        img.src = nextUrl;
      }
    }
  }, [videoSlideIndex, spotlightVideos]);

  // SILENT BACKGROUND PRE-FETCHING & ZERO-LOADING OVERHAUL:
  // Preloads all movie categories, poster images, spotlight video thumbnails, and tab data immediately during app start
  useEffect(() => {
    const urls: string[] = [];
    interleavedHeroPool.forEach((item) => {
      if (item.thumbnailUrl) urls.push(item.thumbnailUrl);
    });
    cinemaMovies.forEach((m) => { if (m.thumbnailUrl) urls.push(m.thumbnailUrl); });
    adultMovies.forEach((m) => { if (m.thumbnailUrl) urls.push(m.thumbnailUrl); });
    seriesItems.forEach((s) => { if (s.thumbnailUrl) urls.push(s.thumbnailUrl); });
    dramaItems.forEach((d) => { if (d.thumbnailUrl) urls.push(d.thumbnailUrl); });
    spotlightVideos.forEach((v) => { if (v.thumbnailUrl) urls.push(v.thumbnailUrl); });
    movieBoxAllPosters.slice(0, 40).forEach((m) => { if (m.thumbnailUrl) urls.push(m.thumbnailUrl); });
    prefetchImages(urls);
  }, [interleavedHeroPool, cinemaMovies, adultMovies, seriesItems, dramaItems, spotlightVideos, movieBoxAllPosters]);

  // Reliable, smooth auto-advance: cycles content one after another without freezing on scroll
  useEffect(() => {
    if (spotlightVideos.length <= 1) return;
    const timer = setInterval(() => {
      setVideoSlideIndex((prev) => (prev + 1) % spotlightVideos.length);
    }, 4200);
    return () => clearInterval(timer);
  }, [spotlightVideos.length]);

  // Swipe gesture support for Video Spotlight (only activates on clear horizontal swipe)
  const [videoTouchStart, setVideoTouchStart] = useState<{ x: number; y: number } | null>(null);
  const handleVideoTouchStart = (e: React.TouchEvent) => {
    setVideoTouchStart({ x: e.touches[0].clientX, y: e.touches[0].clientY });
  };
  const handleVideoTouchEnd = (e: React.TouchEvent) => {
    if (!videoTouchStart) return;
    const touchEnd = e.changedTouches[0];
    const dx = touchEnd.clientX - videoTouchStart.x;
    const dy = touchEnd.clientY - videoTouchStart.y;
    if (Math.abs(dx) > 35 && Math.abs(dx) > Math.abs(dy) * 1.5) {
      if (dx < 0) {
        setVideoSlideIndex((prev) => (prev + 1) % spotlightVideos.length);
      } else {
        setVideoSlideIndex((prev) => (prev - 1 + spotlightVideos.length) % spotlightVideos.length);
      }
    }
    setVideoTouchStart(null);
  };

  const [isPausedHero, setIsPausedHero] = useState(false);
  const heroPauseTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (heroPauseTimerRef.current) clearTimeout(heroPauseTimerRef.current);
    };
  }, []);

  // Swipe gesture support for Hero Banner
  const [heroTouchStart, setHeroTouchStart] = useState<{ x: number; y: number } | null>(null);
  const handleHeroTouchStart = (e: React.TouchEvent) => {
    setIsPausedHero(true);
    setHeroTouchStart({ x: e.touches[0].clientX, y: e.touches[0].clientY });
  };
  const handleHeroTouchEnd = (e: React.TouchEvent) => {
    if (heroPauseTimerRef.current) clearTimeout(heroPauseTimerRef.current);
    heroPauseTimerRef.current = setTimeout(() => setIsPausedHero(false), 3500);
    if (!heroTouchStart) return;
    const touchEnd = e.changedTouches[0];
    const dx = touchEnd.clientX - heroTouchStart.x;
    const dy = touchEnd.clientY - heroTouchStart.y;
    if (Math.abs(dx) > 35 && Math.abs(dx) > Math.abs(dy) * 1.1) {
      if (dx < 0) {
        setCurrentSlide((prev) => (prev + 1) % interleavedHeroPool.length);
      } else {
        setCurrentSlide((prev) => (prev - 1 + interleavedHeroPool.length) % interleavedHeroPool.length);
      }
    }
    setHeroTouchStart(null);
  };

  // Auto-advance featured slider (Sleek 3.8s cadence • Paused on user hover/touch)
  useEffect(() => {
    if (interleavedHeroPool.length <= 1 || isPausedHero) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % interleavedHeroPool.length);
    }, 3800);
    return () => clearInterval(timer);
  }, [interleavedHeroPool.length, isPausedHero]);

  // 2. CATEGORY TAB LIST (All -> Movies -> Adult Movies [when unlocked] -> Drama / Natok -> Web Series -> Videos [when unlocked])
  // Visual pills stay complete: clicking 'Movies' or 'Videos' redirects directly to bottom nav tabs
  const filterTabs = useMemo(() => {
    const tabs = [
      { id: "All", label: t("All", activeLanguage, "All"), icon: null },
      { id: "Movies", label: t("Movies", activeLanguage, "Movies"), icon: Film },
    ];
    if (isAdultUnlocked) {
      tabs.push({ id: "AdultMovies", label: t("Adult Movies", activeLanguage, "Adult Movies"), icon: Flame });
    }
    tabs.push(
      { id: "Drama", label: t("Drama / Natok", activeLanguage, "Drama / Natok"), icon: Tv },
      { id: "Series", label: t("Web Series", activeLanguage, "Web Series"), icon: Layers }
    );
    if (isAdultUnlocked) {
      tabs.push({ id: "Videos", label: t("Videos", activeLanguage, "Videos"), icon: MonitorPlay });
    }
    return tabs;
  }, [isAdultUnlocked, activeLanguage]);

  // Reset tab if 18+ content locked
  useEffect(() => {
    if (!isAdultUnlocked && (activeFilterTab === "Videos" || activeFilterTab === "AdultMovies")) {
      setActiveFilterTab("All");
      setCategorySearchQuery("");
      setVideoSubCategory("All");
    }
  }, [isAdultUnlocked, activeFilterTab]);

  // Global Home Button Reset Hook: Instantly resets all state to default
  useEffect(() => {
    if (resetTrigger !== undefined && resetTrigger > 0) {
      setActiveFilterTab("All");
      setSearchQuery("");
      setCategorySearchQuery("");
      setVideoSubCategory("All");
      setSelectedTaskItem(null);
      setTimeout(() => {
        const tabBtn = document.getElementById("tab-button-All");
        if (tabBtn) {
          tabBtn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
        }
      }, 50);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [resetTrigger]);

  // Auto-scroll category bar whenever activeFilterTab changes
  useEffect(() => {
    const timer = setTimeout(() => {
      const tabBtn = document.getElementById(`tab-button-${activeFilterTab}`);
      if (tabBtn) {
        tabBtn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }
    }, 40);
    return () => clearTimeout(timer);
  }, [activeFilterTab]);

  // Video Country / Sub-category filter pills
  const videoCategoryFilters = useMemo(() => [
    { key: "All", label: t("All", activeLanguage, "All") },
    { key: "Deshi", label: t("Deshi", activeLanguage, "Deshi") },
    { key: "Indian", label: t("Indian", activeLanguage, "Indian") },
    { key: "Russian", label: t("Russian", activeLanguage, "Russian") },
    { key: "Pakistani", label: t("Pakistani", activeLanguage, "Pakistani") },
    { key: "English", label: t("English", activeLanguage, "English") },
  ], [activeLanguage]);

  // Smart Auto-Center scroll handler on tab click
  const handleTabClick = (tabId: string, event: React.MouseEvent<HTMLButtonElement>) => {
    setActiveFilterTab(tabId);
    onCategoryChange?.(tabId);
    setSearchQuery("");
    setCategorySearchQuery("");
    setVideoSubCategory("All");
    event.currentTarget.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  };

  // Programmatic tab selector that updates state and scrolls tab into center view
  const handleTabSelect = (tabId: string) => {
    setActiveFilterTab(tabId);
    onCategoryChange?.(tabId);
    setSearchQuery("");
    setCategorySearchQuery("");
    setVideoSubCategory("All");
    setTimeout(() => {
      const tabBtn = document.getElementById(`tab-button-${tabId}`);
      if (tabBtn) {
        tabBtn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }
    }, 50);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToAll = () => {
    handleTabSelect("All");
  };

  const filteredDedicatedAdultMovies = useMemo(() => {
    if (!categorySearchQuery.trim()) return adultMovies;
    const q = categorySearchQuery.toLowerCase().trim();
    return sortMediaNewestFirst(adultMovies.filter(m => {
      const matchTitle = m.title.toLowerCase().includes(q);
      const matchGenre = Boolean(m.genre && m.genre.toLowerCase().includes(q));
      const matchDesc = Boolean(m.description && m.description.toLowerCase().includes(q));
      return matchTitle || matchGenre || matchDesc;
    }));
  }, [adultMovies, categorySearchQuery]);

  const filteredDedicatedVideos = useMemo(() => {
    return sortMediaNewestFirst((videos || []).filter(v => {
      if (videoSubCategory !== "All") {
        const cat = (v.category || "").toLowerCase().trim();
        const target = videoSubCategory.toLowerCase().trim();
        const titleGenre = `${v.title || ''} ${v.genre || ''} ${v.description || ''}`.toLowerCase();
        const matchesDirect = cat === target;
        const matchesFallback = !cat && (
          (target === 'deshi' && (titleGenre.includes('deshi') || titleGenre.includes('bangla') || titleGenre.includes('bd'))) ||
          (target === 'indian' && (titleGenre.includes('indian') || titleGenre.includes('hindi') || titleGenre.includes('tamil') || titleGenre.includes('telugu'))) ||
          (target === 'russian' && titleGenre.includes('russian')) ||
          (target === 'pakistani' && (titleGenre.includes('pakistani') || titleGenre.includes('pakistan'))) ||
          (target === 'english' && (titleGenre.includes('english') || titleGenre.includes('hollywood')))
        );
        if (!matchesDirect && !matchesFallback) return false;
      }
      if (categorySearchQuery.trim()) {
        const q = categorySearchQuery.toLowerCase().trim();
        const matchTitle = v.title.toLowerCase().includes(q);
        const matchDesc = Boolean(v.description && v.description.toLowerCase().includes(q));
        const matchGenre = Boolean(v.genre && v.genre.toLowerCase().includes(q));
        const matchCat = Boolean(v.category && v.category.toLowerCase().includes(q));
        if (!matchTitle && !matchDesc && !matchGenre && !matchCat) return false;
      }
      return true;
    }));
  }, [videos, videoSubCategory, categorySearchQuery]);

  // Reusable Clean Organic Empty State for Categories (Solid flat dark theme, no glow)
  const renderEmptyState = (categoryName: string) => (
    <div className="bg-[#1A1A1E] border border-[#2A2A2E] rounded-xl p-6 text-center space-y-3.5 my-2">
      <div className="space-y-1">
        <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
          {t("no_content_found", activeLanguage, "No Content Found")}
        </h4>
        <p className="text-xs text-[#A0A0A0] font-normal max-w-xs mx-auto">
          {categorySearchQuery.trim()
            ? `No releases matching "${categorySearchQuery}" found in ${categoryName}.`
            : videoSubCategory !== "All" && categoryName.includes("Viral")
            ? `No releases available in "${videoSubCategory}" sub-category yet.`
            : "No releases available in this category yet."}
        </p>
      </div>
      <button
        type="button"
        onClick={() => {
          setCategorySearchQuery("");
          setVideoSubCategory("All");
          handleBackToAll();
        }}
        className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase px-6 py-2.5 rounded-lg font-mono tracking-wider transition duration-150 cursor-pointer active:scale-95 inline-flex items-center justify-center select-none"
      >
        {t("view_all_content", activeLanguage, "View All Content")}
      </button>
    </div>
  );

  // Render content type badge helper (Clean Neutral OTT Badges)
  const renderTypeBadge = (item: Movie | Video) => {
    const type = 'contentType' in item ? item.contentType : 'video';
    if (type === 'adult_movie' || ('category' in item && item.category === 'Adult Movies')) {
      return (
        <span className="text-[8px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800/60 px-1.5 py-0.5 rounded uppercase">
          18+ Adult
        </span>
      );
    }
    if (type === 'drama' || ('genre' in item && item.genre?.toLowerCase().includes('natok'))) {
      return (
        <span className="text-[8px] font-mono font-semibold bg-[#26262B] text-[#A0A0A0] border border-[#2A2A2E] px-1.5 py-0.5 rounded uppercase">
          Natok
        </span>
      );
    }
    if (type === 'series' || ('genre' in item && item.genre?.toLowerCase().includes('series'))) {
      return (
        <span className="text-[8px] font-mono font-semibold bg-[#26262B] text-[#A0A0A0] border border-[#2A2A2E] px-1.5 py-0.5 rounded uppercase">
          Series
        </span>
      );
    }
    if (type === 'video') {
      return (
        <span className="text-[8px] font-mono font-semibold bg-[#26262B] text-[#A0A0A0] border border-[#2A2A2E] px-1.5 py-0.5 rounded uppercase">
          Clip
        </span>
      );
    }
    return (
      <span className="text-[8px] font-mono font-semibold bg-[#26262B] text-[#A0A0A0] border border-[#2A2A2E] px-1.5 py-0.5 rounded uppercase">
        Movie
      </span>
    );
  };

  return (
    <div id="home-screen" className="overflow-x-hidden w-full max-w-full space-y-4 pb-12 relative max-w-md mx-auto">
      
      {/* 1. Horizontal Scrolling Category Pill Bar (Always at the very TOP) */}
      <div className="w-full overflow-hidden pt-1">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none px-4 py-1 no-scrollbar scroll-smooth">
          {filterTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeFilterTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-button-${tab.id}`}
                onClick={(e) => handleTabClick(tab.id, e)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono tracking-wide active:scale-95 transition-transform duration-75 whitespace-nowrap cursor-pointer flex items-center gap-1.5 select-none shrink-0 border ${
                  isActive
                    ? "bg-[#E50914] text-white font-bold border border-[#E50914] shadow-md shadow-red-950/40"
                    : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E] font-medium"
                }`}
              >
                {Icon && <Icon size={12} className={isActive ? "text-white stroke-[2.5]" : "text-[#A0A0A0]"} />}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Single Flat Solid Dark Search Bar (Always in the MIDDLE, directly underneath Category Bar) */}
      <div className="px-4 search-bar-container">
        <div className="relative bg-slate-900 border border-slate-800 focus-within:border-emerald-500/80 rounded-xl flex items-center px-3.5 py-1 transition duration-150 shadow-sm">
          <div className="mr-2.5 shrink-0 text-slate-400">
            <Search size={15} />
          </div>
          <input
            id="home-global-search"
            type="text"
            placeholder={t("search_global_placeholder", activeLanguage, "Search movies, natok, web series & videos...")}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-transparent text-white placeholder-slate-400 text-xs sm:text-sm py-2 outline-none font-sans font-normal"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery("")}
              className="text-[10px] text-slate-300 hover:text-white font-mono font-semibold bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg transition-transform duration-75 active:scale-95 cursor-pointer shrink-0 ml-2 border border-slate-700/60 select-none"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* 3. Dynamic Search Results Overlay or Category Content */}
      {searchQuery ? (
        <div className="space-y-4 relative z-10 px-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Zap size={14} className="text-amber-400" />
              Search Results ({totalResultsCount})
            </h3>
          </div>
          
          {totalResultsCount === 0 && !isSearching ? (
            <div className="bg-slate-900 rounded-xl p-8 border border-slate-800 text-center space-y-3 shadow-sm">
              <ShieldAlert size={36} className="mx-auto text-slate-500" />
              <p className="text-xs text-slate-400 font-normal">No media found matching "{searchQuery}"</p>
              <button 
                onClick={() => setSearchQuery("")} 
                className="text-xs text-amber-400 font-semibold hover:underline inline-flex items-center gap-1 font-mono uppercase cursor-pointer active:scale-95 transition-transform duration-75 select-none"
              >
                Clear Search <ChevronRight size={12} />
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2.5">
              {searchResults.movies.map((item) => {
                const isItemOpening = openingItemId === item.id;
                return (
                  <div 
                    key={`m-${item.id}`}
                    onClick={() => handleOpenItem(item, 'movie')}
                    className={`bg-slate-900 border hover:border-slate-700 rounded-2xl p-3 flex gap-3 items-center cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 shadow-sm select-none ${
                      isItemOpening ? "border-emerald-500/80 shadow-lg shadow-emerald-950/40" : "border-slate-800"
                    }`}
                  >
                    <div className="w-14 h-20 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-center overflow-hidden shrink-0 relative">
                      <img 
                        src={item.thumbnailUrl} 
                        alt={item.title} 
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
                        }}
                        className={`w-full h-full object-cover transition-all duration-200 ${
                          isItemOpening ? "filter blur-xs brightness-75 scale-105" : ""
                        }`}
                        referrerPolicy="no-referrer"
                      />
                      {isItemOpening && <PosterDownloadOverlay size="sm" />}
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {renderTypeBadge(item)}
                        <span className="text-[9px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800/60">
                          {item.duration || "Full HD"}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white truncate">{item.title}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono">
                        <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                          <Star size={10} className="fill-amber-400/30 text-amber-400" />
                          {item.rating || "8.8"}
                        </span>
                        {item.totalEpisodes && <span className="text-slate-500">• {item.totalEpisodes}</span>}
                      </div>
                    </div>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenItem(item, 'movie', e);
                      }}
                      onTouchEnd={(e) => e.stopPropagation()}
                      className={`py-1.5 px-2.5 rounded-lg font-bold text-xs tracking-wide border shadow-md transition-all duration-75 ease-out shrink-0 cursor-pointer flex items-center justify-center gap-1.5 select-none active:scale-95 active:brightness-125 ${
                        isItemOpening 
                          ? "bg-amber-700 border-amber-400 text-amber-200 ring-1.5 ring-amber-400" 
                          : "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black border border-amber-400/40 shadow-amber-950/50"
                      }`}
                    >
                      {isItemOpening ? (
                        <>
                          <div className="w-3 h-3 rounded-full border-[1.5px] border-black border-t-transparent animate-spin shrink-0" />
                          <span className="text-[11px] text-black font-bold">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                        </>
                      ) : (
                        <>
                          <Download size={12} strokeWidth={2.4} className="shrink-0 text-black" />
                          <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}

              {isAdultUnlocked && searchResults.videos.map((vid) => {
                const isVidOpening = openingItemId === vid.id;
                return (
                  <div 
                    key={`v-${vid.id}`}
                    onClick={() => handleOpenItem(vid, 'video')}
                    className={`bg-slate-900 border hover:border-slate-700 rounded-2xl p-3 flex gap-3 items-center cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 shadow-sm select-none ${
                      isVidOpening ? "border-purple-500/80 shadow-lg shadow-purple-950/40" : "border-slate-800"
                    }`}
                  >
                    <div className="w-20 h-14 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-center overflow-hidden shrink-0 relative">
                      <img 
                        src={vid.thumbnailUrl} 
                        alt={vid.title} 
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=600&q=80";
                        }}
                        className={`w-full h-full object-cover transition-all duration-200 ${
                          isVidOpening ? "filter blur-xs brightness-75 scale-105" : ""
                        }`}
                        referrerPolicy="no-referrer"
                      />
                      {isVidOpening && <PosterDownloadOverlay size="sm" />}
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-1.5">
                        {renderTypeBadge(vid)}
                        <span className="text-[9px] font-mono text-slate-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800/60">
                          {vid.category || "Video"}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold text-white truncate">{vid.title}</h4>
                    </div>
                    <button 
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenItem(vid, 'video', e);
                      }}
                      onTouchEnd={(e) => e.stopPropagation()}
                      className={`py-1.5 px-2.5 rounded-lg text-white font-bold text-xs tracking-wide border shadow-md transition-all duration-75 ease-out shrink-0 cursor-pointer flex items-center justify-center gap-1.5 select-none active:scale-95 active:brightness-125 ${
                        isVidOpening 
                          ? "bg-purple-800 border-purple-400 text-purple-200 ring-1.5 ring-purple-400" 
                          : "bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 border-purple-400/30 shadow-purple-950/50"
                      }`}
                    >
                      {isVidOpening ? (
                        <>
                          <div className="w-3 h-3 rounded-full border-[1.5px] border-purple-300 border-t-transparent animate-spin shrink-0" />
                          <span className="text-[11px] text-purple-200 font-bold">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                        </>
                      ) : (
                        <>
                          <Download size={12} strokeWidth={2.4} className="shrink-0 text-white" />
                          <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <>

          {/* 1. DYNAMIC INTERLEAVED TOP HERO SLIDER (Natural Dark-Slate UI • Zero-Lag Fast Touch & Swipe) */}
          {interleavedHeroPool.length > 0 && (
            <div className={activeFilterTab === "All" ? "block px-4" : "hidden"}>
              <div 
                className="relative rounded-2xl overflow-hidden bg-[#0B0F17] border border-slate-800/80 p-3.5 sm:p-4 shadow-xl"
                onTouchStart={handleHeroTouchStart}
                onTouchEnd={handleHeroTouchEnd}
                onMouseEnter={() => setIsPausedHero(true)}
                onMouseLeave={() => setIsPausedHero(false)}
              >
                {/* Subtle top indicator bar showing cycle timing */}
                <div className="absolute top-0 left-0 right-0 h-[2px] bg-slate-800/80 overflow-hidden">
                  <motion.div
                    key={`hero-progress-${currentSlide}`}
                    initial={{ width: "0%" }}
                    animate={{ width: isPausedHero ? "100%" : "100%" }}
                    transition={{ duration: isPausedHero ? 0 : 3.8, ease: "linear" }}
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-600"
                  />
                </div>

                <div className="relative min-h-[140px] flex items-center overflow-hidden">
                  <AnimatePresence mode="wait">
                    {(() => {
                      const heroItem = interleavedHeroPool[currentSlide] || interleavedHeroPool[0];
                      if (!heroItem) return null;
                      const isHeroOpening = openingItemId === heroItem.id;
                      return (
                        <motion.div
                          key={`hero-slide-${currentSlide}-${heroItem.id}`}
                          initial={{ opacity: 0, x: 12 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -12 }}
                          transition={{ duration: 0.28, ease: "easeInOut" }}
                          className="relative z-10 flex gap-3.5 items-center cursor-pointer w-full transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 rounded-2xl select-none"
                          onClick={() => handleOpenItem(heroItem, 'movie')}
                        >
                          {/* True Portrait Poster Container (2:3 Aspect Ratio) */}
                          <div className="w-24 sm:w-28 aspect-[2/3] rounded-xl bg-slate-950 border border-slate-800/80 overflow-hidden shrink-0 relative shadow-md">
                            <img
                              src={heroItem.thumbnailUrl}
                              alt={heroItem.title}
                              loading="lazy"
                              decoding="async"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=400&h=600&q=80";
                              }}
                              className={`w-full h-full object-cover transition-all duration-200 ${
                                isHeroOpening ? "filter blur-xs brightness-75 scale-105" : ""
                              }`}
                              referrerPolicy="no-referrer"
                            />
                            {isHeroOpening && <PosterDownloadOverlay size="sm" />}
                          </div>

                          {/* Highlight Info & CTA */}
                          <div className="flex-1 min-w-0 space-y-2 flex flex-col justify-between py-0.5">
                            <div className="space-y-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {renderTypeBadge(heroItem)}
                                <span className="text-[9px] font-mono font-bold text-white bg-slate-950 border border-slate-800/80 px-1.5 py-0.5 rounded flex items-center gap-1">
                                  <Star size={10} className="text-amber-400 fill-amber-400/40" />
                                  {heroItem.rating || "8.8"}
                                </span>
                                <span className="text-[9px] font-mono font-medium text-slate-400 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800/60">
                                  {heroItem.releaseYear || "2025"}
                                </span>
                              </div>

                              <h3 className="text-xs sm:text-sm font-extrabold text-white leading-snug line-clamp-2">
                                {heroItem.title}
                              </h3>

                              <p className="text-[10px] text-slate-400 line-clamp-1 leading-relaxed font-normal">
                                {heroItem.description}
                              </p>
                            </div>

                            <div className="pt-1 flex items-center justify-between gap-2">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenItem(heroItem, 'movie', e);
                                }}
                                onTouchEnd={(e) => e.stopPropagation()}
                                className={`w-full max-w-[200px] py-1.5 px-2.5 rounded-lg font-black text-xs tracking-wider border shadow-md transition-all duration-75 ease-out flex items-center justify-center gap-1.5 cursor-pointer uppercase select-none active:scale-95 ${
                                  isHeroOpening 
                                    ? "bg-amber-700 border-amber-400 text-black ring-1.5 ring-amber-400" 
                                    : "bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black border-amber-400/40 shadow-amber-950/60"
                                }`}
                              >
                                {isHeroOpening ? (
                                  <>
                                    <div className="w-3 h-3 rounded-full border-[1.5px] border-black border-t-transparent animate-spin shrink-0" />
                                    <span className="text-black">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                                  </>
                                ) : (
                                  <>
                                    <Download size={13} strokeWidth={2.4} className="shrink-0 text-black" />
                                    <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })()}
                  </AnimatePresence>
                </div>

                {/* Navigation Dots */}
                <div className="flex justify-center gap-1.5 pt-3">
                  {interleavedHeroPool.map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setCurrentSlide(idx)}
                      className={`h-1.5 rounded-full transition-all duration-200 cursor-pointer ${
                        idx === currentSlide ? "w-4 bg-amber-500" : "w-1.5 bg-slate-700 hover:bg-slate-600"
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* DEDICATED FULL CATALOG VIEW: MOVIES */}
          <div className={activeFilterTab === "Movies" ? "block" : "hidden"}>
            <MoviesScreen
              movies={movies}
              user={user}
              onViewedMovie={onViewedMovie}
              guideVideoUrl={guideVideoUrl}
              guideVideoLogoUrl={guideVideoLogoUrl}
              isAdultUnlocked={isAdultUnlocked}
              onBackToAll={undefined}
              showSearchBar={false}
              currentLanguage={activeLanguage}
            />
          </div>

          {/* DEDICATED FULL CATALOG VIEW: ADULT MOVIES (18+) */}
          <div className={activeFilterTab === "AdultMovies" && isAdultUnlocked ? "block space-y-3.5 pt-1 px-4" : "hidden"}>
            <div className="bg-slate-900/60 border border-rose-900/60 rounded-xl py-2 px-3 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2">
                <div className="p-1 bg-rose-950 text-rose-400 rounded border border-rose-800/60 shrink-0">
                  <Flame size={13} />
                </div>
                <h3 className="text-xs font-bold text-rose-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <span>{t("adult_movies_title", activeLanguage, "Adult Movies (18+)")}</span>
                  <span className="text-[8px] bg-rose-600 text-white font-mono px-1 rounded font-bold">18+</span>
                </h3>
              </div>
            </div>

            {/* Full Responsive 2-Column Mobile / 3-Column Tablet Grid */}
            {filteredDedicatedAdultMovies.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {filteredDedicatedAdultMovies.map((item) => (
                  <MovieCard
                    key={`full-amv-${item.id}`}
                    movie={item}
                    isAdult={true}
                    layout="grid"
                    showGetLink={true}
                    showBadges={false}
                    onClick={() => setSelectedTaskItem({ item, type: 'movie' })}
                  />
                ))}
              </div>
            ) : (
              renderEmptyState(t("adult_movies_title", activeLanguage, "Adult Movies (18+)"))
            )}
          </div>

          {/* DEDICATED FULL CATALOG VIEW: DRAMA & BANGLA NATOK */}
          <div className={activeFilterTab === "Drama" ? "block" : "hidden"}>
            <DramaScreen
              movies={movies}
              user={user}
              onViewedMovie={onViewedMovie}
              guideVideoUrl={guideVideoUrl}
              guideVideoLogoUrl={guideVideoLogoUrl}
              onBackToAll={undefined}
              showSearchBar={false}
              currentLanguage={activeLanguage}
            />
          </div>

          {/* DEDICATED FULL CATALOG VIEW: WEB SERIES */}
          <div className={activeFilterTab === "Series" ? "block" : "hidden"}>
            <SeriesScreen
              movies={movies}
              user={user}
              onViewedMovie={onViewedMovie}
              guideVideoUrl={guideVideoUrl}
              guideVideoLogoUrl={guideVideoLogoUrl}
              onBackToAll={undefined}
              showSearchBar={false}
              currentLanguage={activeLanguage}
            />
          </div>

          {/* DEDICATED FULL CATALOG VIEW: VIRAL VIDEOS */}
          <div className={activeFilterTab === "Videos" && isAdultUnlocked ? "block space-y-3.5 pt-1 px-4" : "hidden"}>
            <div className="bg-slate-900/60 border border-purple-900/60 rounded-xl py-2 px-3 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2">
                <div className="p-1 bg-purple-950 text-purple-400 rounded border border-purple-800/60 shrink-0">
                  <MonitorPlay size={13} />
                </div>
                <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider font-mono">
                  {t("viral_videos_title", activeLanguage, "Viral Videos")}
                </h3>
              </div>
            </div>

            {/* Video Country / Sub-category Tabs with Auto-Centering */}
            <div className="w-full overflow-hidden -mx-4">
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none px-4 py-1 no-scrollbar scroll-smooth">
                {videoCategoryFilters.map((subCat) => {
                  const isSubActive = videoSubCategory === subCat.key;
                  return (
                    <button
                      key={subCat.key}
                      id={`subcat-tab-${subCat.key.toLowerCase()}`}
                      onClick={(e) => {
                        setVideoSubCategory(subCat.key);
                        e.currentTarget.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                      }}
                      className={`px-3 py-1 rounded-lg text-[11px] font-mono font-semibold tracking-wide active:scale-95 transition-transform duration-75 whitespace-nowrap cursor-pointer shrink-0 select-none border ${
                        isSubActive
                          ? "bg-[#E50914] text-white font-bold border border-[#E50914] shadow-md shadow-red-950/40"
                          : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E] font-medium"
                      }`}
                    >
                      {subCat.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Full Responsive Grid of Video Clips or Empty State */}
            {filteredDedicatedVideos.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredDedicatedVideos.map((video) => {
                  const isVidOpening = openingItemId === video.id;
                  return (
                    <div
                      key={`full-vid-${video.id}`}
                      onClick={() => handleOpenItem(video, 'video')}
                      className={`bg-slate-900 border hover:border-slate-700 rounded-2xl p-3 cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 group flex flex-col justify-between gap-2.5 shadow-sm select-none ${
                        isVidOpening ? "border-emerald-500/80 shadow-lg shadow-emerald-950/40" : "border-slate-800"
                      }`}
                    >
                      {/* Clean 1:1 (Square) Poster View with Zero Overlays */}
                      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-slate-950 border border-slate-800/80 shrink-0">
                        <img
                          src={video.thumbnailUrl}
                          alt={video.title}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=600&q=80";
                          }}
                          className={`w-full h-full object-cover transition-all duration-200 ${
                            isVidOpening ? "filter blur-xs brightness-75 scale-105" : ""
                          }`}
                          referrerPolicy="no-referrer"
                        />
                        {isVidOpening && <PosterDownloadOverlay size="md" />}
                      </div>

                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-white line-clamp-1 leading-snug">
                          {video.title}
                        </h4>
                        {video.description && (
                          <p className="text-[10px] text-slate-400 line-clamp-1 font-normal">
                            {video.description}
                          </p>
                        )}
                      </div>

                      <div className="flex justify-center pt-0.5">
                        <button 
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenItem(video, 'video', e);
                          }}
                          onTouchEnd={(e) => e.stopPropagation()}
                          className={`w-full max-w-[200px] py-1.5 px-2.5 rounded-lg font-bold text-xs tracking-wide border shadow-md transition-all duration-75 ease-out flex items-center justify-center gap-1.5 shrink-0 select-none cursor-pointer uppercase active:scale-95 ${
                            isVidOpening 
                              ? "bg-purple-800 border-purple-400 text-purple-200 ring-1.5 ring-purple-400" 
                              : "bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white border-purple-400/30 shadow-purple-950/50"
                          }`}
                        >
                          {isVidOpening ? (
                            <>
                              <div className="w-3 h-3 rounded-full border-[1.5px] border-purple-300 border-t-transparent animate-spin shrink-0" />
                              <span className="text-purple-200">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                            </>
                          ) : (
                            <>
                              <Download size={13} strokeWidth={2.4} className="shrink-0 text-white" />
                              <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              renderEmptyState("Viral Videos")
            )}
          </div>

          {/* ALL CATEGORY HORIZONTAL CAROUSELS & POSTER GRID (Permanently mounted in memory for zero-loading scroll & instant navigation) */}
          <div className={activeFilterTab === "All" ? "block space-y-6" : "hidden"}>
            {/* 2. TRENDING MOVIES */}
            {cinemaMovies.length > 0 && (
              <div className="w-full">
                {/* Premium Unique Section Header */}
                <div className="flex items-center justify-between px-4 mb-2.5 mt-6">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-4.5 bg-gradient-to-b from-amber-400 to-amber-600 rounded-full shadow-xs shadow-amber-500/50" />
                    <div className="w-6 h-6 rounded-lg bg-amber-950/40 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                      <Film size={13} />
                    </div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                      {t("trending_movies", activeLanguage, "Trending Movies")}
                    </h3>
                  </div>
                  <button 
                    onClick={() => handleTabSelect('Movies')}
                    className="px-2.5 py-1 rounded-full bg-amber-950/20 hover:bg-amber-950/40 border border-amber-500/30 hover:border-amber-400/50 text-amber-400 hover:text-amber-300 text-[10px] sm:text-[11px] font-bold tracking-wider flex items-center gap-1 cursor-pointer active:scale-95 transition-transform duration-75 shadow-xs"
                  >
                    VIEW ALL
                    <ChevronRight size={12} />
                  </button>
                </div>

                {/* Fluid Carousel with Clean Left-Margin Alignment */}
                <div className="flex overflow-x-auto gap-3 px-4 scroll-pl-4 scrollbar-none snap-x pb-2 pt-0.5 no-scrollbar scroll-smooth">
                  {cinemaMovies.map((movie) => (
                    <MovieCard
                      key={`cm-${movie.id}`}
                      movie={movie}
                      onClick={() => setSelectedTaskItem({ item: movie, type: 'movie' })}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 3. ADULT MOVIES (18+) (Rendered directly under Trending Movies when 18+ is unlocked) */}
            {isAdultUnlocked && adultMovies.length > 0 && (
              <div className="w-full">
                {/* Premium Unique Section Header */}
                <div className="flex items-center justify-between px-4 mb-2.5 mt-6">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-4.5 bg-gradient-to-b from-rose-500 to-rose-700 rounded-full shadow-xs shadow-rose-500/50" />
                    <div className="w-6 h-6 rounded-lg bg-rose-950/40 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0">
                      <Flame size={13} />
                    </div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                      {t("adult_movies_title", activeLanguage, "Adult Movies (18+)")}
                    </h3>
                  </div>
                  <button 
                    onClick={() => handleTabSelect('AdultMovies')}
                    className="px-2.5 py-1 rounded-full bg-rose-950/20 hover:bg-rose-950/40 border border-rose-500/30 hover:border-rose-400/50 text-rose-400 hover:text-rose-300 text-[10px] sm:text-[11px] font-bold tracking-wider flex items-center gap-1 cursor-pointer active:scale-95 transition-transform duration-75 shadow-xs"
                  >
                    VIEW ALL
                    <ChevronRight size={12} />
                  </button>
                </div>

                {/* Fluid Carousel with Clean Left-Margin Alignment */}
                <div className="flex overflow-x-auto gap-3 px-4 scroll-pl-4 scrollbar-none snap-x pb-2 pt-0.5 no-scrollbar scroll-smooth">
                  {adultMovies.map((movie) => (
                    <MovieCard
                      key={`amv-row-${movie.id}`}
                      movie={movie}
                      isAdult={true}
                      onClick={() => setSelectedTaskItem({ item: movie, type: 'movie' })}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 4. TRENDING WEB SERIES */}
            {seriesItems.length > 0 && (
              <div className="w-full">
                {/* Premium Unique Section Header */}
                <div className="flex items-center justify-between px-4 mb-2.5 mt-6">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-4.5 bg-gradient-to-b from-sky-400 to-blue-600 rounded-full shadow-xs shadow-sky-500/50" />
                    <div className="w-6 h-6 rounded-lg bg-sky-950/40 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0">
                      <Layers size={13} />
                    </div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                      {t("trending_series", activeLanguage, "Trending Web Series")}
                    </h3>
                  </div>
                  <button 
                    onClick={() => handleTabSelect('Series')}
                    className="px-2.5 py-1 rounded-full bg-sky-950/20 hover:bg-sky-950/40 border border-sky-500/30 hover:border-sky-400/50 text-sky-400 hover:text-sky-300 text-[10px] sm:text-[11px] font-bold tracking-wider flex items-center gap-1 cursor-pointer active:scale-95 transition-transform duration-75 shadow-xs"
                  >
                    VIEW ALL
                    <ChevronRight size={12} />
                  </button>
                </div>

                {/* Fluid Carousel with Clean Left-Margin Alignment */}
                <div className="flex overflow-x-auto gap-3 px-4 scroll-pl-4 scrollbar-none snap-x pb-2 pt-0.5 no-scrollbar scroll-smooth">
                  {seriesItems.map((item) => (
                    <MovieCard
                      key={`ws-${item.id}`}
                      movie={item}
                      onClick={() => setSelectedTaskItem({ item, type: 'movie' })}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* 5. DRAMA & BANGLA NATOK */}
            {dramaItems.length > 0 && (
              <div className="w-full">
                {/* Premium Unique Section Header */}
                <div className="flex items-center justify-between px-4 mb-2.5 mt-6">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-4.5 bg-gradient-to-b from-emerald-400 to-teal-600 rounded-full shadow-xs shadow-emerald-500/50" />
                    <div className="w-6 h-6 rounded-lg bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                      <Tv size={13} />
                    </div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                      {t("trending_drama", activeLanguage, "Drama & Bangla Natok")}
                    </h3>
                  </div>
                  <button 
                    onClick={() => handleTabSelect('Drama')}
                    className="px-2.5 py-1 rounded-full bg-emerald-950/20 hover:bg-emerald-950/40 border border-emerald-500/30 hover:border-emerald-400/50 text-emerald-400 hover:text-emerald-300 text-[10px] sm:text-[11px] font-bold tracking-wider flex items-center gap-1 cursor-pointer active:scale-95 transition-transform duration-75 shadow-xs"
                  >
                    VIEW ALL
                    <ChevronRight size={12} />
                  </button>
                </div>

                {/* Fluid Carousel with Clean Left-Margin Alignment */}
                <div className="flex overflow-x-auto gap-3 px-4 scroll-pl-4 scrollbar-none snap-x pb-2 pt-0.5 no-scrollbar scroll-smooth">
                  {dramaItems.map((item) => (
                    <MovieCard
                      key={`dr-${item.id}`}
                      movie={item}
                      onClick={() => setSelectedTaskItem({ item, type: 'movie' })}
                    />
                  ))}
                </div>
              </div>
            )}

          {/* 6. VIRAL VIDEO LINKS SPOTLIGHT (Screen-Perfect Single Video Card • Continuous Smooth Auto-Advance • Only when 18+ is unlocked) */}
          {isAdultUnlocked && spotlightVideos.length > 0 && (
            <div className="w-full space-y-2">
              {/* Premium Unique Section Header */}
              <div className="flex items-center justify-between px-4 mb-2.5 mt-6">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-4.5 bg-gradient-to-b from-purple-500 to-indigo-600 rounded-full shadow-xs shadow-purple-500/50" />
                  <div className="w-6 h-6 rounded-lg bg-purple-950/40 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
                    <MonitorPlay size={13} />
                  </div>
                  <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                    VIRAL VIDEO LINKS
                  </h3>
                </div>
                <button 
                  onClick={() => handleTabSelect('Videos')}
                  className="px-2.5 py-1 rounded-full bg-purple-950/20 hover:bg-purple-950/40 border border-purple-500/30 hover:border-purple-400/50 text-purple-400 hover:text-purple-300 text-[10px] sm:text-[11px] font-bold tracking-wider flex items-center gap-1 cursor-pointer active:scale-95 transition-transform duration-75 shadow-xs"
                >
                  VIEW ALL
                  <ChevronRight size={12} />
                </button>
              </div>

              <div className="px-4">

              {/* Exact Single Video Post Card (Solid Flat Dark Surface • Continuous Smooth Cycle) */}
              <div 
                className="relative rounded-xl overflow-hidden bg-slate-900 border border-slate-800 p-3 sm:p-3.5 shadow-sm"
                onTouchStart={handleVideoTouchStart}
                onTouchEnd={handleVideoTouchEnd}
              >
                {/* Continuous Amber Progress Indicator Bar */}
                <div className="absolute top-0 left-0 right-0 h-[2.5px] bg-slate-800 overflow-hidden z-10">
                  <motion.div
                    key={`video-progress-${videoSlideIndex}`}
                    initial={{ width: "0%" }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 4.2, ease: "linear" }}
                    className="h-full bg-gradient-to-r from-amber-500 to-amber-600"
                  />
                </div>

                <div className="relative overflow-hidden w-full min-h-[250px] sm:min-h-[275px] flex items-center">
                  <AnimatePresence mode="wait">
                    {(() => {
                      const spotlightItem = spotlightVideos[videoSlideIndex] || spotlightVideos[0];
                      if (!spotlightItem) return null;
                      const isSpotlightOpening = openingItemId === spotlightItem.id;
                      return (
                        <motion.div
                          key={`video-active-${spotlightItem.id || videoSlideIndex}`}
                          initial={{ opacity: 0, scale: 0.985 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.985 }}
                          transition={{ duration: 0.28, ease: "easeOut" }}
                          className="w-full flex flex-col gap-2.5 cursor-pointer transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 rounded-2xl select-none"
                          onClick={() => handleOpenItem(spotlightItem, 'video')}
                        >
                          {/* 1:1 (Square) Screen-Perfect Poster Image */}
                          <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-slate-950 border border-slate-800/80 group">
                            <img
                              src={spotlightItem.thumbnailUrl}
                              alt={spotlightItem.title}
                              loading="eager"
                              decoding="async"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&h=600&q=80";
                              }}
                              className={`w-full h-full object-cover transition-all duration-200 ${
                                isSpotlightOpening ? "filter blur-xs brightness-75 scale-105" : ""
                              }`}
                              referrerPolicy="no-referrer"
                            />

                            {/* Category Badge */}
                            {!isSpotlightOpening && spotlightItem.category && (
                              <div className="absolute top-2 left-2 z-10 bg-slate-950 text-amber-400 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border border-slate-800 shadow-sm">
                                {spotlightItem.category}
                              </div>
                            )}

                            {/* Play Overlay Indicator or Download Animation */}
                            {isSpotlightOpening ? (
                              <PosterDownloadOverlay size="md" />
                            ) : (
                              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-150 bg-black/40">
                                <div className="w-11 h-11 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center shadow-md scale-90 group-hover:scale-100 transition-transform">
                                  <Play size={18} fill="currentColor" className="ml-0.5" />
                                </div>
                              </div>
                            )}
                          </div>

                          {/* Video Title & Action Button */}
                          <div className="space-y-1 px-0.5">
                            <div className="flex items-center justify-between gap-2">
                              <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1 leading-snug">
                                {spotlightItem.title}
                              </h4>
                              <span className="text-[9px] font-mono font-medium text-slate-400 bg-slate-800 px-2 py-0.5 rounded shrink-0 border border-slate-700/60">
                                {videoSlideIndex + 1} / {spotlightVideos.length}
                              </span>
                            </div>
                            {spotlightItem.description && (
                              <p className="text-[10px] text-slate-400 line-clamp-1 font-normal">
                                {spotlightItem.description}
                              </p>
                            )}
                          </div>

                          <div className="flex justify-center pt-1">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenItem(spotlightItem, 'video');
                              }}
                              className={`w-full max-w-[200px] py-1.5 px-2.5 rounded-lg font-bold text-xs tracking-wide border shadow-md transition-all duration-75 ease-out flex items-center justify-center gap-1.5 shrink-0 select-none cursor-pointer uppercase active:scale-95 ${
                                isSpotlightOpening 
                                  ? "bg-purple-800 border-purple-400 text-purple-200 ring-1.5 ring-purple-400" 
                                  : "bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white border-purple-400/30 shadow-purple-950/50"
                              }`}
                            >
                              {isSpotlightOpening ? (
                                <>
                                  <div className="w-3 h-3 rounded-full border-[1.5px] border-purple-300 border-t-transparent animate-spin shrink-0" />
                                  <span className="text-purple-200">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                                </>
                              ) : (
                                <>
                                  <Download size={13} strokeWidth={2.4} className="shrink-0 text-white" />
                                  <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                                </>
                              )}
                            </button>
                          </div>
                        </motion.div>
                      );
                    })()}
                  </AnimatePresence>
                </div>

                {/* Smooth Carousel Dots Navigation */}
                <div className="flex justify-center gap-1.5 pt-2">
                  {spotlightVideos.slice(0, Math.min(spotlightVideos.length, 10)).map((_, idx) => (
                    <button
                      key={`v-dot-${idx}`}
                      type="button"
                      onClick={() => setVideoSlideIndex(idx)}
                      className={`h-1.5 rounded-full transition-all duration-200 cursor-pointer ${
                        idx === videoSlideIndex ? "w-4 bg-gradient-to-r from-amber-500 to-amber-600" : "w-1.5 bg-slate-700 hover:bg-slate-600"
                      }`}
                      aria-label={`Slide ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

          {/* 7. MOVIEBOX 4-COLUMN COMPACT POSTER GRID (Universal All-Posters Hub • Newest First) */}
          {movieBoxAllPosters.length > 0 && (
            <div className="w-full pb-6">
              {/* Premium Unique Section Header */}
              <div className="flex items-center justify-between px-4 mb-3 mt-7">
                <div className="flex items-center gap-2.5">
                  <span className="w-1.5 h-4.5 bg-gradient-to-b from-orange-500 to-amber-500 rounded-full shadow-xs shadow-orange-500/50" />
                  <h3 className="text-xs sm:text-sm font-extrabold text-white tracking-wider uppercase font-sans">
                    Most Trending All Releases
                  </h3>
                </div>
              </div>

              {/* 4-Column Mobile / 5-6 Column Tablet Poster Grid (Exactly 4 posters per row on mobile) */}
              <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-2 sm:gap-2.5 px-3 sm:px-4">
                {movieBoxAllPosters.map((item, index) => {
                  const isAdult = isAdultMovieItem(item);

                  return (
                    <MovieCard
                      key={`mb-${item.id}`}
                      movie={item}
                      layout="compact"
                      isAdult={isAdult}
                      priorityBadge={index < 4 ? "NEW" : undefined}
                      onClick={() => setSelectedTaskItem({ item, type: 'movie' })}
                    />
                  );
                })}
              </div>
            </div>
          )}
        </div>
        </>
      )}

      {/* Link Unlock & Multi-Language Modal */}
      {selectedTaskItem && selectedTaskItem.item && (
        <LinkUnlockModal
          item={selectedTaskItem.item}
          type={selectedTaskItem.type}
          guideVideoUrl={guideVideoUrl}
          guideVideoLogoUrl={guideVideoLogoUrl}
          userId={user.id}
          onClose={() => setSelectedTaskItem(null)}
        />
      )}
    </div>
  );
}

const HomeScreen = React.memo(HomeScreenComponent);
export default HomeScreen;
