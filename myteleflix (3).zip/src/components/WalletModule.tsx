/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Coins, Wallet, History, AlertCircle, ArrowUpRight, ArrowDownLeft, Gift, ShieldAlert, Sparkles } from "lucide-react";
import { Transaction } from "../types";
import TokenIcon from "./TokenIcon";

interface WalletModuleProps {
  userPoints: number;
  transactions: Transaction[];
  minimumWithdrawal: number;
  onWithdraw: (amount: number, address: string) => Promise<{ success: boolean; error?: string }>;
}

export default function WalletModule({
  userPoints,
  transactions,
  minimumWithdrawal,
  onWithdraw,
}: WalletModuleProps) {
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("bKash");
  const [walletAddress, setWalletAddress] = useState("");
  const [errorText, setErrorText] = useState<string | null>(null);
  const [successText, setSuccessText] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmitWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText(null);
    setSuccessText(null);

    const amountNum = parseInt(withdrawAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setErrorText("Please enter a valid positive number for withdrawal.");
      return;
    }

    if (amountNum < minimumWithdrawal) {
      setErrorText(`The minimum withdrawal threshold is ${minimumWithdrawal} points.`);
      return;
    }

    if (amountNum > userPoints) {
      setErrorText("Insufficient balance. Complete more cinema missions to earn more points!");
      return;
    }

    if (!walletAddress.trim()) {
      setErrorText(`Please enter a valid ${paymentMethod} account number or address.`);
      return;
    }

    setSubmitting(true);
    try {
      const fullAddressDetails = `[${paymentMethod}] ${walletAddress.trim()}`;
      const res = await onWithdraw(amountNum, fullAddressDetails);
      if (res.success) {
        setSuccessText(`Success! Your payout request of 🪙 ${amountNum} via ${paymentMethod} is submitted for review.`);
        setWithdrawAmount("");
        setWalletAddress("");
      } else if (res.error) {
        setErrorText(res.error);
      }
    } catch (err: any) {
      setErrorText(err.message || "Failed to submit withdrawal request.");
    } finally {
      setSubmitting(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "reward_mission":
        return <Gift className="text-indigo-600" size={14} />;
      case "reward_referral":
        return <Gift className="text-amber-600" size={14} />;
      case "referral_commission":
        return <Sparkles className="text-indigo-600" size={14} />;
      case "withdrawal":
        return <ArrowUpRight className="text-rose-600" size={14} />;
      case "bonus":
        return <Sparkles className="text-amber-600" size={14} />;
      default:
        return <ArrowDownLeft className="text-emerald-650" size={14} />;
    }
  };

  const getTransactionBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <span className="text-[10px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-bold border border-amber-250 uppercase font-mono tracking-wider">
            Pending
          </span>
        );
      case "failed":
        return (
          <span className="text-[10px] bg-rose-50 text-rose-700 px-2 py-0.5 rounded font-bold border border-rose-250 uppercase font-mono tracking-wider">
            Rejected
          </span>
        );
      default:
        return (
          <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-bold border border-emerald-250 uppercase font-mono tracking-wider">
            Completed
          </span>
        );
    }
  };

  return (
    <div id="wallet-module" className="space-y-6 animate-in fade-in duration-300">
      
      {/* 1. Wallet Balance Card & Forms */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        
        {/* Balance Card */}
        <div className="md:col-span-5 bg-white rounded-2xl p-6 flex flex-col justify-between shadow-sm relative overflow-hidden border border-indigo-50">
          <div className="absolute -top-6 -right-6 p-4 opacity-5">
            <Coins size={130} className="text-indigo-650 animate-float" />
          </div>
          <div className="relative z-10 space-y-4">
            <span className="text-[10px] bg-indigo-50 text-indigo-600 px-2.5 py-1 rounded-full border border-indigo-150 uppercase font-mono tracking-wider inline-block font-extrabold">
              Available Balance
            </span>
            <h1 id="wallet-balance-num" className="text-4xl font-black text-indigo-600 font-mono tracking-tight flex items-center gap-2">
              <TokenIcon size={32} />
              <span>{userPoints.toLocaleString()}</span>
            </h1>
            <p className="text-xs text-slate-500 leading-relaxed">
              Cinema reward points can be requested for direct swap to Toncoin (TON) wallet addresses. Participate in high-definition cinema streams to claim instant rewards.
            </p>
          </div>
        </div>

        {/* Withdrawal Form Card */}
        <div className="md:col-span-7 bg-white rounded-2xl p-6 border border-indigo-50 shadow-sm">
          <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-widest flex items-center gap-2 mb-5 font-mono">
            <Wallet size={14} className="text-indigo-600" />
            Submit Withdrawal Request
          </h4>

          {errorText && (
            <div id="withdraw-error" className="mb-4 bg-rose-50 border border-rose-250 text-rose-700 px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
              <ShieldAlert size={14} className="shrink-0 animate-bounce text-rose-600" />
              <span className="font-bold">{errorText}</span>
            </div>
          )}

          {successText && (
            <div id="withdraw-success" className="mb-4 bg-emerald-50 border border-emerald-250 text-emerald-700 px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
              <AlertCircle size={14} className="shrink-0 animate-pulse text-emerald-600" />
              <span className="font-bold">{successText}</span>
            </div>
          )}

          <form id="withdraw-form" onSubmit={handleSubmitWithdrawal} className="space-y-4">
            <div className="space-y-4">
              <div>
                <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1.5 font-bold">
                  Select Payout Method
                </label>
                <select
                  id="withdraw-method-select"
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-slate-800 font-mono outline-none transition font-bold"
                >
                  <option value="bKash">bKash (Mobile Wallet)</option>
                  <option value="Nagad">Nagad (Mobile Wallet)</option>
                  <option value="Crypto (TON / USDT)">Crypto (TON / USDT)</option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1.5 font-bold">
                    Amount to Cash Out
                  </label>
                  <input
                    id="withdraw-amount-input"
                    type="number"
                    placeholder={`Min: ${minimumWithdrawal}`}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-slate-800 font-mono placeholder-slate-400 outline-none transition"
                    required
                  />
                </div>

                <div>
                  <label className="text-[10px] text-slate-500 uppercase font-mono tracking-wider block mb-1.5 font-bold">
                    {paymentMethod.includes("Crypto") ? 'TON / USDT Wallet Address' : `${paymentMethod} Account / Mobile Number`}
                  </label>
                  <input
                    id="withdraw-address-input"
                    type="text"
                    placeholder={paymentMethod.includes("Crypto") ? 'e.g. EQC4vP...Z_X89K' : '017XXXXXXXX'}
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-slate-800 font-mono placeholder-slate-400 outline-none transition"
                    required
                  />
                </div>
              </div>
            </div>

            <button
              id="withdraw-submit-btn"
              type="submit"
              disabled={submitting}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all duration-300 flex items-center justify-center gap-1.5 ${
                submitting
                  ? "bg-slate-100 text-slate-400 border border-slate-250 cursor-not-allowed"
                  : "bg-indigo-600 hover:bg-indigo-500 text-white cursor-pointer active:scale-97 shadow-sm"
              }`}
            >
              {submitting ? (
                <>
                  <div className="h-3.5 w-3.5 rounded-full border-2 border-white border-t-indigo-600 animate-spin"></div>
                  Broadcasting payout request...
                </>
              ) : (
                `Submit Payout Request (${paymentMethod})`
              )}
            </button>
          </form>
        </div>
      </div>

      {/* 2. Transaction Ledger List */}
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-indigo-50">
        <div className="px-5 py-4 border-b border-indigo-50 bg-slate-50/50 flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-2 font-mono">
            <History size={14} className="text-indigo-600 animate-pulse" />
            Wallet Transaction Ledger
          </h4>
          <span className="text-[10px] text-indigo-600 font-mono bg-indigo-50 px-2.5 py-0.5 rounded border border-indigo-100">{transactions.length} entries</span>
        </div>

        {transactions.length === 0 ? (
          <div className="p-10 text-center space-y-2">
            <Coins size={32} className="text-indigo-300 mx-auto animate-float" />
            <p className="text-xs text-slate-500 font-bold">No ledger transactions found.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 border-b border-slate-150 font-mono">
                  <th className="px-5 py-3 font-bold uppercase tracking-wider text-[10px]">Date & Time</th>
                  <th className="px-5 py-3 font-bold uppercase tracking-wider text-[10px]">Source description</th>
                  <th className="px-5 py-3 font-bold uppercase tracking-wider text-[10px]">Status</th>
                  <th className="px-5 py-3 font-bold uppercase tracking-wider text-[10px] text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/50 transition-all duration-200">
                    <td className="px-5 py-4 text-slate-500 whitespace-nowrap font-mono">
                      {new Date(tx.timestamp).toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2.5">
                        <span className="p-2 rounded-xl bg-slate-50 border border-slate-150 shrink-0">
                          {getTransactionIcon(tx.type)}
                        </span>
                        <span className="font-extrabold text-slate-700">{tx.description}</span>
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      {getTransactionBadge(tx.status)}
                    </td>
                    <td className={`px-5 py-4 text-right font-black font-mono whitespace-nowrap text-xs ${
                      tx.amount > 0 ? "text-indigo-600" : "text-rose-600"
                    }`}>
                      <span className="inline-flex items-center justify-end gap-1">
                        <TokenIcon size={12} />
                        <span>{tx.amount > 0 ? `+${tx.amount.toLocaleString()}` : tx.amount.toLocaleString()}</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
