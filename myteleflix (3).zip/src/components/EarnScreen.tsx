/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * EarnScreen: Complete Earn & Browser-Based Referral Ecosystem
 * Categories (Left-to-Right):
 * 1. Invite & Earn (Complete Detailed Referral & Network Page)
 * 2. Daily Reward (7-Day Check-in Streaks & Continuous Bonus Engine)
 * 3. Watch Video Ads (High-Yield Rewarded Video Ads & Trailers)
 * 4. Social Tasks (YouTube, Twitter/X, Facebook, Instagram, Web)
 * 5. Telegram (Official Telegram Channels & Community Groups)
 */

import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  Users, Gift, PlayCircle, Share2, Send, CheckCircle2, 
  Clock, Flame, Loader2, X, Calendar, Zap, 
  Check, ArrowRight, Sparkles, Copy, ExternalLink, 
  ChevronDown, ChevronUp, ShieldCheck, Award, MessageCircle,
  HelpCircle, RefreshCw
} from "lucide-react";
import { Mission, MissionLog, User, SystemSettings } from "../types";
import TelegramAdModal from "./TelegramAdModal";
import TokenIcon from "./TokenIcon";
import ReferralModule from "./ReferralModule";
import { getAdNetworkConfig, injectAdNetworkScript } from "../services/adNetwork";
import { useLanguage } from "../context/LanguageContext";

export interface EarnProps {
  missions: Mission[];
  missionLogs: MissionLog[];
  onVerifyMission: (missionId: string) => Promise<{ success: boolean; error?: string; pointsEarned?: number }>;
  userId: string;
  user?: User;
  settings?: SystemSettings;
  onUpdateUser?: (u: User) => void;
  onTriggerAuth?: (action: 'earn') => void;
  onOpenStream?: (media: any, type?: 'movie' | 'video') => void;
}

export type EarnCategory = 'invite_earn' | 'daily_reward' | 'video_ads' | 'social_tasks' | 'telegram';
export type TaskCategory = EarnCategory;

export const EARN_CATEGORIES: {
  id: EarnCategory;
  label: string;
  shortLabel: string;
  icon: React.ElementType;
  badgeBg: string;
  color: string;
}[] = [
  {
    id: "invite_earn",
    label: "Invite & Earn",
    shortLabel: "Invite",
    icon: Users,
    badgeBg: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30",
    color: "text-indigo-400"
  },
  {
    id: "daily_reward",
    label: "Daily Reward",
    shortLabel: "Daily",
    icon: Gift,
    badgeBg: "bg-amber-500/15 text-amber-300 border-amber-500/30",
    color: "text-amber-400"
  },
  {
    id: "video_ads",
    label: "Watch Video Ads",
    shortLabel: "Video Ads",
    icon: PlayCircle,
    badgeBg: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    color: "text-rose-400"
  },
  {
    id: "social_tasks",
    label: "Social Tasks",
    shortLabel: "Social",
    icon: Share2,
    badgeBg: "bg-sky-500/15 text-sky-300 border-sky-500/30",
    color: "text-sky-400"
  },
  {
    id: "telegram",
    label: "Telegram",
    shortLabel: "Channels",
    icon: Send,
    badgeBg: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
    color: "text-cyan-400"
  }
];

export function classifyMissionCategory(m: Mission): EarnCategory {
  if (m.category === "invite_earn" || m.category === "daily_reward" || m.category === "video_ads" || m.category === "social_tasks" || m.category === "telegram") {
    return m.category;
  }
  const t = (m.type || "").toLowerCase();
  const title = (m.title || "").toLowerCase();
  const url = (m.url || "").toLowerCase();

  if (t === "telegram_join" || t === "telegram" || title.includes("telegram") || url.includes("t.me")) {
    return "telegram";
  }
  if (t === "daily_checkin" || t === "daily" || title.includes("daily") || title.includes("check-in") || title.includes("streak")) {
    return "daily_reward";
  }
  if (t === "youtube" || t === "video_watch" || t === "adsgram" || title.includes("video") || title.includes("watch") || url.includes("youtube.com/watch") || url.includes("youtu.be")) {
    return "video_ads";
  }
  return "social_tasks";
}

export default function EarnScreen({
  missions,
  missionLogs,
  onVerifyMission,
  userId,
  user,
  settings,
  onUpdateUser: _onUpdateUser,
  onTriggerAuth,
  onOpenStream: _onOpenStream,
}: EarnProps) {
  const { t, language } = useLanguage();

  const getCategoryLabel = (id: EarnCategory, fallback: string) => {
    if (id === 'invite_earn') {
      return language === 'bn' ? 'ইনভাইট ও ইনকাম' : language === 'hi' ? 'आमंत्रित करें' : 'Invite & Earn';
    }
    if (id === 'daily_reward') {
      return language === 'bn' ? 'দৈনিক রিওয়ার্ড' : language === 'hi' ? 'दैनिक इनाम' : 'Daily Reward';
    }
    if (id === 'video_ads') {
      return language === 'bn' ? 'ভিডিও অ্যাড' : language === 'hi' ? 'वीडियो विज्ञापन' : 'Watch Video Ads';
    }
    if (id === 'social_tasks') {
      return language === 'bn' ? 'সোশ্যাল টাস্ক' : language === 'hi' ? 'सोशल टास्क' : 'Social Tasks';
    }
    if (id === 'telegram') {
      return language === 'bn' ? 'টেলিগ্রাম' : language === 'hi' ? 'टेलीग्राम' : 'Telegram';
    }
    return fallback;
  };

  // 1. Categories State (Default to 'invite_earn' or 'daily_reward')
  const [selectedCategory, setSelectedCategory] = useState<EarnCategory>("invite_earn");
  
  // 2. Browser Referral Link State & Sharing
  const [copiedRef, setCopiedRef] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // 3. Ad Network injection
  const adConfig = getAdNetworkConfig(settings);
  useEffect(() => {
    if (adConfig.enabled) {
      injectAdNetworkScript(adConfig);
    }
  }, [adConfig.networkType, adConfig.enabled, adConfig.monetagScriptCode, adConfig.adsterraScriptTag]);

  // 4. Local completion state for zero-latency UI updates
  const [locallyCompletedIds, setLocallyCompletedIds] = useState<Set<string>>(new Set());
  const [completionBanner, setCompletionBanner] = useState<{ title: string; points: number } | null>(null);

  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [errorText, setErrorText] = useState<string | null>(null);

  // 5. Active Task Verification Modal State
  const [activeVerifyingTask, setActiveVerifyingTask] = useState<Mission | null>(null);
  const [countdownSeconds, setCountdownSeconds] = useState<number>(0);
  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    };
  }, []);

  // 6. Telegram Ad Modal state
  const [adModalMission, setAdModalMission] = useState<Mission | null>(null);

  // 7. Effective User Representation
  const effectiveUser: User = user || {
    id: userId,
    telegramId: userId.replace("tg-", ""),
    username: "user",
    fullName: "Member",
    email: "",
    points: 0,
    role: "user",
    isPremium: false,
    createdAt: new Date().toISOString(),
    last_active_at: new Date().toISOString()
  };

  // Browser-based Referral System Link
  const rawId = effectiveUser.telegramId || effectiveUser.id.replace(/^tg-/, "") || "101";
  const referralCode = `REF_${rawId}`;
  const webOrigin = typeof window !== "undefined" && window.location?.origin 
    ? window.location.origin 
    : "https://myteleflix.com";
  const referralLink = `${webOrigin}/?ref=${referralCode}`;

  const handleCopyReferralLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopiedRef(true);
      setShareFeedback("Referral link copied to clipboard!");
      setTimeout(() => {
        setCopiedRef(false);
        setShareFeedback(null);
      }, 3000);
    } catch {
      setShareFeedback("Failed to copy. Please copy manually.");
      setTimeout(() => setShareFeedback(null), 3000);
    }
  };

  const handleCopyReferralCode = async () => {
    try {
      await navigator.clipboard.writeText(referralCode);
      setCopiedCode(true);
      setShareFeedback(`Referral code ${referralCode} copied!`);
      setTimeout(() => {
        setCopiedCode(false);
        setShareFeedback(null);
      }, 3000);
    } catch {
      setShareFeedback("Failed to copy code.");
      setTimeout(() => setShareFeedback(null), 3000);
    }
  };

  // Web Sharing Handlers
  const handleNativeShare = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({
          title: "Watch & Earn Tokens",
          text: `🎬 Watch HD videos, complete tasks, and earn daily tokens! Join with my invite link to get an instant bonus:`,
          url: referralLink,
        });
        return;
      } catch {
        // User cancelled or unsupported; fallback to copy
      }
    }
    handleCopyReferralLink();
  };

  const handleWhatsAppShare = () => {
    const text = encodeURIComponent(`🎬 Watch HD videos & earn daily tokens!\n\nJoin with my referral link to get an instant bonus:\n${referralLink}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, "_blank");
  };

  const handleTelegramShare = () => {
    const text = encodeURIComponent(`🔥 Join now to watch HD videos and earn tokens daily!\n\nUse my invite link to get an instant welcome bonus: ${referralLink}`);
    window.open(`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${text}`, "_blank");
  };

  const handleFacebookShare = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`, "_blank");
  };

  // Check completion
  const isMissionCompleted = (m: Mission) => {
    if (locallyCompletedIds.has(m.id)) return true;
    return missionLogs.some(log => log.missionId === m.id);
  };

  // Active missions
  const activeMissionsList = useMemo(() => {
    return missions.filter(m => m.isActive !== false);
  }, [missions]);

  // Filtered list strictly by selected category
  const filteredMissions = useMemo(() => {
    return activeMissionsList.filter(m => classifyMissionCategory(m) === selectedCategory);
  }, [activeMissionsList, selectedCategory]);

  // Category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<EarnCategory, number> = {
      invite_earn: 0,
      daily_reward: 0,
      video_ads: 0,
      social_tasks: 0,
      telegram: 0,
    };
    activeMissionsList.forEach(m => {
      const cat = classifyMissionCategory(m);
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return counts;
  }, [activeMissionsList]);

  // Daily Streak Calculations
  const activeDaysCount = effectiveUser.activeDaysCount || 1;
  const isDailyRewardClaimedToday = useMemo(() => {
    return activeMissionsList.some(m => {
      const isDaily = classifyMissionCategory(m) === "daily_reward";
      return isDaily && isMissionCompleted(m);
    });
  }, [activeMissionsList, missionLogs, locallyCompletedIds]);

  // Task execution handler
  const handleStartTask = async (mission: Mission) => {
    if (effectiveUser.role === 'guest') {
      onTriggerAuth?.('earn');
      return;
    }

    if (isMissionCompleted(mission)) return;

    const cat = classifyMissionCategory(mission);
    const reward = mission.rewardPoints || mission.pointsReward || 250;

    // Daily Reward Instant Claim
    if (cat === "daily_reward") {
      setVerifyingId(mission.id);
      try {
        await onVerifyMission(mission.id);
        setLocallyCompletedIds(prev => new Set(prev).add(mission.id));
        setCompletionBanner({
          title: mission.title,
          points: reward,
        });
        setTimeout(() => setCompletionBanner(null), 4500);
      } catch (err: any) {
        setErrorText(err?.message || "Failed to claim reward");
      } finally {
        setVerifyingId(null);
      }
      return;
    }

    // Launch Target URL
    if (mission.url && mission.url !== "internal://daily_reward") {
      window.open(mission.url, "_blank", "noopener,noreferrer");
    }

    // Open Verification Modal with timer
    setActiveVerifyingTask(mission);
    const initialSeconds = mission.durationSeconds || (cat === "video_ads" ? 15 : cat === "telegram" ? 6 : 10);
    setCountdownSeconds(initialSeconds);

    let remaining = initialSeconds;
    if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
    countdownTimerRef.current = setInterval(() => {
      remaining -= 1;
      setCountdownSeconds(remaining);
      if (remaining <= 0) {
        if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
      }
    }, 1000);
  };

  const handleConfirmVerification = async () => {
    if (!activeVerifyingTask) return;
    const mission = activeVerifyingTask;
    const reward = mission.rewardPoints || mission.pointsReward || 250;

    setVerifyingId(mission.id);
    setErrorText(null);
    try {
      await onVerifyMission(mission.id);
      setLocallyCompletedIds(prev => new Set(prev).add(mission.id));
      setCompletionBanner({
        title: mission.title,
        points: reward,
      });
      setTimeout(() => setCompletionBanner(null), 4500);
      setActiveVerifyingTask(null);
    } catch (err: any) {
      setErrorText(err?.message || "Verification failed. Please try again.");
    } finally {
      setVerifyingId(null);
    }
  };

  // Platform icon helper
  const renderCategoryIcon = (cat: EarnCategory, size = 18) => {
    switch (cat) {
      case "invite_earn":
        return <Users size={size} className="text-indigo-400" />;
      case "daily_reward":
        return <Gift size={size} className="text-amber-400" />;
      case "video_ads":
        return <PlayCircle size={size} className="text-rose-400" />;
      case "social_tasks":
        return <Share2 size={size} className="text-sky-400" />;
      case "telegram":
        return <Send size={size} className="text-cyan-400" />;
    }
  };

  return (
    <div id="earn-screen" className="space-y-4 max-w-xl mx-auto px-2 sm:px-0 pb-28">
      
      {/* ============================================================ */}
      {/* 1. TOP HORIZONTAL CATEGORIES BAR (LEFT TO RIGHT)            */}
      {/* Options: 1. Invite & Earn | 2. Daily Reward | 3. Video Ads  */}
      {/*          4. Social Tasks | 5. Telegram                      */}
      {/* ============================================================ */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <span className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-wider">
            {language === 'bn' ? 'রিওয়ার্ড ও ইনকাম হাব' : language === 'hi' ? 'रिवॉर्ड्स और अर्निंग हब' : 'Rewards & Earn Hub'}
          </span>
          <div className="flex items-center gap-1.5 bg-[#182232] border border-[#243247] px-2.5 py-1 rounded-lg shadow-sm">
            <TokenIcon size={13} />
            <span className="text-xs font-mono font-black text-amber-400">
              {effectiveUser.points.toLocaleString()} {language === 'bn' ? 'টোকেন' : language === 'hi' ? 'टोकन' : 'Tokens'}
            </span>
          </div>
        </div>

        {/* Category Navigation Bar: Solid Scrollable Left-to-Right without Neon or Washed Gradients */}
        <div 
          id="earn-categories-bar"
          className="flex items-center gap-1.5 overflow-x-auto no-scrollbar p-1.5 bg-[#0F141E] border border-[#243247] rounded-2xl sticky top-1 z-20 shadow-md"
        >
          {EARN_CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            const count = categoryCounts[cat.id] || 0;
            const label = getCategoryLabel(cat.id, cat.label);

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`py-2 px-3 rounded-xl text-xs font-mono font-bold transition-colors flex items-center gap-1.5 shrink-0 whitespace-nowrap cursor-pointer select-none active:scale-95 ${
                  isSelected
                    ? "bg-[#1E2B3E] border border-amber-500/80 text-white shadow-sm"
                    : "bg-[#131924] text-slate-300 hover:text-white hover:bg-[#182232] border border-[#243247]"
                }`}
              >
                <Icon size={15} className={isSelected ? "text-amber-400" : "text-slate-400"} />
                <span>{label}</span>

                {cat.id === "invite_earn" ? (
                  <span className="text-[9px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.2 rounded-md">
                    {language === 'bn' ? '+বোনাস' : language === 'hi' ? '+बोनस' : '+Bonus'}
                  </span>
                ) : (
                  <span className={`text-[10px] font-normal px-1.5 py-0.2 rounded-md ${
                    isSelected ? "bg-white/10 text-slate-200" : "text-slate-400"
                  }`}>
                    ({count})
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Floating Share Feedback Toast */}
      {shareFeedback && (
        <div className="bg-[#182232] border border-[#243247] text-white p-3 rounded-2xl shadow-lg flex items-center justify-between gap-3 animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-200">
            <CheckCircle2 size={16} className="text-emerald-400" />
            <span>{shareFeedback}</span>
          </div>
          <button onClick={() => setShareFeedback(null)} className="text-slate-400 hover:text-white p-1">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Floating Instant Notification Banner */}
      {completionBanner && (
        <div className="bg-[#182232] border border-emerald-500/40 text-white p-3 rounded-2xl shadow-lg flex items-center justify-between gap-3 animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="p-1.5 bg-emerald-500/20 rounded-xl text-emerald-400 shrink-0">
              <CheckCircle2 size={18} />
            </div>
            <div className="min-w-0">
              <h5 className="text-xs font-bold text-white truncate">টোকেন সফলভাবে যোগ হয়েছে</h5>
              <p className="text-[10px] text-slate-400 truncate">{completionBanner.title}</p>
            </div>
          </div>
          <span className="text-xs font-mono font-black bg-amber-500/15 border border-amber-500/30 text-amber-300 px-2.5 py-1 rounded-xl shrink-0 flex items-center gap-1.5">
            <TokenIcon size={12} />
            +{completionBanner.points} টোকেন
          </span>
        </div>
      )}

      {/* ============================================================ */}
      {/* 2. CATEGORY 1: INVITE & EARN (FULL DETAILED PAGE)           */}
      {/* ============================================================ */}
      {selectedCategory === "invite_earn" && (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Main Hero Card for Browser-based Referral System */}
          <div className="bg-[#121824] border border-[#243247] rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
            
            {/* Header */}
            <div className="flex items-center justify-between gap-3 border-b border-[#243247] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
                  <Users size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                      ব্রাউজার রেফারেল হাব
                    </span>
                    <span className="text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded-full">
                      লাইফটাইম কমিশন
                    </span>
                  </div>
                  <h3 className="text-sm sm:text-base font-black text-white tracking-tight">
                    বন্ধু ইনভাইট করে আনলিমিটেড টোকেন অর্জন করুন
                  </h3>
                </div>
              </div>
            </div>

            {/* Value Proposition Box: Solid High-Contrast */}
            <div className="p-3.5 rounded-2xl bg-[#182232] border border-[#243247] flex items-center gap-3">
              <Sparkles size={20} className="text-amber-400 shrink-0" />
              <p className="text-xs text-slate-300 leading-relaxed">
                প্রতি ভেরিফাইড বন্ধুর জন্য সরাসরি <strong className="text-amber-300 font-bold">+২০০ টোকেন</strong> বোনাস, সাথে তারা ব্রাউজারে যত কাজ ও বিজ্ঞাপন দেখবে তার থেকে <strong className="text-emerald-400 font-bold">১০% লাইফটাইম প্যাসিভ কমিশন</strong>!
              </p>
            </div>

            {/* Browser Referral Link Bar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className="text-slate-400">আপনার ইউনিক রেফারেল লিংক:</span>
                <span className="text-amber-400 font-bold">{referralCode}</span>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex-1 bg-[#0A0E15] border border-[#243247] rounded-xl px-3 py-2.5 text-xs font-mono text-slate-200 truncate select-all">
                  {referralLink}
                </div>

                <button
                  type="button"
                  onClick={handleCopyReferralLink}
                  className={`px-4 py-2.5 rounded-xl text-xs font-mono font-black transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-sm active:scale-95 ${
                    copiedRef 
                      ? "bg-emerald-600 text-white" 
                      : "bg-amber-500 hover:bg-amber-400 text-[#0A0E15]"
                  }`}
                >
                  {copiedRef ? <Check size={14} strokeWidth={3} /> : <Copy size={14} />}
                  <span>{copiedRef ? "কপি হয়েছে" : "কপি লিংক"}</span>
                </button>
              </div>
            </div>

            {/* Quick Share Toolbar for Browser Users */}
            <div className="space-y-2 pt-1">
              <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider block">
                বন্ধুদের সাথে শেয়ার করুন
              </span>
              <div className="grid grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={handleWhatsAppShare}
                  className="py-2.5 px-1 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 shadow-sm"
                >
                  <MessageCircle size={14} />
                  <span>WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={handleTelegramShare}
                  className="py-2.5 px-1 rounded-xl bg-[#0284C7]/20 hover:bg-[#0284C7]/30 border border-[#0284C7]/40 text-sky-300 text-xs font-mono font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 shadow-sm"
                >
                  <Send size={14} />
                  <span>Telegram</span>
                </button>

                <button
                  type="button"
                  onClick={handleFacebookShare}
                  className="py-2.5 px-1 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs font-mono font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 shadow-sm"
                >
                  <Share2 size={14} />
                  <span>Facebook</span>
                </button>

                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="py-2.5 px-1 rounded-xl bg-[#1E2B3E] hover:bg-[#25364E] border border-[#243247] text-slate-200 text-xs font-mono font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 shadow-sm"
                >
                  <ExternalLink size={14} />
                  <span>Share</span>
                </button>
              </div>
            </div>

            {/* Referral Code Quick Copy */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#0A0E15] border border-[#243247] text-xs font-mono">
              <span className="text-slate-400">রেফারেল কোড:</span>
              <div className="flex items-center gap-2">
                <span className="font-bold text-amber-400">{referralCode}</span>
                <button
                  type="button"
                  onClick={handleCopyReferralCode}
                  className="text-slate-400 hover:text-white p-1 rounded hover:bg-[#182232] transition"
                  title="Copy Referral Code"
                >
                  {copiedCode ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                </button>
              </div>
            </div>
          </div>

          {/* How It Works (3-Step Illustrated Guide) */}
          <div className="bg-[#121824] border border-[#243247] rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <HelpCircle size={14} className="text-amber-400" />
              <span>রেফারেল যেভাবে কাজ করে</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-[#182232] border border-[#243247] space-y-1.5">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-300 font-bold font-mono flex items-center justify-center text-[11px]">
                  ১
                </div>
                <h5 className="font-bold text-white">লিংক শেয়ার করুন</h5>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আপনার রেফারেল লিংক বন্ধুদের হোয়াটসঅ্যাপ, টেলিগ্রাম বা সোশ্যাল মিডিয়ায় পাঠান।
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#182232] border border-[#243247] space-y-1.5">
                <div className="w-6 h-6 rounded-full bg-sky-500/20 text-sky-300 font-bold font-mono flex items-center justify-center text-[11px]">
                  ২
                </div>
                <h5 className="font-bold text-white">বন্ধু যুক্ত হবে</h5>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আপনার বন্ধু ব্রাউজারে প্ল্যাটফর্ম ওপেন করে অ্যাকাউন্ট খুলে কাজ ও ভিডিও দেখা শুরু করবে।
                </p>
              </div>

              <div className="p-3 rounded-xl bg-[#182232] border border-[#243247] space-y-1.5">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-300 font-bold font-mono flex items-center justify-center text-[11px]">
                  ৩
                </div>
                <h5 className="font-bold text-white">টোকেন ও কমিশন পান</h5>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  আপনি তাত্ক্ষণিক বোনাস টোকেন পাবেন এবং তাদের প্রতিটি কাজের থেকে ১০% লাইফটাইম টোকেন পাবেন!
                </p>
              </div>
            </div>
          </div>

          {/* Full Interactive Referral Dashboard & Milestones Module */}
          <div className="space-y-3">
            <ReferralModule user={effectiveUser} />
          </div>

        </div>
      )}

      {/* ============================================================ */}
      {/* 3. CATEGORY 2: DAILY REWARD (STREAK CALENDAR & TASKS)        */}
      {/* ============================================================ */}
      {selectedCategory === "daily_reward" && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          <div className="bg-[#121824] border border-[#243247] rounded-3xl p-4 sm:p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between gap-3 border-b border-[#243247] pb-3">
              <div className="flex items-center gap-2.5">
                <span className="p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
                  <Flame size={20} />
                </span>
                <div>
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                    ধারাবাহিক স্ট্রিক বোনাস
                  </span>
                  <h4 className="text-sm sm:text-base font-black text-white tracking-tight">
                    ৭ দিনের ডেইলি চেক-ইন রিওয়ার্ড
                  </h4>
                </div>
              </div>

              <span className="text-xs font-mono font-bold text-amber-300 bg-[#182232] px-2.5 py-1 rounded-xl border border-[#243247] flex items-center gap-1">
                <TokenIcon size={12} />
                +৫০ থেকে +৩৫০ টোকেন
              </span>
            </div>

            {/* 7-Day Visual Calendar: Solid, Sharp, Organic */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Calendar size={13} className="text-amber-400" />
                  <span>দিন {activeDaysCount} / ৭ দিনের স্ট্রিক</span>
                </span>
                <span className={isDailyRewardClaimedToday ? "text-emerald-400 font-bold" : "text-amber-400 font-bold"}>
                  {isDailyRewardClaimedToday ? "✓ আজকের বোনাস ক্লেইমড" : "ক্লেম করার জন্য প্রস্তুত"}
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {[1, 2, 3, 4, 5, 6, 7].map((day) => {
                  const isPast = day < activeDaysCount;
                  const isCurrent = day === activeDaysCount;
                  return (
                    <div 
                      key={day}
                      className={`py-3 rounded-2xl text-center border text-[11px] font-mono transition-all flex flex-col items-center justify-center gap-1 shadow-sm ${
                        isPast 
                          ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold"
                          : isCurrent
                          ? "bg-[#1E2B3E] border-2 border-amber-400 text-white font-black"
                          : "bg-[#0F141E] border border-[#243247] text-slate-400"
                      }`}
                    >
                      <span className="text-[9px] uppercase font-bold text-slate-400">দিন {day}</span>
                      {isPast ? (
                        <Check size={14} className="text-emerald-400 stroke-[3]" />
                      ) : (
                        <span className={isCurrent ? "text-amber-300 font-black text-xs" : "text-slate-300"}>
                          +{day * 50}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 4. CATEGORY 3: WATCH VIDEO ADS (REWARDED ADS & TRAILERS)     */}
      {/* ============================================================ */}
      {selectedCategory === "video_ads" && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          <div 
            onClick={() => {
              if (adConfig.enabled) {
                window.open("https://youtube.com", "_blank");
              }
            }}
            className="p-4 rounded-3xl bg-[#121824] border border-[#243247] flex items-center justify-between gap-3 cursor-pointer hover:border-[#354866] transition shadow-sm"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
                <PlayCircle size={22} />
              </div>
              <div>
                <span className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  ভিডিও বিজ্ঞাপন
                </span>
                <h5 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  ১৫ থেকে ৩০ সেকেন্ডের স্পন্সরড ভিডিও দেখুন
                </h5>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-[#182232] border border-[#243247] px-3 py-1.5 rounded-xl shrink-0">
              <TokenIcon size={13} />
              <span className="text-xs font-mono font-black text-amber-400">
                +{adConfig.adRewardPoints || 350} টোকেন
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 5. CATEGORY 4: SOCIAL TASKS (YOUTUBE, FB, TWITTER, WEB)     */}
      {/* ============================================================ */}
      {selectedCategory === "social_tasks" && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          <div className="p-4 rounded-3xl bg-[#121824] border border-[#243247] flex items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center shrink-0">
                <Share2 size={22} />
              </div>
              <div>
                <span className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300 border border-sky-500/30">
                  সোশ্যাল মিশন
                </span>
                <h5 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  অফিসিয়াল সোশ্যাল পেজ ফলো ও সাবস্ক্রাইব করুন
                </h5>
              </div>
            </div>

            <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/15 border border-emerald-500/30 px-3 py-1 rounded-xl">
              তাত্ক্ষণিক রিওয়ার্ড
            </span>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 6. CATEGORY 5: TELEGRAM (OFFICIAL TELEGRAM CHANNELS)        */}
      {/* ============================================================ */}
      {selectedCategory === "telegram" && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          <div className="p-4 rounded-3xl bg-[#121824] border border-[#243247] flex items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#0284C7]/20 border border-[#0284C7]/40 text-sky-400 flex items-center justify-center shrink-0">
                <Send size={22} />
              </div>
              <div>
                <span className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-[#0284C7]/20 text-sky-300 border border-[#0284C7]/30">
                  অফিসিয়াল টেলিগ্রাম
                </span>
                <h5 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  অফিসিয়াল টেলিগ্রাম চ্যানেল ও কমিউনিটিতে যুক্ত হোন
                </h5>
              </div>
            </div>

            <span className="text-xs font-mono text-sky-300 font-bold bg-[#0284C7]/15 border border-[#0284C7]/30 px-3 py-1 rounded-xl">
              ১-ক্লিক জয়েন
            </span>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* 7. TASK CARDS LIST (FOR ACTIVE TASK CATEGORIES)              */}
      {/* Only rendered for task categories, NOT for invite_earn       */}
      {/* ============================================================ */}
      {selectedCategory !== "invite_earn" && (
        <div className="space-y-2.5">
          {filteredMissions.length === 0 ? (
            <div className="py-12 text-center bg-[#121824] border border-dashed border-[#243247] rounded-3xl p-6 space-y-2">
              {renderCategoryIcon(selectedCategory, 28)}
              <h5 className="text-sm font-bold text-white font-mono">এই ক্যাটাগরিতে বর্তমানে কোনো টাস্ক নেই</h5>
              <p className="text-xs text-slate-400">
                নতুন স্পন্সরড টাস্ক পাবলিশ হওয়ার সাথে সাথে এখানে প্রদর্শিত হবে।
              </p>
            </div>
          ) : (
            filteredMissions.map((mission) => {
              const done = isMissionCompleted(mission);
              const reward = mission.rewardPoints || mission.pointsReward || 300;
              const isCurrentlyVerifying = verifyingId === mission.id;
              const duration = mission.durationSeconds || (selectedCategory === "video_ads" ? 15 : selectedCategory === "telegram" ? 6 : 10);

              return (
                <div
                  key={mission.id}
                  className={`bg-[#121824] border rounded-2xl p-3.5 flex items-center justify-between gap-3 transition-colors shadow-sm ${
                    done 
                      ? "opacity-60 bg-[#0F141E] border-[#1E283A]" 
                      : "border-[#243247] hover:border-[#354866]"
                  }`}
                >
                  {/* Left Side: Category Icon + Details */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-11 h-11 rounded-xl bg-[#0A0E15] border border-[#243247] flex items-center justify-center shrink-0">
                      {renderCategoryIcon(selectedCategory, 20)}
                    </div>

                    <div className="min-w-0 space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[9.5px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-[#182232] text-slate-300 border border-[#243247] flex items-center gap-1">
                          <Clock size={9} />
                          {selectedCategory === "daily_reward" ? "তাত্ক্ষণিক" : `${duration}s`}
                        </span>
                        <span className="text-[9.5px] font-mono font-bold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <TokenIcon size={10} />
                          +{reward} টোকেন
                        </span>
                      </div>

                      <h5 className="text-xs sm:text-sm font-bold text-white truncate leading-snug">
                        {mission.title}
                      </h5>

                      {mission.description && (
                        <p className="text-[10px] text-slate-400 truncate">
                          {mission.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right Side: Action Button */}
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    {done ? (
                      <button
                        disabled
                        className="px-3.5 py-1.5 min-h-[34px] bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-bold rounded-xl text-[11px] font-mono uppercase flex items-center justify-center gap-1 select-none"
                      >
                        <Check size={12} strokeWidth={3} /> ক্লেইমড
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleStartTask(mission)}
                        disabled={isCurrentlyVerifying}
                        className="bg-amber-500 hover:bg-amber-400 text-[#0A0E15] font-black px-4 py-2 rounded-xl text-xs flex items-center gap-1 active:scale-95 transition-all cursor-pointer select-none shadow-sm disabled:opacity-50"
                      >
                        {isCurrentlyVerifying ? (
                          <>
                            <Loader2 size={12} className="animate-spin text-[#0A0E15]" />
                            <span>যাচাই হচ্ছে...</span>
                          </>
                        ) : (
                          <>
                            <span>{selectedCategory === "video_ads" ? "দেখুন" : selectedCategory === "telegram" ? "জয়েন" : "শুরু"}</span>
                            <ArrowRight size={12} strokeWidth={3} />
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/* 8. ACTIVE VERIFICATION COUNTDOWN MODAL                       */}
      {/* ============================================================ */}
      {activeVerifyingTask && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#121824] border border-[#243247] rounded-3xl p-5 max-w-sm w-full space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#243247] pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                <h4 className="text-sm font-bold text-white font-mono">টাস্ক ভেরিফিকেশন</h4>
              </div>
              <button 
                onClick={() => {
                  if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);
                  setActiveVerifyingTask(null);
                }}
                className="text-slate-400 hover:text-white p-1 cursor-pointer select-none active:scale-95 duration-75"
              >
                <X size={18} />
              </button>
            </div>

            <div className="text-center py-2 space-y-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Clock size={28} className="animate-spin" />
              </div>
              <h5 className="text-sm font-bold text-white">{activeVerifyingTask.title}</h5>
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedCategory === "telegram"
                  ? "দয়া করে অফিসিয়াল টেলিগ্রাম চ্যানেলে যুক্ত হোন। টাইমার শেষ হলে ক্লেইম সক্রিয় হবে।"
                  : "দয়া করে স্পন্সরড টাস্ক সম্পূর্ণ দেখুন। টাইমার শেষ হলে ক্লেইম বাটন সক্রিয় হবে।"}
              </p>
            </div>

            <div className="p-3 bg-[#0A0E15] rounded-2xl border border-[#243247] text-center font-mono">
              {countdownSeconds > 0 ? (
                <span className="text-amber-400 font-bold text-xs">
                  যাচাই সম্পন্ন হতে বাকি: <span className="text-sm font-black">{countdownSeconds}s</span>
                </span>
              ) : (
                <span className="text-emerald-400 font-bold text-xs flex items-center justify-center gap-1">
                  <CheckCircle2 size={14} /> ভেরিফিকেশন প্রস্তুত!
                </span>
              )}
            </div>

            {errorText && (
              <p className="text-xs text-rose-400 text-center font-sans font-medium">{errorText}</p>
            )}

            <button
              onClick={handleConfirmVerification}
              disabled={countdownSeconds > 0 || verifyingId !== null}
              className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-[#0A0E15] font-black rounded-xl text-xs font-mono uppercase tracking-wide border border-amber-400/30 shadow-sm active:scale-95 transition cursor-pointer flex items-center justify-center gap-2 select-none disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {verifyingId ? (
                <>
                  <Loader2 size={14} className="animate-spin text-[#0A0E15]" />
                  <span>টোকেন জমা হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Check size={14} strokeWidth={3} />
                  <span className="flex items-center gap-1.5">
                    <TokenIcon size={14} />
                    ক্লেইম +{activeVerifyingTask.rewardPoints || activeVerifyingTask.pointsReward || 250} টোকেন
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Telegram Ad Modal */}
      {adModalMission && (
        <TelegramAdModal
          taskTitle={adModalMission.title}
          rewardPoints={adModalMission.rewardPoints || adModalMission.pointsReward || 500}
          onAdCompleted={() => {
            setAdModalMission(null);
          }}
          onAdDismissed={() => setAdModalMission(null)}
        />
      )}

    </div>
  );
}
