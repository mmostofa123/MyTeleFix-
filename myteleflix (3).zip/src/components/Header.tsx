/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { User as UserType, Notification } from "../types";
import TokenIcon from "./TokenIcon";
import { User as UserIcon, Bell, X, AlertTriangle, CheckCircle2 } from "lucide-react";
import { NotificationCenterTray } from "./NotificationCenterTray";
import { auth } from "../services/firebase";
import { getUserProfileDB } from "../db";
import { getDiceBearAvatar, isUnsplashOrBrokenPhoto } from "../utils/avatar";

import { AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";

interface HeaderProps {
  user: UserType;
  notifications?: Notification[];
  onMarkRead?: (id: string) => void;
  onMarkAllRead?: () => void;
  onClearAll?: () => void;
  onNavigate?: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
  activeTab?: string;
  onOpenAdmin?: () => void;
  onSecretAdminTrigger?: () => void;
  currentLanguage?: AppLanguage;
}

const DEFAULT_SIGN_IN = "Sign In Now";

function HeaderComponent({ 
  user, 
  notifications = [], 
  onMarkRead, 
  onMarkAllRead,
  onClearAll,
  onNavigate, 
  activeTab, 
  onOpenAdmin,
  onSecretAdminTrigger,
  currentLanguage: propLanguage
}: HeaderProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleLangChange = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleLangChange);
  }, []);

  const fullText = t("sign_in_now", activeLanguage, DEFAULT_SIGN_IN);
  const isGuest = !user || user.role === 'guest' || !user.id || user.id.startsWith('guest_') || user.id === 'tg-guest';
  const tapTimestampsRef = React.useRef<number[]>([]);
  const [showNotifPopover, setShowNotifPopover] = useState(false);

  const unreadCount = (notifications || []).filter(n => !(n.is_read ?? n.isRead)).length;
  const prevUnreadRef = React.useRef(unreadCount);
  const [isBouncing, setIsBouncing] = useState(false);

  // Fast & Reliable Instant Avatar Hydration
  const [imageError, setImageError] = useState(false);
  const [resolvedPhoto, setResolvedPhoto] = useState<string | null>(() => {
    // 1. Direct prop check
    if (user?.photoURL || user?.photoUrl) {
      return user.photoURL || user.photoUrl || null;
    }
    // 2. Immediate LocalStorage lookup to prevent flash/flicker
    if (typeof window !== "undefined") {
      try {
        const saved = localStorage.getItem("myteleflix_user");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed?.photoURL || parsed?.photoUrl) {
            return parsed.photoURL || parsed.photoUrl;
          }
        }
      } catch (e) {}
    }
    // 3. Direct Firebase auth lookup
    try {
      if (auth?.currentUser?.photoURL) {
        return auth.currentUser.photoURL;
      }
    } catch (e) {}
    return null;
  });

  // Re-sync avatar whenever user prop updates or cached DB changes
  useEffect(() => {
    const photo = user?.photoURL || user?.photoUrl;
    if (photo) {
      setResolvedPhoto(photo);
      setImageError(false);
    } else if (user?.email) {
      getUserProfileDB(user.email).then((cached) => {
        const cachedPhoto = cached?.photoURL || (cached as any)?.photoUrl;
        if (cachedPhoto) {
          setResolvedPhoto(cachedPhoto);
          setImageError(false);
        }
      }).catch(() => {});
    }
  }, [user?.photoURL, user?.photoUrl, user?.email]);

  useEffect(() => {
    if (unreadCount > prevUnreadRef.current) {
      setIsBouncing(true);
      const timer = setTimeout(() => setIsBouncing(false), 2200);
      return () => clearTimeout(timer);
    }
    prevUnreadRef.current = unreadCount;
  }, [unreadCount]);

  const handleAvatarClick = () => {
    const now = Date.now();
    tapTimestampsRef.current = tapTimestampsRef.current.filter((t: number) => now - t <= 2000);
    tapTimestampsRef.current.push(now);

    if (tapTimestampsRef.current.length >= 5) {
      tapTimestampsRef.current = [];
      if (onSecretAdminTrigger) {
        onSecretAdminTrigger();
        return;
      }
    }

    onNavigate?.('profile');
  };

  // Detect whether the active view is Guest Sign-Up / Onboarding / Profile Screen
  const [isOnSignUpView, setIsOnSignUpView] = useState(false);

  useEffect(() => {
    if (!isGuest) return;

    if (activeTab) {
      setIsOnSignUpView(activeTab === 'profile');
      return;
    }

    const profileEl = document.getElementById('profile-screen-container');
    const isVisible = Boolean(profileEl && profileEl.closest('.hidden') === null);
    setIsOnSignUpView(isVisible);
  }, [isGuest, activeTab]);

  // Typewriter animation state for guest users
  const [visibleCount, setVisibleCount] = useState(0);
  const [phase, setPhase] = useState<'TYPING' | 'HOLD' | 'REVERSING' | 'REST'>('TYPING');
  const [showSparkle, setShowSparkle] = useState(false);

  useEffect(() => {
    if (!isGuest) return;

    // When on the Guest Sign-Up / Onboarding screen, IMMEDIATELY freeze/stop the loop
    // and keep the text continuously visible in its rectangular box as a solid static element
    if (isOnSignUpView) {
      setVisibleCount(fullText.length);
      setPhase('HOLD');
      setShowSparkle(false);
      return;
    }

    let timer: NodeJS.Timeout;

    if (phase === 'TYPING') {
      if (visibleCount < fullText.length) {
        // Relaxed slow-motion typing pace (120ms per character)
        timer = setTimeout(() => {
          setVisibleCount((prev) => prev + 1);
        }, 120);
      } else {
        // Fully visible: pause and hold for 8-10 seconds (9000ms)
        setPhase('HOLD');
      }
    } else if (phase === 'HOLD') {
      // Extended hold duration: 9 seconds for ample reading time
      timer = setTimeout(() => {
        setPhase('REVERSING');
      }, 9000);
    } else if (phase === 'REVERSING') {
      if (visibleCount > 0) {
        // Relaxed slow-motion reverse pace (95ms per character)
        timer = setTimeout(() => {
          setVisibleCount((prev) => prev - 1);
        }, 95);
      } else {
        // Text fully disappeared: trigger micro sparkle burst and rest
        setPhase('REST');
        setShowSparkle(true);
      }
    } else if (phase === 'REST') {
      const sparkleTimer = setTimeout(() => {
        setShowSparkle(false);
      }, 750);

      const restartTimer = setTimeout(() => {
        setPhase('TYPING');
      }, 1400);

      return () => {
        clearTimeout(sparkleTimer);
        clearTimeout(restartTimer);
      };
    }

    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [isGuest, phase, visibleCount, isOnSignUpView, fullText]);

  return (
    <header 
      id="main-header" 
      className="sticky top-0 z-50 bg-[#161618] border-b border-[#2A2A2E] px-4 py-3 flex items-center justify-between text-white"
    >
      <style>{`
        @keyframes sparkle-flare {
          0% {
            transform: scale(0) rotate(0deg);
            opacity: 0;
          }
          50% {
            transform: scale(1.25) rotate(45deg);
            opacity: 1;
          }
          100% {
            transform: scale(0) rotate(90deg);
            opacity: 0;
          }
        }
        .animate-sparkle {
          animation: sparkle-flare 0.75s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>

      {/* 1. Text-based Brand Identity (Netflix / OTT Typography) */}
      <div 
        onClick={() => {
          setIsOnSignUpView(false);
          onNavigate?.('home');
        }} 
        className="flex flex-col cursor-pointer select-none active:scale-95 transition-transform duration-75 group"
      >
        <div className="flex items-center gap-0.5 leading-tight">
          <span className="font-extrabold text-white text-lg sm:text-xl tracking-tight">
            My
          </span>
          <span className="font-extrabold text-lg sm:text-xl tracking-tight text-[#E50914]">
            TeleFlix
          </span>
        </div>
        <span className="text-[8.5px] sm:text-[9px] font-mono text-[#8C8C8C] font-semibold uppercase tracking-[0.22em] leading-none mt-0.5">
          OTT STREAM
        </span>
      </div>

      {/* 2. Right Side: Coin/Wallet Badge & Profile Avatar */}
      <div className="flex items-center gap-3">
        {/* Only authenticated users show the reward points counter - Strictly static display box */}
        {!isGuest && (
          <div 
            id="header-points-display" 
            className="border border-amber-500/30 bg-amber-950/20 text-amber-400 font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 select-none pointer-events-none cursor-default"
          >
            <TokenIcon size={14} />
            <span className="text-xs font-bold text-white font-mono tracking-tight">
              {user.points.toLocaleString()}
            </span>
          </div>
        )}

        {/* Notification Bell Button & Notification Center Tray (VRMS-3 ULTRA Phase 12) */}
        {!isGuest && (
          <div className="relative flex items-center">
            <button
              type="button"
              id="header-notifications-bell"
              onClick={() => {
                const nextState = !showNotifPopover;
                setShowNotifPopover(nextState);
                setIsBouncing(false);
                if (nextState && unreadCount > 0 && onMarkAllRead) {
                  onMarkAllRead();
                }
              }}
              className={`relative p-2 rounded-full bg-[#1F1F24] hover:bg-[#2A2A30] border border-[#2A2A2E] text-slate-300 hover:text-white transition active:scale-95 cursor-pointer flex items-center justify-center ${
                unreadCount > 0 ? 'ring-2 ring-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.4)]' : ''
              }`}
              title="Notifications"
            >
              <Bell size={17} className={unreadCount > 0 ? "text-red-400" : "text-slate-400"} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-600 text-white font-extrabold text-[9px] w-4 h-4 rounded-full flex items-center justify-center border border-[#161618] animate-pulse shadow-[0_0_8px_#EF4444]">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>

            {/* Dedicated VRMS-3 Notification Center Tray */}
            <NotificationCenterTray
              isOpen={showNotifPopover}
              onClose={() => setShowNotifPopover(false)}
              notifications={notifications}
              onMarkRead={(id) => onMarkRead?.(id)}
              onMarkAllRead={() => onMarkAllRead?.()}
              onClearAll={() => onClearAll?.()}
              unreadCount={unreadCount}
            />
          </div>
        )}

        {/* Unauthenticated Guest: Compact Circular Profile Icon with Slim Rectangular Badge */}
        {isGuest ? (
          <div
            id="header-guest-auth-trigger"
            onClick={() => {
              setIsOnSignUpView(true);
              onNavigate?.('profile');
            }}
            className="relative flex items-center justify-end cursor-pointer select-none group"
            title="Sign In to unlock VIP Perks"
            role="button"
            tabIndex={0}
          >
            {/* Slim, Compact Rectangular "Sign In Now" Box Attached to the Left */}
            <div 
              className={`absolute right-full mr-1 origin-right transition-all duration-300 ease-out flex items-center z-10 ${
                !isOnSignUpView && phase === 'REST' && visibleCount === 0
                  ? 'opacity-0 scale-x-0 pointer-events-none' 
                  : 'opacity-100 scale-x-100'
              }`}
            >
              <div className="flex items-center gap-1.5 py-0.5 px-2 rounded-md bg-[#18191E]/95 backdrop-blur-md border border-[#2F3138] shadow-sm text-white whitespace-nowrap">
                <span className={`w-1 h-1 rounded-full bg-[#E50914] shrink-0 ${!isOnSignUpView ? 'animate-pulse' : ''}`} />
                <span className="text-[10px] font-bold tracking-tight text-slate-100 font-mono flex items-center">
                  {isOnSignUpView ? fullText : fullText.slice(0, visibleCount)}
                  {!isOnSignUpView && phase === 'TYPING' && (
                    <span className="inline-block w-[1.5px] h-2.5 bg-[#E50914] ml-0.5 animate-pulse" />
                  )}
                </span>
              </div>
            </div>

            {/* Premium Profile Icon Container with Metallic/Neon Ring & High-Contrast Icon */}
            <div 
              id="header-guest-avatar"
              className="relative z-20 w-8 h-8 rounded-full bg-[#1A1B22]/90 backdrop-blur-md border border-red-500/40 group-hover:border-red-500/80 shadow-[0_0_8px_rgba(229,9,20,0.25)] ring-1 ring-white/10 flex items-center justify-center text-white transition-all duration-200 shrink-0 active:scale-95"
            >
              <UserIcon size={16} strokeWidth={2.3} className="text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" />

              {/* Micro Sparkle Burst when text fully disappears (only during active typewriter animation) */}
              {!isOnSignUpView && showSparkle && (
                <div className="absolute inset-0 pointer-events-none z-30">
                  {/* Sparkle 1: Top-Left star flare */}
                  <span className="absolute -top-1 -left-1 w-2.5 h-2.5 animate-sparkle pointer-events-none">
                    <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-amber-300 drop-shadow-[0_0_6px_#F59E0B]">
                      <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                    </svg>
                  </span>
                  {/* Sparkle 2: Bottom-Left mini star flare */}
                  <span className="absolute -bottom-0.5 -left-1.5 w-2 h-2 animate-sparkle pointer-events-none" style={{ animationDelay: '80ms' }}>
                    <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full text-emerald-300 drop-shadow-[0_0_6px_#10B981]">
                      <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
                    </svg>
                  </span>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Authenticated User Profile Avatar */
          <div 
            id="header-user-avatar-trigger"
            onClick={handleAvatarClick}
            className="relative cursor-pointer active:scale-95 transition-transform duration-100 select-none shrink-0 flex items-center justify-center"
            aria-label="Profile navigation"
            role="button"
            tabIndex={0}
          >
            {/* Refined Avatar Container (w-9 h-9 sm:w-10 sm:h-10) with Subtle 1.5px Metallic Ring */}
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-full p-[1.5px] border-[1.5px] border-[#FFB800]/70 bg-gradient-to-tr from-[#FFB800]/80 via-[#FFE082]/60 to-[#FF8F00]/80 shadow-[0_0_8px_rgba(255,184,0,0.25)] flex items-center justify-center overflow-hidden">
              <div className="w-full h-full rounded-full overflow-hidden bg-[#14151B] flex items-center justify-center">
                {resolvedPhoto && !imageError && !isUnsplashOrBrokenPhoto(resolvedPhoto) ? (
                  <img
                    id="header-user-avatar"
                    src={resolvedPhoto}
                    alt={user.displayName || user.fullName || "User Avatar"}
                    className="w-full h-full rounded-full object-cover bg-[#161618] block select-none"
                    referrerPolicy="no-referrer"
                    loading="eager"
                    onError={() => {
                      setImageError(true);
                    }}
                  />
                ) : (
                  /* Robust Dynamic Gender DiceBear Avatar (100+ variations) */
                  <img
                    id="header-user-avatar"
                    src={getDiceBearAvatar(user?.gender, user?.id || user?.telegramId || user?.email)}
                    alt={user.displayName || user.fullName || "User Avatar"}
                    className="w-full h-full rounded-full object-cover bg-[#161618] block select-none"
                    referrerPolicy="no-referrer"
                    loading="eager"
                  />
                )}
              </div>
            </div>

            {/* VIP / Premium Indicator */}
            {user.isPremium && (
              <span 
                className="absolute -bottom-0.5 -right-0.5 bg-[#E50914] text-white rounded-full p-0.5 border-2 border-[#161618] shadow-md z-10"
                title="VIP Member"
              >
                <span className="block w-2 h-2 bg-amber-400 rounded-full"></span>
              </span>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

const Header = React.memo(HeaderComponent);
export default Header;

