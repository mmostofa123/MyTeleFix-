/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * EditProfileModal: Strict enterprise profile editing modal
 * Only DisplayName, Gender Persona, and Telegram Username are editable.
 * Primary Gmail and Join Date are frozen (non-editable).
 * Commits permanently to IndexedDB + LocalStorage via db.ts and Firestore.
 */

import React, { useState, useEffect, useMemo } from "react";
import { 
  X, 
  User as UserIcon, 
  Send, 
  Lock, 
  Calendar, 
  Check, 
  Loader2, 
  Mail, 
  ShieldCheck,
  Sparkles,
  RotateCw,
  CheckCircle2,
  Hash,
  HelpCircle
} from "lucide-react";
import { User } from "../types";
import { saveUserProfileDB, getUserProfileDB, UserProfileData, formatTelegramHandle, generateTeleFlixUid } from "../db";
import { 
  getHumanAvatar, 
  getDiceBearAvatar, 
  isUnsplashOrBrokenPhoto, 
  BOYS_AVATARS_100, 
  GIRLS_AVATARS_100 
} from "../utils/avatar";
import { saveUserToFirestore } from "../services/firebase";
import TelegramIdHelpModal from "./TelegramIdHelpModal";

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onProfileUpdated?: (updated: UserProfileData) => void;
}

export default function EditProfileModal({
  isOpen,
  onClose,
  currentUser,
  onProfileUpdated
}: EditProfileModalProps) {
  const [displayName, setDisplayName] = useState<string>("");
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [telegramHandle, setTelegramHandle] = useState<string>("@");
  const [telegramId, setTelegramId] = useState<string>("");
  const [showHelpModal, setShowHelpModal] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [successToast, setSuccessToast] = useState<boolean>(false);
  const [imageError, setImageError] = useState<boolean>(false);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [avatarOffset, setAvatarOffset] = useState<number>(0);
  const [galleryTab, setGalleryTab] = useState<'boys' | 'girls'>('boys');

  useEffect(() => {
    setImageError(false);
  }, [currentUser?.photoURL, currentUser?.photoUrl, selectedPhoto]);

  // Initialize or re-sync form state from current profile
  useEffect(() => {
    if (!isOpen || !currentUser) return;

    // Load initial values from currentUser or IndexedDB
    const initFromUser = async () => {
      let profile: UserProfileData | null = null;
      if (currentUser.email) {
        profile = await getUserProfileDB(currentUser.email);
      }

      const rawName = profile?.displayName || currentUser.displayName || currentUser.fullName || currentUser.username || "";
      setDisplayName(rawName);

      const rawGender = (profile?.gender || currentUser.gender || "male").toLowerCase();
      const resolvedG = rawGender === "female" ? "Female" : rawGender === "other" ? "Other" : "Male";
      setGender(resolvedG);
      setGalleryTab(resolvedG === "Female" ? "girls" : "boys");

      const existingPhoto = profile?.photoURL || currentUser.photoURL || currentUser.photoUrl;
      if (existingPhoto && !isUnsplashOrBrokenPhoto(existingPhoto)) {
        setSelectedPhoto(existingPhoto);
      } else {
        setSelectedPhoto(null);
      }

      const rawTg = profile?.telegramHandle || currentUser.telegramUsername || (currentUser.username && !currentUser.username.startsWith("user_") && !currentUser.username.startsWith("guest_") ? currentUser.username : "");
      setTelegramHandle(formatTelegramHandle(rawTg));

      const rawTgId = profile?.telegramId || profile?.telegramNumericId || currentUser.telegramId || "";
      setTelegramId(rawTgId);

      setError(null);
      setSuccessToast(false);
    };

    initFromUser();
  }, [isOpen, currentUser]);

  if (!isOpen || !currentUser) return null;

  const primaryEmail = currentUser.email || "mostofa7077a@gmail.com";
  const rawGooglePhoto = currentUser.photoURL || currentUser.photoUrl || null;
  const hasRealGooglePhoto = Boolean(rawGooglePhoto && !isUnsplashOrBrokenPhoto(rawGooglePhoto));
  const fallbackHumanAvatar = getHumanAvatar(gender, currentUser.uid || currentUser.id || currentUser.telegramId || currentUser.email);
  const activePhoto = selectedPhoto || (hasRealGooglePhoto && !imageError ? rawGooglePhoto! : fallbackHumanAvatar);

  // Format Join Date (Immutable Timestamp)
  const formattedJoinDate = (() => {
    const raw = currentUser.createdAt || new Date().toISOString();
    try {
      const d = new Date(raw);
      return d.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric"
      });
    } catch (e) {
      return "Sep 20, 2026";
    }
  })();

  const handleTelegramChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.trim();
    if (!val.startsWith("@")) {
      val = val ? `@${val.replace(/@/g, "")}` : "@";
    }
    setTelegramHandle(val);
    if (error) setError(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanName = displayName.trim();
    if (!cleanName || cleanName.length < 2) {
      setError("Display Name must be at least 2 characters long.");
      return;
    }

    let cleanTg = formatTelegramHandle(telegramHandle);
    if (cleanTg !== "@" && cleanTg.length > 1) {
      const body = cleanTg.slice(1);
      if (body.length < 3 || body.length > 32 || !/^[a-zA-Z0-9_]+$/.test(body)) {
        setError("Telegram handle must be 3–32 characters (letters, numbers, underscores).");
        return;
      }
    } else {
      cleanTg = "@teleflix_vip";
    }

    const cleanTgId = telegramId.trim();
    if (cleanTgId && !/^\d+$/.test(cleanTgId)) {
      setError("Telegram Numeric User ID must be strictly numbers (e.g. 703119315615).");
      return;
    }

    setIsSaving(true);

    try {
      const finalPhotoToSave = activePhoto;

      // 1. Build immutable profile structure
      const updatedProfile: UserProfileData = {
        uid: generateTeleFlixUid(currentUser.id),
        email: primaryEmail,
        displayName: cleanName,
        gender,
        telegramHandle: cleanTg,
        telegramId: cleanTgId,
        telegramNumericId: cleanTgId,
        photoURL: finalPhotoToSave,
        joinDate: currentUser.createdAt || new Date().toISOString(),
        role: (currentUser.role === "ADMIN" || currentUser.role === "admin" || primaryEmail === "mostofa7077a@gmail.com") ? "ADMIN" : "USER",
        points: currentUser.points ?? 100,
        hwid: currentUser.device_fingerprint || currentUser.deviceFingerprint,
        isProfileCompleted: true,
        lastUpdated: new Date().toISOString()
      };

      // 2. Commit to IndexedDB + LocalStorage permanently
      await saveUserProfileDB(updatedProfile);

      // 3. Commit to Firestore
      try {
        await saveUserToFirestore({
          id: currentUser.id,
          displayName: cleanName,
          fullName: cleanName,
          gender: (gender.toLowerCase() as 'male' | 'female' | 'other'),
          telegramId: cleanTgId,
          telegramUsername: cleanTg,
          photoURL: finalPhotoToSave,
          photoUrl: finalPhotoToSave,
          isProfileCompleted: true,
          profileInitialized: true,
          profileStatus: 'completed',
          last_active_at: new Date().toISOString()
        });
      } catch (fsErr) {
        console.warn("Firestore save notice:", fsErr);
      }

      // 4. Update backend API
      try {
        await fetch("/api/auth/update-profile", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            userId: currentUser.id,
            displayName: cleanName,
            gender: gender.toLowerCase(),
            telegramId: cleanTgId,
            telegramUsername: cleanTg,
            photoURL: finalPhotoToSave,
            isProfileCompleted: true,
            profileStatus: 'completed'
          })
        });
      } catch (apiErr) {}

      // 5. Notify parent callback
      if (onProfileUpdated) {
        onProfileUpdated(updatedProfile);
      }

      setSuccessToast(true);
      setTimeout(() => {
        setIsSaving(false);
        onClose();
      }, 350);
    } catch (err: any) {
      console.error("Save profile error:", err);
      setError(err?.message || "Failed to save profile permanently. Please try again.");
      setIsSaving(false);
    }
  };

  return (
    <div 
      id="edit-profile-modal-overlay"
      className="fixed inset-0 z-[220] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none overflow-hidden"
      role="dialog"
      aria-modal="true"
    >
      <div 
        id="edit-profile-card"
        className="relative w-full max-w-md w-[92%] bg-[#0A0D14] border border-[#1F293D] rounded-2xl p-4 sm:p-5 text-left overflow-hidden max-h-[88vh] flex flex-col shadow-2xl text-white"
      >
        {/* Subtle Top Close Button */}
        <button
          type="button"
          id="btn-close-edit-profile"
          onClick={onClose}
          className="absolute top-3.5 right-3.5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition active:scale-95 cursor-pointer z-10"
          aria-label="Close"
        >
          <X size={16} />
        </button>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto pr-0.5 space-y-3.5">
          {/* Header */}
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#111622] border border-[#1F293D] text-amber-300 text-[10.5px] font-mono font-bold uppercase tracking-wider">
              <Sparkles size={11} className="text-amber-400" />
              <span>EDIT PROFILE</span>
            </span>
          </div>

          <div>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
              User Identity Settings
            </h2>
            <p className="text-xs text-gray-300 font-normal leading-relaxed mt-0.5">
              Updates are committed permanently to the database and will persist across all devices.
            </p>
          </div>

          {/* Dynamic Avatar with Selected Indicator */}
          <div className="flex items-center gap-3.5 p-3 rounded-xl bg-[#0E121C] border border-[#1F293D]">
            <div className="relative shrink-0 flex flex-col items-center">
              <div className={`w-14 h-14 rounded-full overflow-hidden p-0.5 border-2 transition-all ${
                gender === 'Female' 
                  ? 'border-pink-400 ring-4 ring-pink-500/20 shadow-[0_0_16px_rgba(244,114,182,0.35)]' 
                  : 'border-cyan-400 ring-4 ring-cyan-500/20 shadow-[0_0_16px_rgba(34,211,238,0.35)]'
              }`}>
                <img
                  src={activePhoto}
                  alt={displayName || "User"}
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                  onError={() => setImageError(true)}
                />
              </div>
              <span className="mt-1 text-[8px] font-mono font-black px-1.5 py-0.2 rounded-full bg-emerald-500 text-black uppercase tracking-wider shadow">
                SELECTED
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs sm:text-sm font-bold text-white truncate">
                  {displayName || "TeleFlix Member"}
                </span>
                <span className={`text-[9.5px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                  gender === 'Female'
                    ? 'bg-pink-500/15 text-pink-300 border-pink-500/30'
                    : 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                }`}>
                  {gender} Persona
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-400 block truncate mt-0.5">
                {telegramHandle}
              </span>
              <p className="text-[10px] text-slate-400 mt-1">
                নিচের গ্যালারি থেকে ১০০+ রিয়েল ছেলে বা মেয়ের ছবি বেছে নিতে পারেন।
              </p>
            </div>
          </div>

          <form onSubmit={handleSave} className="space-y-3">
            {/* FROZEN FIELD 1: Primary Gmail (Read-Only) */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <label className="text-slate-400 flex items-center gap-1">
                  <Mail size={12} className="text-slate-400" />
                  <span>Primary Gmail</span>
                </label>
                <span className="inline-flex items-center gap-1 text-[9.5px] font-bold text-slate-400 bg-white/5 px-1.5 py-0.2 rounded border border-white/10">
                  <Lock size={9} />
                  <span>FROZEN / READ-ONLY</span>
                </span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#080B10] border border-[#182030] text-slate-400 text-xs font-mono select-none">
                <Mail size={13} className="text-slate-500 shrink-0" />
                <span className="truncate">{primaryEmail}</span>
              </div>
            </div>

            {/* FROZEN FIELD 2: Registration Join Date (Immutable Timestamp) */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] font-mono">
                <label className="text-slate-400 flex items-center gap-1">
                  <Calendar size={12} className="text-slate-400" />
                  <span>Join Date</span>
                </label>
                <span className="inline-flex items-center gap-1 text-[9.5px] font-bold text-slate-400 bg-white/5 px-1.5 py-0.2 rounded border border-white/10">
                  <Lock size={9} />
                  <span>IMMUTABLE</span>
                </span>
              </div>
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#080B10] border border-[#182030] text-slate-400 text-xs font-mono select-none">
                <Calendar size={13} className="text-slate-500 shrink-0" />
                <span>{formattedJoinDate}</span>
              </div>
            </div>

            {/* EDITABLE FIELD 1: Display Name */}
            <div className="space-y-1">
              <label className="block text-[11px] font-mono font-bold text-slate-300">
                Display Name (Editable)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-amber-400">
                  <UserIcon size={14} />
                </div>
                <input
                  type="text"
                  id="input-edit-display-name"
                  value={displayName}
                  onChange={(e) => {
                    setDisplayName(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="Enter your name"
                  maxLength={30}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#0D111A] border border-[#1F293D] focus:border-amber-400 text-white text-xs sm:text-sm font-medium outline-none transition"
                />
              </div>
            </div>

            {/* EDITABLE FIELD 2: Gender Persona */}
            <div className="space-y-1">
              <label className="block text-[11px] font-mono font-bold text-slate-300">
                Gender Persona (Editable)
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  id="btn-select-gender-male"
                  onClick={() => {
                    setGender('Male');
                    setGalleryTab('boys');
                  }}
                  className={`py-2 px-2.5 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-mono font-bold transition cursor-pointer active:scale-95 ${
                    gender === 'Male'
                      ? 'bg-cyan-950/70 border-cyan-400 text-cyan-300 shadow-sm'
                      : 'bg-[#0D111A] border-[#1F293D] text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-cyan-400 font-bold">♂</span>
                  <span>Male</span>
                </button>

                <button
                  type="button"
                  id="btn-select-gender-female"
                  onClick={() => {
                    setGender('Female');
                    setGalleryTab('girls');
                  }}
                  className={`py-2 px-2.5 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-mono font-bold transition cursor-pointer active:scale-95 ${
                    gender === 'Female'
                      ? 'bg-pink-950/70 border-pink-400 text-pink-300 shadow-sm'
                      : 'bg-[#0D111A] border-[#1F293D] text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-pink-400 font-bold">♀</span>
                  <span>Female</span>
                </button>

                <button
                  type="button"
                  id="btn-select-gender-other"
                  onClick={() => {
                    setGender('Other');
                  }}
                  className={`py-2 px-2.5 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-mono font-bold transition cursor-pointer active:scale-95 ${
                    gender === 'Other'
                      ? 'bg-purple-950/70 border-purple-400 text-purple-300 shadow-sm'
                      : 'bg-[#0D111A] border-[#1F293D] text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-purple-400 font-bold">⚧</span>
                  <span>Other</span>
                </button>
              </div>
            </div>

            {/* REALISTIC HUMAN AVATAR GALLERY (100+ Boys & 100+ Girls) */}
            <div className="space-y-2 p-3 rounded-xl bg-[#0B0F19] border border-[#1F293D]">
              <div className="flex items-center justify-between gap-2">
                <label className="text-[11px] font-mono font-bold text-amber-300 flex items-center gap-1.5 truncate">
                  <Sparkles size={12} className="text-amber-400 shrink-0" />
                  <span>পছন্দের প্রোফাইল ছবি বেছে নিন:</span>
                </label>
                <button
                  type="button"
                  id="btn-shuffle-avatars"
                  onClick={() => setAvatarOffset(prev => (prev + 10) % 100)}
                  className="text-[10px] font-mono text-cyan-300 hover:text-cyan-200 flex items-center gap-1 px-2 py-0.5 rounded-lg bg-cyan-950/60 border border-cyan-500/40 transition cursor-pointer active:scale-95 shrink-0"
                >
                  <RotateCw size={10} className="text-cyan-400" />
                  <span>আরও ছবি ({(avatarOffset / 10) + 1}/10)</span>
                </button>
              </div>

              {/* Gallery Tabs */}
              <div className="flex items-center gap-1.5 text-[10.5px] font-mono font-semibold">
                <button
                  type="button"
                  id="btn-tab-boys-avatars"
                  onClick={() => {
                    setGalleryTab('boys');
                    setAvatarOffset(0);
                  }}
                  className={`flex-1 py-1.5 px-2 rounded-lg border text-center transition cursor-pointer active:scale-95 ${
                    galleryTab === 'boys'
                      ? 'bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-sm'
                      : 'bg-[#0E121C] border-[#1F293D] text-slate-400 hover:text-white'
                  }`}
                >
                  👦 ছেলেদের ছবি (Boys - 100)
                </button>
                <button
                  type="button"
                  id="btn-tab-girls-avatars"
                  onClick={() => {
                    setGalleryTab('girls');
                    setAvatarOffset(0);
                  }}
                  className={`flex-1 py-1.5 px-2 rounded-lg border text-center transition cursor-pointer active:scale-95 ${
                    galleryTab === 'girls'
                      ? 'bg-pink-950/80 border-pink-400 text-pink-300 shadow-sm'
                      : 'bg-[#0E121C] border-[#1F293D] text-slate-400 hover:text-white'
                  }`}
                >
                  👧 মেয়েদের ছবি (Girls - 100)
                </button>
                {hasRealGooglePhoto && (
                  <button
                    type="button"
                    id="btn-use-google-photo"
                    onClick={() => setSelectedPhoto(rawGooglePhoto)}
                    className={`py-1.5 px-2 rounded-lg border text-center transition cursor-pointer text-[10px] active:scale-95 ${
                      selectedPhoto === rawGooglePhoto
                        ? 'bg-amber-950/80 border-amber-400 text-amber-300 shadow-sm'
                        : 'bg-[#0E121C] border-[#1F293D] text-slate-400 hover:text-white'
                    }`}
                  >
                    Google
                  </button>
                )}
              </div>

              {/* 10 Avatars Grid */}
              <div className="grid grid-cols-5 gap-2 pt-1">
                {(galleryTab === 'boys' ? BOYS_AVATARS_100 : GIRLS_AVATARS_100)
                  .slice(avatarOffset, avatarOffset + 10)
                  .map((imgUrl, idx) => {
                    const isSelected = activePhoto === imgUrl;
                    return (
                      <button
                        key={`${galleryTab}-${avatarOffset}-${idx}`}
                        type="button"
                        id={`btn-avatar-${galleryTab}-${avatarOffset + idx}`}
                        onClick={() => {
                          setSelectedPhoto(imgUrl);
                          if (galleryTab === 'boys' && gender !== 'Male') setGender('Male');
                          if (galleryTab === 'girls' && gender !== 'Female') setGender('Female');
                        }}
                        className={`relative aspect-square rounded-full overflow-hidden border-2 transition-all active:scale-95 group cursor-pointer ${
                          isSelected
                            ? 'border-emerald-400 ring-2 ring-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.6)] scale-105 z-10'
                            : 'border-[#1F293D] hover:border-slate-400 bg-[#0E121C]'
                        }`}
                        title="Click to select this profile picture"
                      >
                        <img
                          src={imgUrl}
                          alt="Avatar option"
                          className="w-full h-full object-cover rounded-full"
                          loading="lazy"
                        />
                        {isSelected && (
                          <div className="absolute inset-0 bg-emerald-950/30 flex items-center justify-center">
                            <span className="bg-emerald-500 text-black text-[8px] font-black px-1 rounded-sm shadow uppercase">
                              ✓
                            </span>
                          </div>
                        )}
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* EDITABLE FIELD 3: Telegram Numeric User ID */}
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="block text-[11px] font-mono font-bold text-slate-300">
                  Telegram Numeric User ID (Editable)
                </label>
                <button
                  type="button"
                  onClick={() => setShowHelpModal(true)}
                  className="text-[10px] font-mono text-cyan-300 hover:text-cyan-200 flex items-center gap-1 px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30 cursor-pointer active:scale-95"
                >
                  <HelpCircle size={10} className="text-cyan-400" />
                  <span>কীভাবে পাবেন?</span>
                </button>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-cyan-400">
                  <Hash size={13} />
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  id="input-edit-telegram-id"
                  value={telegramId}
                  onChange={(e) => {
                    const v = e.target.value.trim();
                    setTelegramId(v);
                    if (error) setError(null);
                  }}
                  placeholder="e.g. 703119315615"
                  maxLength={18}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#0D111A] border border-[#1F293D] focus:border-cyan-400 text-cyan-300 text-xs sm:text-sm font-mono font-medium outline-none transition"
                />
              </div>
              <p className="text-[10px] font-mono text-slate-400">
                Strictly numeric digits only (e.g. 123456789 from @userinfobot).
              </p>
            </div>

            {/* EDITABLE FIELD 4: Telegram Handle */}
            <div className="space-y-1">
              <label className="block text-[11px] font-mono font-bold text-slate-300">
                Telegram Handle (Editable)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-cyan-400">
                  <Send size={13} />
                </div>
                <input
                  type="text"
                  id="input-edit-telegram-handle"
                  value={telegramHandle}
                  onChange={handleTelegramChange}
                  placeholder="@username"
                  maxLength={32}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#0D111A] border border-[#1F293D] focus:border-cyan-400 text-cyan-300 text-xs sm:text-sm font-mono font-medium outline-none transition"
                />
              </div>
              <p className="text-[10px] font-mono text-slate-400">
                Must start with @ for automated referral reward attribution.
              </p>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-2.5 rounded-xl bg-[#2A080C] border border-[#4A1017] text-rose-200 text-xs font-mono">
                {error}
              </div>
            )}

            {/* Permanent Commit Assurance Badge */}
            <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#0E121C] border border-[#1F293D] text-[10.5px] font-mono text-slate-300">
              <ShieldCheck size={13} className="text-emerald-400 shrink-0" />
              <span>Persists permanently in IndexedDB across browser reopens.</span>
            </div>

            {/* Buttons */}
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                id="btn-cancel-edit-profile"
                onClick={onClose}
                disabled={isSaving}
                className="flex-1 py-2 sm:py-2.5 px-3 rounded-xl bg-[#111622] hover:bg-[#161D2E] text-slate-300 hover:text-white border border-[#1F293D] text-xs font-mono font-semibold transition cursor-pointer active:scale-95"
              >
                Cancel
              </button>

              <button
                type="submit"
                id="btn-save-profile-changes"
                disabled={isSaving}
                className="flex-1 py-2 sm:py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 text-xs font-mono font-bold transition duration-150 cursor-pointer flex items-center justify-center gap-1.5 shadow-sm active:scale-95 disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <Loader2 size={13} className="animate-spin text-slate-950" />
                    <span>Saving...</span>
                  </>
                ) : successToast ? (
                  <>
                    <Check size={14} className="text-slate-950" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Check size={14} className="text-slate-950" />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* "How to get Telegram ID?" (কীভাবে Telegram ID পাবেন?) Help Modal */}
      <TelegramIdHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
      />
    </div>
  );
}
