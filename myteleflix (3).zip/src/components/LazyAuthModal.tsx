/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, Sparkles, Flame, Wallet, Users, Lock, 
  ChevronRight, CheckCircle2, ShieldCheck, 
  AlertCircle, Loader2
} from "lucide-react";
import { useAuth, SUPER_ADMIN_EMAIL } from "../context/AuthContext";
import { User } from "../types";
import { signInWithGoogleSeamless } from "../services/auth";

export type LazyAuthAction = 'earn' | 'withdraw' | 'referral' | 'adult_unlock' | 'profile' | 'generic' | 'wallet';

interface LazyAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  actionReason?: LazyAuthAction;
  customTitle?: string;
  customDescription?: string;
  onLoginSuccess?: (user: User) => void;
  onPolicyViolation?: (data: any) => void;
  onNeedOnboarding?: (user: User) => void;
}

export default function LazyAuthModal({
  isOpen,
  onClose,
  actionReason = 'generic',
  customTitle,
  customDescription,
  onLoginSuccess,
  onPolicyViolation,
  onNeedOnboarding
}: LazyAuthModalProps) {
  const { isSyncing, guestDeviceId } = useAuth();
  const [loadingMethod, setLoadingMethod] = useState<'google' | null>(null);
  const [errorMessage, setErrorMessage] = useState("");

  if (!isOpen) return null;

  // Contextual visual elements based on action reason
  const actionDetails = {
    earn: {
      badge: "VIP EARNING ENGINE",
      badgeColor: "bg-amber-950/80 text-amber-300 border-amber-800/60",
      icon: Flame,
      iconColor: "text-amber-500",
      title: customTitle || "Sign in with Google to Start Earning",
      description: customDescription || "Sign in with Google to activate your Wallet, earn Tiered Referral rewards, unlock Cashouts, and access 18+ Special Content.",
      perk: "Earn +100 Welcome Bonus upon signing in"
    },
    profile: {
      badge: "PROFILE & REWARDS MANAGEMENT",
      badgeColor: "bg-cyan-950/80 text-cyan-300 border-cyan-800/60",
      icon: Users,
      iconColor: "text-cyan-400",
      title: customTitle || "Sign in to Earn & Manage Profile",
      description: customDescription || "Sign in with 1-click Google to set up your VIP avatar, track mission bonuses, earn referral points, and manage cashouts.",
      perk: "Instant +100 Welcome Bonus and Custom Avatar"
    },
    withdraw: {
      badge: "SECURE CASHOUT GATEWAY",
      badgeColor: "bg-emerald-950/80 text-emerald-300 border-emerald-800/60",
      icon: Wallet,
      iconColor: "text-emerald-500",
      title: customTitle || "Sign in with Google to Withdraw Rewards",
      description: customDescription || "Sign in with Google to activate your Wallet, earn Tiered Referral rewards, unlock Cashouts, and access 18+ Special Content.",
      perk: "Zero withdrawal fees on your first 3 cashouts"
    },
    wallet: {
      badge: "VIP WALLET ACCESS",
      badgeColor: "bg-amber-950/80 text-amber-300 border-amber-800/60",
      icon: Wallet,
      iconColor: "text-amber-400",
      title: customTitle || "Want to EARN from this download? Sign up now to unlock your VIP Wallet!",
      description: customDescription || "Sign in with Google to activate your VIP Wallet, earn rewards per download, unlock tiered referral bonuses, and withdraw earnings directly to bKash & Nagad.",
      perk: "Instant +100 Points Welcome Gift & Download Earnings"
    },
    referral: {
      badge: "REFERRAL REWARD TRACKER",
      badgeColor: "bg-purple-950/80 text-purple-300 border-purple-800/60",
      icon: Users,
      iconColor: "text-purple-400",
      title: customTitle || "Unlock Referral Mission Tracker",
      description: customDescription || "Sign in with Google to activate your Wallet, earn Tiered Referral rewards, unlock Cashouts, and access 18+ Special Content.",
      perk: "Instant tier tracking & automated commission payouts"
    },
    adult_unlock: {
      badge: "AGE VERIFICATION & 18+ ACCESS",
      badgeColor: "bg-rose-950/80 text-rose-300 border-rose-800/60",
      icon: Lock,
      iconColor: "text-[#E50914]",
      title: customTitle || "Unlock 18+ Private Vault",
      description: customDescription || "Sign in with Google to activate your Wallet, earn Tiered Referral rewards, unlock Cashouts, and access 18+ Special Content.",
      perk: "Unlocks dedicated 18+ private channel & HD stream links"
    },
    generic: {
      badge: "ACCOUNT ACTIVATION GATEWAY",
      badgeColor: "bg-red-950/80 text-red-300 border-red-800/60",
      icon: Sparkles,
      iconColor: "text-[#E50914]",
      title: customTitle || "Activate Your Account",
      description: customDescription || "Sign in with Google to activate your Wallet, earn Tiered Referral rewards, unlock Cashouts, and access 18+ Special Content.",
      perk: "Seamlessly merges your guest activity with your account"
    }
  }[actionReason];

  const CurrentIcon = actionDetails.icon;

  const handleGoogleSignIn = async () => {
    try {
      setErrorMessage("");
      setLoadingMethod('google');

      const result = await signInWithGoogleSeamless({
        usePopup: true
      });

      if (result.needsOnboarding) {
        if (onNeedOnboarding) {
          onNeedOnboarding(result.user);
        } else if (onLoginSuccess) {
          onLoginSuccess(result.user);
        }
      } else if (onLoginSuccess) {
        onLoginSuccess(result.user);
      }
      onClose();
    } catch (err: any) {
      if (err.blocked || err.message?.includes("অবৈধভাবে") || err.message?.includes("1 Device = 1 Account") || err.message?.includes("POLICY VIOLATION")) {
        if (onPolicyViolation) {
          onPolicyViolation({
            error: err.message || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
            existingAccount: err.existingAccount,
            primaryEmail: err.primaryEmail || (typeof err.existingAccount === 'object' ? err.existingAccount?.email : err.existingAccount),
            deviceFingerprint: err.deviceFingerprint,
            ipAddress: err.ipAddress
          });
          onClose();
          return;
        }
      }
      setErrorMessage(err.message || "Google authentication failed. Please try again.");
    } finally {
      setLoadingMethod(null);
    }
  };

  const GoogleLogoSvg = () => (
    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
      <path
        fill="#EA4335"
        d="M12 5c1.56 0 2.98.54 4.1 1.6l3.08-3.08C17.3 1.74 14.83 1 12 1 7.42 1 3.54 3.6 1.72 7.37l3.75 2.91C6.35 7.44 8.94 5 12 5z"
      />
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58l3.72 2.89c2.18-2.01 3.7-4.99 3.7-8.71z"
      />
      <path
        fill="#FBBC05"
        d="M5.47 14.72c-.24-.71-.38-1.47-.38-2.26s.14-1.55.38-2.26L1.72 7.29C.63 9.47 0 11.91 0 14.46s.63 4.99 1.72 7.17l3.75-2.91z"
      />
      <path
        fill="#34A853"
        d="M12 23c3.24 0 5.95-1.08 7.93-2.91l-3.72-2.89c-1.07.72-2.45 1.16-4.21 1.16-3.06 0-5.65-2.07-6.53-4.87L1.72 16.4C3.54 20.17 7.42 23 12 23z"
      />
    </svg>
  );

  return (
    <AnimatePresence>
      <div 
        id="lazy-auth-modal" 
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 12 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-sm bg-[#161618] border border-[#2A2A2E] rounded-3xl p-5 shadow-2xl space-y-4 overflow-hidden"
        >
          {/* Top Brand Stripe */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#E50914]" />

          {/* Header Controls */}
          <div className="flex items-center justify-between pt-1">
            <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${actionDetails.badgeColor}`}>
              {actionDetails.badge}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-full text-[#8C8C8C] hover:text-white hover:bg-[#26262B] transition cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>

          {/* Context Icon & Title */}
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-[#1A1A1E] border border-[#2A2A2E] shrink-0">
              <CurrentIcon size={22} className={actionDetails.iconColor} />
            </div>
            <div className="space-y-1 min-w-0 flex-1">
              <h3 className="text-base font-extrabold text-white leading-tight font-mono">
                {actionDetails.title}
              </h3>
              <p className="text-xs text-[#A0A0A0] leading-relaxed font-sans">
                {actionDetails.description}
              </p>
            </div>
          </div>

          {/* Perk Highlight */}
          <div className="bg-[#1A1A1E] border border-[#2A2A2E] rounded-xl p-2.5 flex items-center gap-2">
            <ShieldCheck size={16} className="text-[#E50914] shrink-0" />
            <span className="text-[11px] font-medium text-[#E0E0E0] line-clamp-1">
              {actionDetails.perk}
            </span>
          </div>

          {/* Error Message if any */}
          {errorMessage && (
            <div className="bg-rose-950/40 border border-rose-800/60 rounded-xl p-2.5 flex items-center gap-2 text-rose-300 text-xs font-mono">
              <AlertCircle size={14} className="shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Authentication Action: Strictly "Sign in with Google" */}
          <div className="space-y-2.5 pt-1">
            <div className="space-y-2">
              <button
                id="lazy-auth-google-btn"
                type="button"
                disabled={isSyncing || loadingMethod !== null}
                onClick={() => handleGoogleSignIn()}
                className="w-full bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs uppercase py-3.5 px-4 rounded-xl transition duration-75 cursor-pointer active:scale-95 active:brightness-125 active:ring-2 active:ring-emerald-400/80 active:shadow-lg active:shadow-emerald-900/50 flex items-center justify-between font-mono tracking-wider disabled:opacity-50 select-none shadow-lg"
              >
                <div className="flex items-center gap-2.5">
                  {loadingMethod === 'google' ? (
                    <Loader2 size={16} className="animate-spin text-slate-900" />
                  ) : (
                    <GoogleLogoSvg />
                  )}
                  <span>{loadingMethod === 'google' ? "Connecting Google..." : "1-Click Sign in with Google"}</span>
                </div>
                <ChevronRight size={14} className="text-slate-400" />
              </button>

              <div className="flex items-center justify-center pt-1">
                <span className="text-[10.5px] text-slate-400 font-mono">
                  Hardware-bound profile • No manual typing required
                </span>
              </div>
            </div>
          </div>

          {/* Guest Identity Notice & Dismiss */}
          <div className="pt-1 flex flex-col items-center gap-2">
            <p className="text-[10px] text-[#8C8C8C] font-mono text-center flex items-center gap-1">
              <CheckCircle2 size={11} className="text-emerald-400 shrink-0" />
              <span>Guest session ({guestDeviceId?.slice(0, 14)}...) will be preserved</span>
            </p>
            <button
              id="lazy-auth-continue-guest-btn"
              type="button"
              onClick={onClose}
              className="text-xs text-[#A0A0A0] hover:text-white font-mono transition cursor-pointer py-1"
            >
              Continue Browsing as Guest
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
