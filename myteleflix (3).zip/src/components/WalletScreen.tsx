/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * PREMIUM ENTERPRISE WALLET & CASHOUT SYSTEM
 * - Single consistent language (Pure authentic Bengali UI copy without dual English clutter)
 * - Deep, rich organic dark aesthetic (zero washed-out or watery tones)
 * - Zero emoji stickers in labels
 * - bKash & Nagad buttons with fixed, non-breaking single-line text layout
 * - Dedicated Notice: "শুধু পার্সোনাল নাম্বার প্রযোজ্য"
 * - Step 3: Refined Points Amount design with live BDT conversion
 * - High-conversion, tactile "ক্যাশআউট রিকোয়েস্ট জমা দিন" Action Button
 * - Real-time Live Payout Ticker (Social Proof)
 * - Dedicated Organic Containers: "মাই ওয়ে টু উইথড্র", "টাস্ক রিভিউ", "অফিসিয়াল সাপোর্ট"
 */

import React, { useState, useMemo, useEffect } from "react";
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Wallet, 
  Send, 
  Check, 
  ShieldAlert, 
  Power,
  Smartphone,
  Shield,
  History,
  Sparkles,
  AlertTriangle,
  Headphones,
  ExternalLink,
  Zap
} from "lucide-react";
import { TokenIcon } from "./TokenIcon";
import { Transaction, WithdrawalRequest } from "../types";
import { saveWithdrawalToFirestore } from "../services/firebase";
import { useGlobalConfig } from "../context/GlobalConfigContext";
import { useLanguage } from "../context/LanguageContext";
import { LazyAuthAction } from "./LazyAuthModal";
import { 
  TOKEN_TO_BDT_RATE,
  MIN_WITHDRAWAL_TOKENS, 
  MIN_WITHDRAWAL_BDT,
  MAX_DAILY_WITHDRAWAL_TOKENS,
  QUICK_WITHDRAWAL_PACKAGES,
  SupportedPaymentGateway,
  tokensToBdt,
  formatBdt,
  DEFAULT_TELEGRAM_SUPPORT_LINK
} from "../constants";

interface WalletScreenProps {
  userPoints: number;
  transactions: Transaction[];
  minimumWithdrawal?: number;
  tokenRateBdt?: number;
  tokenRateUsd?: number;
  userId?: string;
  userEmail?: string;
  username?: string;
  isBanned?: boolean;
  banReason?: string;
  isGuest?: boolean;
  onTriggerAuth?: (action?: LazyAuthAction) => void;
  onWithdraw?: (
    amount: number, 
    address: string, 
    paymentMethod?: string, 
    email?: string, 
    accountNumber?: string
  ) => Promise<{ success: boolean; error?: string }>;
}

// Live real-time withdrawal ticker announcements (Social Proof)
const LIVE_PAYOUT_RECORDS = [
  { name: "আরিফ হোসেন", amount: 1890, method: "বিকাশ", time: "২ মিনিট আগে" },
  { name: "তানভীর আহমেদ", amount: 1000, method: "নগদ", time: "৪ মিনিট আগে" },
  { name: "সুমাইয়া আক্তার", amount: 500, method: "বিকাশ", time: "৭ মিনিট আগে" },
  { name: "সাকিব আল হাসান", amount: 2500, method: "নগদ", time: "৯ মিনিট আগে" },
  { name: "মেহেদী হাসান", amount: 500, method: "বিকাশ", time: "১২ মিনিট আগে" },
  { name: "ফাতেমা খাতুন", amount: 1200, method: "বিকাশ", time: "১৫ মিনিট আগে" },
  { name: "জাহিদুল ইসলাম", amount: 800, method: "নগদ", time: "১৮ মিনিট আগে" },
  { name: "নাজমুল হক", amount: 1500, method: "বিকাশ", time: "২১ মিনিট আগে" },
];

function WalletScreenComponent({
  userPoints,
  transactions = [],
  minimumWithdrawal = MIN_WITHDRAWAL_TOKENS,
  userId = "",
  userEmail = "",
  username = "user",
  isBanned = false,
  banReason,
  isGuest = false,
  onTriggerAuth,
  onWithdraw,
}: WalletScreenProps) {
  const { t, language } = useLanguage();
  const { configMap, isMaintenance, maintenanceMessage } = useGlobalConfig();

  // Enforce enterprise minimum: at least 100,000 tokens
  const effectiveMinWithdrawal = Math.max(
    configMap?.MIN_WITHDRAWAL_POINTS ?? 0,
    minimumWithdrawal ?? MIN_WITHDRAWAL_TOKENS,
    MIN_WITHDRAWAL_TOKENS
  );
  const effectiveMaxDaily = configMap?.MAX_DAILY_WITHDRAWAL_POINTS ?? MAX_DAILY_WITHDRAWAL_TOKENS;

  // Method selection strictly: bKash (Pink) and Nagad (Orange) only
  const [selectedMethod, setSelectedMethod] = useState<SupportedPaymentGateway>('bKash');
  const accountType = 'Personal'; // Strict policy: Personal numbers only
  
  // Input fields
  const [accountNumber, setAccountNumber] = useState("");
  const [tokenAmount, setTokenAmount] = useState("");
  const applicantEmail = userEmail;
  
  // Status states
  const [submitting, setSubmitting] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);
  const [toastNotice, setToastNotice] = useState<{ message: string; type: 'error' | 'success' | 'warn' } | null>(null);
  const [successReceipt, setSuccessReceipt] = useState<{
    id: string;
    amount: number;
    destination: string;
    method: string;
    bdtEst: number;
    timestamp: string;
  } | null>(null);

  // Live Payout Ticker cycle index
  const [tickerIndex, setTickerIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % LIVE_PAYOUT_RECORDS.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  // Ledger Filter
  const [ledgerFilter, setLedgerFilter] = useState<'all' | 'payouts'>('all');

  // Saved Payment Profiles
  const [savedProfiles, setSavedProfiles] = useState<any[]>([]);

  useEffect(() => {
    if (!userId) return;
    fetch(`/api/wallet/payment-profile?userId=${encodeURIComponent(userId)}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.profiles)) {
          setSavedProfiles(data.profiles);
        }
      })
      .catch(() => {});
  }, [userId]);

  // When selectedMethod changes, pre-fill account if user has saved profile
  useEffect(() => {
    const matched = savedProfiles.find((p) => p.payment_method === selectedMethod);
    if (matched && matched.account_number_or_wallet_address) {
      setAccountNumber(matched.account_number_or_wallet_address);
    }
  }, [selectedMethod, savedProfiles]);

  // Auto-dismiss toast
  useEffect(() => {
    if (toastNotice) {
      const timer = setTimeout(() => setToastNotice(null), 4500);
      return () => clearTimeout(timer);
    }
  }, [toastNotice]);

  const parsedAmount = parseInt(tokenAmount, 10) || 0;

  // Fixed conversion rate: 100,000 Tokens = 100 BDT
  const liveEstimateBdt = useMemo(() => {
    return tokensToBdt(parsedAmount);
  }, [parsedAmount]);

  const totalBalanceBdt = useMemo(() => {
    return tokensToBdt(userPoints);
  }, [userPoints]);

  const withdrawalProgress = Math.min(100, Math.round((userPoints / effectiveMinWithdrawal) * 100));
  const hasMinBalance = userPoints >= effectiveMinWithdrawal;

  // Quick preset package selection
  const handleSelectPackage = (points: number) => {
    setErrorText(null);
    if (userPoints < points) {
      setToastNotice({
        message: `আপনার ব্যালেন্সে পর্যাপ্ত পয়েন্ট নেই। এই প্যাকেজের জন্য ${points.toLocaleString()} পয়েন্ট প্রয়োজন (আপনার আছে ${userPoints.toLocaleString()})।`,
        type: 'warn'
      });
    }
    setTokenAmount(points.toString());
  };

  // Form Submission
  const handleSubmitWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText(null);

    if (isMaintenance) {
      const msg = maintenanceMessage || "সিস্টেম আপডেটের কাজ চলছে। ক্যাশআউট সাময়িকভাবে স্থগিত আছে।";
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'warn' });
      return;
    }

    if (isBanned) {
      const msg = banReason || "আপনার অ্যাকাউন্টে ক্যাশআউট সাময়িকভাবে সীমাবদ্ধ আছে। সাপোর্টে যোগাযোগ করুন।";
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    // Minimum Threshold Guard
    if (userPoints < effectiveMinWithdrawal) {
      const msg = `ন্যূনতম ক্যাশআউট সীমা ${effectiveMinWithdrawal.toLocaleString()} পয়েন্ট (৳${tokensToBdt(effectiveMinWithdrawal)} টাকা)। আপনার ব্যালেন্স এখনও পর্যাপ্ত নয়।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      const msg = "দয়া করে ক্যাশআউটের জন্য সঠিক পয়েন্টের পরিমাণ লিখুন।";
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'warn' });
      return;
    }

    if (parsedAmount < effectiveMinWithdrawal) {
      const msg = `সর্বনিম্ন ক্যাশআউট পরিমাণ ${effectiveMinWithdrawal.toLocaleString()} পয়েন্ট (৳${tokensToBdt(effectiveMinWithdrawal)} টাকা)।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    if (parsedAmount > effectiveMaxDaily) {
      const msg = `একবারে সর্বোচ্চ ক্যাশআউট সীমা ${effectiveMaxDaily.toLocaleString()} পয়েন্ট।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    if (parsedAmount > userPoints) {
      const msg = `অপর্যাপ্ত পয়েন্ট ব্যালেন্স! আপনার অ্যাকাউন্টে আছে ${userPoints.toLocaleString()}।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    const cleanDest = accountNumber.trim();
    if (!cleanDest) {
      const methodName = selectedMethod === 'bKash' ? 'বিকাশ' : 'নগদ';
      const msg = `দয়া করে আপনার ১১ ডিজিটের ${methodName} পার্সোনাল নম্বর লিখুন।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'warn' });
      return;
    }

    // Bangladeshi mobile number validation (013-019)
    const bdPhoneRegex = /^01[3-9]\d{8}$/;
    if (!bdPhoneRegex.test(cleanDest)) {
      const msg = `সঠিক ১১ ডিজিটের পার্সোনাল মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।`;
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
      return;
    }

    setSubmitting(true);
    try {
      if (onWithdraw) {
        const res = await onWithdraw(
          parsedAmount,
          cleanDest,
          selectedMethod,
          applicantEmail,
          cleanDest
        );
        if (!res.success) {
          setErrorText(res.error || "ক্যাশআউট রিকোয়েস্ট সাবমিট করা যায়নি। আবার চেষ্টা করুন।");
          setToastNotice({ message: res.error || "ক্যাশআউট ব্যর্থ হয়েছে", type: 'error' });
          setSubmitting(false);
          return;
        }
      } else {
        // Direct firestore fallback
        const withdrawalReq: WithdrawalRequest = {
          id: `w_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          userId: userId || 'anonymous',
          username: username || 'User',
          amount: parsedAmount,
          walletAddress: cleanDest,
          paymentMethod: selectedMethod,
          accountNumber: cleanDest,
          email: applicantEmail,
          status: 'pending',
          timestamp: new Date().toISOString(),
        };
        await saveWithdrawalToFirestore(withdrawalReq);
      }

      // Success
      setSuccessReceipt({
        id: `TX-${Date.now().toString().slice(-6)}`,
        amount: parsedAmount,
        destination: cleanDest,
        method: selectedMethod === 'bKash' ? 'বিকাশ' : 'নগদ',
        bdtEst: liveEstimateBdt,
        timestamp: new Date().toLocaleTimeString(),
      });
      setTokenAmount("");
      setErrorText(null);
      setToastNotice({
        message: `৳ ${liveEstimateBdt} টাকা ক্যাশআউট রিকোয়েস্ট সফলভাবে জমা হয়েছে!`,
        type: 'success'
      });
    } catch (err: any) {
      console.error("Cashout submit error:", err);
      const msg = err.message || "ক্যাশআউট প্রক্রিয়াকরণে অপ্রত্যাশিত ত্রুটি ঘটেছে।";
      setErrorText(msg);
      setToastNotice({ message: msg, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  // Filter transactions for history ledger
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const isPayout = t.type.toLowerCase().includes('withdraw') || 
                       t.type.toLowerCase().includes('cashout') ||
                       t.amount < 0;
      if (ledgerFilter === 'payouts') return isPayout;
      return true;
    });
  }, [transactions, ledgerFilter]);

  const currentTicker = LIVE_PAYOUT_RECORDS[tickerIndex];

  return (
    <div className="w-full max-w-2xl mx-auto space-y-3.5 pb-24 font-sans text-slate-100 px-3 sm:px-4">
      
      {/* 0. REAL-TIME LIVE PAYOUT TICKER (Social Proof Notification Ticker) */}
      <div className="relative overflow-hidden bg-[#0A121F] border border-emerald-500/30 rounded-2xl p-2.5 sm:p-3 shadow-[0_4px_18px_rgba(0,0,0,0.5),0_0_12px_rgba(16,185,129,0.12)]">
        <div className="flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            {/* Live Green Pulsing Beacon */}
            <div className="relative flex items-center justify-center w-3 h-3 shrink-0">
              <span className="absolute w-3 h-3 rounded-full bg-emerald-400 animate-ping opacity-75" />
              <span className="relative w-2 h-2 rounded-full bg-emerald-500" />
            </div>

            <div className="min-w-0 flex-1 flex items-center gap-1.5 text-xs">
              <span className="font-bold text-emerald-400 whitespace-nowrap text-[11px] sm:text-xs">
                {currentTicker.name}
              </span>
              <span className="text-slate-300 text-[11px] sm:text-xs truncate">
                {t('wallet.live_ticker_action', 'সফলভাবে')} <strong className="text-white font-bold">৳{currentTicker.amount.toLocaleString()}</strong> {language === 'en' ? 'withdrawn' : language === 'hi' ? 'निकाले' : 'উত্তোলন করেছেন'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${
              currentTicker.method === 'বিকাশ'
                ? 'bg-[#E2136E]/20 text-pink-300 border-[#E2136E]/40'
                : 'bg-[#FA541C]/20 text-orange-300 border-[#FA541C]/40'
            }`}>
              {currentTicker.method === 'বিকাশ' ? t('wallet.bkash', 'বিকাশ') : t('wallet.nagad', 'নগদ')}
            </span>
            <span className="text-[10px] text-slate-400 hidden sm:inline">
              {currentTicker.time}
            </span>
          </div>
        </div>
      </div>

      {/* Toast Alert Banner */}
      {toastNotice && (
        <div 
          className={`p-3 rounded-2xl border backdrop-blur-md flex items-center justify-between gap-3 shadow-2xl transition-all duration-200 ${
            toastNotice.type === 'error'
              ? 'bg-[#220B0F] border-rose-500/50 text-rose-200'
              : toastNotice.type === 'warn'
              ? 'bg-[#261605] border-amber-500/50 text-amber-200'
              : 'bg-[#061D15] border-emerald-500/50 text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2.5 text-xs font-medium">
            {toastNotice.type === 'error' && <AlertCircle size={16} className="shrink-0 text-rose-400" />}
            {toastNotice.type === 'warn' && <AlertTriangle size={16} className="shrink-0 text-amber-400" />}
            {toastNotice.type === 'success' && <CheckCircle2 size={16} className="shrink-0 text-emerald-400" />}
            <span className="leading-snug">{toastNotice.message}</span>
          </div>
          <button
            onClick={() => setToastNotice(null)}
            className="text-xs px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white transition cursor-pointer select-none shrink-0"
          >
            ✕
          </button>
        </div>
      )}

      {/* Guest Mode Restriction Banner: Prompt to Earn and unlock VIP Wallet */}
      {isGuest && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 border-2 border-amber-500/50 shadow-2xl space-y-3 animate-in fade-in">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 text-xl shrink-0 shadow-inner">
              🌟
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-amber-200">
                Want to EARN from this download? Sign up now to unlock your VIP Wallet!
              </h2>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Guest users can stream and download contents freely, but cannot accumulate earnings, referral rewards, or wallet points. Sign up or log in now to unlock your VIP Wallet, earn per download, and withdraw real BDT via bKash & Nagad!
              </p>
            </div>
          </div>
          <div className="pt-1 flex flex-col sm:flex-row items-center gap-2">
            <button
              type="button"
              onClick={() => onTriggerAuth?.('wallet')}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-slate-950 font-black text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg active:scale-95 transition cursor-pointer"
            >
              <Sparkles size={15} />
              <span>Sign Up / Log In to Unlock VIP Wallet</span>
            </button>
            <span className="text-[11px] text-slate-400 font-mono">
              Takes less than 10 seconds via Google Auth
            </span>
          </div>
        </div>
      )}

      {/* 1. BALANCE OVERVIEW & CONVERSION HEADER (Deep Solid Slate/Obsidian) */}
      <div className="relative overflow-hidden bg-[#0C121E] border border-[#1E293B] rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4">
        {/* Subtle Organic Deep Accent Gradients */}
        <div className="absolute -top-16 -right-16 w-56 h-56 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Bar: Title & Enterprise Tag */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-[#1A2333] pb-3.5 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shadow-inner shrink-0">
              <Wallet size={19} />
            </div>
            <div>
              <h1 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>{t('wallet.title', 'মাই ওয়ালেট ও ক্যাশআউট')}</span>
                <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-950/90 text-emerald-300 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.25)]">
                  {t('wallet.badge', 'অফিশিয়াল ওয়ালেট')}
                </span>
              </h1>
              <p className="text-[11px] text-slate-300 mt-0.5">
                {t('wallet.subtitle', 'বিকাশ ও নগদে সরাসরি ও নির্ভরযোগ্য পেমেন্ট সিস্টেম')}
              </p>
            </div>
          </div>

          {/* Fixed Conversion Rate Chip */}
          <div className="inline-flex items-center gap-1.5 self-start sm:self-auto px-2.5 py-1 rounded-xl bg-[#140E04] border border-amber-500/40 text-amber-300 text-xs font-bold shadow-inner">
            <Sparkles size={12} className="text-amber-400" />
            <span>{t('wallet.rate', '১০০,০০০ পয়েন্ট = ১০০ ৳')}</span>
          </div>
        </div>

        {/* Side-by-Side Balance Metrics Grid (High Contrast Solid Cards) */}
        <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5 relative z-10">
          {/* Points Balance */}
          <div className="bg-[#070A12] border border-[#1A2333] rounded-2xl p-3.5 flex flex-col justify-between shadow-inner">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold tracking-wide text-slate-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
                <span>{t('wallet.points_balance', 'মোট পয়েন্ট ব্যালেন্স')}</span>
              </span>
            </div>
            <div className="my-1.5 truncate">
              <div className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight flex items-center gap-1.5">
                <TokenIcon size={19} className="shrink-0" />
                <span className="truncate">{userPoints.toLocaleString()}</span>
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-medium">{t('wallet.points_rate_sub', '১ পয়েন্ট = ০.০০১ টাকা')}</span>
          </div>

          {/* BDT Value */}
          <div className="bg-[#051411] border border-emerald-500/40 rounded-2xl p-3.5 flex flex-col justify-between shadow-inner">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold tracking-wide text-emerald-300 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                <span>{t('wallet.bdt_value', 'টাকার সমপরিমাণ')}</span>
              </span>
            </div>
            <div className="my-1.5 truncate">
              <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tracking-tight truncate">
                {formatBdt(totalBalanceBdt)}
              </div>
            </div>
            <span className="text-[10px] text-emerald-400/90 font-semibold truncate">{t('wallet.bdt_sub', 'বিকাশ ও নগদ ক্যাশআউট')}</span>
          </div>
        </div>

        {/* Withdrawal Threshold Progress */}
        <div className="space-y-1.5 pt-0.5 relative z-10">
          <div className="flex items-center justify-between text-xs flex-wrap gap-1">
            <span className="text-slate-200 flex items-center gap-1.5">
              <span className="text-slate-400">{t('wallet.min_limit', 'ন্যূনতম সীমা')}:</span>
              <strong className="text-emerald-400 font-bold">{effectiveMinWithdrawal.toLocaleString()} {t('wallet.points_suffix', 'পয়েন্ট')} (১০০ ৳)</strong>
            </span>
            <span className={`text-[11px] font-bold ${hasMinBalance ? "text-emerald-400" : "text-amber-400"}`}>
              {hasMinBalance 
                ? t('wallet.eligible', '✓ ক্যাশআউটের উপযোগী') 
                : `${(effectiveMinWithdrawal - userPoints).toLocaleString()} ${t('wallet.need_more', 'পয়েন্ট প্রয়োজন')}`}
            </span>
          </div>
          <div className="w-full h-2 bg-[#060912] rounded-full overflow-hidden border border-[#1A2333] p-0.5">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                hasMinBalance 
                  ? "bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_12px_rgba(16,185,129,0.5)]" 
                  : "bg-gradient-to-r from-amber-600 to-amber-400"
              }`}
              style={{ width: `${withdrawalProgress}%` }}
            />
          </div>
        </div>

        {/* Maintenance Alert */}
        {isMaintenance && (
          <div className="p-3 rounded-2xl bg-[#261502] border border-amber-500/40 text-amber-200 text-xs flex items-center gap-2.5">
            <Power className="w-4 h-4 shrink-0 text-amber-400" />
            <div className="flex-1">
              <strong className="font-bold">সিস্টেম আপডেট: </strong>
              <span>{maintenanceMessage}</span>
            </div>
          </div>
        )}
      </div>

      {/* 2. SUCCESS RECEIPT OVERLAY */}
      {successReceipt && (
        <div className="bg-[#071712] border border-emerald-500/50 rounded-3xl p-4 sm:p-5 shadow-2xl space-y-3.5 backdrop-blur-xl">
          <div className="flex items-center justify-between border-b border-emerald-500/20 pb-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0">
                <CheckCircle2 size={18} />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-white">
                  ক্যাশআউট রিকোয়েস্ট সফলভাবে জমা হয়েছে
                </h3>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  আইডি: <span className="text-emerald-400">{successReceipt.id}</span> • অবস্থা: <strong className="text-amber-400 font-bold">রিভিউ চলছে</strong>
                </p>
              </div>
            </div>

            <button
              onClick={() => setSuccessReceipt(null)}
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-xl bg-[#030A07] border border-white/10 active:scale-95 transition cursor-pointer select-none"
            >
              বন্ধ করুন
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-2.5 bg-[#030906] border border-emerald-500/20 rounded-xl">
              <span className="text-slate-400 block text-[10px]">পেমেন্ট মাধ্যম</span>
              <strong className="text-white font-bold text-sm mt-0.5 block">{successReceipt.method}</strong>
            </div>
            <div className="p-2.5 bg-[#030906] border border-emerald-500/20 rounded-xl">
              <span className="text-slate-400 block text-[10px]">কাটা পয়েন্ট</span>
              <strong className="text-amber-400 flex items-center gap-1 text-sm mt-0.5">
                <TokenIcon size={13} />
                {successReceipt.amount.toLocaleString()}
              </strong>
            </div>
            <div className="p-2.5 bg-[#030906] border border-emerald-500/20 rounded-xl">
              <span className="text-slate-400 block text-[10px]">প্রাপ্য টাকা</span>
              <strong className="text-emerald-400 font-bold text-sm mt-0.5 block">৳ {successReceipt.bdtEst} টাকা</strong>
            </div>
            <div className="p-2.5 bg-[#030906] border border-emerald-500/20 rounded-xl">
              <span className="text-slate-400 block text-[10px]">মোবাইল নম্বর</span>
              <strong className="text-slate-200 truncate block select-all text-sm mt-0.5 font-mono">{successReceipt.destination}</strong>
            </div>
          </div>
        </div>
      )}

      {/* 3. QUICK REDEEM PACKAGES (Symmetrical Saturated 2-Column Mobile Grid) */}
      <div className="bg-[#0C121E] border border-[#1E293B] rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-amber-400" />
            <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide">
              {t('wallet.quick_redeem', 'কুইক রিডিম প্যাকেজ')}
            </h3>
          </div>
          <span className="text-[11px] text-slate-300 hidden sm:inline">
            {t('wallet.quick_redeem_sub', 'ক্লিক করে দ্রুত নির্বাচন করুন')}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
          {QUICK_WITHDRAWAL_PACKAGES.map((pkg) => {
            const isSelected = parsedAmount === pkg.points;
            const canAfford = userPoints >= pkg.points;

            return (
              <button
                key={pkg.id}
                type="button"
                onClick={() => handleSelectPackage(pkg.points)}
                className={`relative p-3 sm:p-3.5 rounded-2xl border text-left transition-all duration-150 cursor-pointer active:scale-[0.98] select-none ${
                  isSelected
                    ? "bg-[#061E16] border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.2)] ring-2 ring-emerald-500/40"
                    : canAfford
                    ? "bg-[#070A12] border-[#1C263A] hover:border-emerald-500/50 hover:bg-[#0A0F1D]"
                    : "bg-[#05070D] border-[#121824] opacity-60 hover:opacity-85"
                }`}
              >
                {pkg.popular && (
                  <span className="absolute -top-2 right-2.5 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-[9px] uppercase tracking-wider shadow-md">
                    {t('action.popular', 'জনপ্রিয়')}
                  </span>
                )}
                <div className="space-y-1">
                  <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <TokenIcon size={14} className="shrink-0" />
                    <span className="truncate">{pkg.label} {t('wallet.points_suffix', 'পয়েন্ট')}</span>
                  </div>
                  <div className="text-lg sm:text-xl font-black text-emerald-400">
                    ৳ {pkg.bdt} <span className="text-[10px] text-slate-300 font-normal">{t('wallet.taka_suffix', 'টাকা')}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 pt-0.5 font-medium">
                    {canAfford ? (
                      <span className="text-emerald-400 font-semibold">{t('wallet.has_balance', '✓ ব্যালেন্স রয়েছে')}</span>
                    ) : (
                      <span>{t('wallet.need_balance', 'পয়েন্ট প্রয়োজন')}</span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. "মাই ওয়ে টু উইথড্র" - CASHOUT REQUEST FORM */}
      <div 
        id="box-my-way-to-withdraw"
        className="bg-[#0C121E] border border-[#1E293B] rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4"
      >
        <div className="flex items-center justify-between border-b border-[#1A2333] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
              <Send size={15} />
            </div>
            <h2 className="text-xs sm:text-sm font-bold text-white tracking-wide">
              {t('wallet.withdraw_form', 'মাই ওয়ে টু উইথড্র')}
            </h2>
          </div>
          <span className="text-[10px] text-emerald-300 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold">
            {t('wallet.zero_fee', '০% ক্যাশআউট ফি')}
          </span>
        </div>

        {/* Banned Alert */}
        {isBanned && (
          <div className="p-3 bg-[#240B10] border border-rose-500/30 rounded-2xl flex items-start gap-2.5 text-xs text-rose-200">
            <ShieldAlert size={16} className="shrink-0 mt-0.5 text-rose-400" />
            <div>
              <strong className="block font-bold">ক্যাশআউট সুবিধা সাময়িক স্থগিত</strong>
              <span className="text-[11px]">{banReason || "অ্যাকাউন্টে বিধিনিষেধ রয়েছে। সাপোর্টে যোগাযোগ করুন।"}</span>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorText && (
          <div className="p-3 bg-[#240B10] border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-200">
            <AlertCircle size={16} className="shrink-0 text-rose-400" />
            <span>{errorText}</span>
          </div>
        )}

        <form onSubmit={handleSubmitWithdrawal} className="space-y-3.5">
          {/* STEP 1: Exclusive Payment Gateway Selection (বিকাশ ও নগদ) */}
          <div className="space-y-2">
            <label className="text-xs text-slate-300 font-bold tracking-wide block">
              {t('wallet.step_method', '১. পেমেন্ট মাধ্যম বেছে নিন')}
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {/* বিকাশ (Fixed Non-Breaking Layout with Absolute Indicator) */}
              <button
                type="button"
                onClick={() => {
                  setSelectedMethod('bKash');
                  setErrorText(null);
                }}
                className={`relative py-3 px-3 rounded-2xl border transition-all duration-150 cursor-pointer select-none text-left ${
                  selectedMethod === 'bKash'
                    ? "bg-[#250919] border-[#E2136E] text-white shadow-[0_0_16px_rgba(226,19,110,0.3)] ring-2 ring-[#E2136E]/40"
                    : "bg-[#14060E] border-[#2E0F21] text-slate-300 hover:text-white hover:border-[#E2136E]/40"
                }`}
              >
                {/* Fixed Top-Right Indicator (Takes zero space in text flex flow) */}
                <div className="absolute top-2.5 right-2.5">
                  <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                    selectedMethod === 'bKash' 
                      ? "bg-[#E2136E] text-white scale-100 shadow-[0_0_8px_rgba(226,19,110,0.8)]" 
                      : "border border-white/20 bg-black/40 scale-90 opacity-40"
                  }`}>
                    {selectedMethod === 'bKash' && <Check size={10} className="stroke-[3]" />}
                  </div>
                </div>

                <div className="flex items-center gap-2.5 pr-4">
                  <div className="w-8 h-8 rounded-xl bg-[#E2136E]/20 border border-[#E2136E]/50 flex items-center justify-center text-[#E2136E] shrink-0 font-bold">
                    <Smartphone size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-sm font-bold text-white block leading-tight truncate whitespace-nowrap">
                      {t('wallet.bkash', 'বিকাশ')}
                    </span>
                    <span className="text-[10px] text-pink-300/90 font-medium block truncate whitespace-nowrap mt-0.5">
                      {t('wallet.personal_acc', 'পার্সোনাল একাউন্ট')}
                    </span>
                  </div>
                </div>
              </button>

              {/* নগদ (Fixed Non-Breaking Layout with Absolute Indicator) */}
              <button
                type="button"
                onClick={() => {
                  setSelectedMethod('Nagad');
                  setErrorText(null);
                }}
                className={`relative py-3 px-3 rounded-2xl border transition-all duration-150 cursor-pointer select-none text-left ${
                  selectedMethod === 'Nagad'
                    ? "bg-[#2A0E04] border-[#FA541C] text-white shadow-[0_0_16px_rgba(250,84,28,0.3)] ring-2 ring-[#FA541C]/40"
                    : "bg-[#160702] border-[#331306] text-slate-300 hover:text-white hover:border-[#FA541C]/40"
                }`}
              >
                {/* Fixed Top-Right Indicator */}
                <div className="absolute top-2.5 right-2.5">
                  <div className={`w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                    selectedMethod === 'Nagad' 
                      ? "bg-[#FA541C] text-white scale-100 shadow-[0_0_8px_rgba(250,84,28,0.8)]" 
                      : "border border-white/20 bg-black/40 scale-90 opacity-40"
                  }`}>
                    {selectedMethod === 'Nagad' && <Check size={10} className="stroke-[3]" />}
                  </div>
                </div>

                <div className="flex items-center gap-2.5 pr-4">
                  <div className="w-8 h-8 rounded-xl bg-[#FA541C]/20 border border-[#FA541C]/50 flex items-center justify-center text-[#FA541C] shrink-0 font-bold">
                    <Smartphone size={16} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-sm font-bold text-white block leading-tight truncate whitespace-nowrap">
                      {t('wallet.nagad', 'নগদ')}
                    </span>
                    <span className="text-[10px] text-orange-300/90 font-medium block truncate whitespace-nowrap mt-0.5">
                      {t('wallet.personal_acc', 'পার্সোনাল একাউন্ট')}
                    </span>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Account Policy Notice: শুধু পার্সোনাল নাম্বার প্রযোজ্য */}
          <div className="flex items-center justify-between text-xs bg-[#070A12] px-3 py-2 rounded-xl border border-[#1A2333]">
            <span className="text-slate-300 font-medium">{t('wallet.acc_type', 'অ্যাকাউন্টের ধরন:')}</span>
            <span className="text-emerald-400 font-bold bg-emerald-950/70 border border-emerald-500/30 px-2.5 py-0.5 rounded-lg text-[11px]">
              {t('wallet.personal_only', 'শুধু পার্সোনাল নাম্বার প্রযোজ্য')}
            </span>
          </div>

          {/* STEP 2: Mobile Number Input */}
          <div className="space-y-1">
            <label className="text-xs text-slate-300 font-bold tracking-wide block">
              {t('wallet.step_mobile', '২. পার্সোনাল মোবাইল নম্বর')} ({selectedMethod === 'bKash' ? t('wallet.bkash', 'বিকাশ') : t('wallet.nagad', 'নগদ')})
            </label>
            <div className="relative">
              <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                <Smartphone size={16} />
              </div>
              <input
                type="tel"
                inputMode="numeric"
                value={accountNumber}
                onChange={(e) => {
                  setErrorText(null);
                  setAccountNumber(e.target.value.replace(/[^0-9]/g, ''));
                }}
                maxLength={11}
                placeholder="01XXXXXXXXX"
                className="w-full bg-[#070A12] border border-[#1E293B] focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-2xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 font-mono outline-none transition"
                required
              />
            </div>
            <p className="text-[10px] text-slate-400 font-medium flex items-center gap-1.5 pl-1 pt-0.5">
              <Shield size={12} className="text-slate-400 shrink-0" />
              <span>{t('wallet.mobile_note', 'সঠিক ১১ ডিজিটের পার্সোনাল নম্বর লিখুন।')}</span>
            </p>
          </div>

          {/* STEP 3: Token Amount & Live BDT Valuation (Modified & Clean Design) */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between">
              <label className="text-xs text-slate-200 font-bold tracking-wide">
                {t('wallet.step_amount', '৩. পয়েন্টের পরিমাণ')}
              </label>
              <div className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/30 shadow-sm">
                {t('wallet.equivalent', 'সমপরিমাণ')}: ৳ {liveEstimateBdt.toLocaleString()} {t('wallet.taka_suffix', 'টাকা')}
              </div>
            </div>

            <div className="relative">
              <input
                type="number"
                inputMode="numeric"
                value={tokenAmount}
                onChange={(e) => {
                  setErrorText(null);
                  setTokenAmount(e.target.value);
                }}
                min={effectiveMinWithdrawal}
                step={1000}
                placeholder={`${t('wallet.min_limit', 'ন্যূনতম সীমা')}: ${effectiveMinWithdrawal.toLocaleString()}`}
                className="w-full bg-[#070A12] border border-[#1E293B] focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-2xl pl-4 pr-11 py-2.5 text-sm text-white placeholder-slate-500 font-mono outline-none transition"
                required
              />
              <div className="absolute right-3.5 top-1/2 -translate-y-1/2 flex items-center pointer-events-none text-amber-400">
                <TokenIcon size={18} />
              </div>
            </div>

            {/* Quick Helper Links */}
            <div className="flex items-center justify-between text-[11px] pt-0.5 text-slate-300 font-medium">
              <button
                type="button"
                onClick={() => setTokenAmount(effectiveMinWithdrawal.toString())}
                className="text-amber-400 hover:underline cursor-pointer transition"
              >
                {t('wallet.min_link', 'ন্যূনতম সীমা')}: {effectiveMinWithdrawal.toLocaleString()} {t('wallet.points_suffix', 'পয়েন্ট')}
              </button>
              <button
                type="button"
                onClick={() => setTokenAmount(userPoints.toString())}
                disabled={userPoints < effectiveMinWithdrawal}
                className="text-emerald-400 hover:underline disabled:opacity-40 cursor-pointer font-bold transition"
              >
                {t('wallet.max_link', 'সম্পূর্ণ ব্যালেন্স')}: {userPoints.toLocaleString()} {t('wallet.points_suffix', 'পয়েন্ট')}
              </button>
            </div>
          </div>

          {/* Submit Action Button */}
          <div className="pt-2">
            {isGuest ? (
              <button
                type="button"
                onClick={() => onTriggerAuth?.('wallet')}
                className="w-full py-3.5 px-5 bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 active:scale-[0.99] text-slate-950 font-black rounded-2xl text-sm tracking-wide transition-all duration-150 cursor-pointer shadow-[0_4px_22px_rgba(245,158,11,0.35)] flex items-center justify-center gap-2 select-none"
              >
                <Sparkles size={16} />
                <span>সাইন আপ করে ভিআইপি ওয়ালেট আনলক করুন</span>
              </button>
            ) : (
              <button
                type="submit"
                disabled={submitting || isBanned || userPoints < effectiveMinWithdrawal}
                className="w-full py-3.5 px-5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 active:scale-[0.99] text-slate-950 font-black rounded-2xl text-sm tracking-wide transition-all duration-150 cursor-pointer shadow-[0_4px_22px_rgba(16,185,129,0.35)] flex items-center justify-center gap-2 disabled:opacity-45 disabled:cursor-not-allowed select-none"
              >
                {submitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>{t('wallet.submitting', 'ক্যাশআউট রিকোয়েস্ট জমা হচ্ছে...')}</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Send size={16} className="stroke-[2.5]" />
                    <span>{t('wallet.submit_btn', 'ক্যাশআউট রিকোয়েস্ট জমা দিন')}</span>
                  </span>
                )}
              </button>
            )}
            {!isGuest && userPoints < effectiveMinWithdrawal && (
              <p className="text-[11px] text-amber-300/90 text-center font-medium pt-1.5">
                {t('wallet.need_more', 'ক্যাশআউট করতে আপনার আরও')} {(effectiveMinWithdrawal - userPoints).toLocaleString()} {t('wallet.points_suffix', 'পয়েন্ট')}
              </p>
            )}
          </div>
        </form>
      </div>

      {/* 5. "টাস্ক রিভিউ" ও "অফিসিয়াল সাপোর্ট" ORGANIC DISTINCT FEATURE BOXES */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Feature Box: টাস্ক রিভিউ (Task Review & Audit) */}
        <div 
          id="box-task-review"
          className="relative overflow-hidden bg-[#0A0E1A] border-2 border-indigo-500/40 hover:border-indigo-400/70 rounded-3xl p-4 shadow-[0_4px_18px_rgba(0,0,0,0.6),0_0_14px_rgba(99,102,241,0.12)] space-y-2.5 transition-all"
        >
          {/* Subtle Ambient Indigo Aura */}
          <div className="absolute -top-8 -right-8 w-28 h-28 bg-indigo-500/15 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-950/90 border border-indigo-500/50 flex items-center justify-center text-indigo-400 shrink-0 shadow-inner">
                <CheckCircle2 size={16} />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight leading-tight">
                  {t('wallet.task_review', 'টাস্ক রিভিউ ও অনুমোদন')}
                </h4>
                <p className="text-[10px] text-indigo-300 font-medium">
                  {t('wallet.task_review_sub', 'স্বয়ংক্রিয় অডিট ও পয়েন্ট যোগ')}
                </p>
              </div>
            </div>
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
              {t('wallet.task_review_tag', 'স্বয়ংক্রিয় অডিট')}
            </span>
          </div>

          <div className="space-y-1.5 text-[11px] text-slate-300 font-sans leading-relaxed relative z-10 pt-1">
            <div className="flex items-start gap-2 bg-[#060912] p-2 rounded-xl border border-indigo-500/20">
              <Clock size={13} className="text-indigo-400 shrink-0 mt-0.5" />
              <span>{t('wallet.review_time', 'রিভিউ সময়: সাধারণত ১২ থেকে ২৪ ঘণ্টার মধ্যে অডিট সম্পন্ন হয়।')}</span>
            </div>
            <div className="flex items-start gap-2 bg-[#060912] p-2 rounded-xl border border-indigo-500/20">
              <Zap size={13} className="text-amber-400 shrink-0 mt-0.5" />
              <span>{t('wallet.review_rule', 'কাজের সত্যতা: সঠিক নিয়ম মেনে ভিডিও দেখা ও নির্দেশ অনুসরণ করলে পয়েন্ট দ্রুত ব্যালেন্সে যুক্ত হয়।')}</span>
            </div>
          </div>
        </div>

        {/* Feature Box: অফিসিয়াল সাপোর্ট (Official 24/7 Helpline) */}
        <div 
          id="box-official-support"
          className="relative overflow-hidden bg-[#041410] border-2 border-emerald-500/40 hover:border-emerald-400/70 rounded-3xl p-4 shadow-[0_4px_18px_rgba(0,0,0,0.6),0_0_14px_rgba(16,185,129,0.12)] space-y-2.5 transition-all"
        >
          {/* Subtle Ambient Emerald Aura */}
          <div className="absolute -top-8 -right-8 w-28 h-28 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-950/90 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
                <Headphones size={16} />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight leading-tight">
                  {t('wallet.official_support', 'অফিসিয়াল সাপোর্ট')}
                </h4>
                <p className="text-[10px] text-emerald-300 font-medium">
                  {t('wallet.support_sub', 'সার্বক্ষণিক সহায়তা কেন্দ্র')}
                </p>
              </div>
            </div>
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              {t('wallet.support_tag', 'সার্বক্ষণিক হেল্পলাইন')}
            </span>
          </div>

          <div className="space-y-1.5 text-[11px] text-slate-300 font-sans leading-relaxed relative z-10 pt-1">
            <div className="flex items-start gap-2 bg-[#020A07] p-2 rounded-xl border border-emerald-500/20">
              <Shield size={13} className="text-emerald-400 shrink-0 mt-0.5" />
              <span>{t('wallet.support_rule', 'ক্যাশআউট বা পয়েন্ট সংক্রান্ত যেকোনো প্রয়োজনে সরাসরি অফিসিয়াল অ্যাডমিন সাপোর্টে যোগাযোগ করুন।')}</span>
            </div>
            
            <a
              href={DEFAULT_TELEGRAM_SUPPORT_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-2 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs transition-colors cursor-pointer"
            >
              <span className="flex items-center gap-1.5">
                <Send size={13} className="text-emerald-400" />
                <span>{t('wallet.support_btn', 'টেলিগ্রাম সাপোর্টে যোগাযোগ করুন')}</span>
              </span>
              <ExternalLink size={13} className="text-emerald-400" />
            </a>
          </div>
        </div>
      </div>

      {/* 6. RECENT PAYOUT HISTORY & TRANSACTION AUDIT */}
      <div className="bg-[#0C121E] border border-[#1E293B] rounded-3xl p-4 sm:p-5 shadow-xl space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-[#1A2333] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <History size={16} />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-white tracking-wide flex items-center gap-2">
                <span>{t('wallet.history_title', 'ক্যাশআউট লেনদেন হিস্ট্রি')}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                  {transactions.filter(t => t.type.toLowerCase().includes('withdraw') || t.type.toLowerCase().includes('cashout') || t.amount < 0).length} {t('wallet.tx_count', 'লেনদেন')}
                </span>
              </h3>
              <p className="text-[11px] text-slate-300 mt-0.5">
                {t('wallet.history_sub', 'বিকাশ ও নগদে আপনার ক্যাশআউট লেনদেনের সম্পূর্ণ রেকর্ড')}
              </p>
            </div>
          </div>

          {/* Filter Segmented Control */}
          <div className="flex items-center gap-1 bg-[#070A12] p-1 rounded-xl border border-[#1A2333] text-[11px] self-start sm:self-auto">
            <button
              onClick={() => setLedgerFilter('all')}
              className={`px-3 py-1 rounded-lg transition-all duration-150 cursor-pointer font-bold select-none ${
                ledgerFilter === 'all'
                  ? "bg-slate-800 text-white shadow border border-white/10"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {t('wallet.all_tx', 'সকল লেনদেন')}
            </button>
            <button
              onClick={() => setLedgerFilter('payouts')}
              className={`px-3 py-1 rounded-lg transition-all duration-150 cursor-pointer font-bold select-none ${
                ledgerFilter === 'payouts'
                  ? "bg-slate-800 text-white shadow border border-white/10"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {t('wallet.withdrawals', 'ক্যাশআউট')}
            </button>
          </div>
        </div>

        {/* Transactions Tight Clean List */}
        {filteredTransactions.length === 0 ? (
          <div className="p-6 text-center bg-[#070A12] border border-[#1A2333] rounded-2xl space-y-1.5">
            <div className="w-9 h-9 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center mx-auto text-slate-400">
              <Wallet size={16} />
            </div>
            <p className="text-xs text-slate-200 font-bold">{t('wallet.no_tx', 'এখনও কোনো ক্যাশআউট লেনদেনের রেকর্ড নেই।')}</p>
            <p className="text-[11px] text-slate-400 font-sans">
              {t('wallet.no_tx_sub', 'ন্যূনতম ১০০,০০০ পয়েন্ট অর্জন করার পর বিকাশ বা নগদে ক্যাশআউট রিকোয়েস্ট পাঠালে তা এখানে প্রদর্শিত হবে।')}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#1A2333] rounded-2xl bg-[#070A12] border border-[#1A2333] overflow-hidden">
            {filteredTransactions.map((tx) => {
              const isPayout = tx.amount < 0 || tx.type.toLowerCase().includes('withdraw') || tx.type.toLowerCase().includes('cashout');
              const statusLower = (tx.status || 'completed').toLowerCase();
              const rawMethod = (tx as any).paymentMethod || (isPayout ? 'bKash' : 'Reward');
              const method = rawMethod === 'bKash' || rawMethod === 'বিকাশ' ? t('wallet.bkash', 'বিকাশ') : rawMethod === 'Nagad' || rawMethod === 'নগদ' ? t('wallet.nagad', 'নগদ') : rawMethod;
              const absAmount = Math.abs(tx.amount);
              const bdtVal = tokensToBdt(absAmount);

              return (
                <div
                  key={tx.id}
                  className="p-3 hover:bg-white/[0.02] flex items-center justify-between gap-2.5 transition"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border ${
                      isPayout 
                        ? "bg-[#200A0E] text-rose-400 border-rose-500/30" 
                        : "bg-[#061811] text-emerald-400 border-emerald-500/30"
                    }`}>
                      {isPayout ? <ArrowUpRight size={15} /> : <ArrowDownLeft size={15} />}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white truncate">
                          {isPayout ? `${method} ${t('wallet.withdrawals', 'ক্যাশআউট')}` : (tx.description || "টাস্ক রিওয়ার্ড")}
                        </span>

                        {/* Gateway Tag */}
                        {isPayout && (
                          <span className={`text-[9px] px-1.5 py-0.2 rounded-md font-bold ${
                            rawMethod.toLowerCase().includes('nagad') || rawMethod === 'নগদ'
                              ? 'bg-[#FA541C]/20 text-[#FA541C] border border-[#FA541C]/40'
                              : 'bg-[#E2136E]/20 text-[#E2136E] border border-[#E2136E]/40'
                          }`}>
                            {method}
                          </span>
                        )}
                        
                        {/* Status Pills */}
                        {statusLower === 'pending' && (
                          <span className="text-[9px] bg-amber-950/80 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/40 font-bold inline-flex items-center gap-1">
                            <Clock size={9} className="animate-spin" />
                            {t('wallet.pending', 'অপেক্ষমান')}
                          </span>
                        )}
                        {(statusLower === 'completed' || statusLower === 'approved' || statusLower === 'paid') && (
                          <span className="text-[9px] bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/40 font-bold inline-flex items-center gap-0.5">
                            <Check size={9} />
                            {t('wallet.approved', 'অনুমোদিত')}
                          </span>
                        )}
                        {statusLower === 'rejected' && (
                          <span className="text-[9px] bg-rose-950/80 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/40 font-bold">
                            {t('wallet.rejected', 'বাতিল')}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                        <span>{new Date(tx.timestamp).toLocaleString()}</span>
                        {(tx as any).accountNumber && (
                          <>
                            <span>•</span>
                            <span className="text-slate-300">{(tx as any).accountNumber}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Amount in Numbers & BDT */}
                  <div className="text-right shrink-0">
                    <div className={`text-xs sm:text-sm font-black flex items-center gap-1 justify-end font-mono ${
                      isPayout ? "text-rose-400" : "text-emerald-400"
                    }`}>
                      <TokenIcon size={13} />
                      <span>
                        {isPayout ? "-" : "+"}{absAmount.toLocaleString()}
                      </span>
                    </div>
                    {isPayout && (
                      <div className="text-[10px] text-slate-300 font-bold font-mono">
                        ৳ {bdtVal} {t('wallet.taka_suffix', 'টাকা')}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export const WalletScreen = React.memo(WalletScreenComponent);
export default WalletScreen;
