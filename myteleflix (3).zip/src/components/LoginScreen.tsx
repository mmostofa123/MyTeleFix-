/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Film, Play, Sparkles, ShieldCheck, ArrowRight, Globe, Lock, CheckCircle2, Loader2, AlertCircle } from "lucide-react";
import { getDeviceFingerprint, getCachedDeviceFingerprint } from "../utils/fingerprint";
import { signInWithGoogleSeamless, getClientIp } from "../services/auth";
import OnboardingFlow from "./OnboardingFlow";
import WelcomeOnboardingModal from "./WelcomeOnboardingModal";
import PolicyViolationModal from "./PolicyViolationModal";
import SecurityWarningModal from "./SecurityWarningModal";
import { clearSecondaryDraftSession, restorePrimaryAccount } from "../SecurityManager";
import { User } from "../types";

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  isSyncing?: boolean;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  // Check if returning user with existing valid session
  const [hasStarted, setHasStarted] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const savedUser = localStorage.getItem("myteleflix_user");
      if (savedUser) {
        try {
          const parsed = JSON.parse(savedUser);
          return Boolean(parsed && parsed.id && parsed.role !== 'guest');
        } catch {
          return false;
        }
      }
    }
    return false;
  });

  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [isProcessingAuth, setIsProcessingAuth] = useState(false);
  const [deviceFingerprint, setDeviceFingerprint] = useState<string>(() => getCachedDeviceFingerprint());
  const [clientIp, setClientIp] = useState<string>("");
  const [lockNotice, setLockNotice] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Policy Violation Modal state
  const [policyViolation, setPolicyViolation] = useState<{
    isOpen: boolean;
    error?: string;
    existingAccount?: { id?: string; email?: string; username?: string };
    deviceFingerprint?: string;
    ipAddress?: string;
  }>({ isOpen: false });

  // Strict Hardware Security Warning Screen state
  const [securityModal, setSecurityModal] = useState<{
    isOpen: boolean;
    primaryEmail: string;
    attemptedEmail?: string;
    hwid?: string;
    message?: string;
  }>({ isOpen: false, primaryEmail: "" });

  // Welcome Onboarding Modal state (Gender & Dynamic Avatar setup)
  const [pendingOnboardingUser, setPendingOnboardingUser] = useState<User | null>(null);

  // Detect Telegram environment
  const [isTelegram, setIsTelegram] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return Boolean((window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id);
  });

  const [tgUser, setTgUser] = useState<any>(() => {
    if (typeof window === "undefined") return null;
    return (window as any).Telegram?.WebApp?.initDataUnsafe?.user || null;
  });

  const loadingSteps = [
    "Verifying Hardware Device ID...",
    "Registering Secure IP Signature...",
    "Binding Security Vault...",
    "Access Granted..."
  ];

  // Initialize environment detection, fingerprint & IP
  useEffect(() => {
    getDeviceFingerprint().then((fp) => {
      setDeviceFingerprint(fp);
    });
    getClientIp().then((ip) => {
      setClientIp(ip);
    });

    if (typeof window !== "undefined" && (window as any).Telegram?.WebApp) {
      try {
        (window as any).Telegram.WebApp.ready();
        (window as any).Telegram.WebApp.expand();
        const user = (window as any).Telegram.WebApp.initDataUnsafe?.user;
        if (user && user.id) {
          setIsTelegram(true);
          setTgUser(user);
        }
      } catch (e) {
        console.warn("Telegram WebApp init warning:", e);
      }
    }
  }, []);

  // Run progress animation into app
  const runProgressSequence = (targetUser: User) => {
    setHasStarted(true);
    const totalDuration = 1200;
    const intervalTime = 20;
    const increment = 100 / (totalDuration / intervalTime);

    const timer = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            onLoginSuccess(targetUser);
          }, 200);
          return 100;
        }
        const stepIndex = Math.min(Math.floor((next / 100) * loadingSteps.length), loadingSteps.length - 1);
        setCurrentStep(stepIndex);
        return next;
      });
    }, intervalTime);
  };

  // If returning user with saved token in localStorage, auto-trigger the progress animation
  const hasTriggeredRef = useRef(false);
  useEffect(() => {
    if (hasStarted && !hasTriggeredRef.current) {
      hasTriggeredRef.current = true;
      try {
        const saved = localStorage.getItem("myteleflix_user");
        if (saved) {
          const u = JSON.parse(saved);
          runProgressSequence(u);
        }
      } catch {
        // ignore
      }
    }
  }, [hasStarted]);

  // SEAMLESS 1-CLICK GOOGLE SIGN-IN HANDLER
  const handleGoogleSignIn = async (preferredEmail?: string, preferredName?: string) => {
    if (isProcessingAuth) return;
    setIsProcessingAuth(true);
    setAuthError(null);

    try {
      // Direct 1-Click Google Sign-In with 1-Device Policy Enforcement
      const result = await signInWithGoogleSeamless({
        email: preferredEmail,
        fullName: preferredName,
        usePopup: !preferredEmail // Use native popup if no pre-selected account
      });

      setIsProcessingAuth(false);

      // Check if user requires the First-Time Welcome Onboarding Modal
      if (result.needsOnboarding) {
        setPendingOnboardingUser(result.user);
      } else {
        runProgressSequence(result.user);
      }
    } catch (err: any) {
      setIsProcessingAuth(false);

      // Check if blocked by Strict Hardware Device / Anti-Multi Account Policy
      if (err.blocked || err.message?.includes("1 Device = 1 Account") || err.message?.includes("POLICY VIOLATION") || err.primaryEmail || err.message?.includes("অ্যাকাউন্ট") || err.message?.includes("একউন্ট") || err.message?.includes("নিষিদ্ধ")) {
        clearSecondaryDraftSession();
        try {
          localStorage.removeItem("myteleflix_user");
          localStorage.removeItem("myteleflix_auth_token");
          localStorage.removeItem("myteleflix_current_session");
        } catch (e) {}

        const pEmail = err.primaryEmail || (typeof err.existingAccount === 'object' ? err.existingAccount?.email : err.existingAccount) || "Authorized Account";
        setSecurityModal({
          isOpen: true,
          primaryEmail: pEmail,
          attemptedEmail: preferredEmail,
          hwid: err.hwid || deviceFingerprint,
          message: err.message
        });
        return;
      }

      // Other errors
      setAuthError(err.message || "Authentication failed. Please try again.");
    }
  };

  // Completion from Welcome Onboarding Modal
  const handleOnboardingComplete = (initializedUser: User) => {
    setPendingOnboardingUser(null);
    runProgressSequence(initializedUser);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#0a0b10] text-white flex flex-col justify-between items-center p-6 sm:p-8 select-none font-sans overflow-hidden">
      {/* AMBIENT BACKGROUND GLOWS */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div
          animate={{
            rotate: [0, 360],
            scale: [1, 1.25, 1],
            opacity: [0.35, 0.55, 0.35],
          }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
          className="absolute -top-40 -left-40 w-[35rem] h-[35rem] rounded-full bg-gradient-to-br from-cyan-500/35 via-indigo-600/25 to-transparent blur-[120px]"
        />

        <motion.div
          animate={{
            rotate: [360, 0],
            scale: [1.25, 1, 1.25],
            opacity: [0.35, 0.55, 0.35],
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-40 -right-40 w-[35rem] h-[35rem] rounded-full bg-gradient-to-tl from-fuchsia-600/35 via-purple-600/25 to-transparent blur-[120px]"
        />

        <div 
          className="absolute inset-0 opacity-[0.035] pointer-events-none" 
          style={{
            backgroundImage: `radial-gradient(circle, #38BDF8 1px, transparent 1px)`,
            backgroundSize: '32px 32px'
          }}
        />
      </div>

      {/* TOP HEADER */}
      <div className="w-full max-w-md flex justify-between items-center text-[10px] font-mono tracking-widest text-slate-500 uppercase font-semibold relative z-10 pt-2">
        <span className="text-cyan-400/90 font-bold tracking-widest flex items-center gap-1.5">
          <Film className="w-3 h-3 text-cyan-400" />
          MY TELEFLIX CINEMA
        </span>
        <span className="flex items-center gap-1.5 text-slate-400">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
          {isTelegram ? "TMA SECURE" : "1-DEVICE LOCK ACTIVE"}
        </span>
      </div>

      {/* CENTER LOGO & TITLE */}
      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 relative z-10 my-auto w-full max-w-md">
        <motion.div
          initial={{ scale: 0.75, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="relative"
        >
          <div className="absolute -inset-6 rounded-full bg-gradient-to-r from-cyan-500 via-purple-500 to-fuchsia-500 blur-3xl opacity-60 animate-pulse" />
          
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-slate-950/80 border border-cyan-500/30 backdrop-blur-3xl shadow-[0_0_60px_rgba(56,189,248,0.4)] flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/20 to-transparent -translate-x-full animate-[shimmer_2.5s_infinite]" />
            
            <div className="w-full h-full rounded-[22px] bg-gradient-to-b from-slate-900 via-[#0a0b10] to-[#05060a] flex items-center justify-center relative">
              <motion.div
                animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="relative flex items-center justify-center"
              >
                <Film className="w-14 h-14 sm:w-16 sm:h-16 text-cyan-400 drop-shadow-[0_0_20px_rgba(56,189,248,0.9)]" />
                <div className="absolute bg-white text-indigo-950 rounded-full p-2 shadow-2xl border border-cyan-200">
                  <Play size={16} className="fill-indigo-950 translate-x-0.5" />
                </div>
              </motion.div>
            </div>
          </div>

          <motion.div 
            animate={{ y: [-4, 4, -4] }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-2 -right-2 bg-gradient-to-r from-cyan-400 to-fuchsia-500 p-2 rounded-xl text-slate-950 shadow-lg shadow-cyan-500/40"
          >
            <Sparkles size={13} className="fill-slate-950 text-slate-950" />
          </motion.div>
        </motion.div>

        <div className="space-y-2 max-w-sm mx-auto">
          <motion.h1
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-4xl sm:text-5xl font-black tracking-tight"
          >
            <span className="bg-gradient-to-r from-white via-cyan-100 via-indigo-200 to-fuchsia-300 bg-clip-text text-transparent font-sans drop-shadow-[0_0_35px_rgba(56,189,248,0.6)]">
              My TeleFlix
            </span>
          </motion.h1>

          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="text-[11px] font-mono font-bold tracking-[0.2em] text-cyan-400/90 uppercase"
          >
            PREMIUM CINEMA & REWARDS ENGINE
          </motion.p>
        </div>

        {/* ERROR NOTICE IF OCCURRED */}
        {authError && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full bg-rose-950/80 border border-rose-500/40 rounded-xl p-2.5 text-xs text-rose-300 flex items-center gap-2"
          >
            <AlertCircle size={15} className="text-rose-400 shrink-0" />
            <span className="text-left font-mono">{authError}</span>
          </motion.div>
        )}

        {/* 1. SEAMLESS 1-CLICK GOOGLE SIGN-IN INTERFACE (ZERO DROP-OFF, ZERO INPUT FIELDS) */}
        {!hasStarted && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="w-full space-y-3 pt-2"
          >
            <div className="bg-slate-900/80 border border-cyan-500/30 rounded-2xl p-4 sm:p-5 backdrop-blur-xl shadow-xl space-y-3.5">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
                <div className="flex items-center gap-2">
                  <Globe className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-mono font-bold text-cyan-300 uppercase tracking-wider">Fast Access</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
                  <Lock size={10} /> 1 Device = 1 Account
                </span>
              </div>

              <p className="text-xs text-slate-300 text-center leading-relaxed">
                Sign in with 1-click Google Auth to bind your hardware profile, set up your avatar, and unlock +100 Welcome bonus.
              </p>

              {/* PRIMARY 1-CLICK GOOGLE AUTH BUTTON (TACTILE LASER PRESS) */}
              <button
                id="btn-google-1click"
                onClick={() => handleGoogleSignIn()}
                disabled={isProcessingAuth}
                className="w-full py-3.5 px-5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-sm flex items-center justify-center gap-3 shadow-lg active:scale-95 active:brightness-125 active:ring-2 active:ring-emerald-400/80 active:shadow-lg active:shadow-emerald-900/50 transition-all duration-75 ease-out cursor-pointer disabled:opacity-50"
              >
                {isProcessingAuth ? (
                  <Loader2 className="w-5 h-5 animate-spin text-slate-800" />
                ) : (
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/>
                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"/>
                    <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"/>
                    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                  </svg>
                )}
                <span>{isProcessingAuth ? "Verifying Device & Signing In..." : "1-Click Sign in with Google"}</span>
              </button>

              {/* Instant Developer Quick Login (Frictionless Sandbox Testing) */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="text-[10px] font-mono text-slate-400 mb-2 flex items-center justify-between">
                  <span>Fast Sandbox Access:</span>
                  <span className="text-cyan-400">Zero Typing</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleGoogleSignIn("mostofa7077a@gmail.com", "Mostofa Showkat")}
                    disabled={isProcessingAuth}
                    className="py-2 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono font-medium text-amber-300 border border-amber-500/30 truncate active:scale-95 transition cursor-pointer"
                  >
                    Super Admin
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGoogleSignIn("cinema_fan@gmail.com", "Alex Cinema")}
                    disabled={isProcessingAuth}
                    className="py-2 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono font-medium text-cyan-300 border border-cyan-500/30 truncate active:scale-95 transition cursor-pointer"
                  >
                    Member Demo
                  </button>
                </div>
              </div>

              {/* Hardware Device Fingerprint Badge */}
              <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-400 font-mono pt-1">
                <ShieldCheck size={11} className="text-emerald-400" />
                <span>Device FP: {deviceFingerprint ? `${deviceFingerprint.slice(0, 8)}...` : "Detecting..."}</span>
                {clientIp && <span className="text-slate-500">&bull; IP: {clientIp}</span>}
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* PROGRESS BAR & DYNAMIC STATUS (FOR RETURNING USERS OR POST-AUTH) */}
      {hasStarted && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm mx-auto space-y-3 pb-6 relative z-10 text-center"
        >
          {lockNotice && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-emerald-950/80 border border-emerald-500/40 rounded-xl px-3 py-1.5 text-[11px] font-mono text-emerald-300 flex items-center justify-center gap-1.5 shadow-lg"
            >
              <CheckCircle2 size={13} className="text-emerald-400" />
              <span>{lockNotice}</span>
            </motion.div>
          )}

          <div className="w-full h-2.5 bg-slate-950 rounded-full border border-slate-800/80 p-0.5 relative overflow-hidden shadow-[0_0_20px_rgba(0,0,0,0.8)]">
            <motion.div
              initial={{ width: "0%" }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1, ease: "linear" }}
              className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-fuchsia-500 relative shadow-[0_0_20px_rgba(56,189,248,0.9)]"
            >
              <div className="absolute right-0 top-0 bottom-0 w-3 bg-white rounded-full blur-[1px] opacity-90 animate-pulse" />
            </motion.div>
          </div>

          <div className="flex justify-between items-center text-xs font-mono px-1">
            <AnimatePresence mode="wait">
              <motion.span
                key={currentStep}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.2 }}
                className="text-slate-300 font-semibold tracking-wide"
              >
                {loadingSteps[currentStep]}
              </motion.span>
            </AnimatePresence>

            <span className="text-cyan-400 font-bold tracking-wider">
              {Math.round(progress)}%
            </span>
          </div>
        </motion.div>
      )}

      {/* 2. WELCOME ONBOARDING FLOW (MULTI-STEP PROFILE SETUP & PLATFORM BENEFITS) */}
      {pendingOnboardingUser && (
        <OnboardingFlow
          isOpen={Boolean(pendingOnboardingUser)}
          user={pendingOnboardingUser}
          onComplete={handleOnboardingComplete}
        />
      )}

      {/* 3. STRICT HARDWARE SECURITY WARNING SCREEN */}
      <SecurityWarningModal
        isOpen={securityModal.isOpen}
        primaryEmail={securityModal.primaryEmail}
        attemptedEmail={securityModal.attemptedEmail}
        hwid={securityModal.hwid}
        message={securityModal.message}
        onClose={() => {
          clearSecondaryDraftSession();
          try {
            localStorage.removeItem("myteleflix_user");
            localStorage.removeItem("myteleflix_auth_token");
            localStorage.removeItem("myteleflix_current_session");
          } catch (e) {}
          setSecurityModal(prev => ({ ...prev, isOpen: false }));
        }}
        onSwitchToPrimary={async (targetEmail) => {
          setSecurityModal(prev => ({ ...prev, isOpen: false }));
          const target = targetEmail || securityModal.primaryEmail;
          if (target) {
            try {
              const primaryUser = await restorePrimaryAccount(target);
              if (primaryUser) {
                runProgressSequence(primaryUser);
                return;
              }
            } catch (e) {
              console.warn("restorePrimaryAccount notice:", e);
            }
            await handleGoogleSignIn(target);
          }
        }}
      />

      {/* 4. STRICT 1-DEVICE 1-ACCOUNT POLICY VIOLATION MODAL */}
      <PolicyViolationModal
        isOpen={policyViolation.isOpen}
        errorMessage={policyViolation.error}
        existingAccount={policyViolation.existingAccount}
        deviceFingerprint={policyViolation.deviceFingerprint}
        ipAddress={policyViolation.ipAddress}
        onClose={() => setPolicyViolation({ isOpen: false })}
        onRestoreOriginalAccount={async () => {
          setPolicyViolation({ isOpen: false });
          const target = policyViolation.existingAccount?.email || securityModal.primaryEmail;
          if (target) {
            try {
              const primaryUser = await restorePrimaryAccount(target);
              if (primaryUser) {
                runProgressSequence(primaryUser);
                return;
              }
            } catch (e) {
              console.warn("restorePrimaryAccount notice:", e);
            }
            await handleGoogleSignIn(target);
          }
        }}
      />
    </div>
  );
}
