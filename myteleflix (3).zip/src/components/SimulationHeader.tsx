/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { User, Shield, Users, RefreshCw } from "lucide-react";

interface SimulationHeaderProps {
  currentUser: { id: string; fullName: string; role: 'user' | 'guest' | 'admin' | 'super_admin' };
  onSwitchRole: (role: 'user' | 'guest' | 'admin' | 'super_admin') => void;
  isSyncing: boolean;
}

export default function SimulationHeader({ currentUser, onSwitchRole, isSyncing }: SimulationHeaderProps) {
  const [copiedLink, setCopiedLink] = useState(false);

  const referralLink = `${window.location.origin}?ref=tg-101`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div id="sim-header" className="bg-white text-[#1E293B] text-[11px] px-4 py-2 flex flex-wrap items-center justify-between gap-2.5 border-b border-[#E2E8F0] shadow-sm relative z-40">
      <div className="flex items-center gap-1.5 font-mono">
        <span className="inline-flex h-2 w-2 rounded-full bg-[#4F46E5]"></span>
        <span className="font-extrabold text-[9px] tracking-wider uppercase text-[#4F46E5]">MY TELEFLIX SIMULATOR PANEL</span>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[#64748B] text-[10px] font-bold uppercase tracking-wider">Role Switcher:</span>
        <div className="inline-flex rounded-xl bg-[#F8FAFC] p-0.5 border border-[#E2E8F0]">
          <button
            id="sim-role-user"
            onClick={() => onSwitchRole('user')}
            className={`px-3 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-wider transition-all duration-200 flex items-center gap-1 ${
              currentUser.role === 'user' 
                ? 'bg-[#4F46E5] text-white shadow-sm' 
                : 'text-[#64748B] hover:text-[#1E293B]'
            }`}
          >
            <User size={10} />
            User: Mostofa
          </button>
          <button
            id="sim-role-guest"
            onClick={() => onSwitchRole('guest')}
            className={`px-3 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-wider transition-all duration-200 flex items-center gap-1 ${
              currentUser.role === 'guest' 
                ? 'bg-[#4F46E5] text-white shadow-sm' 
                : 'text-[#64748B] hover:text-[#1E293B]'
            }`}
          >
            <Users size={10} />
            Guest: Referred
          </button>
          <button
            id="sim-role-admin"
            onClick={() => onSwitchRole('admin')}
            className={`px-3 py-1 rounded-lg text-[9px] font-extrabold uppercase tracking-wider transition-all duration-200 flex items-center gap-1 ${
              currentUser.role === 'admin' 
                ? 'bg-[#EF4444] text-white shadow-sm' 
                : 'text-[#64748B] hover:text-[#1E293B]'
            }`}
          >
            <Shield size={10} />
            Admin Mode
          </button>
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        {currentUser.role === 'guest' ? (
          <div className="hidden md:flex items-center gap-1 text-[9px] text-[#4F46E5] bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-150 font-mono font-bold uppercase tracking-wider">
            🎁 Joined via referral code: tg-101
          </div>
        ) : (
          <button
            id="sim-copy-ref"
            onClick={handleCopyLink}
            className="text-[9px] font-bold bg-white hover:bg-slate-50 text-[#4F46E5] transition px-2.5 py-1 rounded-lg border border-[#E2E8F0] flex items-center gap-1 uppercase tracking-wider font-mono shadow-sm cursor-pointer"
          >
            {copiedLink ? "Copied!" : "Copy referral link to test"}
          </button>
        )}
        {isSyncing && (
          <RefreshCw size={11} className="animate-spin text-[#4F46E5]" />
        )}
      </div>
    </div>
  );
}
