/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import OnboardingFlow, { OnboardingFlowProps } from "./OnboardingFlow";

export default function WelcomeOnboardingModal(props: OnboardingFlowProps) {
  return <OnboardingFlow {...props} />;
}

export { OnboardingFlow };
