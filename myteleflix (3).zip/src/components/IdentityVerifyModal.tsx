/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ShieldCheck, Smartphone, Zap, X, ArrowRight, CheckCircle2 } from "lucide-react";

export interface IdentityVerifyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onProceed?: () => void;
  frequencyHours?: number;
  countdownSeconds?: number;
}

export const SEEN_STORAGE_KEY = "account_verification_notice_seen";
const STORAGE_KEY = "myteleflix_identity_security_notice_ts";
const DEFAULT_COOLDOWN_HOURS = 72;

export const getVerificationSettingsFromStorage = () => {
  try {
    const raw = localStorage.getItem("myteleflix_verification_settings");
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
};

/**
 * Checks if the account verification modal should be shown:
 * 1. If seen once (account_verification_notice_seen === 'true'), NEVER show again.
 * 2. Otherwise check cooldown / first-time status.
 */
export const shouldShowSecurityNotice = (customCooldownHours?: number): boolean => {
  try {
    if (typeof window === "undefined") return false;
    const hasSeenOnce = localStorage.getItem(SEEN_STORAGE_KEY);
    if (hasSeenOnce === "true") {
      return false;
    }
    const lastShown = localStorage.getItem(STORAGE_KEY);
    if (!lastShown) return true;
    const diffMs = Date.now() - parseInt(lastShown, 10);
    const hours = diffMs / (1000 * 60 * 60);
    const cooldown = customCooldownHours ?? getVerificationSettingsFromStorage()?.noticeFrequencyHours ?? DEFAULT_COOLDOWN_HOURS;
    return hours >= cooldown;
  } catch {
    return true;
  }
};

export const markSecurityNoticeAsShown = (): void => {
  try {
    localStorage.setItem(SEEN_STORAGE_KEY, "true");
    localStorage.setItem(STORAGE_KEY, Date.now().toString());
  } catch (err) {
    console.error("Failed to save security notice timestamp", err);
  }
};

export const IdentityVerifyModal: React.FC<IdentityVerifyModalProps> = ({
  isOpen,
  onClose,
  onProceed,
}) => {
  // Mark as seen immediately when rendered so it is strictly guaranteed to appear at most once
  React.useEffect(() => {
    if (isOpen) {
      markSecurityNoticeAsShown();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClose = () => {
    markSecurityNoticeAsShown();
    onClose();
  };

  const handleProceed = () => {
    markSecurityNoticeAsShown();
    if (onProceed) {
      onProceed();
    } else {
      onClose();
    }
  };

  return (
    <div
      id="identity-verify-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-150"
      onClick={handleClose}
    >
      <div
        id="identity-verify-modal-card"
        className="w-full max-w-md bg-[#0A0D14] border border-[#1E2536] rounded-2xl sm:rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] p-5 sm:p-6 text-white relative overflow-hidden my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 right-1/4 w-32 h-20 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#1A2234] relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
              <ShieldCheck size={20} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                অ্যাকাউন্ট ভেরিফিকেশন
              </h3>
              <p className="text-[11px] text-slate-400 font-mono">
                এক-কালীন অ্যাকাউন্ট তথ্য যাচাইকরণ
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-close-identity-modal"
            onClick={handleClose}
            className="p-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition cursor-pointer"
            title="Close"
          >
            <X size={16} />
          </button>
        </div>

        {/* 3-Bullet Summary in Clean Bangla */}
        <div className="my-5 space-y-3 relative z-10 font-sans">
          {/* Bullet 1 */}
          <div className="p-3.5 rounded-xl bg-[#0F1420] border border-[#1E2638] flex items-start gap-3">
            <div className="p-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 shrink-0 mt-0.5">
              <CheckCircle2 size={16} />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-white tracking-tight">
                ১. পরিচয় যাচাই
              </h4>
              <p className="text-[11.5px] text-slate-300 leading-relaxed">
                অনুমোদিত রেফারেল এবং রিওয়ার্ড বোনাস নিশ্চিত করতে তথ্য যাচাই বাধ্যতামূলক।
              </p>
            </div>
          </div>

          {/* Bullet 2 */}
          <div className="p-3.5 rounded-xl bg-[#0F1420] border border-[#1E2638] flex items-start gap-3">
            <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 shrink-0 mt-0.5">
              <Smartphone size={16} />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-white tracking-tight">
                ২. একটি ডিভাইসে একটি অ্যাকাউন্ট
              </h4>
              <p className="text-[11.5px] text-slate-300 leading-relaxed">
                প্রতিটি ডিভাইসে কেবলমাত্র একটি একক ভেরিফাইড অ্যাকাউন্ট অনুমোদনযোগ্য।
              </p>
            </div>
          </div>

          {/* Bullet 3 */}
          <div className="p-3.5 rounded-xl bg-[#0F1420] border border-[#1E2638] flex items-start gap-3">
            <div className="p-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-400 shrink-0 mt-0.5">
              <Zap size={16} />
            </div>
            <div className="space-y-0.5">
              <h4 className="text-xs font-bold text-white tracking-tight">
                ৩. দ্রুত সুবিধা আনলক
              </h4>
              <p className="text-[11.5px] text-slate-300 leading-relaxed">
                ভেরিফিকেশন সম্পন্ন হওয়া মাত্রই রেফারেল ও উইথড্র ফিচার সক্রিয় হবে।
              </p>
            </div>
          </div>
        </div>

        {/* Action Button - High Contrast Green Style, No Delays */}
        <div className="pt-2 relative z-10">
          <button
            type="button"
            id="btn-proceed-verification"
            onClick={handleProceed}
            className="w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm font-mono tracking-wide flex items-center justify-center gap-2 bg-[#059669] hover:bg-[#10B981] active:bg-[#047857] text-white shadow-lg shadow-emerald-950/50 transition-all duration-150 cursor-pointer select-none"
          >
            <span>ভেরিফিকেশন শুরু করুন</span>
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default IdentityVerifyModal;
