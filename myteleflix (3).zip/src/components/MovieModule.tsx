/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Movie, Mission, MovieRequest, User, AppLanguage } from "../types";
import MoviesScreen from "./MoviesScreen";

export interface MovieModuleProps {
  movies: Movie[];
  completedMissionIds?: string[];
  userIsPremium?: boolean;
  onViewedMovie: (id: string, isMovie: boolean) => Promise<void>;
  missions?: Mission[];
  requests?: MovieRequest[];
  onSearchAi?: (query: string, notes?: string) => Promise<{ success: boolean; responseText: string; request: MovieRequest }>;
  isSyncing?: boolean;
  isAdultUnlocked?: boolean;
  onNavigate?: (tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => void;
  onCategoryChange?: (cat: string) => void;
  user?: User;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  currentLanguage?: AppLanguage;
}

function MovieModuleComponent(props: MovieModuleProps) {
  return (
    <MoviesScreen
      movies={props.movies}
      completedMissionIds={props.completedMissionIds}
      userIsPremium={props.userIsPremium}
      onViewedMovie={props.onViewedMovie}
      missions={props.missions}
      requests={props.requests}
      onSearchAi={props.onSearchAi}
      isSyncing={props.isSyncing}
      isAdultUnlocked={props.isAdultUnlocked}
      onNavigate={props.onNavigate}
      onCategoryChange={props.onCategoryChange}
      user={props.user}
      guideVideoUrl={props.guideVideoUrl}
      guideVideoLogoUrl={props.guideVideoLogoUrl}
      onBackToAll={undefined}
      showSearchBar={true}
      currentLanguage={props.currentLanguage}
    />
  );
}

const MovieModule = React.memo(MovieModuleComponent);
export default MovieModule;
