/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldAlert, 
  ShieldCheck, 
  Check, 
  X, 
  CheckCircle2,
  FileCheck,
  Lock,
  FileText,
  AlertTriangle
} from "lucide-react";

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm?: () => void;
  initialTab?: 'verify' | 'policy';
}

export default function PrivacyModal({ 
  isOpen, 
  onClose, 
  onConfirm,
  initialTab = 'verify'
}: PrivacyModalProps) {
  const [activeTab, setActiveTab] = useState<'verify' | 'policy'>(initialTab);
  const [hasAcknowledged, setHasAcknowledged] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setHasAcknowledged(false);
    }
  }, [isOpen, initialTab]);

  const handleAgreeAndUnlock = () => {
    try {
      localStorage.setItem("myteleflix_18plus_unlocked", "true");
    } catch (e) {
      console.error("Failed to save to localStorage", e);
    }
    onConfirm?.();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div 
          id="privacy-18plus-modal-overlay" 
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="bg-slate-900 text-slate-100 w-full max-w-md rounded-2xl overflow-hidden shadow-2xl border border-slate-800 relative my-auto flex flex-col max-h-[90vh]"
          >
            {/* Modal Header */}
            <div className="px-3.5 py-3 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 min-w-0">
                <span className="p-1.5 bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg shrink-0">
                  {activeTab === 'verify' ? <ShieldAlert size={16} /> : <FileText size={16} />}
                </span>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wide truncate">
                    {activeTab === 'verify' ? "Safe Mode Deactivation" : "Content Privacy & Terms"}
                  </h4>
                  <span className="text-[9.5px] text-slate-400 font-mono block truncate">
                    {activeTab === 'verify' ? "Age 18+ Verification Gateway" : "Safety, Privacy & Legal Policy"}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition cursor-pointer shrink-0"
              >
                <X size={15} />
              </button>
            </div>

            {/* Sub-Tabs: Age Verification vs Legal Policy */}
            <div className="px-3.5 pt-2.5 pb-1 bg-slate-950/60 border-b border-slate-800/60 shrink-0">
              <div className="grid grid-cols-2 gap-1 bg-[#0A0D15] p-1 rounded-xl border border-slate-800 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() => setActiveTab('verify')}
                  className={`py-1.5 px-2 rounded-lg font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 truncate ${
                    activeTab === 'verify'
                      ? 'bg-rose-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ShieldAlert size={12} className="shrink-0" />
                  <span className="truncate">Age Verification</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('policy')}
                  className={`py-1.5 px-2 rounded-lg font-semibold transition cursor-pointer flex items-center justify-center gap-1.5 truncate ${
                    activeTab === 'policy'
                      ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText size={12} className="shrink-0" />
                  <span className="truncate">Privacy & Safety</span>
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 sm:p-4 space-y-3 overflow-y-auto flex-1 text-slate-100">
              {activeTab === 'verify' ? (
                <>
                  {/* Notice List */}
                  <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl p-3 space-y-2 text-[11.5px] text-slate-300 font-sans leading-snug">
                    <div className="flex items-center gap-2 text-rose-300 font-semibold">
                      <CheckCircle2 size={14} className="text-rose-400 shrink-0" />
                      <span>I confirm that I am at least 18 years of age (বয়স ১৮ বছর বা তার বেশি)</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-300">
                      <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                      <span>Deactivating Safe Mode unlocks unrestricted catalog content on this device</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 text-[10.5px]">
                      <Lock size={13} className="text-slate-500 shrink-0" />
                      <span>Maintain Safe Mode active if children or family members use this hardware</span>
                    </div>
                  </div>

                  {/* Instant Tap Consent Checkbox */}
                  <label 
                    onClick={() => setHasAcknowledged(!hasAcknowledged)}
                    className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/90 border border-slate-800 hover:border-slate-700 cursor-pointer select-none transition"
                  >
                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition ${
                      hasAcknowledged 
                        ? 'bg-rose-600 border-rose-500 text-white' 
                        : 'bg-slate-900 border-slate-700'
                    }`}>
                      {hasAcknowledged && <Check size={12} strokeWidth={3} />}
                    </div>
                    <span className="text-xs font-medium text-slate-200 leading-snug">
                      I confirm that I am 18+ years of age and explicitly agree to disable parental controls
                    </span>
                  </label>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={onClose}
                      className="w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-bold transition border border-slate-700 cursor-pointer text-center"
                    >
                      Keep Safe Mode On
                    </button>

                    <button
                      type="button"
                      onClick={handleAgreeAndUnlock}
                      disabled={!hasAcknowledged}
                      className={`w-full py-2.5 px-3 rounded-xl text-xs font-mono font-bold transition flex items-center justify-center gap-1.5 uppercase cursor-pointer shadow-md ${
                        hasAcknowledged
                          ? 'bg-rose-600 hover:bg-rose-500 text-white active:scale-95'
                          : 'bg-slate-800 text-slate-500 border border-slate-800 cursor-not-allowed'
                      }`}
                    >
                      <FileCheck size={14} />
                      <span>Confirm Deactivation</span>
                    </button>
                  </div>
                </>
              ) : (
                /* ============================================================ */
                /* TAB 2: CLEAR, PROFESSIONAL CONTENT PRIVACY & LEGAL POLICY */
                /* ============================================================ */
                <div className="space-y-3 text-xs leading-relaxed text-slate-300">
                  {/* Section 1: Age-Restricted Content & Safe Mode Protocol */}
                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-rose-400 font-mono font-bold text-[11px] uppercase">
                      <AlertTriangle size={13} className="shrink-0" />
                      <span>1. Age-Restricted Content Policy</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      My TeleFlix employs a strict default <strong>Safe Mode</strong> filter. Mature and age-restricted titles are completely excluded from general view until the user explicitly verifies they are 18 years of age or older. Safe Mode can be re-enabled at any time in App Settings.
                    </p>
                  </div>

                  {/* Section 2: Data Protection & Hardware Security */}
                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-emerald-400 font-mono font-bold text-[11px] uppercase">
                      <ShieldCheck size={13} className="shrink-0" />
                      <span>2. Data Protection & Hardware ID</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      We collect cryptographic device fingerprints (HWID) solely for preventing multi-accounting abuse and securing legitimate reward payouts. Your credentials are authenticated directly through official Google OAuth SSO. We do not sell, rent, or distribute personal user information to third-party advertisers.
                    </p>
                  </div>

                  {/* Section 3: Safe Harbor & Content Disclaimers */}
                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-1.5 text-blue-400 font-mono font-bold text-[11px] uppercase">
                      <Lock size={13} className="shrink-0" />
                      <span>3. Disclaimer & Safe Harbor Compliance</span>
                    </div>
                    <p className="text-[11px] text-slate-300">
                      Media streams are indexed from public distributed content delivery networks. My TeleFlix respects intellectual property rights. If you believe any catalog entry infringes copyright or community standards, submit a removal inquiry to our administration desk for immediate review.
                    </p>
                  </div>

                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={onClose}
                      className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-white font-mono text-xs font-semibold rounded-xl border border-slate-700 transition cursor-pointer"
                    >
                      Close Policy Window
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
