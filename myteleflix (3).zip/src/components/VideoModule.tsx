/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect, useRef } from "react";
import { 
  Download, Search, Zap, X
} from "lucide-react";
import { Video, Mission, User, AppLanguage } from "../types";
import { t, getStoredLanguage, LANGUAGE_CHANGE_EVENT } from "../utils/translations";
import LinkUnlockModal from "./LinkUnlockModal";
import PosterDownloadOverlay from "./PosterDownloadOverlay";
import { sortMediaNewestFirst } from "../utils/sorting";

interface VideoModuleProps {
  videos: Video[];
  completedMissionIds?: string[];
  userIsPremium?: boolean;
  onViewedVideo?: (id: string, isVideo: boolean) => Promise<void>;
  onViewedMovie?: (id: string, isMovie: boolean) => Promise<void>;
  missions?: Mission[];
  user?: User;
  guideVideoUrl?: string;
  guideVideoLogoUrl?: string;
  showSearchBar?: boolean;
  onBackToAll?: () => void;
  currentLanguage?: AppLanguage;
}

function VideoModuleComponent({
  videos,
  completedMissionIds: _completedMissionIds,
  onViewedVideo: _onViewedVideo,
  onViewedMovie: _onViewedMovie,
  missions: _missions,
  user,
  guideVideoUrl,
  guideVideoLogoUrl,
  showSearchBar = true,
  onBackToAll,
  currentLanguage: propLanguage,
}: VideoModuleProps) {
  const [activeLanguage, setActiveLanguage] = useState<AppLanguage>(() => {
    return propLanguage || getStoredLanguage();
  });

  useEffect(() => {
    if (propLanguage) {
      setActiveLanguage(propLanguage);
    }
  }, [propLanguage]);

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      if (e.detail) {
        setActiveLanguage(e.detail);
      }
    };
    window.addEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
    return () => window.removeEventListener(LANGUAGE_CHANGE_EVENT, handleGlobalLang);
  }, []);

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  
  // Selection states for modal workflows
  const [selectedPost, setSelectedPost] = useState<any | null>(null);
  const [showFreeUnlockModal, setShowFreeUnlockModal] = useState(false);
  const [toastInfo, setToastInfo] = useState<string | null>(null);

  // Predefined Category Filters with 3-Language UI Display
  const categoryFilters = useMemo(() => [
    { key: "All", label: t("All", activeLanguage, "All") },
    { key: "Deshi", label: t("Deshi", activeLanguage, "দেশি") },
    { key: "Indian", label: t("Indian", activeLanguage, "ইন্ডিয়ান") },
    { key: "Russian", label: t("Russian", activeLanguage, "রাশিয়ান") },
    { key: "Pakistani", label: t("Pakistani", activeLanguage, "পাকিস্তানি") },
    { key: "English", label: t("English", activeLanguage, "ইংলিশ") },
  ], [activeLanguage]);

  // Automotion: Auto-center scroll category bar when selectedCategory changes
  useEffect(() => {
    const timer = setTimeout(() => {
      const tabBtn = document.getElementById(`filter-tab-${selectedCategory.toLowerCase()}`);
      if (tabBtn) {
        tabBtn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
      }
    }, 40);
    return () => clearTimeout(timer);
  }, [selectedCategory]);

  // Robust Category Matching & Search Filtering
  const filteredVideos = useMemo(() => {
    return sortMediaNewestFirst(videos.filter((video) => {
      // 1. Category Filter Matching
      if (selectedCategory !== "All") {
        const cat = (video.category || "").trim().toLowerCase();
        const target = selectedCategory.trim().toLowerCase();
        
        // Also check if video title/genre mentions category for backwards-compatibility
        const titleGenre = `${video.title || ''} ${video.genre || ''} ${video.description || ''}`.toLowerCase();
        const matchesDirectCategory = cat === target;
        const matchesTextFallback = !cat && (
          (target === 'deshi' && (titleGenre.includes('deshi') || titleGenre.includes('bangla') || titleGenre.includes('bd'))) ||
          (target === 'indian' && (titleGenre.includes('indian') || titleGenre.includes('hindi') || titleGenre.includes('tamil') || titleGenre.includes('telugu'))) ||
          (target === 'russian' && titleGenre.includes('russian')) ||
          (target === 'pakistani' && (titleGenre.includes('pakistani') || titleGenre.includes('pakistan'))) ||
          (target === 'english' && (titleGenre.includes('english') || titleGenre.includes('hollywood')))
        );

        if (!matchesDirectCategory && !matchesTextFallback) {
          return false;
        }
      }

      // 2. Search Query Matching
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchTitle = video.title.toLowerCase().includes(q);
        const matchDesc = Boolean(video.description && video.description.toLowerCase().includes(q));
        const matchGenre = Boolean(video.genre && video.genre.toLowerCase().includes(q));
        const matchCat = Boolean(video.category && video.category.toLowerCase().includes(q));
        if (!matchTitle && !matchDesc && !matchGenre && !matchCat) {
          return false;
        }
      }

      return true;
    }));
  }, [videos, selectedCategory, searchQuery]);

  const [openingVideoId, setOpeningVideoId] = useState<string | null>(null);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleOpenFreeUnlock = (video: any, e?: React.SyntheticEvent) => {
    if (e) {
      e.stopPropagation();
    }
    setOpeningVideoId(video.id);
    setSelectedPost(video);
    setShowFreeUnlockModal(true);

    if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    clickTimerRef.current = setTimeout(() => {
      setOpeningVideoId(null);
    }, 400);
  };

  useEffect(() => {
    return () => {
      if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
    };
  }, []);

  return (
    <div id="video-module" className="space-y-4 animate-in fade-in duration-300 relative w-full max-w-full overflow-x-hidden">
      
      {/* Floating Toast Notification */}
      {toastInfo && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-md w-[92%] bg-[#1A1A1E] border border-[#2A2A2E] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center justify-between gap-3 animate-in slide-in-from-top-4 fade-in duration-300">
          <div className="flex items-center gap-2.5 text-xs font-bold font-sans">
            <Zap size={16} className="text-[#E50914] shrink-0 fill-current" />
            <span>{toastInfo}</span>
          </div>
          <button onClick={() => setToastInfo(null)} className="text-[#A0A0A0] hover:text-white p-1 cursor-pointer">
            <X size={14} />
          </button>
        </div>
      )}

      {/* 1. Horizontal Scrolling Category Filter Bar (At the very TOP) */}
      <div className="w-full overflow-hidden pt-1">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none px-4 pb-1.5 pt-0.5 no-scrollbar scroll-smooth">
          {categoryFilters.map((cat) => {
            const isActive = selectedCategory === cat.key;
            return (
              <button
                key={cat.key}
                id={`filter-tab-${cat.key.toLowerCase()}`}
                onClick={(e) => {
                  setSelectedCategory(cat.key);
                  e.currentTarget.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold font-mono transition-transform duration-75 active:scale-95 shrink-0 cursor-pointer flex items-center gap-1.5 select-none h-8 whitespace-nowrap border ${
                  isActive
                    ? "bg-[#E50914] text-white border border-[#E50914]"
                    : "bg-[#1A1A1E] hover:bg-[#26262B] text-[#A0A0A0] hover:text-white border border-[#2A2A2E]"
                }`}
              >
                <span className="whitespace-nowrap">{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Single Search Box (In the MIDDLE, directly below Category Bar) */}
      {showSearchBar && (
        <div className="relative px-4 pt-0.5 search-bar-container">
          <div className="bg-[#1A1A1E] border border-[#2A2A2E] focus-within:border-emerald-500/80 rounded-xl flex items-center px-3.5 sm:px-4 py-1 transition-all">
            <div className="p-1.5 bg-[#26262B] rounded-lg mr-2.5 border border-[#2A2A2E] shrink-0">
              <Search size={15} className="text-[#A0A0A0]" />
            </div>
            <input
              id="video-catalog-search"
              type="text"
              placeholder={t("search_videos_placeholder", activeLanguage, "Search videos...")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-white placeholder-[#8C8C8C] text-xs sm:text-sm py-2.5 outline-none font-sans font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="text-[10px] text-[#A0A0A0] hover:text-white font-mono font-bold bg-[#26262B] hover:bg-[#323238] px-2.5 py-1 rounded-lg transition-transform duration-75 active:scale-95 cursor-pointer shrink-0 ml-2 border border-[#2A2A2E]"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. Full-Width Single Column Card Layout */}
      <div id="videos-list" className="grid grid-cols-1 gap-3.5 px-4">
        {filteredVideos.length > 0 ? (
          filteredVideos.map((video) => {
            const isVidOpening = openingVideoId === video.id;
            return (
              <div
                key={video.id}
                id={`video-card-${video.id}`}
                onClick={() => handleOpenFreeUnlock(video)}
                className={`group bg-[#1A1A1E] rounded-2xl p-3 border transition-all duration-150 ease-out active:scale-[0.97] active:opacity-90 active:brightness-105 flex flex-col space-y-3 cursor-pointer select-none ${
                  isVidOpening ? "border-emerald-500/80 shadow-lg shadow-emerald-950/40" : "border-[#2A2A2E] hover:border-[#444]"
                }`}
              >
                {/* High-Resolution 1:1 (Square) Thumbnail Container - Clean Unobstructed View */}
                <div className="relative aspect-square rounded-lg overflow-hidden bg-black border border-[#2A2A2E] w-full flex items-center justify-center shrink-0">
                  <img
                    src={video.thumbnailUrl}
                    alt={video.title}
                    loading="lazy"
                    decoding="async"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&w=800&h=600&q=80";
                    }}
                    className={`w-full h-full object-cover group-hover:scale-105 transition duration-300 ${
                      isVidOpening ? "filter blur-xs brightness-75 scale-105" : ""
                    }`}
                    referrerPolicy="no-referrer"
                  />
                  {isVidOpening && <PosterDownloadOverlay size="md" />}
                </div>

                {/* Video Title & Meta Bar */}
                <div className="space-y-1 px-0.5">
                  <h4 className="text-sm font-bold text-white group-hover:text-white transition-colors leading-snug line-clamp-2">
                    {video.title}
                  </h4>
                  {video.description && (
                    <p className="text-xs text-[#8C8C8C] font-sans line-clamp-1">
                      {video.description}
                    </p>
                  )}
                </div>

                {/* Primary OTT Minimalist CTA Button */}
                <div className="pt-1 w-full flex justify-center">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenFreeUnlock(video, e);
                    }}
                    onTouchEnd={(e) => {
                      e.stopPropagation();
                    }}
                    className={`w-[85%] max-w-[260px] py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm tracking-wider border shadow-md transition-all duration-75 ease-out flex items-center justify-center gap-1.5 select-none cursor-pointer uppercase active:scale-95 ${
                      isVidOpening 
                        ? "bg-purple-800 border-purple-400 text-purple-200 ring-1.5 ring-purple-400" 
                        : "bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white border-purple-400/40 shadow-purple-950/60"
                    }`}
                  >
                    {isVidOpening ? (
                      <>
                        <div className="w-3.5 h-3.5 rounded-full border-[1.5px] border-purple-300 border-t-transparent animate-spin shrink-0" />
                        <span className="text-purple-200">{t("OPENING...", activeLanguage, "OPENING...")}</span>
                      </>
                    ) : (
                      <>
                        <Download size={14} strokeWidth={2.4} className="shrink-0 text-white" />
                        <span>{t("DOWNLOAD", activeLanguage, "DOWNLOAD")}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-[#1A1A1E] border border-[#2A2A2E] rounded-2xl p-8 text-center space-y-4 my-2">
            <div className="space-y-1.5">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                {t("no_content_found", activeLanguage, "No Content Found")}
              </h4>
              <p className="text-xs text-[#A0A0A0] font-normal max-w-xs mx-auto">
                {searchQuery.trim()
                  ? `No video releases matched "${searchQuery}".`
                  : selectedCategory !== "All"
                  ? `No releases available in "${selectedCategory}" category yet.`
                  : "No releases available in this category yet."}
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedCategory("All");
                setSearchQuery("");
              }}
              className="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2.5 rounded-lg transition-all duration-75 ease-out shadow-md text-xs font-mono uppercase tracking-wider cursor-pointer active:scale-95 active:brightness-125 active:ring-2 active:ring-emerald-400/80 active:shadow-lg active:shadow-emerald-900/50 inline-flex items-center justify-center select-none"
            >
              {t("view_all_content", activeLanguage, "View All Content")}
            </button>
          </div>
        )}
      </div>

      {/* MODAL: 2ND PAGE GET-LINK UNLOCK & AUDIO DUB MODAL */}
      {showFreeUnlockModal && selectedPost && (
        <LinkUnlockModal
          item={selectedPost}
          type="video"
          userId={user?.id}
          guideVideoUrl={guideVideoUrl}
          guideVideoLogoUrl={guideVideoLogoUrl}
          onClose={() => {
            setShowFreeUnlockModal(false);
            setSelectedPost(null);
          }}
        />
      )}
    </div>
  );
}

const VideoModule = React.memo(VideoModuleComponent);
export default VideoModule;
