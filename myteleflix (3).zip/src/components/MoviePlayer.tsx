/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, 
  RotateCcw, RotateCw, X, Clock, 
  Film, AlertCircle, Loader2, PictureInPicture,
  Zap, Cloud, RefreshCw, Settings, Radio, Sparkles, ExternalLink, CheckCircle2
} from "lucide-react";
import { Movie, Video, SystemSettings } from "../types";
import VideoPlayer, { VideoPlayerProps } from "./VideoPlayer";
import { getAdNetworkConfig, openAdImpressionWindow, claimAdRewardApi } from "../services/adNetwork";
import TokenIcon from "./TokenIcon";

export interface MoviePlayerProps extends VideoPlayerProps {
  settings?: SystemSettings;
  onRewardAwarded?: (points: number) => void;
}

export default function MoviePlayer(props: MoviePlayerProps) {
  const { media, settings, userId = "guest", onRewardAwarded, onClose } = props;
  const adConfig = getAdNetworkConfig(settings);

  // Real Ad Pre-Roll Overlay State
  const [showPreRollAd, setShowPreRollAd] = useState<boolean>(
    (settings as any)?.videoPreRollAd ?? true
  );
  const [preRollCountdown, setPreRollCountdown] = useState<number>(6);
  const [isAdClaiming, setIsAdClaiming] = useState<boolean>(false);
  const [adRewardToast, setAdRewardToast] = useState<string | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (showPreRollAd) {
      timerRef.current = setInterval(() => {
        setPreRollCountdown((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [showPreRollAd]);

  /**
   * Triggers the real ad smartlink/impression when user interacts with pre-roll
   */
  const handleOpenAdPartner = () => {
    let targetUrl = adConfig.directImpressionUrl;
    if (adConfig.networkType === 'adsterra') {
      targetUrl = adConfig.adsterraDirectLink;
    } else if (adConfig.networkType === 'monetag') {
      targetUrl = adConfig.monetagDirectTag;
    }
    openAdImpressionWindow(targetUrl);
  };

  /**
   * Skips or completes the pre-roll ad and awards points if watched
   */
  const handleCompletePreRoll = async () => {
    if (userId !== "guest" && !isAdClaiming) {
      setIsAdClaiming(true);
      try {
        const result = await claimAdRewardApi({
          userId,
          adNetwork: adConfig.networkType,
          impressionId: `preroll-${Date.now()}`,
          adTitle: `Movie Pre-Roll Ad (${media.title})`,
          rewardPoints: Math.round(adConfig.adRewardPoints / 2) || 75,
        });
        if (onRewardAwarded) {
          onRewardAwarded(result.pointsEarned || 75);
        }
        setAdRewardToast(`🎉 +${result.pointsEarned || 75} credited for watching pre-roll ad!`);
        setTimeout(() => setAdRewardToast(null), 4000);
      } catch (err) {
        console.warn("Notice claiming pre-roll ad reward:", err);
      } finally {
        setIsAdClaiming(false);
      }
    }
    setShowPreRollAd(false);
  };

  /**
   * In-Player Sponsor Boost
   */
  const handleTriggerInPlayerAd = async () => {
    handleOpenAdPartner();
    if (userId !== "guest") {
      try {
        const result = await claimAdRewardApi({
          userId,
          adNetwork: adConfig.networkType,
          impressionId: `inplayer-${Date.now()}`,
          adTitle: `Mid-Stream Sponsor (${media.title})`,
          rewardPoints: adConfig.adRewardPoints || 150,
        });
        if (onRewardAwarded) {
          onRewardAwarded(result.pointsEarned || 150);
        }
        setAdRewardToast(`🎉 +${result.pointsEarned || 150} added!`);
        setTimeout(() => setAdRewardToast(null), 4000);
      } catch (err: any) {
        setAdRewardToast("Ad reward already credited or locked.");
        setTimeout(() => setAdRewardToast(null), 3000);
      }
    }
  };

  return (
    <div className="relative w-full h-full">
      {/* Underlying High-Performance Video Player */}
      <VideoPlayer {...props} />

      {/* Real Ad Pre-Roll Overlay */}
      {showPreRollAd && (
        <div className="absolute inset-0 z-40 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-center p-6 text-white text-center animate-in fade-in duration-300">
          <div className="max-w-md w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <span className="text-[10px] font-mono font-black uppercase px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center gap-1">
                <Radio size={12} className="animate-pulse" /> {adConfig.networkType.toUpperCase()} SPONSOR
              </span>
              <span className="text-xs font-mono font-bold text-amber-400">
                {preRollCountdown > 0 ? `Skip in ${preRollCountdown}s` : "Ready"}
              </span>
            </div>

            <div className="space-y-2 text-left py-2">
              <h3 className="text-base font-bold text-white font-sans">
                Supporting Free HD Streaming
              </h3>
              <p className="text-xs text-slate-400">
                This short sponsor message keeps My TeleFlix 100% free and awards you bonus tokens.
              </p>
            </div>

            <div className="p-4 bg-slate-950/90 rounded-2xl border border-slate-800/80 flex items-center justify-between gap-3">
              <div className="text-left">
                <span className="text-[10px] text-slate-500 uppercase font-mono block">Featured Offer</span>
                <span className="text-xs font-bold text-slate-200">Official Adsterra & Monetag Partner</span>
              </div>
              <button
                type="button"
                onClick={handleOpenAdPartner}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold transition flex items-center gap-1 cursor-pointer shrink-0"
              >
                <span>Visit Sponsor</span>
                <ExternalLink size={12} />
              </button>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={preRollCountdown > 0}
                onClick={handleCompletePreRoll}
                className={`w-full py-3 rounded-2xl font-mono text-xs font-black uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2 shadow-lg ${
                  preRollCountdown > 0 
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700' 
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                }`}
              >
                {preRollCountdown > 0 ? (
                  <span>Wait {preRollCountdown}s to Continue...</span>
                ) : (
                  <>
                    <Play size={14} fill="currentColor" />
                    <span>Start Cinema Playback {userId !== "guest" ? "(+Reward)" : ""}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Sponsor Boost Button (During Playback) */}
      {!showPreRollAd && (
        <div className="absolute top-4 right-16 z-30 flex items-center gap-2">
          <button
            onClick={handleTriggerInPlayerAd}
            title="Engage sponsor ad for +Points"
            className="px-3 py-1.5 rounded-full bg-slate-900/80 hover:bg-indigo-600/90 border border-indigo-500/40 text-indigo-300 hover:text-white backdrop-blur-md text-[11px] font-mono font-bold transition cursor-pointer flex items-center gap-1.5 shadow-lg active:scale-95"
          >
            <TokenIcon size={13} />
            <span>+{adConfig.adRewardPoints}</span>
          </button>
        </div>
      )}

      {/* Toast confirmation for ad rewards */}
      {adRewardToast && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-950/95 border border-emerald-500/50 text-emerald-200 px-4 py-2 rounded-2xl font-mono text-xs font-bold shadow-2xl flex items-center gap-2 animate-in fade-in zoom-in-95">
          <Sparkles size={14} className="text-emerald-400 shrink-0" />
          <span>{adRewardToast}</span>
        </div>
      )}
    </div>
  );
}
