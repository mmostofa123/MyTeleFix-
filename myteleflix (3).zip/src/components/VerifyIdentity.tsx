/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export * from "./IdentityVerificationScreen";
export { default } from "./IdentityVerificationScreen";
