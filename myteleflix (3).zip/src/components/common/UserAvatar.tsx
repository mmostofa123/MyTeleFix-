/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * UserAvatar: Robust Enterprise Avatar Component
 * 1. Checks for Google Photo (user.photoURL)
 * 2. On error or missing photo, falls back to 100+ DiceBear Gender Avatar:
 *    https://api.dicebear.com/7.x/bottts/svg?seed=MaleUser_${seed}
 *    https://api.dicebear.com/7.x/bottts/svg?seed=FemaleUser_${seed}
 * 3. Secondary offline fallback to Gender3DAvatar inline SVG
 */

import React, { useState, useEffect } from "react";
import { resolveUserAvatar, getDiceBearAvatar } from "../../utils/avatar";
import { Gender3DAvatar } from "../profile/Gender3DAvatar";

export interface UserAvatarProps {
  user?: {
    photoURL?: string | null;
    photoUrl?: string | null;
    gender?: string | null;
    id?: string | number | null;
    uid?: string | number | null;
    email?: string | null;
    displayName?: string | null;
    fullName?: string | null;
  } | null;
  photoURL?: string | null;
  gender?: string | null;
  seedId?: string | number | null;
  alt?: string;
  className?: string;
  containerClassName?: string;
  id?: string;
}

export const UserAvatar: React.FC<UserAvatarProps> = ({
  user,
  photoURL,
  gender,
  seedId,
  alt = "User Avatar",
  className = "w-full h-full object-cover",
  containerClassName = "w-full h-full relative overflow-hidden flex items-center justify-center",
  id = "user-avatar-img",
}) => {
  const effectiveGender = gender || user?.gender || "male";
  const effectiveId = seedId || user?.uid || user?.id || user?.email || "user";
  const directPhoto = photoURL || user?.photoURL || user?.photoUrl;

  const { primaryPhoto, diceBearAvatar } = resolveUserAvatar(
    {
      ...user,
      photoURL: directPhoto,
      gender: effectiveGender,
      id: effectiveId,
    },
    effectiveGender
  );

  const [primaryError, setPrimaryError] = useState<boolean>(false);
  const [diceBearError, setDiceBearError] = useState<boolean>(false);

  // Reset errors whenever inputs change
  useEffect(() => {
    setPrimaryError(false);
    setDiceBearError(false);
  }, [directPhoto, effectiveGender, effectiveId]);

  // Fallback 1: Google Photo is valid and hasn't errored
  if (primaryPhoto && !primaryError) {
    return (
      <div className={containerClassName}>
        <img
          id={id}
          src={primaryPhoto}
          alt={alt}
          className={className}
          referrerPolicy="no-referrer"
          loading="eager"
          onError={() => setPrimaryError(true)}
        />
      </div>
    );
  }

  // Fallback 2: DiceBear 100+ Gender Avatar
  if (!diceBearError) {
    return (
      <div className={containerClassName}>
        <img
          id={id}
          src={diceBearAvatar}
          alt={alt}
          className={className}
          referrerPolicy="no-referrer"
          loading="eager"
          onError={() => setDiceBearError(true)}
        />
      </div>
    );
  }

  // Fallback 3: Offline inline 3D SVG Avatar
  return (
    <div className={containerClassName}>
      <Gender3DAvatar gender={effectiveGender} className={className} />
    </div>
  );
};

export default UserAvatar;
