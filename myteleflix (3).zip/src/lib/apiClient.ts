/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function getTelegramInitData(): string {
  if (typeof window !== "undefined") {
    return (window as any).Telegram?.WebApp?.initData || "";
  }
  return "";
}

export async function apiFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const initData = getTelegramInitData();
  const headers = new Headers(options.headers || {});

  if (initData) {
    headers.set("X-Telegram-Init-Data", initData);
  }

  if (!headers.has("Content-Type") && options.body && typeof options.body === "string") {
    headers.set("Content-Type", "application/json");
  }

  return fetch(url, {
    ...options,
    headers
  });
}
