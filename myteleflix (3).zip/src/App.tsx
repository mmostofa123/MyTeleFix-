/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { AnimatePresence } from "motion/react";
import { AlertTriangle, X, Shield } from "lucide-react";

import Header from "./components/Header";
import SimulationHeader from "./components/SimulationHeader";
import MovieModule from "./components/MovieModule";
import VideoModule from "./components/VideoModule";
import EarnModule from "./components/EarnModule";
import AdminDashboard from "./components/AdminDashboard";
import VideoPlayer from "./components/VideoPlayer";
import MoviePlayer from "./components/MoviePlayer";
import { authenticatedFetch } from "./services/authBearer";

// Brand-New Phase 2 TMA Screens
import SplashScreen from "./components/SplashScreen";
import HomeScreen from "./components/HomeScreen";
import WalletScreen from "./components/WalletScreen";
import ProfileScreen from "./components/ProfileScreen";
import LoginScreen from "./components/LoginScreen";
import Navigation from "./components/Navigation";
import { sortMediaNewestFirst } from "./utils/sorting";
import { prefetchImages } from "./utils/imageCache";
import { getDeviceFingerprint, getCachedDeviceFingerprint, getGuestDeviceId, getHardwareMetrics } from "./utils/fingerprint";
import { isSuperAdminEmail, createInitialGuestUser, MASTER_ADMIN_EMAIL } from "./context/AuthContext";
import { ADMIN_WHITELIST, isEmailInAdminWhitelist } from "./constants";
import { 
  evaluateAuthorityGateway, 
  clearPersistentAdminToken, 
  logSecurityViolation, 
  verifyAdminRouteAccess, 
  SECURITY_VIOLATION_EVENT 
} from "./SecurityGuard";
import MasterPinModal from "./components/MasterPinModal";
import LazyAuthModal, { LazyAuthAction } from "./components/LazyAuthModal";
import OnboardingFlow from "./components/OnboardingFlow";
import WelcomeOnboardingModal from "./components/WelcomeOnboardingModal";
import PolicyViolationModal from "./components/PolicyViolationModal";
import SecurityWarningModal from "./SecurityWarningModal";
import { restorePrimaryAccount, clearSecondaryDraftSession } from "./SecurityManager";
import { NotificationToast } from "./components/NotificationToast";
import FloatingAiSupportWidget from "./components/FloatingAiSupportWidget";
import { 
  subscribeToWithdrawals, 
  updateWithdrawalStatusInFirestore,
  subscribeToMovies,
  saveMovieToFirestore,
  deleteMovieFromFirestore,
  subscribeToVideos,
  saveVideoToFirestore,
  deleteVideoFromFirestore,
  saveUserToFirestore,
  getUserFromFirestore,
  auth
} from "./services/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { 
  recordUserActivity, 
  enforce72HourInactivityRule, 
  INACTIVITY_RESET_EVENT 
} from "./utils/activityTracker";

import { 
  User, Movie, Video, Mission, MissionLog, Transaction, 
  Referral, Notification, MovieRequest, SystemSettings, AdminAnalytics,
  WithdrawalRequest
} from "./types";
import VerificationStep1 from "./components/verification/VerificationStep1";
import VerificationStep2 from "./components/verification/VerificationStep2";
import Phase6AdminControlPanel from "./components/admin/Phase6AdminControlPanel";

// ==========================================
// High-Fidelity Skeletons & Fallback Mock Data
// ==========================================

const defaultUser: User = {
  id: "tg-101",
  telegramId: "703119315615",
  username: "mostofashowkat",
  fullName: "Mostofa Showkat",
  photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
  points: 92450,
  createdAt: "2026-07-01T04:54:00Z",
  isPremium: true,
  role: "user"
};

const defaultGuestUser: User = {
  id: "tg-guest",
  telegramId: "123456789",
  username: "tester_guest",
  fullName: "Referred Guest",
  photoUrl: "",
  points: 150,
  createdAt: "2026-07-03T08:21:00Z",
  isPremium: false,
  role: "guest"
};

const defaultMovies: Movie[] = [
  {
    id: "mv-101",
    title: "Interstellar Premiere (Bangla & Hindi Dubbed)",
    description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    thumbnailUrl: "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Sci-Fi",
    duration: "2h 49m",
    pointsReward: 450,
    isPremiumOnly: false,
    rating: 8.7,
    releaseYear: 2014,
    isActive: true,
    views: 12409,
    contentType: 'movie',
    languages: ['Bangla', 'Hindi', 'English', 'Original'],
    banglaLink: 'https://t.me/teleflix_bot?start=mv101_bn',
    hindiLink: 'https://t.me/teleflix_bot?start=mv101_hi',
    englishLink: 'https://t.me/teleflix_bot?start=mv101_en'
  },
  {
    id: "mv-102",
    title: "The Dark Knight 4K Ultra HD",
    description: "When the menace known as the Joker wreaks havoc and chaos on Gotham, Batman must accept one of the greatest tests.",
    thumbnailUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Action",
    duration: "2h 32m",
    pointsReward: 600,
    isPremiumOnly: true,
    rating: 9.0,
    releaseYear: 2008,
    isActive: true,
    views: 28402,
    contentType: 'movie',
    languages: ['English', 'Hindi']
  },
  {
    id: "mv-107",
    title: "Oppenheimer IMAX Enhanced Dubbed",
    description: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.",
    thumbnailUrl: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Biography",
    duration: "3h 00m",
    pointsReward: 550,
    isPremiumOnly: false,
    rating: 8.9,
    releaseYear: 2023,
    isActive: true,
    views: 34100,
    contentType: 'movie',
    languages: ['Bangla', 'Hindi', 'English']
  },
  {
    id: "mv-108",
    title: "Avatar: The Way of Water 3D",
    description: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora once more under siege.",
    thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Sci-Fi",
    duration: "3h 12m",
    pointsReward: 600,
    isPremiumOnly: false,
    rating: 8.5,
    releaseYear: 2024,
    isActive: true,
    views: 41200,
    contentType: 'movie',
    languages: ['Hindi', 'English']
  },
  {
    id: "drm-103",
    title: "Bachelor Point Season 4 - Episode 116 (Kabila Special)",
    description: "Exclusive hilarious episode featuring Kabila, Habu, Passu and friends in Dhaka.",
    thumbnailUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Deshi Natok",
    category: "Deshi",
    duration: "48m",
    pointsReward: 300,
    isPremiumOnly: false,
    rating: 9.3,
    releaseYear: 2025,
    isActive: true,
    views: 54120,
    contentType: 'drama',
    languages: ['Bangla'],
    groupTitle: "Bachelor Point",
    series_group_title: "Bachelor Point",
    season: "Season 4",
    season_number: 4,
    episode: "Episode 116",
    episode_number: 116,
    totalEpisodes: "Season 4 • Episode 116"
  },
  {
    id: "drm-103b",
    title: "Bachelor Point Season 4 - Episode 117 (Habu Wedding Special)",
    description: "Habu Bhai makes a surprise return to Bachelor Flat with unexpected celebrations.",
    thumbnailUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Deshi Natok",
    category: "Deshi",
    duration: "45m",
    pointsReward: 300,
    isPremiumOnly: false,
    rating: 9.4,
    releaseYear: 2025,
    isActive: true,
    views: 61200,
    contentType: 'drama',
    languages: ['Bangla'],
    groupTitle: "Bachelor Point",
    series_group_title: "Bachelor Point",
    season: "Season 4",
    season_number: 4,
    episode: "Episode 117",
    episode_number: 117,
    totalEpisodes: "Season 4 • Episode 117"
  },
  {
    id: "drm-104",
    title: "Buker Moddhe Agun Single Drama",
    description: "Romantic emotional Bangla telefilm starring Ziaul Faruq Apurba & Mehazabien.",
    thumbnailUrl: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Deshi Natok",
    category: "Deshi",
    duration: "42m",
    pointsReward: 250,
    isPremiumOnly: false,
    rating: 8.9,
    releaseYear: 2025,
    isActive: true,
    views: 31200,
    contentType: 'drama',
    languages: ['Bangla']
  },
  {
    id: "drm-109",
    title: "Punorjonmo The Final Chapter",
    description: "The thrilling climax of Rafat Mozumder Rinku's culinary thriller masterpiece starring Afran Nisho.",
    thumbnailUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Deshi Natok",
    category: "Deshi",
    duration: "55m",
    pointsReward: 350,
    isPremiumOnly: false,
    rating: 9.4,
    releaseYear: 2025,
    isActive: true,
    views: 62800,
    contentType: 'drama',
    languages: ['Bangla']
  },
  {
    id: "drm-110",
    title: "Senior vs Junior Love Story",
    description: "Campus romantic comedy drama featuring Jovan and Tanjin Tisha.",
    thumbnailUrl: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Deshi Natok",
    category: "Deshi",
    duration: "38m",
    pointsReward: 220,
    isPremiumOnly: false,
    rating: 8.8,
    releaseYear: 2025,
    isActive: true,
    views: 29800,
    contentType: 'drama',
    languages: ['Bangla']
  },
  {
    id: "ser-105a",
    title: "Mirzapur Season 3 - Episode 1 (Tetar Ka Shikaar)",
    description: "The battle for Purvanchal intensifies with Guddu Pandit and Kaleen Bhaiya.",
    thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Web Series",
    totalEpisodes: "Season 3 • Episode 1",
    duration: "48m",
    pointsReward: 500,
    isPremiumOnly: false,
    rating: 8.8,
    releaseYear: 2024,
    isActive: true,
    views: 48900,
    contentType: 'series',
    languages: ['Hindi', 'Bangla'],
    groupTitle: "Mirzapur",
    series_group_title: "Mirzapur",
    season: "Season 3",
    season_number: 3,
    episode: "Episode 1",
    episode_number: 1
  },
  {
    id: "ser-105b",
    title: "Mirzapur Season 3 - Episode 2 (Guddu Ka Raj)",
    description: "Purvanchal witnesses new alliances forming as tensions rise to a boiling point.",
    thumbnailUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Web Series",
    totalEpisodes: "Season 3 • Episode 2",
    duration: "52m",
    pointsReward: 500,
    isPremiumOnly: false,
    rating: 8.9,
    releaseYear: 2024,
    isActive: true,
    views: 52100,
    contentType: 'series',
    languages: ['Hindi', 'Bangla'],
    groupTitle: "Mirzapur",
    series_group_title: "Mirzapur",
    season: "Season 3",
    season_number: 3,
    episode: "Episode 2",
    episode_number: 2
  },
  {
    id: "ser-106",
    title: "Sacred Games Season 1 & 2 Pack",
    description: "A link in their pasts leads an honest cop to a fugitive gang boss whose cryptic warning spurs crime mystery.",
    thumbnailUrl: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Web Series",
    totalEpisodes: "Complete 16 Episodes",
    duration: "50m/Ep",
    pointsReward: 480,
    isPremiumOnly: false,
    rating: 8.6,
    releaseYear: 2023,
    isActive: true,
    views: 39400,
    contentType: 'series',
    languages: ['Hindi', 'English']
  },
  {
    id: "ser-111",
    title: "Farzi Season 1 Complete Dual Audio",
    description: "An artist gets pulled into the murky high stakes of a con job and a task force officer on his trail.",
    thumbnailUrl: "https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Web Series",
    totalEpisodes: "8 Full Episodes 4K",
    duration: "55m/Ep",
    pointsReward: 520,
    isPremiumOnly: false,
    rating: 8.7,
    releaseYear: 2024,
    isActive: true,
    views: 43200,
    contentType: 'series',
    languages: ['Hindi', 'Bangla']
  },
  {
    id: "ser-112",
    title: "Money Heist (La Casa de Papel) Complete Pack",
    description: "The Professor and his gang embark on daring heists at the Royal Mint of Spain and Bank of Spain.",
    thumbnailUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Web Series",
    totalEpisodes: "5 Seasons All Episodes",
    duration: "48m/Ep",
    pointsReward: 650,
    isPremiumOnly: false,
    rating: 8.9,
    releaseYear: 2024,
    isActive: true,
    views: 78900,
    contentType: 'series',
    languages: ['Hindi', 'English', 'Spanish']
  },
  {
    id: "amv-101",
    title: "Deshi Midnight Romance 18+ UNCUT HDR",
    description: "Exclusive premium adult feature film in full 1080p uncut version.",
    thumbnailUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Adult 18+",
    category: "Deshi",
    duration: "1h 38m",
    pointsReward: 600,
    isPremiumOnly: false,
    rating: 9.1,
    releaseYear: 2025,
    isActive: true,
    views: 64200,
    contentType: 'adult_movie',
    languages: ['Bangla', 'Hindi']
  },
  {
    id: "amv-102",
    title: "Russian Passion Ultra HD 4K 18+",
    description: "High budget international adult drama uncut cinematic release with multi audio.",
    thumbnailUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&h=350&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    genre: "Adult 18+",
    category: "Russian",
    duration: "1h 45m",
    pointsReward: 650,
    isPremiumOnly: false,
    rating: 9.3,
    releaseYear: 2026,
    isActive: true,
    views: 89400,
    contentType: 'adult_movie',
    languages: ['Russian', 'English', 'Hindi']
  }
];

const defaultVideos: Video[] = [
  {
    id: "vd-201",
    title: "Bangla Viral Short Drama Highlights HD",
    description: "Exclusive Deshi trending scene release with full high-definition clarity.",
    thumbnailUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 150,
    isActive: true,
    category: "Deshi",
    genre: "Deshi Clip",
    views: 4509,
    duration: "1m 45s"
  },
  {
    id: "vd-202",
    title: "Bollywood Epic Action Stunt Clip 1080p",
    description: "Trending Indian blockbuster cinematic scene breakdown and behind-the-scenes.",
    thumbnailUrl: "https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 200,
    isActive: true,
    category: "Indian",
    genre: "Indian Action",
    views: 8902,
    duration: "2m 15s"
  },
  {
    id: "vd-203",
    title: "Russian Winter Wilderness Drone 4K",
    description: "Cinematic drone shots over snowy Siberian mountains and frozen lakes.",
    thumbnailUrl: "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 250,
    isActive: true,
    category: "Russian",
    genre: "Russian Nature",
    views: 6120,
    duration: "3m 10s"
  },
  {
    id: "vd-204",
    title: "Pakistani Drama OST Acoustic Performance",
    description: "Soulful live unplugged rendition of the top trending drama soundtrack.",
    thumbnailUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 180,
    isActive: true,
    category: "Pakistani",
    genre: "Pakistani Music",
    views: 5430,
    duration: "4m 20s"
  },
  {
    id: "vd-205",
    title: "Hollywood Cyberpunk VFX Breakdown",
    description: "Stunning futuristic English sci-fi special effects reel and lighting breakdown.",
    thumbnailUrl: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 300,
    isActive: true,
    category: "English",
    genre: "English Sci-Fi",
    views: 9810,
    duration: "2m 50s"
  },
  {
    id: "vd-206",
    title: "Shibuya Tokyo Neon Midnight Vibes",
    description: "Atmospheric Japanese cinematic night walk through illuminated streets.",
    thumbnailUrl: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&h=450&q=80",
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pointsReward: 280,
    isActive: true,
    category: "Viral",
    genre: "Cinematic Reel",
    views: 11450,
    duration: "3m 15s"
  }
];

const defaultMissions: Mission[] = [
  {
    id: "ms-401",
    title: "Daily Mining Bonus Claim",
    description: "Check in consecutively to trigger points multipliers and accumulate weights.",
    type: "daily_checkin",
    rewardPoints: 100,
    isActive: true,
    order: 1,
    cooldownHours: 24
  },
  {
    id: "ms-403",
    title: "Join Telegram Announcement Channel",
    description: "Stay connected with the latest reward listings, audits, and platform updates.",
    type: "telegram_join",
    rewardPoints: 300,
    url: "https://telegram.org",
    isActive: true,
    order: 2
  }
];

const defaultReferrals: Referral[] = [
  {
    id: "ref-501",
    userId: "tg-101",
    referredUserId: "tg-user-201",
    referredUsername: "ton_tycoon",
    referredFullName: "TON Tycoon",
    status: "QUALIFIED",
    pointsAwarded: 300,
    pointsEarned: 1500, // 10% of their 15,000 Token
    timestamp: "2026-07-02T12:00:00Z"
  },
  {
    id: "ref-502",
    userId: "tg-101",
    referredUserId: "tg-user-202",
    referredUsername: "dubai_crypto",
    referredFullName: "Dubai Crypto",
    status: "PENDING",
    pointsAwarded: 300,
    pointsEarned: 0, // Pending
    timestamp: "2026-07-03T01:30:00Z"
  }
];

const normalizeAppRole = (r?: User['role'] | string | null): 'user' | 'guest' | 'admin' | 'super_admin' => {
  if (!r || r === 'guest') return 'guest';
  if (r === 'admin' || r === 'ADMIN' || r === 'super_admin') return 'admin';
  return 'user';
};

export default function App() {
  // Splash screen presentation
  const [showSplash, setShowSplash] = useState(true);

  // Authentication & Testing Role State (Strict RBAC with Authority Gateway)
  const [role, setRole] = useState<'user' | 'guest' | 'admin' | 'super_admin'>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("myteleflix_user");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed) {
            if (parsed.role === 'guest') return 'guest';
            // ABSOLUTE ADMIN ROLE LOCK VIA AUTHORITY GATEWAY:
            const authRes = evaluateAuthorityGateway(parsed.email);
            return authRes.role === 'ADMIN' ? 'admin' : 'user';
          }
        } catch (e) {}
      }
    }
    return 'guest';
  });

  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("myteleflix_user");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && parsed.id && parsed.role !== 'guest') {
            const authRes = evaluateAuthorityGateway(parsed.email);
            parsed.role = authRes.role === 'ADMIN' ? 'admin' : 'user';
            return parsed;
          }
        } catch (e) {}
      }
    }
    const fp = getCachedDeviceFingerprint();
    const guestId = getGuestDeviceId(fp);
    return createInitialGuestUser(fp, guestId);
  });

  const [lazyAuthAction, setLazyAuthAction] = useState<LazyAuthAction | null>(null);
  const [pendingOnboardingUser, setPendingOnboardingUser] = useState<User | null>(null);
  const [policyViolation, setPolicyViolation] = useState<{
    isOpen: boolean;
    error?: string;
    existingAccount?: any;
    deviceFingerprint?: string;
    ipAddress?: string;
  }>({ isOpen: false });

  const [securityModal, setSecurityModal] = useState<{
    isOpen: boolean;
    primaryEmail: string;
    attemptedEmail?: string;
    hwid?: string;
    message?: string;
  }>({ isOpen: false, primaryEmail: "" });
  
  // App-wide Master Lists (populated with persistent LocalStorage and server state)
  const [movies, setMovies] = useState<Movie[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("myteleflix_movies");
      if (saved !== null) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return sortMediaNewestFirst(parsed);
          }
        } catch (e) {
          console.warn("Error parsing stored movies:", e);
        }
      }
    }
    return sortMediaNewestFirst(defaultMovies.map(m => ({
      ...m,
      createdAt: m.createdAt || "2026-01-01T00:00:00.000Z"
    })));
  });

  const [videos, setVideos] = useState<Video[]>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("myteleflix_videos");
      if (saved !== null) {
        try {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            return sortMediaNewestFirst(parsed);
          }
        } catch (e) {
          console.warn("Error parsing stored videos:", e);
        }
      }
    }
    return sortMediaNewestFirst(defaultVideos.map(v => ({
      ...v,
      createdAt: v.createdAt || "2026-01-01T00:00:00.000Z"
    })));
  });

  // State-and-Storage Synced Updaters
  const updateMoviesState = (updater: Movie[] | ((prev: Movie[]) => Movie[])) => {
    setMovies(prev => {
      const resolved = typeof updater === 'function' ? updater(prev) : updater;
      const sorted = sortMediaNewestFirst(resolved);
      try {
        localStorage.setItem("myteleflix_movies", JSON.stringify(sorted));
        localStorage.setItem("myteleflix_media_customized", "true");
      } catch (e) {}
      return sorted;
    });
  };

  const updateVideosState = (updater: Video[] | ((prev: Video[]) => Video[])) => {
    setVideos(prev => {
      const resolved = typeof updater === 'function' ? updater(prev) : updater;
      const sorted = sortMediaNewestFirst(resolved);
      try {
        localStorage.setItem("myteleflix_videos", JSON.stringify(sorted));
        localStorage.setItem("myteleflix_media_customized", "true");
      } catch (e) {}
      return sorted;
    });
  };
  const [missions, setMissions] = useState<Mission[]>(defaultMissions);
  const [completedLogs, setCompletedLogs] = useState<MissionLog[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [, setReferrals] = useState<Referral[]>(defaultReferrals);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activeToast, setActiveToast] = useState<Notification | null>(null);
  const seenNotificationIdsRef = useRef<Set<string>>(
    (() => {
      try {
        const stored = localStorage.getItem("seen_notice_ids") || localStorage.getItem("myteleflix_seen_notification_ids");
        if (stored) {
          return new Set<string>(JSON.parse(stored));
        }
      } catch (e) {}
      return new Set<string>();
    })()
  );

  const markNotificationAsSeenLocally = useCallback((id: string) => {
    if (!id) return;
    seenNotificationIdsRef.current.add(id);
    try {
      const idsArray = Array.from(seenNotificationIdsRef.current).slice(-300);
      localStorage.setItem("seen_notice_ids", JSON.stringify(idsArray));
      localStorage.setItem("myteleflix_seen_notification_ids", JSON.stringify(idsArray));
    } catch (e) {}
  }, []);

  // Notice Display Gate: Platform load complete + 2.5s delay
  const [canShowNotices, setCanShowNotices] = useState(false);
  const pendingToastAlertRef = useRef<Notification | null>(null);
  const pendingInactivityNoticeRef = useRef<string | null>(null);

  // Once splash screen finishes (platform entered), wait 2.5s before allowing any notice popup
  useEffect(() => {
    if (!showSplash) {
      const timer = setTimeout(() => {
        setCanShowNotices(true);
        if (pendingToastAlertRef.current) {
          setActiveToast(pendingToastAlertRef.current);
          pendingToastAlertRef.current = null;
        }
        if (pendingInactivityNoticeRef.current) {
          setInactivityNotice(pendingInactivityNoticeRef.current);
          pendingInactivityNoticeRef.current = null;
        }
      }, 2500); // 2.5s after platform has loaded
      return () => clearTimeout(timer);
    }
  }, [showSplash]);

  const triggerToastAlert = useCallback((alert: Notification) => {
    if (canShowNotices) {
      setActiveToast(alert);
    } else {
      pendingToastAlertRef.current = alert;
    }
  }, [canShowNotices]);

  const triggerInactivityAlert = useCallback((msg: string) => {
    if (canShowNotices) {
      setInactivityNotice(msg);
    } else {
      pendingInactivityNoticeRef.current = msg;
    }
  }, [canShowNotices]);
  const [requests, setRequests] = useState<MovieRequest[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [settings, setSettings] = useState<SystemSettings>({
    domain: "t.me/myteleflix_bot",
    referralReward: 300,
    referralCommissionPercent: 10,
    minimumWithdrawal: 100000,
    isMaintenance: false,
    telegramBotLink: "https://t.me/myteleflix_bot",
  });
  const [analytics, setAnalytics] = useState<AdminAnalytics>({
    totalUsers: 14249,
    totalPointsAwarded: 12495000,
    totalWithdrawals: 15000,
    pendingWithdrawals: 4,
    activeMissionsCount: 3,
    pointsDistribution: [],
  });

  // Navigation tab state (TMA standard layout)
  const [activeTab, setActiveTab] = useState<'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet'>('home');
  const [homeActiveCategory, setHomeActiveCategory] = useState<string>("All");
  const [homeResetTrigger, setHomeResetTrigger] = useState(0);
  const [isAdultUnlocked, setIsAdultUnlocked] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("myteleflix_18plus_unlocked") === "true";
    }
    return false;
  });
  const [isSyncing, setIsSyncing] = useState(false);
  const [isAdminActive, setIsAdminActive] = useState(false);
  const [showMasterPinModal, setShowMasterPinModal] = useState(false);
  const [showDevPanel, setShowDevPanel] = useState(false);
  const [inactivityNotice, setInactivityNotice] = useState<string | null>(null);

  // Hardware ID for audit logging
  const [hwid] = useState<string>(() => getCachedDeviceFingerprint() || "fp_d0870c0b68934aa1b");

  // Zero-Trust Master Admin Verification Memo
  const isAuthorizedAdminUser = useMemo(() => {
    if (!user?.email) return false;
    const cleanEmail = user.email.toLowerCase().trim();
    if (!isEmailInAdminWhitelist(cleanEmail)) return false;
    return role === 'admin' || role === 'super_admin' || user.role === 'admin' || (user.role as string) === 'ADMIN';
  }, [user?.email, user?.role, role]);

  // UI Concealment & Auto-Revocation:
  // If at any time an active user does not have confirmed Admin whitelist status,
  // revoke any admin views, close PIN modals, and return strictly to profile/home.
  useEffect(() => {
    if (!isAuthorizedAdminUser && (isAdminActive || showMasterPinModal)) {
      setIsAdminActive(false);
      setShowMasterPinModal(false);
      clearPersistentAdminToken();
    }
  }, [isAuthorizedAdminUser, isAdminActive, showMasterPinModal]);

  // HARDENED ROUTE PROTECTION & DIRECT URL INTERCEPTOR ENGINE:
  // Intercepts any direct URL (/admin), hash, or query parameter attempts.
  // If non-admin attempts access: aborts session, logs security violation, clears URL, redirects to Profile with Toast.
  useEffect(() => {
    const enforceRouteProtection = () => {
      const pathname = window.location.pathname;
      const hash = window.location.hash;
      const search = window.location.search;
      const searchParams = new URLSearchParams(search);

      const isDirectAdminUrlAttempt = 
        pathname.toLowerCase().includes('/admin') ||
        hash.toLowerCase().includes('admin') ||
        searchParams.get('tab') === 'admin' ||
        searchParams.get('route') === 'admin';

      if (isDirectAdminUrlAttempt) {
        if (isAuthorizedAdminUser) {
          setIsAdminActive(true);
        } else {
          // Unwhitelisted user attempting /admin access:
          // 1. Immediately abort session & revoke admin states
          setIsAdminActive(false);
          setShowMasterPinModal(false);
          clearPersistentAdminToken();

          // 2. Log security violation
          logSecurityViolation({
            attemptedEmail: user?.email || "anonymous_user",
            attemptedPath: `${pathname}${hash}${search}`,
            roleClaimed: role,
            reason: "Non-admin attempted direct URL navigation or RBAC bypass to /admin",
            hwid: hwid || "unknown_hwid",
            actionTaken: 'ABORT_SESSION_REDIRECT'
          });

          // 3. Clear URL without reloading
          window.history.replaceState({}, '', '/');

          // 4. Redirect strictly to User Profile
          setActiveTab('profile');

          // 5. Trigger error toast
          const nowStr = new Date().toISOString();
          const alertId = `sec-viol-${Date.now()}`;
          triggerToastAlert({
            id: alertId,
            notification_id: alertId,
            userId: user?.id || "guest",
            user_id: user?.id || "guest",
            title: "নিরাপত্তা লঙ্ঘন সতর্কতা (Security Alert)",
            message: "এডমিন কনসোলে সরাসরি প্রবেশের অনুমতি নেই। আপনার অ্যাক্সেস অবিলম্বে বাতিল করা হয়েছে এবং সেশন প্রোফাইলে রিডাইরেক্ট করা হয়েছে।",
            type: "SYSTEM",
            isRead: false,
            is_read: false,
            timestamp: nowStr,
            created_at: nowStr
          });
        }
      }
    };

    enforceRouteProtection();
    window.addEventListener('popstate', enforceRouteProtection);
    window.addEventListener('hashchange', enforceRouteProtection);

    // Also listen for broadcast security violations
    const handleSecurityViolationEvent = () => {
      setIsAdminActive(false);
      setShowMasterPinModal(false);
      clearPersistentAdminToken();
      setActiveTab('profile');
      const nowStr = new Date().toISOString();
      const alertId = `sec-alert-${Date.now()}`;
      triggerToastAlert({
        id: alertId,
        notification_id: alertId,
        userId: user?.id || "guest",
        user_id: user?.id || "guest",
        title: "নিরাপত্তা লঙ্ঘন সতর্কতা (Security Alert)",
        message: "অননুমোদিত অ্যাক্সেস প্রচেষ্টা শনাক্ত ও প্রতিরোধ করা হয়েছে। আপনাকে প্রোফাইলে রিডাইরেক্ট করা হয়েছে।",
        type: "SYSTEM",
        isRead: false,
        is_read: false,
        timestamp: nowStr,
        created_at: nowStr
      });
    };
    window.addEventListener(SECURITY_VIOLATION_EVENT, handleSecurityViolationEvent);

    return () => {
      window.removeEventListener('popstate', enforceRouteProtection);
      window.removeEventListener('hashchange', enforceRouteProtection);
      window.removeEventListener(SECURITY_VIOLATION_EVENT, handleSecurityViolationEvent);
    };
  }, [isAuthorizedAdminUser, user?.email, role, hwid, triggerToastAlert]);

  const handleUpdateUserProfile = useCallback(async (updates: Partial<User>) => {
    setUser(prev => {
      if (!prev) return null;
      const updated: User = { ...prev, ...updates };
      try {
        localStorage.setItem("myteleflix_user", JSON.stringify(updated));
      } catch (e) {}
      saveUserToFirestore(updated).catch(() => {});
      return updated;
    });
  }, []);

  // Inactivity tracking & 72-hour verification progress reset logic
  useEffect(() => {
    if (!user || user.role === 'guest') return;

    enforce72HourInactivityRule(user, handleUpdateUserProfile).then((didReset) => {
      if (didReset) {
        triggerInactivityAlert(
          "৭২ ঘণ্টার বেশি নিষ্ক্রিয়তার কারণে আপনার ভেরিফিকেশন প্রগ্রেস রিসেট করা হয়েছে। অ্যাকাউন্ট অক্ষত রয়েছে, পুনরায় শুরু করুন।"
        );
      }
      recordUserActivity(user, handleUpdateUserProfile);
    });

    const handleInactivityEvent = (e: any) => {
      const msg =
        e.detail?.message ||
        "৭২ ঘণ্টার বেশি নিষ্ক্রিয়তার কারণে আপনার ভেরিফিকেশন প্রগ্রেস রিসেট করা হয়েছে।";
      triggerInactivityAlert(msg);
    };

    window.addEventListener(INACTIVITY_RESET_EVENT, handleInactivityEvent);
    return () => window.removeEventListener(INACTIVITY_RESET_EVENT, handleInactivityEvent);
  }, [user?.id, handleUpdateUserProfile]);

  // Hidden Secret Tap Admin Gateway Handler:
  // Trigger Condition: 5 rapid clicks/taps within 2s on Profile Avatar
  // ONLY opens for verified Admin Whitelist emails
  const handleSecretAdminTrigger = useCallback(() => {
    if (isAuthorizedAdminUser) {
      setShowMasterPinModal(true);
    } else {
      // Non-Admin: Log violation & stealth ignore
      logSecurityViolation({
        attemptedEmail: user?.email || "anonymous_user",
        attemptedPath: "secret_admin_trigger",
        roleClaimed: role,
        reason: "Unauthorized attempt to trigger secret Admin PIN gateway",
        hwid: hwid || "unknown_hwid",
        actionTaken: 'ACCESS_BLOCKED'
      });
      console.warn("Stealth admin gateway: Access locked for non-master accounts.");
    }
  }, [isAuthorizedAdminUser, user?.email, role, hwid]);

  const handleUnlockAdminConsole = useCallback(() => {
    if (!isAuthorizedAdminUser) {
      setIsAdminActive(false);
      setShowMasterPinModal(false);
      clearPersistentAdminToken();
      return;
    }
    setIsAdminActive(true);
    setShowMasterPinModal(false);
  }, [isAuthorizedAdminUser]);

  // Active Video Stream State for Continuous Watch Time & Heartbeat Tracking
  const [activePlayingStream, setActivePlayingStream] = useState<{
    media: Movie | Video;
    type: 'movie' | 'video';
  } | null>(null);

  const handleViewedMovie = useCallback(async (id: string, _isMovie: boolean) => {
    // Client-side visual state reward updater
    setUser(prev => prev ? { ...prev, points: prev.points + 200 } : null);
    try {
      fetch('/api/movies/view', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      }).catch(() => {});
    } catch (err) {
      console.warn("View log stored locally.");
    }
  }, []);

  const handlePlayStream = useCallback((media: Movie | Video, type: 'movie' | 'video' = 'movie') => {
    setActivePlayingStream({ media, type });
    handleViewedMovie(media.id, type === 'video');
  }, [handleViewedMovie]);

  // Global Home Button Reset Handler
  const handleHomeGlobalReset = useCallback(() => {
    setActiveTab('home');
    setHomeActiveCategory('All');
    setHomeResetTrigger(prev => prev + 1);
    window.scrollTo(0, 0);
  }, []);

  // Main Navigation Router Handler (Instant zero-lag tab switching)
  const handleSelectNavTab = useCallback((tab: 'home' | 'movies' | 'videos' | 'earn' | 'profile' | 'wallet') => {
    if (tab === 'home') {
      setActiveTab(prev => {
        if (prev === 'home') {
          setHomeActiveCategory('All');
          setHomeResetTrigger(t => t + 1);
        } else {
          setHomeActiveCategory('All');
        }
        return 'home';
      });
      window.scrollTo(0, 0);
    } else {
      setActiveTab(tab);
      window.scrollTo(0, 0);
    }
  }, []);

  // High-performance memoized active media collections to prevent unnecessary child re-renders
  const activeMovies = useMemo(() => movies.filter(m => m.isActive), [movies]);
  const activeVideos = useMemo(() => videos.filter(v => v.isActive), [videos]);
  const activeMissions = useMemo(() => missions.filter(m => m.isActive), [missions]);

  // SILENT BACKGROUND PRE-FETCHING & ZERO-LOADING USER EXPERIENCE OVERHAUL
  useEffect(() => {
    if (activeMovies.length === 0 && activeVideos.length === 0) return;
    const urls: string[] = [];
    activeMovies.forEach((m) => {
      if (m.thumbnailUrl) urls.push(m.thumbnailUrl);
    });
    activeVideos.forEach((v) => {
      if (v.thumbnailUrl) urls.push(v.thumbnailUrl);
    });
    prefetchImages(urls);
  }, [activeMovies, activeVideos]);

  const handleToggleAdultUnlock = (unlocked: boolean) => {
    setIsAdultUnlocked(unlocked);
    try {
      localStorage.setItem("myteleflix_18plus_unlocked", unlocked ? "true" : "false");
    } catch (e) {
      console.error("Failed to save 18+ unlock state", e);
    }
    if (!unlocked && activeTab === 'videos') {
      setActiveTab('home');
    }
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("dev") === "true" || params.get("test") === "true") {
      setShowDevPanel(true);
    }
  }, []);

  const currentUserId = user?.id || "tg-101";

  // Telegram Native Auto-Authentication Flow
  const initTelegramAuth = async () => {
    setIsSyncing(true);
    
    // Telegram WebApp SDK initialization
    if (typeof window !== "undefined" && (window as any).Telegram?.WebApp) {
      try {
        (window as any).Telegram.WebApp.ready();
        (window as any).Telegram.WebApp.expand();
      } catch (err) {
        console.warn("Telegram WebApp expand warning:", err);
      }
    }

    // Compute device fingerprint
    const fp = await getDeviceFingerprint();

    // Check if user is returning or new visitor
    const savedUser = typeof window !== "undefined" ? localStorage.getItem("myteleflix_user") : null;
    if (!savedUser) {
      // New visitor: initialize guest user with hardware fingerprint so they can immediately browse and stream
      const gId = getGuestDeviceId(fp);
      const guestUser = createInitialGuestUser(fp, gId);
      
      // Cleanly initialize default "seen" flags so onboarding is frictionless without popup spam
      try {
        if (!localStorage.getItem("account_verification_notice_seen")) {
          localStorage.setItem("account_verification_notice_seen", "true");
        }
      } catch (e) {}

      setUser(guestUser);
      setRole('guest');
      setIsSyncing(false);
      return;
    }

    let parsedSavedUser: User | null = null;
    try {
      if (savedUser) {
        parsedSavedUser = JSON.parse(savedUser);
        if (parsedSavedUser) {
          if (parsedSavedUser.role !== 'guest') {
            const isSuper = Boolean(parsedSavedUser.email && isSuperAdminEmail(parsedSavedUser.email));
            parsedSavedUser.role = isSuper ? 'admin' : 'user';
          }
          setUser(parsedSavedUser);
          setRole(normalizeAppRole(parsedSavedUser.role));

          // Check Firestore onboarding status on app reload: if onboardingCompleted is true, skip onboarding automatically
          if (parsedSavedUser.id && parsedSavedUser.role !== 'guest') {
            getUserFromFirestore(parsedSavedUser.id).then((freshDoc) => {
              if (freshDoc) {
                const isCompleted = (freshDoc as any).onboardingCompleted === true || freshDoc.isOnboarded === true || freshDoc.profileInitialized === true;
                if (isCompleted) {
                  setPendingOnboardingUser(null);
                  setUser(prev => prev ? { ...prev, onboardingCompleted: true, isOnboarded: true, isProfileCompleted: true } : null);
                } else if (parsedSavedUser) {
                  setPendingOnboardingUser(parsedSavedUser);
                }
              }
            }).catch(() => {});
          }
        }
      }
    } catch (e) {
      console.warn("Error parsing saved user:", e);
    }

    const tgUser = (typeof window !== "undefined") ? (window as any).Telegram?.WebApp?.initDataUnsafe?.user : null;
    const startParam = (typeof window !== "undefined") 
      ? ((window as any).Telegram?.WebApp?.initDataUnsafe?.start_param || new URLSearchParams(window.location.search).get("ref") || undefined)
      : undefined;

    const authPayload = tgUser ? {
      telegramId: String(tgUser.id),
      username: tgUser.username,
      firstName: tgUser.first_name,
      lastName: tgUser.last_name,
      photoUrl: tgUser.photo_url,
      startParam,
      device_fingerprint: fp
    } : {
      telegramId: parsedSavedUser?.telegramId || defaultUser.telegramId,
      username: parsedSavedUser?.username || defaultUser.username,
      firstName: "Mostofa",
      lastName: "Showkat",
      photoUrl: parsedSavedUser?.photoUrl || defaultUser.photoUrl,
      startParam,
      device_fingerprint: fp
    };

    try {
      const response = await fetch("/api/auth/telegram", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Telegram-Init-Data": (typeof window !== "undefined" ? (window as any).Telegram?.WebApp?.initData || "" : "")
        },
        body: JSON.stringify(authPayload)
      });

      if (response.ok) {
        const data = await response.json();
        if (data.user) {
          setUser(data.user);
          setRole(normalizeAppRole(data.user.role));
          localStorage.setItem("myteleflix_user", JSON.stringify(data.user));
          await syncAllDataForUser(data.user.id, normalizeAppRole(data.user.role));
        }
      } else {
        throw new Error("Telegram Auth response not ok");
      }
    } catch (err) {
      console.warn("Telegram auth backend offline fallback active:", err);
      if (parsedSavedUser) {
        await syncAllDataForUser(parsedSavedUser.id, normalizeAppRole(parsedSavedUser.role));
        return;
      }

      const activeUser: User = {
        id: `tg-${authPayload.telegramId}`,
        telegramId: String(authPayload.telegramId),
        username: authPayload.username || "telegram_user",
        fullName: [authPayload.firstName, authPayload.lastName].filter(Boolean).join(" ") || "Telegram User",
        photoUrl: authPayload.photoUrl || defaultUser.photoUrl,
        points: 100,
        createdAt: new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        device_fingerprint: fp,
        isPremium: false,
        role: "user"
      };

      setUser(activeUser);
      setRole("user");
      localStorage.setItem("myteleflix_user", JSON.stringify(activeUser));
      await syncAllDataForUser(activeUser.id, "user");
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    initTelegramAuth();

    // Real-time Firestore sync for /withdrawals collection
    const unsub = subscribeToWithdrawals((liveWithdrawals) => {
      if (Array.isArray(liveWithdrawals)) {
        setWithdrawals(liveWithdrawals);
      }
    });

    // Real-time Firestore sync for /movies collection (ensures Netlify & multi-device sync)
    const unsubMovies = subscribeToMovies((liveMovies) => {
      if (Array.isArray(liveMovies) && liveMovies.length > 0) {
        updateMoviesState(liveMovies);
      }
    });

    // Real-time Firestore sync for /videos collection
    const unsubVideos = subscribeToVideos((liveVideos) => {
      if (Array.isArray(liveVideos) && liveVideos.length > 0) {
        updateVideosState(liveVideos);
      }
    });

    return () => {
      if (typeof unsub === 'function') unsub();
      if (typeof unsubMovies === 'function') unsubMovies();
      if (typeof unsubVideos === 'function') unsubVideos();
    };
  }, []);

  // Real-time verification of Firebase Google Auth state & Firestore onboarding status
  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const freshDoc = await getUserFromFirestore(fbUser.uid);
          if (freshDoc) {
            const isCompleted = (freshDoc as any).onboardingCompleted === true || freshDoc.isOnboarded === true;
            if (isCompleted) {
              setPendingOnboardingUser(null);
            } else {
              setPendingOnboardingUser({
                id: fbUser.uid,
                uid: fbUser.uid,
                telegramId: String(freshDoc.telegramId || ""),
                username: freshDoc.username || fbUser.email?.split("@")[0] || "user",
                fullName: freshDoc.fullName || fbUser.displayName || "Google User",
                email: fbUser.email || "",
                photoUrl: fbUser.photoURL || undefined,
                points: freshDoc.points ?? 100,
                createdAt: freshDoc.createdAt || new Date().toISOString(),
                isPremium: false,
                role: 'user',
                gender: freshDoc.gender as any
              });
            }
          }
        } catch (e) {
          console.warn("Notice checking Firestore auth on reload:", e);
        }
      }
    });

    return () => unsubAuth();
  }, []);

  // Sync all movie catalog and user stats & record session activity
  const syncAllDataForUser = async (userId: string, targetRole: User['role'] | 'user' | 'guest' | 'admin' | 'super_admin' = role) => {
    setIsSyncing(true);
    try {
      const fp = getCachedDeviceFingerprint();
      const authRes = await fetch(`/api/auth?userId=${userId}&device_fingerprint=${encodeURIComponent(fp)}`);
      if (authRes.ok) {
        const data = await authRes.json();
        if (data.user) {
          // If the email is the admin, enforce role 'admin'
          if (data.user.email?.toLowerCase().trim() === "mostofa7077a@gmail.com" || 
              data.user.telegramId === "703119315615" || 
              data.user.username?.toLowerCase() === "mostofashowkat") {
            data.user.role = "admin";
            setRole("admin");
          }
          setUser(prev => {
            const merged = {
              ...data.user,
              displayName: prev?.displayName || data.user.displayName,
              fullName: prev?.fullName || data.user.fullName,
              gender: prev?.gender || data.user.gender,
              photoUrl: prev?.photoUrl || data.user.photoUrl,
              photoURL: prev?.photoURL || data.user.photoURL,
              telegramUsername: prev?.telegramUsername || data.user.telegramUsername,
              isProfileCompleted: Boolean(prev?.isProfileCompleted || data.user.isProfileCompleted),
              isOnboarded: Boolean(prev?.isOnboarded || data.user.isOnboarded),
            };
            try {
              localStorage.setItem("myteleflix_user", JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }
        if (data.settings) setSettings(data.settings);
      }

      const [moviesRes, videosRes, missionsRes] = await Promise.all([
        fetch('/api/movies?all=true'),
        fetch('/api/videos?all=true'),
        fetch('/api/missions?all=true'),
      ]);

      if (moviesRes.ok) {
        const m = await moviesRes.json();
        if (Array.isArray(m)) {
          const isLocallyCustomized = localStorage.getItem("myteleflix_media_customized") === "true";
          if (isLocallyCustomized && m.length > 0 && m.every((item: any) => item.id.startsWith('mv-10') || item.id.startsWith('ser-10') || item.id.startsWith('drm-10') || item.id.startsWith('amv-10'))) {
            fetch('/api/media/sync-all', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ movies }),
            }).catch(console.error);
          } else {
            updateMoviesState(m);
          }
        }
      }
      if (videosRes.ok) {
        const v = await videosRes.json();
        if (Array.isArray(v)) {
          const isLocallyCustomized = localStorage.getItem("myteleflix_media_customized") === "true";
          if (isLocallyCustomized && v.length > 0 && v.every((item: any) => item.id.startsWith('vd-10'))) {
            fetch('/api/media/sync-all', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ videos }),
            }).catch(console.error);
          } else {
            updateVideosState(v);
          }
        }
      }
      if (missionsRes.ok) {
        const ms = await missionsRes.json();
        if (ms && ms.length > 0) setMissions(ms);
      }

      const [logsRes, txsRes, refsRes, notifsRes] = await Promise.all([
        fetch(`/api/missions/logs?userId=${userId}`),
        fetch(`/api/wallet/transactions?userId=${userId}`),
        fetch(`/api/referrals?userId=${userId}`),
        fetch(`/api/notifications?userId=${userId}`),
      ]);

      if (logsRes.ok) setCompletedLogs(await logsRes.json());
      if (txsRes.ok) setTransactions(await txsRes.json());
      if (refsRes.ok) {
        const r = await refsRes.json();
        if (r && r.length > 0) setReferrals(r);
      }
      if (notifsRes.ok) {
        const notifsData = await notifsRes.json();
        const notifList: Notification[] = Array.isArray(notifsData) ? notifsData : (notifsData?.notifications || []);
        
        const unreadAlerts = notifList.filter(n => !(n.is_read ?? n.isRead));
        const newToastAlert = unreadAlerts.find(n => {
          const id = n.notification_id || n.id;
          return id && !seenNotificationIdsRef.current.has(id);
        });

        if (newToastAlert) {
          const id = newToastAlert.notification_id || newToastAlert.id;
          if (id) markNotificationAsSeenLocally(id);
          triggerToastAlert(newToastAlert);
        }

        notifList.forEach(n => {
          const id = n.notification_id || n.id;
          if (id) markNotificationAsSeenLocally(id);
        });

        setNotifications(notifList);
      }

      try {
        const inactRes = await fetch(`/api/user/inactivity-status?userId=${userId}`);
        if (inactRes.ok) {
          const inactData = await inactRes.json();
          if (inactData.warning_active && inactData.warning_message) {
            triggerInactivityAlert(inactData.warning_message);
          }
        }
      } catch (e) {
        // Inactivity check offline fallback
      }

      const reqsRes = await fetch('/api/requests');
      if (reqsRes.ok) setRequests(await reqsRes.json());

      if (targetRole === 'admin') {
        const [analRes, withsRes] = await Promise.all([
          fetch('/api/admin/analytics'),
          fetch('/api/admin/withdrawals'),
        ]);
        if (analRes.ok) setAnalytics(await analRes.json());
        if (withsRes.ok) setWithdrawals(await withsRes.json());
      }
    } catch (err) {
      console.warn("Offline fallback sync active.", err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Backwards compatibility legacy sync trigger
  const syncAllData = async (targetRole = role) => {
    if (user?.id) {
      await syncAllDataForUser(user.id, targetRole);
    }
  };

  // Switch role inside developer Simulator Header
  const handleSwitchRole = async (newRole: 'user' | 'guest' | 'admin' | 'super_admin') => {
    setRole(newRole);
    setIsAdminActive(newRole === 'admin' || newRole === 'super_admin');
    setIsSyncing(true);

    // Set simulator user representation
    let simUser: User;
    if (newRole === 'guest') {
      simUser = defaultGuestUser;
    } else if (newRole === 'admin') {
      simUser = {
        id: "admin-demo-id",
        telegramId: "703119315615",
        username: "mostofashowkat",
        fullName: "Mostofa Showkat (Admin)",
        email: "mostofa7077a@gmail.com",
        photoUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
        points: 92450,
        createdAt: new Date().toISOString(),
        isPremium: true,
        role: "admin"
      };
    } else {
      simUser = defaultUser;
    }

    setUser(simUser);
    localStorage.setItem("myteleflix_user", JSON.stringify(simUser));

    try {
      const payload = {
        userId: simUser.id,
        username: simUser.username,
        fullName: simUser.fullName,
        isPremium: simUser.isPremium,
        referrerId: newRole === 'guest' ? 'tg-101' : undefined
      };

      const res = await fetch('/api/auth/switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.user) {
          // If the email is the admin, enforce role 'admin'
          if (data.user.email?.toLowerCase().trim() === "mostofa7077a@gmail.com" || data.user.telegramId === "703119315615" || newRole === 'admin') {
            data.user.role = "admin";
          }
          setUser(data.user);
          localStorage.setItem("myteleflix_user", JSON.stringify(data.user));
        }
      }
      
      await syncAllDataForUser(simUser.id, newRole);
    } catch (err) {
      console.warn("Simulator switch synced locally.", err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Handlers for Notification & Alert Engine (VRMS-3 ULTRA Phase 12)
  const handleMarkNotificationRead = useCallback(async (id: string) => {
    try {
      const res = await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, notificationIds: [id] }),
      });
      if (res.ok) {
        setNotifications(prev => prev.map(n => 
          (n.notification_id === id || n.id === id) 
            ? { ...n, isRead: true, is_read: true } 
            : n
        ));
      }
    } catch (err) {
      console.error(err);
    }
  }, [user?.id]);

  const handleMarkAllNotificationsRead = useCallback(async () => {
    // Record all current notification IDs as seen immediately so indicator stays off
    setNotifications(prev => {
      prev.forEach(n => {
        const id = n.notification_id || n.id;
        if (id) markNotificationAsSeenLocally(id);
      });
      return prev.map(n => ({ ...n, isRead: true, is_read: true }));
    });
    try {
      await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.id, all: true }),
      });
    } catch (err) {
      console.error(err);
    }
  }, [user?.id, markNotificationAsSeenLocally]);

  const handleClearAllNotifications = useCallback(() => {
    try {
      localStorage.removeItem("myteleflix_notifications");
      localStorage.removeItem("myteleflix_system_notices");
      setNotifications([]);
      setActiveToast(null);
    } catch (e) {}
  }, []);

  // Periodic real-time background notification poll
  useEffect(() => {
    if (!user?.id || user.id.startsWith('guest_') || user.id === 'tg-guest') return;
    const intervalId = setInterval(async () => {
      try {
        const res = await fetch(`/api/notifications?userId=${user.id}`);
        if (res.ok) {
          const notifsData = await res.json();
          const notifList: Notification[] = Array.isArray(notifsData) ? notifsData : (notifsData?.notifications || []);
          
          const unreadAlerts = notifList.filter(n => !(n.is_read ?? n.isRead));
          const newToastAlert = unreadAlerts.find(n => {
            const id = n.notification_id || n.id;
            return id && !seenNotificationIdsRef.current.has(id);
          });

          if (newToastAlert) {
            const id = newToastAlert.notification_id || newToastAlert.id;
            if (id) markNotificationAsSeenLocally(id);
            triggerToastAlert(newToastAlert);
          }

          notifList.forEach(n => {
            const id = n.notification_id || n.id;
            if (id) markNotificationAsSeenLocally(id);
          });

          setNotifications(notifList);
        }
      } catch {
        // silent background poll error ignore
      }
    }, 15000);

    return () => clearInterval(intervalId);
  }, [user?.id]);

  const handleVerifyMission = async (missionId: string) => {
    const targetMission = missions.find(m => m.id === missionId);
    const reward = targetMission?.rewardPoints || targetMission?.pointsReward || 250;

    // Instant optimistic update to User points, taskStats, and last_active_at
    if (user) {
      recordUserActivity(user, handleUpdateUserProfile);
      setUser(prev => {
        if (!prev) return null;
        const currentStats = prev.taskStats || { missionsCompleted: 0, totalPointsEarned: 0, moviesWatched: 0, videosWatched: 0 };
        const updatedUser: User = {
          ...prev,
          points: prev.points + reward,
          last_active_at: new Date().toISOString(),
          lastActiveTimestamp: Date.now(),
          taskStats: {
            ...currentStats,
            missionsCompleted: (currentStats.missionsCompleted || 0) + 1,
            totalPointsEarned: (currentStats.totalPointsEarned || 0) + reward
          }
        };
        try {
          localStorage.setItem("myteleflix_user", JSON.stringify(updatedUser));
        } catch (e) {}
        saveUserToFirestore(updatedUser).catch(() => {});
        return updatedUser;
      });
    }

    // Optimistically record completed log so Tasks Completed metric increments immediately
    setCompletedLogs(prev => {
      if (prev.some(l => l.missionId === missionId)) return prev;
      return [
        {
          id: "ml-" + Date.now(),
          userId: currentUserId,
          missionId,
          completedAt: new Date().toISOString(),
          pointsEarned: reward
        },
        ...prev
      ];
    });

    // Optimistically record transaction ledger entry
    setTransactions(prev => [
      {
        id: "tx-task-" + Date.now(),
        userId: currentUserId,
        amount: reward,
        type: "task_reward",
        status: "completed",
        description: `Verified Task: ${targetMission?.title || "Sponsored Task"} (+${reward})`,
        timestamp: new Date().toISOString()
      },
      ...prev
    ]);

    try {
      const res = await authenticatedFetch('/api/missions/verify', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Idempotency-Key': `mission_${currentUserId}_${missionId}`
        },
        body: JSON.stringify({ 
          userId: currentUserId, 
          missionId,
          device_fingerprint: getDeviceFingerprint()
        }),
      });
      if (res.ok) {
        const data = await res.json();
        // Securely sync updated user to Firestore
        if (user) {
          saveUserToFirestore({
            ...user,
            points: user.points + (data.pointsReward || reward),
            last_active_at: new Date().toISOString()
          }).catch((e: any) => console.warn("Notice syncing user points to Firestore:", e));
        }
        return { success: true, pointsEarned: data.pointsReward || reward };
      }
    } catch (err) {
      console.warn("Task verified optimistically.");
    }
    return { success: true, pointsEarned: reward };
  };

  const handleWithdraw = async (
    amount: number, 
    walletAddress: string,
    paymentMethod?: string,
    email?: string,
    accountNumber?: string
  ) => {
    if (user?.isBanned || user?.status === 'banned') {
      return { success: false, error: user.banReason || "Account cashouts are currently restricted due to anti-fraud review." };
    }

    const initialPoints = user?.points || 0;
    if (user) {
      setUser(prev => prev ? { ...prev, points: Math.max(0, prev.points - amount) } : null);
    }

    const methodDisplay = paymentMethod || "TON/Crypto";
    const destDisplay = accountNumber || walletAddress;

    const optId = "tx-wd-" + Date.now();
    // Optimistic pending withdrawal transaction in local ledger
    const optimisticTx: Transaction = {
      id: optId,
      userId: currentUserId,
      amount: -amount,
      type: "withdrawal",
      status: "pending",
      description: `Cashout via ${methodDisplay}: ${destDisplay}`,
      timestamp: new Date().toISOString()
    };
    setTransactions(prev => [optimisticTx, ...prev]);

    try {
      const res = await authenticatedFetch('/api/withdrawals/request', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Idempotency-Key': `wd_${currentUserId}_${Date.now()}`
        },
        body: JSON.stringify({ 
          userId: currentUserId, 
          amount, 
          walletAddress: destDisplay,
          paymentMethod: methodDisplay,
          email: email || user?.email || "",
          accountNumber: destDisplay,
          device_fingerprint: getDeviceFingerprint(),
          hardwareMetrics: getHardwareMetrics()
        }),
      });
      if (res.ok) {
        await syncAllData();
        return { success: true };
      } else {
        const data = await res.json();
        // Rollback optimistic state if server rejects
        if (user) {
          setUser(prev => prev ? { ...prev, points: initialPoints } : null);
        }
        setTransactions(prev => prev.filter(t => t.id !== optId));
        return { success: false, error: data.error || "Failed to submit withdrawal request" };
      }
    } catch (err: any) {
      console.warn("Deduction error:", err);
      if (user) {
        setUser(prev => prev ? { ...prev, points: initialPoints } : null);
      }
      setTransactions(prev => prev.filter(t => t.id !== optId));
      return { success: false, error: err.message || "Failed to submit withdrawal request" };
    }
  };

  const handleSearchAi = async (query: string, notes?: string) => {
    try {
      const res = await fetch('/api/search-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query,
          userId: currentUserId,
          username: user?.username || "explorer",
          notes: notes || "",
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setRequests(prev => [data.request, ...prev]);
        return { success: true, responseText: data.responseText, request: data.request };
      }
    } catch (err) {
      console.warn("Consulting local sandbox AI...");
    }

    // Fallback if network or server is offline
    const fallbackRequest = {
      id: "rq-" + Date.now(),
      userId: currentUserId,
      username: user?.username || "explorer",
      title: query,
      notes: notes || "",
      status: "pending" as const,
      aiRecommendation: `Approved! We noted your interest in "${query}". Our curation team will review it.`,
      timestamp: new Date().toISOString()
    };
    setRequests(prev => [fallbackRequest, ...prev]);
    return {
      success: true,
      responseText: `Approved! We noted your interest in "${query}". Our curation team will review it.`,
      request: fallbackRequest
    };
  };

  // Admin adjustments
  const handleUpdateSettings = async (newSettings: Partial<SystemSettings>) => {
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      if (res.ok) {
        setSettings(prev => ({ ...prev, ...newSettings }));
      }
    } catch (e) {
      setSettings(prev => ({ ...prev, ...newSettings }));
    }
  };

  const handleAddMovie = async (movieData: any) => {
    const payload = {
      ...movieData,
      id: movieData.id || "mv-" + Date.now(),
      createdAt: movieData.createdAt || new Date().toISOString(),
      isActive: movieData.isActive ?? true,
      rating: movieData.rating || 8.8,
      views: movieData.views || 0,
    };

    // 1. Immediately update state and LocalStorage with chronological priority (newest first)
    updateMoviesState(prev => {
      const idx = prev.findIndex(m => m.id === payload.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = payload;
        return next;
      }
      return [payload, ...prev];
    });

    // 2. Persist to server backend
    try {
      const res = await fetch('/api/movies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        const savedMovie = data.movie || payload;
        updateMoviesState(prev => {
          const idx = prev.findIndex(m => m.id === savedMovie.id);
          if (idx !== -1) {
            const next = [...prev];
            next[idx] = savedMovie;
            return next;
          }
          return [savedMovie, ...prev];
        });
      }
    } catch (e) {
      console.error("Movie save server error, local persistence active:", e);
    }

    // 3. Persist directly to Google Firebase Firestore cloud database
    saveMovieToFirestore(payload).catch((e) => console.warn("Firestore movie save warning:", e));
  };

  const handleAddVideo = async (videoData: any) => {
    const payload = {
      ...videoData,
      id: videoData.id || "vd-" + Date.now(),
      createdAt: videoData.createdAt || new Date().toISOString(),
      isActive: videoData.isActive ?? true,
      views: videoData.views || 0,
    };

    // 1. Immediately update state and LocalStorage with chronological priority (newest first)
    updateVideosState(prev => {
      const idx = prev.findIndex(v => v.id === payload.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = payload;
        return next;
      }
      return [payload, ...prev];
    });

    // 2. Persist to server backend
    try {
      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        const savedVideo = data.video || payload;
        updateVideosState(prev => {
          const idx = prev.findIndex(v => v.id === savedVideo.id);
          if (idx !== -1) {
            const next = [...prev];
            next[idx] = savedVideo;
            return next;
          }
          return [savedVideo, ...prev];
        });
      }
    } catch (e) {
      console.error("Video save server error, local persistence active:", e);
    }

    // 3. Persist directly to Google Firebase Firestore cloud database
    saveVideoToFirestore(payload).catch((e) => console.warn("Firestore video save warning:", e));
  };

  const handleDeleteMovie = async (id: string) => {
    // 1. Immediately delete from local state and LocalStorage (permanent persistence)
    updateMoviesState(prev => prev.filter(m => m.id !== id));

    // 2. Delete from server backend
    try {
      await fetch('/api/movies/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error("Delete movie server error:", e);
    }

    // 3. Delete directly from Google Firebase Firestore cloud database
    deleteMovieFromFirestore(id).catch((e) => console.warn("Firestore movie delete warning:", e));
  };

  const handleDeleteVideo = async (id: string) => {
    // 1. Immediately delete from local state and LocalStorage (permanent persistence)
    updateVideosState(prev => prev.filter(v => v.id !== id));

    // 2. Delete from server backend
    try {
      await fetch('/api/videos/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error("Delete video server error:", e);
    }

    // 3. Delete directly from Google Firebase Firestore cloud database
    deleteVideoFromFirestore(id).catch((e) => console.warn("Firestore video delete warning:", e));
  };

  const handleClearAllMedia = async (type: 'movies' | 'videos' | 'all' = 'all') => {
    // 1. Immediately clear local state and LocalStorage (permanent persistence)
    if (type === 'movies' || type === 'all') updateMoviesState([]);
    if (type === 'videos' || type === 'all') updateVideosState([]);

    // 2. Clear server database
    try {
      await fetch('/api/media/clear-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      });
    } catch (e) {
      console.error("Clear media server error:", e);
    }
  };

  const handleToggleMovie = async (id: string) => {
    updateMoviesState(prev => prev.map(m => m.id === id ? { ...m, isActive: !m.isActive } : m));
    try {
      await fetch('/api/movies/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleVideo = async (id: string) => {
    updateVideosState(prev => prev.map(v => v.id === id ? { ...v, isActive: !v.isActive } : v));
    try {
      await fetch('/api/videos/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddMission = async (missionData: any) => {
    try {
      const res = await fetch('/api/missions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(missionData),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.mission) {
          setMissions(prev => {
            const idx = prev.findIndex(m => m.id === data.mission.id);
            if (idx !== -1) {
              const updated = [...prev];
              updated[idx] = data.mission;
              return updated;
            }
            return [...prev, data.mission];
          });
        }
      }
    } catch (e) {
      console.error("Error saving mission:", e);
    }
  };

  const handleToggleMission = async (id: string) => {
    setMissions(prev => prev.map(m => m.id === id ? { ...m, isActive: !m.isActive } : m));
    try {
      await fetch('/api/missions/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error("Error toggling mission:", e);
    }
  };

  const handleDeleteMission = async (id: string) => {
    setMissions(prev => prev.filter(m => m.id !== id));
    try {
      await fetch('/api/missions/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
    } catch (e) {
      console.error("Error deleting mission:", e);
    }
  };

  const handleUpdateWithdrawalStatus = async (id: string, status: any) => {
    const target = withdrawals.find(w => w.id === id);
    setWithdrawals(prev => prev.map(w => w.id === id ? { ...w, status } : w));
    try {
      // 1. Direct Firestore status persistence
      await updateWithdrawalStatusInFirestore(id, status);

      // 2. Also notify backend API endpoint
      try {
        await fetch('/api/admin/withdrawals/status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id, status }),
        });
      } catch {}

      // If status is rejected and target belongs to the currently logged in user, refund points in live session
      if (status === 'rejected' && target && user && (target.userId === user.id || (target.email && target.email.toLowerCase() === user.email?.toLowerCase()))) {
        setUser(prev => prev ? { ...prev, points: (prev.points || 0) + (target.amount || 0) } : null);
      }
    } catch (e) {
      console.error("Error updating withdrawal status in Firestore:", e);
    }
  };

  const handleBanUser = async (userId: string, isBanned: boolean, reason?: string) => {
    try {
      const res = await fetch('/api/admin/users/ban', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, isBanned, reason }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to update user security status');
      }
      // If affected user is current active user, update local profile immediately
      if (user && user.id === userId) {
        setUser(prev => prev ? {
          ...prev,
          isBanned,
          status: isBanned ? 'banned' : 'active',
          banReason: isBanned ? (reason || 'Restricted by Admin') : ''
        } : null);
      }
    } catch (e) {
      console.error("Error updating user ban state:", e);
      throw e;
    }
  };

  const handleUpdateRequestStatus = async (id: string, status: any) => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status } : r));
    try {
      await fetch('/api/requests/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
    } catch (e) {
      console.error("Error updating request status:", e);
    }
  };

  const handleBroadcastNotification = async (title: string, message: string) => {
    try {
      const res = await fetch('/api/notifications/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, message }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.announcement) {
          setNotifications(prev => [data.announcement, ...prev]);
        }
      }
    } catch (e) {
      console.error("Error broadcasting notification:", e);
    }
  };

  const handleReorderMissions = async (orders: { id: string; order: number }[]) => {
    try {
      await fetch('/api/missions/reorder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orders }),
      });
    } catch (e) {
      console.error("Error reordering missions:", e);
    }
  };

  const completedMissionIds = completedLogs.map(l => l.missionId);

  // Phase 2 Two-Step Website Redirection Handshake Landing Views
  const currentPath = typeof window !== 'undefined' ? window.location.pathname.toLowerCase() : '';
  const currentSearch = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const verifyParam = currentSearch.get('verify') || currentSearch.get('step') || '';

  const isVerifyStep1 = currentPath.includes('/verify-1') || currentPath.includes('/verify/step-1') || verifyParam === 'step1' || verifyParam === '1';
  const isVerifyStep2 = currentPath.includes('/verify-2') || currentPath.includes('/verify/step-2') || verifyParam === 'step2' || verifyParam === '2';

  if (isVerifyStep1) {
    return <VerificationStep1 />;
  }

  if (isVerifyStep2) {
    return <VerificationStep2 />;
  }

  // Phase 6 Admin Route Handler (/admin)
  const isAdminDirectRoute = currentPath === '/admin' || currentPath.startsWith('/admin') || currentSearch.get('tab') === 'admin' || currentSearch.get('route') === 'admin';

  if (isAdminDirectRoute) {
    if (isAuthorizedAdminUser) {
      return (
        <div className="min-h-screen bg-[#070A12] text-white p-2 sm:p-4">
          <Phase6AdminControlPanel 
            currentUserEmail={user?.email}
            onBackToApp={() => {
              window.history.pushState({}, '', '/');
              setIsAdminActive(false);
              setActiveTab('home');
            }}
          />
        </div>
      );
    } else {
      return (
        <div className="min-h-screen bg-[#070A12] text-white flex items-center justify-center p-4 font-sans select-none">
          <div className="max-w-md w-full rounded-3xl bg-[#0B101B] border border-red-500/40 p-6 sm:p-8 text-center space-y-5 shadow-2xl animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-red-950/80 border border-red-500/40 flex items-center justify-center text-red-400 mx-auto shadow-[0_0_20px_rgba(239,68,68,0.25)]">
              <Shield size={32} />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-white tracking-tight">
                Restricted Admin Access
              </h2>
              <p className="text-xs text-slate-400 leading-relaxed font-mono">
                Route <code>/admin</code> is strictly protected. Only whitelisted Super Admin credentials can access the Phase 6 control panel.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#080C14] border border-slate-800 text-left space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-400 font-mono text-[11px]">
                <span>Active Account:</span>
                <span className="text-white font-semibold">{user?.email || "Not Signed In"}</span>
              </div>
              <div className="flex justify-between text-slate-400 font-mono text-[11px]">
                <span>Required Role:</span>
                <span className="text-amber-400 font-bold">SUPER_ADMIN</span>
              </div>
            </div>

            <div className="pt-2 space-y-2">
              <button
                type="button"
                onClick={() => {
                  window.history.replaceState({}, '', '/');
                  setShowMasterPinModal(true);
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg transition cursor-pointer"
              >
                Authenticate with Master PIN / Admin Key
              </button>

              <button
                type="button"
                onClick={() => {
                  window.history.replaceState({}, '', '/');
                  setActiveTab('home');
                }}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition cursor-pointer"
              >
                Return to Home
              </button>
            </div>
          </div>
        </div>
      );
    }
  }

  return (
    <div className="min-h-screen bg-[#0F0F10] text-white font-sans flex flex-col pb-24 relative overflow-x-hidden w-full max-w-full">
      
      {/* 1. Splash Screen Overlay */}
      <AnimatePresence>
        {showSplash && (
          <SplashScreen onFinish={() => setShowSplash(false)} user={user} />
        )}
      </AnimatePresence>

      {/* 72-Hour Inactivity Auto-Reset Floating Notice (Only displayed 2.5s after platform loads) */}
      {!showSplash && canShowNotices && inactivityNotice && (
        <div className="fixed top-3 left-3 right-3 sm:left-auto sm:right-6 sm:w-96 z-50 animate-in fade-in slide-in-from-top-3 duration-300">
          <div className="bg-gradient-to-r from-amber-950/95 to-red-950/95 border border-amber-500/60 rounded-2xl p-3.5 shadow-2xl backdrop-blur-xl flex items-start gap-3">
            <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-[11px] text-amber-200 leading-snug">
              <span className="font-bold text-amber-100 block mb-0.5">নিষ্ক্রিয়তা নোটিশ (Inactivity Notice)</span>
              {inactivityNotice}
            </div>
            <button
              onClick={() => setInactivityNotice(null)}
              className="text-amber-400 hover:text-white cursor-pointer p-0.5"
            >
              <X size={15} />
            </button>
          </div>
        </div>
      )}

      {/* 2. Simulation Header */}
      {showDevPanel && (
        <SimulationHeader
          currentUser={{
            id: currentUserId,
            fullName: user?.fullName || "Guest",
            role: role,
          }}
          onSwitchRole={handleSwitchRole}
          isSyncing={isSyncing}
        />
      )}

      {/* 3. Main Header (Visible when not actively inside the Admin dashboard) */}
      {!isAdminActive && user && (
        <Header
          user={user}
          notifications={notifications}
          onMarkRead={handleMarkNotificationRead}
          onMarkAllRead={handleMarkAllNotificationsRead}
          onClearAll={handleClearAllNotifications}
          onNavigate={handleSelectNavTab}
          activeTab={activeTab}
          onOpenAdmin={isAuthorizedAdminUser ? () => setIsAdminActive(true) : undefined}
          onSecretAdminTrigger={isAuthorizedAdminUser ? handleSecretAdminTrigger : undefined}
        />
      )}

      {/* 4. Main Tab Pages Content */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden py-2.5 pb-24">
        {(isAdminActive && isAuthorizedAdminUser) ? (
          <AdminDashboard
            movies={movies}
            videos={videos}
            missions={missions}
            withdrawals={withdrawals}
            requests={requests}
            settings={settings}
            analytics={analytics}
            onUpdateSettings={handleUpdateSettings}
            onAddMovie={handleAddMovie}
            onAddVideo={handleAddVideo}
            onAddMission={handleAddMission}
            onDeleteMovie={handleDeleteMovie}
            onDeleteVideo={handleDeleteVideo}
            onClearAllMedia={handleClearAllMedia}
            onToggleMovie={handleToggleMovie}
            onToggleVideo={handleToggleVideo}
            onToggleMission={handleToggleMission}
            onEditMission={handleAddMission}
            onDeleteMission={handleDeleteMission}
            onUpdateWithdrawal={handleUpdateWithdrawalStatus}
            onUpdateRequestStatus={handleUpdateRequestStatus}
            onBroadcastNotification={handleBroadcastNotification}
            onReorderMissions={handleReorderMissions}
            onBanUser={handleBanUser}
            onClose={() => setIsAdminActive(false)}
          />
        ) : (
          <div className="space-y-6">
            <div className={activeTab === 'home' ? "block" : "hidden"}>
              {user && (
                <HomeScreen
                  user={user}
                  onNavigate={handleSelectNavTab}
                  movies={activeMovies}
                  videos={activeVideos}
                  missions={activeMissions}
                  isAdultUnlocked={isAdultUnlocked}
                  resetTrigger={homeResetTrigger}
                  activeCategory={homeActiveCategory}
                  onCategoryChange={(cat) => setHomeActiveCategory(cat)}
                  onViewedMovie={handleViewedMovie}
                />
              )}
            </div>

            <div className={activeTab === 'movies' ? "block" : "hidden"}>
              <MovieModule
                movies={activeMovies}
                completedMissionIds={completedMissionIds}
                userIsPremium={!!user?.isPremium}
                onViewedMovie={handleViewedMovie}
                missions={activeMissions}
                requests={requests}
                onSearchAi={handleSearchAi}
                isSyncing={isSyncing}
                isAdultUnlocked={isAdultUnlocked}
                onNavigate={handleSelectNavTab}
                onCategoryChange={(cat) => setHomeActiveCategory(cat)}
                user={user || undefined}
                guideVideoUrl={settings.guide_video_url || settings.guideVideoUrl}
                guideVideoLogoUrl={settings.guideVideoLogoUrl}
              />
            </div>

            <div className={activeTab === 'videos' ? "block" : "hidden"}>
              <VideoModule
                videos={activeVideos}
                completedMissionIds={completedMissionIds}
                userIsPremium={!!user?.isPremium}
                onViewedVideo={handleViewedMovie}
                missions={activeMissions}
                user={user || undefined}
                guideVideoUrl={settings.guide_video_url || settings.guideVideoUrl}
                guideVideoLogoUrl={settings.guideVideoLogoUrl}
              />
            </div>

            <div className={activeTab === 'earn' ? "block" : "hidden"}>
              <EarnModule
                missions={activeMissions}
                missionLogs={completedLogs}
                onVerifyMission={handleVerifyMission}
                userId={currentUserId}
                user={user || undefined}
                settings={settings}
                onUpdateUser={(u) => setUser(u)}
                onTriggerAuth={(action) => setLazyAuthAction(action)}
                onOpenStream={handlePlayStream}
              />
            </div>

            <div className={activeTab === 'wallet' ? "block" : "hidden"}>
              <WalletScreen
                userPoints={user?.points || 0}
                transactions={transactions}
                minimumWithdrawal={settings.minimumWithdrawal}
                tokenRateBdt={settings.tokenRateBdt}
                tokenRateUsd={settings.tokenRateUsd}
                userId={user?.id}
                userEmail={user?.email}
                username={user?.username || user?.fullName}
                isBanned={user?.isBanned || user?.status === 'banned'}
                banReason={user?.banReason}
                isGuest={!user || user.role === 'guest' || user.id?.startsWith('guest_') || !auth.currentUser}
                onTriggerAuth={(action) => setLazyAuthAction(action || 'wallet')}
                onWithdraw={handleWithdraw}
              />
            </div>

            <div className={activeTab === 'profile' ? "block" : "hidden"}>
              {user && (
                <ProfileScreen
                  user={user}
                  transactions={transactions}
                  minimumWithdrawal={settings.minimumWithdrawal}
                  tokenRateBdt={settings.tokenRateBdt}
                  tokenRateUsd={settings.tokenRateUsd}
                  settings={settings}
                  onWithdraw={handleWithdraw}
                  onOpenAdmin={isAuthorizedAdminUser ? () => setIsAdminActive(true) : undefined}
                  onSecretAdminTrigger={isAuthorizedAdminUser ? handleSecretAdminTrigger : undefined}
                  onOpenWallet={() => handleSelectNavTab('wallet')}
                  onNavigate={handleSelectNavTab}
                  isAdultUnlocked={isAdultUnlocked}
                  onToggleAdultUnlock={handleToggleAdultUnlock}
                  onTriggerAuth={(action) => setLazyAuthAction(action)}
                  onLoginSuccess={async (u) => {
                    const cleanEmail = (u.email || "").toLowerCase().trim();
                    const authRes = evaluateAuthorityGateway(cleanEmail);
                    u.role = authRes.role === 'ADMIN' ? 'admin' : 'user';
                    setRole(authRes.role === 'ADMIN' ? 'admin' : 'user');
                    setUser(u);
                    localStorage.setItem("myteleflix_user", JSON.stringify(u));
                    await syncAllDataForUser(u.id, u.role || 'user');
                  }}
                  onLogout={() => {
                    try {
                      if (typeof window !== "undefined") {
                        clearPersistentAdminToken();
                        localStorage.removeItem("myteleflix_user");
                        localStorage.removeItem("myteleflix_auth_token");
                        localStorage.removeItem("myteleflix_current_session");
                        localStorage.removeItem("myteleflix_admin_token");
                        localStorage.removeItem("myteleflix_admin_session");
                        sessionStorage.clear();
                      }
                    } catch (e) {}
                    const fp = getCachedDeviceFingerprint();
                    const guestId = getGuestDeviceId(fp);
                    const guestUser = createInitialGuestUser(fp, guestId);
                    setUser(guestUser);
                    setRole('guest');
                    setIsAdminActive(false);
                    setActiveTab('home');
                  }}
                />
              )}
            </div>
          </div>
        )}
      </main>

      {/* 5. Sticky Bottom Navigation Bar (Flat Solid Dark OTT) */}
      {!isAdminActive && user && (
        <Navigation
          activeTab={activeTab}
          onSelectTab={handleSelectNavTab}
          onHomeClick={handleHomeGlobalReset}
          isAdultUnlocked={isAdultUnlocked}
        />
      )}

      {/* 6. Lazy Auth Modal (Unified Google Only Gateway) */}
      <LazyAuthModal
        isOpen={Boolean(lazyAuthAction)}
        actionReason={lazyAuthAction || 'generic'}
        onClose={() => setLazyAuthAction(null)}
        onNeedOnboarding={(u) => {
          setPendingOnboardingUser(u);
          setLazyAuthAction(null);
        }}
        onPolicyViolation={(data) => {
          const primary = data.primaryEmail || (typeof data.existingAccount === 'object' ? data.existingAccount?.email : data.existingAccount) || "Authorized Account";
          setPolicyViolation({ isOpen: false });
          setSecurityModal({
            isOpen: true,
            primaryEmail: primary,
            attemptedEmail: data.attemptedEmail,
            hwid: data.deviceFingerprint,
            message: data.error
          });
          setLazyAuthAction(null);
        }}
        onLoginSuccess={async (u) => {
          setUser(u);
          setRole(normalizeAppRole(u.role));
          localStorage.setItem("myteleflix_user", JSON.stringify(u));
          await syncAllDataForUser(u.id, u.role || 'user');
          setLazyAuthAction(null);
        }}
      />

      {/* 7. Full-Screen Continuous Stream Player with Watch Time Heartbeat & Real Ad Monetization */}
      {activePlayingStream && (
        <MoviePlayer
          media={activePlayingStream.media}
          type={activePlayingStream.type}
          userId={currentUserId}
          settings={settings}
          onRewardAwarded={(pts) => {
            if (user) {
              setUser(prev => prev ? {
                ...prev,
                points: prev.points + pts,
                last_active_at: new Date().toISOString()
              } : null);
            }
          }}
          onClose={() => setActivePlayingStream(null)}
          onWatchTimeUpdate={(_seconds) => {
            if (user) {
              setUser(prev => prev ? {
                ...prev,
                totalWatchTimeSeconds: (prev.totalWatchTimeSeconds || 0) + 1,
                last_active_at: new Date().toISOString()
              } : null);
            }
          }}
          onActivityHeartbeat={() => {
            if (user) {
              setUser(prev => prev ? {
                ...prev,
                last_active_at: new Date().toISOString()
              } : null);
            }
          }}
        />
      )}
      {/* Welcome Onboarding Modal - Multi-Step Flow */}
      {pendingOnboardingUser && (
        <OnboardingFlow
          isOpen={true}
          user={pendingOnboardingUser}
          onComplete={(updatedUser: User) => {
            setUser(updatedUser);
            setRole(normalizeAppRole(updatedUser.role));
            localStorage.setItem("myteleflix_user", JSON.stringify(updatedUser));
            setPendingOnboardingUser(null);
            setActiveTab('home'); // Navigates straight to Home Dashboard
          }}
        />
      )}

      {/* Policy Violation Modal (1-Device 1-Account) */}
      <PolicyViolationModal
        isOpen={policyViolation.isOpen}
        onClose={() => setPolicyViolation({ isOpen: false })}
        errorMessage={policyViolation.error}
        existingAccount={policyViolation.existingAccount}
        deviceFingerprint={policyViolation.deviceFingerprint}
        ipAddress={policyViolation.ipAddress}
        onRestoreOriginalAccount={async () => {
          setPolicyViolation({ isOpen: false });
          const target = (typeof policyViolation.existingAccount === 'string' ? policyViolation.existingAccount : policyViolation.existingAccount?.email) || securityModal.primaryEmail;
          if (target) {
            try {
              const primaryUser = await restorePrimaryAccount(target);
              if (primaryUser) {
                setUser(primaryUser);
                setRole(normalizeAppRole(primaryUser.role));
                localStorage.setItem("myteleflix_user", JSON.stringify(primaryUser));
                await syncAllDataForUser(primaryUser.id, primaryUser.role || 'user');
                setActiveTab('home');
              }
            } catch (e) {
              console.warn("restorePrimaryAccount notice:", e);
            }
          }
        }}
      />

      {/* Strict Cross-Browser Hardware Security Warning Screen */}
      <SecurityWarningModal
        isOpen={securityModal.isOpen}
        primaryEmail={securityModal.primaryEmail}
        attemptedEmail={securityModal.attemptedEmail}
        hwid={securityModal.hwid}
        message={securityModal.message}
        onClose={() => {
          clearSecondaryDraftSession();
          setSecurityModal(prev => ({ ...prev, isOpen: false }));
        }}
        onSwitchToPrimary={async (targetEmail) => {
          setSecurityModal(prev => ({ ...prev, isOpen: false }));
          const target = targetEmail || securityModal.primaryEmail;
          if (target) {
            try {
              const primaryUser = await restorePrimaryAccount(target);
              if (primaryUser) {
                setUser(primaryUser);
                setRole(normalizeAppRole(primaryUser.role));
                localStorage.setItem("myteleflix_user", JSON.stringify(primaryUser));
                await syncAllDataForUser(primaryUser.id, primaryUser.role || 'user');
                setActiveTab('home');
              }
            } catch (e) {
              console.warn("restorePrimaryAccount error:", e);
            }
          }
        }}
      />

      {/* 8. Hidden Master Security Key Passcode Modal (Rendered ONLY for Verified Admins) */}
      {isAuthorizedAdminUser && (
        <MasterPinModal
          isOpen={showMasterPinModal}
          onClose={() => setShowMasterPinModal(false)}
          onSuccess={handleUnlockAdminConsole}
          targetEmail={user?.email || MASTER_ADMIN_EMAIL}
        />
      )}
      {/* 10. Top-Floating Transient Alert Notification Toast (Only displayed 2.5s after platform loads) */}
      {!showSplash && canShowNotices && activeToast && (
        <NotificationToast
          notification={activeToast}
          onDismiss={() => setActiveToast(null)}
        />
      )}

      {/* 11. Floating Draggable AI Support Chat Widget (TeleFlix AI) */}
      {!showSplash && !activePlayingStream && !isAdminActive && (
        <FloatingAiSupportWidget 
          user={user} 
          onNavigateTab={handleSelectNavTab}
        />
      )}
    </div>
  );
}
