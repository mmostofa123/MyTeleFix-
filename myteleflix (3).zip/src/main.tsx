/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { AuthProvider } from "./context/AuthContext";
import { GlobalConfigProvider } from "./context/GlobalConfigContext";
import { LanguageProvider } from "./context/LanguageContext";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AuthProvider>
      <GlobalConfigProvider>
        <LanguageProvider>
          <App />
        </LanguageProvider>
      </GlobalConfigProvider>
    </AuthProvider>
  </React.StrictMode>
);
