/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import { db } from "./services/firebase";
import { bindDeviceLockDB, checkDeviceLockDB, getDeviceLockDB } from "./db";
import { generateDeviceHardwareUUID } from "./SecurityGuard";

export const STORAGE_HWID_KEY = "myteleflix_hwid";
export const STORAGE_DEVICE_LOCK_KEY = "myteleflix_device_lock";
export const STORAGE_PRIMARY_EMAIL_KEY = "myteleflix_primary_email";
export const MASTER_ADMIN_EMAIL = "mostofa7077a@gmail.com";

export interface DeviceLockData {
  hwid: string;
  primary_email: string;
  user_id?: string;
  device_fingerprint?: string;
  platform?: string;
  screen_resolution?: string;
  created_at: string;
  updated_at?: string;
}

export interface DeviceLockCheckResult {
  isBlocked: boolean;
  isBound: boolean;
  primaryEmail?: string;
  firstUser?: any;
  hwid: string;
  reason?: string;
}

export interface DeviceLockBindResult {
  success: boolean;
  hwid: string;
  primaryEmail: string;
}

/**
 * Generates an FNV-1a 32-bit hash of a string, represented as hex.
 */
function fnv1aHex(str: string): string {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, "0");
}

/**
 * 1. Browser Canvas fingerprint generation
 */
function getCanvasSignature(): string {
  if (typeof document === "undefined") return "no-canvas-ssr";
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 300;
    canvas.height = 70;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "canvas-unsupported";

    // Text metrics & styling with emojis and shadow
    ctx.textBaseline = "top";
    ctx.font = "15px 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
    ctx.shadowColor = "rgba(225, 29, 72, 0.8)";
    ctx.shadowBlur = 8;
    ctx.shadowOffsetX = 3;
    ctx.shadowOffsetY = 3;
    ctx.fillStyle = "#e11d48";
    ctx.fillText("TeleFlix Vault 🛡️ 100% Secure HwID", 6, 8);

    // Multi-stop linear and radial gradient
    const grad = ctx.createLinearGradient(0, 0, 300, 0);
    grad.addColorStop(0, "#e11d48");
    grad.addColorStop(0.3, "#4f46e5");
    grad.addColorStop(0.7, "#06b6d4");
    grad.addColorStop(1, "#10b981");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 40, 300, 20);

    // Geometrical shapes with alpha blending
    ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
    ctx.beginPath();
    ctx.arc(45, 50, 15, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.fill();

    return canvas.toDataURL();
  } catch (e) {
    return "canvas-error";
  }
}

/**
 * Normalizes GPU strings across Chrome, Firefox, Edge, Brave, and Incognito to extract the true hardware chipset.
 */
export function normalizeGpuChipset(raw: string): string {
  if (!raw || raw === "no-webgl" || raw === "webgl-error" || raw === "no-webgl-ssr") return "standard-gpu";
  let s = raw.toLowerCase();
  s = s.replace(/google inc\.\s*/g, "");
  s = s.replace(/angle\s*\(/g, "");
  s = s.replace(/opengl\s*es\s*[\d.]*/g, "");
  s = s.replace(/direct3d\d*/g, "");
  s = s.replace(/vs_\d+_\d+/g, "");
  s = s.replace(/ps_\d+_\d+/g, "");
  s = s.replace(/d3d\d*/g, "");
  s = s.replace(/[~,()]/g, " ");
  s = s.replace(/\s+/g, " ").trim();
  return s || "standard-gpu";
}

/**
 * 2. GPU & WebGL hardware renderer identification
 */
function getGpuSignature(): string {
  if (typeof document === "undefined") return "no-webgl-ssr";
  try {
    const canvas = document.createElement("canvas");
    const gl = (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (!gl) return "no-webgl";

    const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
    const unmaskedVendor = debugInfo ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) : "";
    const unmaskedRenderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : "";
    const defaultVendor = gl.getParameter(gl.VENDOR) || "";
    const defaultRenderer = gl.getParameter(gl.RENDERER) || "";

    return `${unmaskedVendor || defaultVendor}~${unmaskedRenderer || defaultRenderer}`;
  } catch (e) {
    return "webgl-error";
  }
}

/**
 * Invariant Physical Screen Signature (independent of URL bars, zoom, orientation, or browser chrome)
 */
export function getPhysicalScreenSignature(): string {
  if (typeof window === "undefined" || !window.screen) return "360x800@1x24";
  const s = window.screen;
  const w = s.width || 0;
  const h = s.height || 0;
  const minDim = Math.min(w, h);
  const maxDim = Math.max(w, h);
  const dpr = Math.round(window.devicePixelRatio || 1);
  const depth = s.colorDepth || 24;
  return `${minDim}x${maxDim}@${dpr}x${depth}`;
}

/**
 * 3. Display & Screen resolution specifications
 */
function getResolutionSignature(): string {
  return getPhysicalScreenSignature();
}

/**
 * Invariant Platform Family (normalized across user agents)
 */
export function getPlatformFamily(): string {
  if (typeof navigator === "undefined") return "web";
  const ua = (navigator.userAgent || "").toLowerCase();
  const plat = (navigator.platform || "").toLowerCase();
  if (ua.includes("android") || plat.includes("arm") || plat.includes("android")) return "android";
  if (ua.includes("iphone") || ua.includes("ipad") || plat.includes("iphone") || plat.includes("ipad")) return "ios";
  if (ua.includes("mac") || plat.includes("mac")) return "mac";
  if (ua.includes("win") || plat.includes("win")) return "windows";
  if (ua.includes("linux") || plat.includes("linux")) return "linux";
  return "web";
}

/**
 * 4. System & Platform hardware attributes (Cross-Browser Invariant)
 */
function getPlatformSignature(): string {
  if (typeof navigator === "undefined") return "server-platform";
  return [
    getPlatformFamily(),
    navigator.hardwareConcurrency || 4,
    navigator.maxTouchPoints || 0,
    Intl?.DateTimeFormat()?.resolvedOptions()?.timeZone || "UTC"
  ].join("|");
}

/**
 * Returns structured cross-browser hardware specifications that are identical across Chrome, Firefox, Edge, Safari, Brave, and Incognito.
 */
export function getCrossBrowserHardwareTraits() {
  const rawGpu = getGpuSignature();
  const normGpu = normalizeGpuChipset(rawGpu);
  const physScreen = getPhysicalScreenSignature();
  const platFamily = getPlatformFamily();
  const cpu = typeof navigator !== "undefined" ? (navigator.hardwareConcurrency || 4) : 4;
  const tz = typeof Intl !== "undefined" ? (Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC") : "UTC";
  const touch = typeof navigator !== "undefined" ? (navigator.maxTouchPoints || 0) : 0;

  return {
    gpu_renderer: rawGpu,
    gpu_chipset: normGpu,
    screen_resolution: physScreen,
    physical_screen: physScreen,
    platform: platFamily,
    platform_family: platFamily,
    hardware_concurrency: cpu,
    cpu_cores: cpu,
    device_memory: 4,
    timezone: tz,
    max_touch_points: touch
  };
}

/**
 * Generates a deterministic cross-browser hardware hash that matches on Chrome, Firefox, Edge, Safari, and Opera on the same physical device.
 */
export async function generateCrossBrowserHardwareId(): Promise<string> {
  const traits = getCrossBrowserHardwareTraits();
  const rawSignature = `PLAT:${traits.platform_family}|SCREEN:${traits.physical_screen}|GPU:${traits.gpu_chipset}|CPU:${traits.cpu_cores}|TZ:${traits.timezone}`;

  let hexHash = "";
  if (typeof window !== "undefined" && window.crypto && window.crypto.subtle) {
    try {
      const msgUint8 = new TextEncoder().encode(rawSignature);
      const hashBuffer = await window.crypto.subtle.digest("SHA-256", msgUint8);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      hexHash = hashArray.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 24);
    } catch (e) {}
  }

  if (!hexHash) {
    const h1 = fnv1aHex(rawSignature);
    const h2 = fnv1aHex(rawSignature + "_cross_salt");
    const h3 = fnv1aHex(rawSignature + "_device_pepper");
    hexHash = `${h1}${h2}${h3}`.slice(0, 24);
  }

  return `TF_HW_${hexHash.toUpperCase()}`;
}

/**
 * Checks whether an email is the Master Super Admin (bypasses device lock)
 */
export function isSuperAdminBypass(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return clean === MASTER_ADMIN_EMAIL.toLowerCase() || clean === "mostofa70000@gmail.com";
}

/**
 * Generate a persistent Hardware ID (HwID) using browser canvas, GPU, resolution, and platform attributes.
 */
export async function generateHardwareId(): Promise<string> {
  if (typeof window === "undefined") {
    return "HWID_SSR_SERVER_DEFAULT";
  }

  // 1. Check if an HwID is already stored persistently in LocalStorage
  try {
    const cachedHwid = localStorage.getItem(STORAGE_HWID_KEY);
    if (cachedHwid && cachedHwid.startsWith("HWID_") && cachedHwid.length >= 16) {
      return cachedHwid;
    }
  } catch (e) {}

  try {
    const canvasSig = fnv1aHex(getCanvasSignature());
    const gpuSig = fnv1aHex(getGpuSignature());
    const resolutionSig = getResolutionSignature();
    const platformSig = getPlatformSignature();

    const rawHardwareData = `CANVAS:${canvasSig}|GPU:${gpuSig}|RES:${resolutionSig}|PLATFORM:${platformSig}`;

    let hexHash = "";
    if (window.crypto && window.crypto.subtle) {
      const msgUint8 = new TextEncoder().encode(rawHardwareData);
      const hashBuffer = await window.crypto.subtle.digest("SHA-256", msgUint8);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      hexHash = hashArray.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 24);
    } else {
      const h1 = fnv1aHex(rawHardwareData);
      const h2 = fnv1aHex(rawHardwareData + "_teleflix_salt");
      const h3 = fnv1aHex(rawHardwareData + "_hw_pepper");
      hexHash = `${h1}${h2}${h3}`.slice(0, 24);
    }

    const hwid = `HWID_${hexHash.toUpperCase()}`;

    // Persist permanently in localStorage
    try {
      localStorage.setItem(STORAGE_HWID_KEY, hwid);
    } catch (e) {}

    return hwid;
  } catch (err) {
    const fallback = `HWID_FALLBACK_${fnv1aHex(navigator.userAgent + window.screen.width + window.screen.height).toUpperCase()}`;
    try {
      localStorage.setItem(STORAGE_HWID_KEY, fallback);
    } catch (e) {}
    return fallback;
  }
}

/**
 * Synchronous / instant retrieval of existing HwID (or fallback)
 */
export function getHardwareId(): string {
  if (typeof window === "undefined") return "HWID_SSR_SERVER_DEFAULT";
  try {
    const cached = localStorage.getItem(STORAGE_HWID_KEY);
    if (cached && cached.startsWith("HWID_")) {
      return cached;
    }
  } catch (e) {}
  return "HWID_PENDING_GENERATION";
}

/**
 * Returns any locally saved device lock record
 */
export function getStoredDeviceLock(): DeviceLockData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_DEVICE_LOCK_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.primary_email) {
        return parsed;
      }
    }
    const directEmail = localStorage.getItem(STORAGE_PRIMARY_EMAIL_KEY);
    if (directEmail) {
      return {
        hwid: getHardwareId(),
        primary_email: directEmail.toLowerCase().trim(),
        created_at: new Date().toISOString()
      };
    }
  } catch (e) {}
  return null;
}

/**
 * Returns the primary authorized email bound to this hardware device, if any.
 */
export function getBoundPrimaryEmail(): string | null {
  const lock = getStoredDeviceLock();
  if (lock?.primary_email) return lock.primary_email.toLowerCase().trim();
  try {
    const savedUser = localStorage.getItem("myteleflix_user");
    if (savedUser) {
      const u = JSON.parse(savedUser);
      if (u?.email && u.role !== 'guest' && !u.id?.startsWith('guest_')) {
        return u.email.toLowerCase().trim();
      }
    }
  } catch (e) {}
  return null;
}

/**
 * Clears draft/temporary secondary login sessions from storage.
 * Keeps the primary authorized binding intact.
 */
export function clearSecondaryDraftSession(): void {
  if (typeof window === "undefined") return;
  try {
    // Keep HWID and primary lock
    const hwid = localStorage.getItem(STORAGE_HWID_KEY);
    const lock = localStorage.getItem(STORAGE_DEVICE_LOCK_KEY);
    const primaryEmail = localStorage.getItem(STORAGE_PRIMARY_EMAIL_KEY);

    // Completely wipe unauthorized user tokens and session data
    localStorage.removeItem("myteleflix_user");
    localStorage.removeItem("myteleflix_auth_token");
    localStorage.removeItem("myteleflix_guest_user");
    localStorage.removeItem("myteleflix_current_session");
    localStorage.removeItem("myteleflix_isProfileCompleted");
    localStorage.removeItem("myteleflix_onboarding_completed");

    sessionStorage.clear();

    if (hwid) localStorage.setItem(STORAGE_HWID_KEY, hwid);
    if (lock) localStorage.setItem(STORAGE_DEVICE_LOCK_KEY, lock);
    if (primaryEmail) localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, primaryEmail);
  } catch (e) {}
}

/**
 * Check if the device HwID already exists in local or remote database under a DIFFERENT email.
 * If HwID exists under another email: BLOCKS authentication immediately.
 */
export async function checkDeviceLock(hwidParam?: string, incomingEmail?: string): Promise<DeviceLockCheckResult> {
  const hwid = hwidParam || await generateHardwareId();
  const cleanIncoming = (incomingEmail || "").toLowerCase().trim();

  // Super admin bypasses device lock check
  if (isSuperAdminBypass(cleanIncoming)) {
    return { isBlocked: false, isBound: false, hwid };
  }

  // 1. FAST PERSISTENT INDEXEDDB & LOCAL STORAGE CHECK WITH HARDWARE UUID
  try {
    const hwUUID = await generateDeviceHardwareUUID();
    const dbCheck = await checkDeviceLockDB(hwid, cleanIncoming, hwUUID);
    if (dbCheck.isBlocked && dbCheck.primaryEmail) {
      return {
        isBlocked: true,
        isBound: true,
        primaryEmail: dbCheck.primaryEmail,
        hwid,
        reason: "Device is permanently locked in the database to authorized primary Google account."
      };
    }
    if (dbCheck.isBound && dbCheck.primaryEmail && cleanIncoming === dbCheck.primaryEmail) {
      return {
        isBlocked: false,
        isBound: true,
        primaryEmail: dbCheck.primaryEmail,
        hwid
      };
    }
  } catch (dbErr) {
    console.warn("IndexedDB check notice:", dbErr);
  }

  const localLock = getStoredDeviceLock();
  if (localLock && localLock.primary_email) {
    const boundEmail = localLock.primary_email.toLowerCase().trim();
    if (cleanIncoming && boundEmail && cleanIncoming !== boundEmail) {
      return {
        isBlocked: true,
        isBound: true,
        primaryEmail: boundEmail,
        hwid,
        reason: "Device is permanently locked to a different authorized Google account."
      };
    }
    if (cleanIncoming && boundEmail && cleanIncoming === boundEmail) {
      return {
        isBlocked: false,
        isBound: true,
        primaryEmail: boundEmail,
        hwid
      };
    }
  }

  // 2. REMOTE DATABASE CHECK (Firestore /device_locks/{hwid} & /device_locks/{cross_browser_hwid})
  const crossHwid = await generateCrossBrowserHardwareId();
  try {
    let snap = await getDoc(doc(db, "device_locks", hwid));
    if (!snap.exists() && crossHwid) {
      snap = await getDoc(doc(db, "device_locks", crossHwid));
    }

    if (snap.exists()) {
      const data = snap.data() as DeviceLockData;
      const remoteEmail = (data?.primary_email || "").toLowerCase().trim();

      if (remoteEmail) {
        // Sync to localStorage
        try {
          localStorage.setItem(STORAGE_DEVICE_LOCK_KEY, JSON.stringify(data));
          localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, remoteEmail);
        } catch (e) {}

        if (cleanIncoming && remoteEmail !== cleanIncoming && !isSuperAdminBypass(cleanIncoming)) {
          return {
            isBlocked: true,
            isBound: true,
            primaryEmail: remoteEmail,
            hwid,
            reason: "Device is permanently locked in the database to another Google account."
          };
        }

        return {
          isBlocked: false,
          isBound: true,
          primaryEmail: remoteEmail,
          hwid
        };
      }
    }
  } catch (err) {
    console.warn("Firestore device_locks check warning (fallback to local/server):", err);
  }

  // 3. SERVER DATABASE CHECK (/api/security/check-device-lock)
  try {
    const traits = getCrossBrowserHardwareTraits();
    let clientIp = "";
    try {
      const ipRes = await fetch("/api/auth/client-ip", { signal: AbortSignal.timeout(2000) });
      if (ipRes.ok) {
        const ipData = await ipRes.json();
        clientIp = ipData.ip || "";
      }
    } catch (e) {}

    const res = await fetch("/api/security/check-device-lock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        hwid, 
        cross_browser_hwid: crossHwid,
        gpu_renderer: traits.gpu_renderer,
        gpu_chipset: traits.gpu_chipset,
        screen_resolution: traits.screen_resolution,
        physical_screen: traits.physical_screen,
        hardware_concurrency: traits.hardware_concurrency,
        cpu_cores: traits.cpu_cores,
        timezone: traits.timezone,
        platform: traits.platform,
        platform_family: traits.platform_family,
        ip_address: clientIp,
        email: cleanIncoming,
        device_fingerprint: hwidParam || hwid
      })
    });

    if (res.status === 403) {
      const data = await res.json();
      return {
        isBlocked: true,
        isBound: true,
        primaryEmail: data.primaryEmail || localLock?.primary_email,
        firstUser: data.firstUser,
        hwid,
        reason: data.reason || data.message || "Secondary account registration/login blocked on this device."
      };
    }

    if (res.ok) {
      const data = await res.json();
      if (data.isBlocked) {
        return {
          isBlocked: true,
          isBound: true,
          primaryEmail: data.primaryEmail,
          firstUser: data.firstUser,
          hwid,
          reason: data.reason
        };
      }
      if (data.primaryEmail) {
        return {
          isBlocked: false,
          isBound: true,
          primaryEmail: data.primaryEmail,
          firstUser: data.firstUser,
          hwid
        };
      }
    }
  } catch (e) {}

  return { isBlocked: false, isBound: false, hwid };
}

/**
 * On FIRST successful registration / login:
 * Bind the HwID to the user's primary Google email in LocalStorage + Database (`device_locks` schema).
 */
export async function bindDeviceLock(
  email: string,
  userId?: string,
  customHwid?: string
): Promise<DeviceLockBindResult> {
  const cleanEmail = (email || "").toLowerCase().trim();
  if (!cleanEmail) {
    throw new Error("Cannot bind device lock without an authorized email.");
  }

  const hwid = customHwid || await generateHardwareId();
  const crossHwid = await generateCrossBrowserHardwareId();
  const traits = getCrossBrowserHardwareTraits();
  let clientIp = "";
  try {
    const ipRes = await fetch("/api/auth/client-ip", { signal: AbortSignal.timeout(2000) });
    if (ipRes.ok) {
      const ipData = await ipRes.json();
      clientIp = ipData.ip || "";
    }
  } catch (e) {}

  const lockPayload: DeviceLockData = {
    hwid,
    primary_email: cleanEmail,
    user_id: userId || `u_${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`,
    platform: traits.platform,
    screen_resolution: traits.physical_screen,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  const extendedPayload = {
    ...lockPayload,
    cross_browser_hwid: crossHwid,
    gpu_renderer: traits.gpu_renderer,
    gpu_chipset: traits.gpu_chipset,
    physical_screen: traits.physical_screen,
    platform_family: traits.platform_family,
    hardware_concurrency: traits.hardware_concurrency,
    cpu_cores: traits.cpu_cores,
    timezone: traits.timezone,
    ip_address: clientIp,
    device_fingerprint: hwid
  };

  // 1. Bind in Persistent DB layer (IndexedDB + Safe LocalStorage)
  try {
    const hwUUID = await generateDeviceHardwareUUID();
    await bindDeviceLockDB(hwid, cleanEmail, userId, hwUUID);
  } catch (dbErr) {
    console.warn("bindDeviceLockDB notice:", dbErr);
  }

  // 2. Bind in LocalStorage permanently
  try {
    localStorage.setItem(STORAGE_HWID_KEY, hwid);
    localStorage.setItem("myteleflix_cross_browser_hwid", crossHwid);
    localStorage.setItem(STORAGE_DEVICE_LOCK_KEY, JSON.stringify(extendedPayload));
    localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, cleanEmail);
    localStorage.setItem("tf_primary_bound_email", cleanEmail);
    // Also store in document cookie (persists across tabs and reloads)
    if (typeof document !== "undefined") {
      document.cookie = `tf_primary_email=${encodeURIComponent(cleanEmail)}; path=/; max-age=315360000; SameSite=Lax`;
    }
  } catch (e) {
    console.warn("Failed to write device lock to LocalStorage:", e);
  }

  // 3. Bind in Firestore Database (`device_locks` collection)
  try {
    const lockRef = doc(db, "device_locks", hwid);
    await setDoc(lockRef, {
      ...extendedPayload,
      updated_at: serverTimestamp()
    }, { merge: true });

    if (crossHwid && crossHwid !== hwid) {
      const crossRef = doc(db, "device_locks", crossHwid);
      await setDoc(crossRef, {
        ...extendedPayload,
        updated_at: serverTimestamp()
      }, { merge: true });
    }
  } catch (err) {
    console.warn("Failed to write device lock to Firestore `device_locks`:", err);
  }

  // 4. Bind in Server Database via API
  try {
    fetch("/api/security/bind-device", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(extendedPayload)
    }).catch(() => {});
  } catch (e) {}

  return {
    success: true,
    hwid,
    primaryEmail: cleanEmail
  };
}

/**
 * Restores and logs directly into the primary authorized account on this device.
 * Used when the user clicks "মূল অ্যাকাউন্টে ফিরে যান".
 */
export async function restorePrimaryAccount(primaryEmail?: string): Promise<any> {
  const cookieEmailMatch = typeof document !== "undefined" ? document.cookie.match(/(^|;\s*)tf_primary_email=([^;]*)/) : null;
  const cookieEmail = cookieEmailMatch ? decodeURIComponent(cookieEmailMatch[2]) : "";

  let cleanEmail = (primaryEmail || getBoundPrimaryEmail() || cookieEmail || "").toLowerCase().trim();
  const hwid = await generateHardwareId();
  const crossHwid = await generateCrossBrowserHardwareId();
  const traits = getCrossBrowserHardwareTraits();

  // If cleanEmail is empty (e.g. fresh browser), look up in Firestore device_locks
  if (!cleanEmail) {
    try {
      let snap = await getDoc(doc(db, "device_locks", crossHwid));
      if (!snap.exists()) {
        snap = await getDoc(doc(db, "device_locks", hwid));
      }
      if (snap.exists()) {
        const d = snap.data();
        if (d?.primary_email) {
          cleanEmail = d.primary_email.toLowerCase().trim();
        }
      }
    } catch (e) {}
  }

  // Clear any temporary draft/secondary accounts
  clearSecondaryDraftSession();

  try {
    const res = await fetch("/api/auth/restore-primary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        primary_email: cleanEmail,
        hwid,
        cross_browser_hwid: crossHwid,
        gpu_chipset: traits.gpu_chipset,
        physical_screen: traits.physical_screen,
        cpu_cores: traits.cpu_cores,
        timezone: traits.timezone,
        platform_family: traits.platform_family
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (data.user) {
        localStorage.setItem("myteleflix_user", JSON.stringify(data.user));
        localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, data.user.email || cleanEmail);
        localStorage.setItem("tf_primary_bound_email", data.user.email || cleanEmail);
        localStorage.setItem(STORAGE_HWID_KEY, hwid);
        localStorage.setItem("myteleflix_cross_browser_hwid", crossHwid);
        if (typeof document !== "undefined") {
          document.cookie = `tf_primary_email=${encodeURIComponent(data.user.email || cleanEmail)}; path=/; max-age=315360000; SameSite=Lax`;
        }
        try {
          await bindDeviceLock(data.user.email, data.user.id, hwid);
        } catch (e) {}
        return data.user;
      }
    }
  } catch (err) {
    console.warn("Server restore primary notice:", err);
  }

  // Fallback: check Firestore directly
  if (cleanEmail) {
    try {
      const calculatedUid = `g-${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const snap = await getDoc(doc(db, "users", calculatedUid));
      if (snap.exists()) {
        const u = snap.data();
        localStorage.setItem("myteleflix_user", JSON.stringify(u));
        localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, cleanEmail);
        localStorage.setItem("tf_primary_bound_email", cleanEmail);
        return u;
      }
    } catch (e) {}

    // Fallback constructed user
    const fallback = {
      id: `g-${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`,
      googleId: `g-${cleanEmail.replace(/[^a-zA-Z0-9]/g, '_')}`,
      email: cleanEmail,
      username: cleanEmail.split("@")[0],
      fullName: cleanEmail.split("@")[0],
      role: isSuperAdminBypass(cleanEmail) ? "admin" : "user",
      points: 100,
      status: "active",
      createdAt: new Date().toISOString()
    };
    localStorage.setItem("myteleflix_user", JSON.stringify(fallback));
    localStorage.setItem(STORAGE_PRIMARY_EMAIL_KEY, cleanEmail);
    localStorage.setItem("tf_primary_bound_email", cleanEmail);
    return fallback;
  }

  throw new Error("Unable to locate primary authorized account for this device.");
}

export default {
  generateHardwareId,
  getHardwareId,
  getStoredDeviceLock,
  getBoundPrimaryEmail,
  checkDeviceLock,
  bindDeviceLock,
  clearSecondaryDraftSession,
  isSuperAdminBypass
};
