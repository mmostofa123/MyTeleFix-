/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Persistent Storage Layer for User Profile & Security Matrix
 * Enforces IndexedDB + LocalStorage permanence across all browser sessions.
 */

import { isEmailInAdminWhitelist } from "./constants";
import { Movie, SeriesGroupPack } from "./types";

export type { SeriesGroupPack };

export interface UserProfileData {
  uid: string; // Unique User ID (Auto-generated prefix e.g., #TF-315615)
  email: string; // Primary Auth Gmail (Read-Only / Frozen)
  displayName: string; // User Editable Name
  gender: 'Male' | 'Female' | 'Other'; // User Editable
  telegramHandle: string; // User Editable starting with '@'
  telegramId?: string; // Telegram Numeric User ID
  telegramNumericId?: string; // Telegram Numeric User ID alias
  isProfileCompleted?: boolean;
  profileStatus?: string;
  photoURL: string; // Direct Google Auth Profile Image URL
  joinDate: string; // Automatic timestamp saved on first registration (Immutable)
  role: 'USER' | 'ADMIN'; // Strictly managed by backend context
  hwid?: string;
  device_hardware_uuid?: string;
  points?: number;
  lastUpdated?: string;
}

export interface DeviceLockRecord {
  hwid: string;
  device_hardware_uuid?: string;
  primaryEmail: string;
  uid: string;
  lockedAt: string;
}

const DB_NAME = "myteleflix_enterprise_vault";
const DB_VERSION = 1;
const STORE_PROFILES = "user_profiles";
const STORE_DEVICE_LOCKS = "device_locks";
const STORE_CONFIG = "system_config";

const BACKUP_PREFIX_PROFILE = "myteleflix_perm_profile_";
const BACKUP_KEY_DEVICE_LOCK = "myteleflix_perm_device_lock";
const BACKUP_KEY_PRIMARY_EMAIL = "myteleflix_perm_primary_email";
const BACKUP_KEY_LAST_EMAIL = "myteleflix_perm_last_email";
export const BACKUP_PREFIX_ROLE_LOCK = "myteleflix_perm_role_lock_";
export const BACKUP_KEY_ROLE_LOCK = "myteleflix_authority_role_lock";

/**
 * Open or upgrade the IndexedDB instance
 */
export function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.indexedDB) {
      reject(new Error("IndexedDB not available in current environment"));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORE_PROFILES)) {
        const profileStore = db.createObjectStore(STORE_PROFILES, { keyPath: "email" });
        profileStore.createIndex("uid", "uid", { unique: true });
      }

      if (!db.objectStoreNames.contains(STORE_DEVICE_LOCKS)) {
        db.createObjectStore(STORE_DEVICE_LOCKS, { keyPath: "hwid" });
      }

      if (!db.objectStoreNames.contains(STORE_CONFIG)) {
        db.createObjectStore(STORE_CONFIG, { keyPath: "key" });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error("Failed to open IndexedDB"));
    };
  });
}

/**
 * Generates an immutable, uniform User ID with the #TF- prefix (e.g., #TF-315615).
 */
export function generateTeleFlixUid(seed?: string): string {
  if (seed) {
    if (seed.startsWith("#TF-") && seed.length >= 8) {
      return seed;
    }
    // Extract numbers or hash characters from seed
    const digits = seed.replace(/[^0-9]/g, "");
    if (digits.length >= 6) {
      return `#TF-${digits.slice(-6)}`;
    }
    // Hash non-numeric seed to a stable 6-digit number
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = ((hash << 5) - hash) + seed.charCodeAt(i);
      hash |= 0;
    }
    const positiveNum = Math.abs(hash) % 900000 + 100000;
    return `#TF-${positiveNum}`;
  }
  const randomNum = Math.floor(100000 + Math.random() * 900000);
  return `#TF-${randomNum}`;
}

/**
 * Format telegram handle to guarantee starting with '@'
 */
export function formatTelegramHandle(handle?: string): string {
  if (!handle || handle.trim() === "" || handle.trim() === "@") {
    return "@teleflix_vip";
  }
  const cleaned = handle.trim();
  return cleaned.startsWith("@") ? cleaned : `@${cleaned}`;
}

/**
 * Permanently locks and stores the validated role for an email in IndexedDB & LocalStorage
 */
export async function saveRoleLockDB(email: string, role: 'ADMIN' | 'USER', authorityToken?: string): Promise<void> {
  if (!email) return;
  const cleanEmail = email.toLowerCase().trim();
  // Enforce zero-trust validation against the ADMIN_WHITELIST
  const validatedRole: 'ADMIN' | 'USER' = isEmailInAdminWhitelist(cleanEmail) ? 'ADMIN' : 'USER';

  // 1. Write to LocalStorage
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(`${BACKUP_PREFIX_ROLE_LOCK}${cleanEmail}`, validatedRole);
      localStorage.setItem(BACKUP_KEY_ROLE_LOCK, validatedRole);
      if (authorityToken && validatedRole === 'ADMIN') {
        localStorage.setItem("myteleflix_admin_session_token", authorityToken);
      } else if (validatedRole !== 'ADMIN') {
        localStorage.removeItem("myteleflix_admin_session_token");
      }
    }
  } catch (e) {}

  // 2. Commit to IndexedDB STORE_CONFIG
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_CONFIG, "readwrite");
      const store = tx.objectStore(STORE_CONFIG);
      const req = store.put({
        key: `role_lock_${cleanEmail}`,
        role: validatedRole,
        lockedAt: new Date().toISOString(),
        hasAdminAuthority: validatedRole === 'ADMIN'
      });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {}
}

/**
 * Retrieves the permanently locked role for an email from IndexedDB or LocalStorage
 */
export async function getRoleLockDB(email: string): Promise<'ADMIN' | 'USER' | null> {
  if (!email) return null;
  const cleanEmail = email.toLowerCase().trim();

  // Try LocalStorage first for instant synchronous resolution
  try {
    if (typeof window !== "undefined") {
      const cached = localStorage.getItem(`${BACKUP_PREFIX_ROLE_LOCK}${cleanEmail}`) as 'ADMIN' | 'USER' | null;
      if (cached) {
        // Enforce whitelist constraint: non-whitelisted email can NEVER be ADMIN
        return isEmailInAdminWhitelist(cleanEmail) ? 'ADMIN' : 'USER';
      }
    }
  } catch (e) {}

  // Try IndexedDB STORE_CONFIG
  try {
    const db = await openDB();
    const configRecord = await new Promise<any>((resolve) => {
      const tx = db.transaction(STORE_CONFIG, "readonly");
      const store = tx.objectStore(STORE_CONFIG);
      const req = store.get(`role_lock_${cleanEmail}`);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });

    if (configRecord && configRecord.role) {
      return isEmailInAdminWhitelist(cleanEmail) ? 'ADMIN' : 'USER';
    }
  } catch (err) {}

  // Fallback to strict evaluation
  return isEmailInAdminWhitelist(cleanEmail) ? 'ADMIN' : 'USER';
}

/**
 * Check if the email has locked Admin authority
 */
export async function isRoleLockedAdminDB(email: string): Promise<boolean> {
  const role = await getRoleLockDB(email);
  return role === 'ADMIN' && isEmailInAdminWhitelist(email);
}

/**
 * Save user profile permanently in IndexedDB + LocalStorage fallback
 */
export async function saveUserProfileDB(profile: UserProfileData): Promise<UserProfileData> {
  const cleanEmail = profile.email.toLowerCase().trim();
  // STRICT RBAC ROLE LOCK: Role is strictly derived and locked from whitelist
  const lockedRole: 'ADMIN' | 'USER' = isEmailInAdminWhitelist(cleanEmail) ? 'ADMIN' : 'USER';

  const normalizedProfile: UserProfileData = {
    ...profile,
    email: cleanEmail,
    uid: profile.uid?.startsWith("#TF-") ? profile.uid : generateTeleFlixUid(profile.uid || cleanEmail),
    displayName: profile.displayName?.trim() || cleanEmail.split("@")[0] || "TeleFlix Member",
    gender: (profile.gender === "Female" || (profile.gender as any) === "female") ? "Female" : "Male",
    telegramHandle: formatTelegramHandle(profile.telegramHandle),
    photoURL: profile.photoURL || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
    joinDate: profile.joinDate || new Date().toISOString(),
    role: lockedRole,
    lastUpdated: new Date().toISOString()
  };

  // 1. Save to LocalStorage fallback first for instant sync
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(`${BACKUP_PREFIX_PROFILE}${cleanEmail}`, JSON.stringify(normalizedProfile));
      localStorage.setItem(`${BACKUP_PREFIX_ROLE_LOCK}${cleanEmail}`, lockedRole);
      localStorage.setItem(BACKUP_KEY_LAST_EMAIL, cleanEmail);
    }
  } catch (e) {
    console.warn("LocalStorage backup write notice:", e);
  }

  // 2. Commit to IndexedDB
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_PROFILES, "readwrite");
      const store = tx.objectStore(STORE_PROFILES);
      const req = store.put(normalizedProfile);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn("IndexedDB profile commit warning (LocalStorage backup active):", err);
  }

  return normalizedProfile;
}

/**
 * Retrieve user profile from IndexedDB or LocalStorage fallback
 */
export async function getUserProfileDB(emailOrUid: string): Promise<UserProfileData | null> {
  if (!emailOrUid) return null;
  const cleanKey = emailOrUid.toLowerCase().trim();

  // Try IndexedDB first
  try {
    const db = await openDB();
    const profile = await new Promise<UserProfileData | null>((resolve) => {
      const tx = db.transaction(STORE_PROFILES, "readonly");
      const store = tx.objectStore(STORE_PROFILES);

      // Try reading by email key
      const req = store.get(cleanKey);
      req.onsuccess = () => {
        if (req.result) {
          resolve(req.result as UserProfileData);
        } else {
          // If not found by email, try index by uid
          try {
            const index = store.index("uid");
            const indexReq = index.get(emailOrUid);
            indexReq.onsuccess = () => resolve((indexReq.result as UserProfileData) || null);
            indexReq.onerror = () => resolve(null);
          } catch (idxErr) {
            resolve(null);
          }
        }
      };
      req.onerror = () => resolve(null);
    });

    if (profile) return profile;
  } catch (err) {
    // Fall through to LocalStorage
  }

  // Fallback: LocalStorage
  try {
    if (typeof window !== "undefined") {
      const backup = localStorage.getItem(`${BACKUP_PREFIX_PROFILE}${cleanKey}`);
      if (backup) {
        return JSON.parse(backup) as UserProfileData;
      }
      // Scan keys if query was a UID
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(BACKUP_PREFIX_PROFILE)) {
          try {
            const item = JSON.parse(localStorage.getItem(key) || "{}");
            if (item.uid === emailOrUid || item.email === cleanKey) {
              return item as UserProfileData;
            }
          } catch (e) {}
        }
      }
    }
  } catch (e) {}

  return null;
}

/**
 * Permanently bind Hardware ID to primary Google Email in the DB layer
 */
export async function bindDeviceLockDB(
  hwid: string,
  primaryEmail: string,
  uid?: string,
  deviceHardwareUUID?: string
): Promise<DeviceLockRecord> {
  const cleanEmail = primaryEmail.toLowerCase().trim();
  const hardwareUUID = deviceHardwareUUID || (typeof window !== "undefined" ? localStorage.getItem("device_hardware_uuid") || undefined : undefined);
  const record: DeviceLockRecord = {
    hwid,
    device_hardware_uuid: hardwareUUID,
    primaryEmail: cleanEmail,
    uid: uid || generateTeleFlixUid(cleanEmail),
    lockedAt: new Date().toISOString()
  };

  // 1. Commit to LocalStorage Backup
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(`${BACKUP_KEY_DEVICE_LOCK}_${hwid}`, JSON.stringify(record));
      localStorage.setItem(BACKUP_KEY_DEVICE_LOCK, JSON.stringify(record));
      localStorage.setItem(BACKUP_KEY_PRIMARY_EMAIL, cleanEmail);
      if (hardwareUUID) {
        localStorage.setItem(`myteleflix_hw_uuid_lock_${hardwareUUID}`, cleanEmail);
      }
    }
  } catch (e) {}

  // 2. Commit to IndexedDB
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_DEVICE_LOCKS, "readwrite");
      const store = tx.objectStore(STORE_DEVICE_LOCKS);
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn("IndexedDB lock binding warning:", err);
  }

  return record;
}

/**
 * Retrieve permanent device lock from IndexedDB or LocalStorage
 */
export async function getDeviceLockDB(hwid: string): Promise<DeviceLockRecord | null> {
  if (!hwid) return null;

  // Try IndexedDB
  try {
    const db = await openDB();
    const record = await new Promise<DeviceLockRecord | null>((resolve) => {
      const tx = db.transaction(STORE_DEVICE_LOCKS, "readonly");
      const store = tx.objectStore(STORE_DEVICE_LOCKS);
      const req = store.get(hwid);
      req.onsuccess = () => resolve((req.result as DeviceLockRecord) || null);
      req.onerror = () => resolve(null);
    });

    if (record) return record;
  } catch (err) {}

  // Fallback: LocalStorage
  try {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem(`${BACKUP_KEY_DEVICE_LOCK}_${hwid}`) || 
                  localStorage.getItem(BACKUP_KEY_DEVICE_LOCK);
      if (raw) {
        return JSON.parse(raw) as DeviceLockRecord;
      }
    }
  } catch (e) {}

  return null;
}

/**
 * Strict Security Check: Block secondary Google account attempts against the DB layer
 */
export async function checkDeviceLockDB(
  hwid: string,
  incomingEmail?: string,
  deviceHardwareUUID?: string
): Promise<{ isBlocked: boolean; isBound: boolean; primaryEmail?: string; record?: DeviceLockRecord }> {
  const hardwareUUID = deviceHardwareUUID || (typeof window !== "undefined" ? localStorage.getItem("device_hardware_uuid") || undefined : undefined);

  // Check hardware UUID direct lock first
  if (hardwareUUID && typeof window !== "undefined") {
    const hwBoundEmail = localStorage.getItem(`myteleflix_hw_uuid_lock_${hardwareUUID}`);
    if (hwBoundEmail) {
      const cleanIncoming = (incomingEmail || "").toLowerCase().trim();
      const cleanBound = hwBoundEmail.toLowerCase().trim();
      if (cleanIncoming === "mostofa7077a@gmail.com") {
        return { isBlocked: false, isBound: true, primaryEmail: cleanBound };
      }
      if (cleanIncoming && cleanIncoming !== cleanBound) {
        return { isBlocked: true, isBound: true, primaryEmail: cleanBound };
      }
    }
  }

  if (!hwid) return { isBlocked: false, isBound: false };

  const lock = await getDeviceLockDB(hwid);
  if (!lock || !lock.primaryEmail) {
    // Check fallback primary email
    let fallbackEmail = "";
    if (typeof window !== "undefined") {
      fallbackEmail = localStorage.getItem(BACKUP_KEY_PRIMARY_EMAIL) || "";
    }
    if (fallbackEmail) {
      const cleanIncoming = (incomingEmail || "").toLowerCase().trim();
      const cleanBound = fallbackEmail.toLowerCase().trim();
      if (cleanIncoming === "mostofa7077a@gmail.com") {
        return { isBlocked: false, isBound: true, primaryEmail: cleanBound };
      }
      if (cleanIncoming && cleanIncoming !== cleanBound) {
        return { isBlocked: true, isBound: true, primaryEmail: cleanBound };
      }
      return { isBlocked: false, isBound: true, primaryEmail: cleanBound };
    }
    return { isBlocked: false, isBound: false };
  }

  const cleanIncoming = (incomingEmail || "").toLowerCase().trim();
  const cleanBound = lock.primaryEmail.toLowerCase().trim();

  // Master Admin bypass
  if (cleanIncoming === "mostofa7077a@gmail.com") {
    return { isBlocked: false, isBound: true, primaryEmail: cleanBound, record: lock };
  }

  if (cleanIncoming && cleanIncoming !== cleanBound) {
    return {
      isBlocked: true,
      isBound: true,
      primaryEmail: cleanBound,
      record: lock
    };
  }

  return {
    isBlocked: false,
    isBound: true,
    primaryEmail: cleanBound,
    record: lock
  };
}

/**
 * Purge active session tokens without destroying the permanent DB hardware lock
 */
export function purgeSessionRetainLock(): void {
  if (typeof window === "undefined") return;

  try {
    // Save the permanent locks
    const permLock = localStorage.getItem(BACKUP_KEY_DEVICE_LOCK);
    const permEmail = localStorage.getItem(BACKUP_KEY_PRIMARY_EMAIL);
    const permLastEmail = localStorage.getItem(BACKUP_KEY_LAST_EMAIL);
    
    // Collect all profile backups and role lock records
    const preservedItems: Record<string, string> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (
        key.startsWith(BACKUP_PREFIX_PROFILE) ||
        key.startsWith(`${BACKUP_KEY_DEVICE_LOCK}_`) ||
        key.startsWith(BACKUP_PREFIX_ROLE_LOCK) ||
        key === BACKUP_KEY_ROLE_LOCK
      )) {
        preservedItems[key] = localStorage.getItem(key) || "";
      }
    }

    // Clear session & runtime state
    localStorage.removeItem("myteleflix_user");
    sessionStorage.clear();

    // Re-instate permanent DB backups
    if (permLock) localStorage.setItem(BACKUP_KEY_DEVICE_LOCK, permLock);
    if (permEmail) localStorage.setItem(BACKUP_KEY_PRIMARY_EMAIL, permEmail);
    if (permLastEmail) localStorage.setItem(BACKUP_KEY_LAST_EMAIL, permLastEmail);
    for (const [k, v] of Object.entries(preservedItems)) {
      if (v) localStorage.setItem(k, v);
    }
  } catch (e) {
    console.warn("Notice during safe session purge:", e);
  }
}

/**
 * Helper to extract numeric episode index from episode string or number
 */
function parseEpisodeNumber(ep?: string | number): number {
  if (ep === undefined || ep === null) return 0;
  if (typeof ep === "number") return ep;
  const match = String(ep).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

/**
 * Helper to extract numeric season index from season string or number
 */
function parseSeasonNumber(s?: string | number): number {
  if (s === undefined || s === null) return 1;
  if (typeof s === "number") return s;
  const match = String(s).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 1;
}

/**
 * Group multi-episode series by groupTitle (or series_group_title).
 * Returns a dictionary mapping groupTitle -> SeriesGroupPack.
 */
export function groupSeriesByGroupTitle(mediaList: Movie[]): Record<string, SeriesGroupPack> {
  const groups: Record<string, SeriesGroupPack> = {};

  if (!Array.isArray(mediaList)) return groups;

  for (const item of mediaList) {
    // Resolve group title from structured fields or fallback
    const rawGroup = item.groupTitle || item.series_group_title;
    let groupKey = (rawGroup || "").trim();

    // If no explicit groupTitle, but item is marked as series and has season/episode or title pattern
    if (!groupKey && item.contentType === 'series') {
      const matchedBase = item.title.replace(/(\s*[-•]\s*)?(Season|\bS\d+|\bEp|\bEpisode).*$/i, '').trim();
      if (matchedBase && matchedBase !== item.title) {
        groupKey = matchedBase;
      }
    }

    if (!groupKey) continue;

    if (!groups[groupKey]) {
      groups[groupKey] = {
        groupTitle: groupKey,
        masterItem: item,
        episodes: [],
        totalEpisodesCount: 0,
        seasons: [],
        latestEpisode: undefined
      };
    }

    groups[groupKey].episodes.push(item);
  }

  // Finalize each group pack
  for (const groupKey of Object.keys(groups)) {
    const pack = groups[groupKey];
    
    // Sort episodes: First by season ascending, then by episode ascending
    pack.episodes.sort((a, b) => {
      const seasonA = parseSeasonNumber(a.season ?? a.season_number);
      const seasonB = parseSeasonNumber(b.season ?? b.season_number);
      if (seasonA !== seasonB) return seasonA - seasonB;

      const epA = parseEpisodeNumber(a.episode ?? a.episode_number);
      const epB = parseEpisodeNumber(b.episode ?? b.episode_number);
      return epA - epB;
    });

    // Extract unique seasons
    const seasonSet = new Set<string>();
    for (const ep of pack.episodes) {
      const s = (ep.season ?? ep.season_number);
      if (s) {
        seasonSet.add(typeof s === 'number' ? `Season ${s}` : String(s).trim());
      }
    }
    pack.seasons = Array.from(seasonSet);
    pack.totalEpisodesCount = pack.episodes.length;

    // Pick best master item (prefers pack master or item with thumbnail and highest rating)
    const master = pack.episodes.find(e => e.thumbnailUrl && !e.thumbnailUrl.includes('placeholder')) || pack.episodes[0];
    if (master) {
      pack.masterItem = master;
    }

    // Latest episode is the last episode in sorted array
    const lastEp = pack.episodes[pack.episodes.length - 1];
    pack.latestEpisode = lastEp?.episode ?? lastEp?.episode_number ?? lastEp?.totalEpisodes ?? `Ep ${pack.episodes.length}`;
  }

  return groups;
}

/**
 * Database query helper function to group multi-episode series by groupTitle
 * when requested by frontend group cards. Optionally filters by a target group title.
 */
export function getSeriesGroupPacks(mediaList: Movie[], targetGroupTitle?: string): SeriesGroupPack[] {
  const groupsDict = groupSeriesByGroupTitle(mediaList);
  const packs = Object.values(groupsDict);

  if (targetGroupTitle && targetGroupTitle.trim()) {
    const cleanTarget = targetGroupTitle.toLowerCase().trim();
    return packs.filter(p => p.groupTitle.toLowerCase().trim() === cleanTarget);
  }

  return packs;
}

/**
 * Query helper to retrieve all episodes belonging to a specific group title
 */
export function queryEpisodesByGroupTitle(mediaList: Movie[], groupTitle: string): Movie[] {
  if (!groupTitle || !Array.isArray(mediaList)) return [];
  const cleanTarget = groupTitle.toLowerCase().trim();
  
  return mediaList.filter(item => {
    const rawGroup = item.groupTitle || item.series_group_title;
    if (rawGroup && rawGroup.toLowerCase().trim() === cleanTarget) {
      return true;
    }
    const matchedBase = item.title.replace(/(\s*[-•]\s*)?(Season|\bS\d+|\bEp|\bEpisode).*$/i, '').trim();
    return matchedBase.toLowerCase() === cleanTarget;
  }).sort((a, b) => {
    const seasonA = parseSeasonNumber(a.season ?? a.season_number);
    const seasonB = parseSeasonNumber(b.season ?? b.season_number);
    if (seasonA !== seasonB) return seasonA - seasonB;
    return parseEpisodeNumber(a.episode ?? a.episode_number) - parseEpisodeNumber(b.episode ?? b.episode_number);
  });
}
