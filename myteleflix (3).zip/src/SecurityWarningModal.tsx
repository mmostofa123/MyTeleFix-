/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Lock, 
  Mail, 
  LogIn,
  X,
  Loader2
} from "lucide-react";
import { clearSecondaryDraftSession, restorePrimaryAccount, getBoundPrimaryEmail } from "./SecurityManager";

export interface SecurityWarningModalProps {
  isOpen: boolean;
  primaryEmail?: string;
  attemptedEmail?: string;
  hwid?: string;
  message?: string;
  onClose?: () => void;
  onSwitchToPrimary?: (primaryEmail: string) => Promise<void> | void;
}

export default function SecurityWarningModal({
  isOpen,
  primaryEmail,
  attemptedEmail,
  hwid,
  message,
  onClose,
  onSwitchToPrimary
}: SecurityWarningModalProps) {
  const [isRestoring, setIsRestoring] = useState(false);

  if (!isOpen) return null;

  const resolvedPrimaryEmail = primaryEmail || getBoundPrimaryEmail() || "mostofa7077a@gmail.com";

  const handleDismiss = () => {
    clearSecondaryDraftSession();
    try {
      localStorage.removeItem("myteleflix_user");
      localStorage.removeItem("myteleflix_auth_token");
      localStorage.removeItem("myteleflix_current_session");
    } catch (e) {}
    if (onClose) {
      onClose();
    }
  };

  const handleSwitch = async () => {
    if (isRestoring) return;
    setIsRestoring(true);
    clearSecondaryDraftSession();
    try {
      localStorage.removeItem("myteleflix_user");
      localStorage.removeItem("myteleflix_auth_token");
      localStorage.removeItem("myteleflix_current_session");
    } catch (e) {}

    try {
      if (onSwitchToPrimary && resolvedPrimaryEmail) {
        await onSwitchToPrimary(resolvedPrimaryEmail);
      } else if (resolvedPrimaryEmail) {
        const u = await restorePrimaryAccount(resolvedPrimaryEmail);
        if (u) {
          window.location.reload();
        }
      } else if (onClose) {
        onClose();
      }
    } catch (e) {
      console.warn("handleSwitch notice:", e);
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <AnimatePresence>
      <div 
        id="security-warning-overlay"
        className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm select-none overflow-hidden"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="security-alert-title"
      >
        <motion.div
          id="security-warning-card"
          initial={{ opacity: 0, scale: 0.96, y: 8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 8 }}
          transition={{ duration: 0.16, ease: "easeOut" }}
          className="relative w-full max-w-sm bg-[#0B0E14] border border-red-900/40 rounded-2xl p-4 text-center shadow-2xl overflow-hidden"
        >
          {/* Subtle Top Close Button */}
          {onClose && (
            <button
              id="security-warning-dismiss-btn"
              onClick={handleDismiss}
              className="absolute top-3 right-3 p-1 rounded-lg text-slate-500 hover:text-white hover:bg-white/5 transition active:scale-95 cursor-pointer z-10"
              aria-label="Dismiss Alert"
            >
              <X size={15} />
            </button>
          )}

          {/* 1. Top Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-950/70 border border-red-800/60 text-red-400 text-[10.5px] font-mono font-bold uppercase tracking-wider mb-2.5">
            <span>⛔ SECURITY VIOLATION DETECTED</span>
          </div>

          {/* 2. Streamlined Warning Content */}
          <h2 
            id="security-alert-title"
            className="text-base sm:text-[17px] font-bold text-white tracking-tight leading-snug mb-1.5"
          >
            এক ডিভাইসে একাধিক অ্যাকাউন্ট নিষিদ্ধ!
          </h2>
          
          <p className="text-xs text-slate-300 font-normal leading-relaxed mb-3">
            একটি ডিভাইসে একাধিক অ্যাকাউন্ট তৈরি বা প্রবেশ সম্পূর্ণ বেআইনি। এই ডিভাইসে আপনার অনুমোদিত প্রথম অ্যাকাউন্টটি নিচে দেওয়া হলো:
          </p>

          {/* 3. Primary Authorized Account Card */}
          <div className="bg-[#121620] border border-[#1E2638] rounded-xl p-3 mb-3 text-left space-y-1.5">
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-400 uppercase tracking-wider font-semibold">অনুমোদিত মূল অ্যাকাউন্ট</span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9px] font-bold flex items-center gap-1">
                <Lock size={9} /> LOCKED
              </span>
            </div>

            <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-[#080B10] border border-[#1C2333]">
              <Mail size={14} className="text-red-400 shrink-0" />
              <span className="text-white font-mono font-bold text-xs sm:text-[13px] tracking-tight truncate select-text">
                {resolvedPrimaryEmail}
              </span>
            </div>

            {attemptedEmail && attemptedEmail !== resolvedPrimaryEmail && (
              <div className="flex items-center justify-between text-[10.5px] font-mono text-slate-400 pt-1 border-t border-[#1C2333]">
                <span>ব্লকড প্রচেষ্টা:</span>
                <span className="text-red-400/90 line-through truncate max-w-[170px]">{attemptedEmail}</span>
              </div>
            )}
          </div>

          {/* 4. Ultimate Hardline Footnote (Critical) */}
          <div className="bg-red-950/40 border border-red-800/50 rounded-xl p-2.5 mb-3.5 text-left">
            <p className="text-[11px] text-red-300 font-medium leading-relaxed">
              ⚠️ আপনি ইতিমধ্যে আমাদের সিকিউরিটি নজরদারিতে পড়েছেন! পরবর্তীতে সামান্যতম চিটিং বা নিয়ম লঙ্ঘনের চেষ্টা পাওয়া গেলে কোনো সুযোগ না দিয়ে ডিভাইস ও মূল অ্যাকাউন্ট পার্মানেন্ট ব্যান করা হবে। সৎভাবে কাজ করুন।
            </p>
          </div>

          {/* 5. Single CTA Button & Zero Confusion */}
          <button
            type="button"
            id="switch-to-primary-account-btn"
            onClick={handleSwitch}
            disabled={isRestoring}
            className="w-full py-2.5 px-4 rounded-xl bg-red-700 hover:bg-red-800 active:bg-red-900 disabled:opacity-60 text-white font-medium text-xs sm:text-sm tracking-wide transition duration-150 cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-red-950/40 active:scale-[0.99]"
          >
            {isRestoring ? (
              <>
                <Loader2 size={15} className="animate-spin shrink-0" />
                <span>মূল অ্যাকাউন্টে লগইন হচ্ছে...</span>
              </>
            ) : (
              <>
                <LogIn size={15} className="shrink-0" />
                <span>মূল অ্যাকাউন্টে ফিরে যান</span>
              </>
            )}
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
