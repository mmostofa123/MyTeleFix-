/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User } from "../types";
import { getDeviceFingerprint, getCachedDeviceFingerprint, getGuestDeviceId } from "../utils/fingerprint";
import { 
  auth, 
  googleProvider, 
  saveUserToFirestore, 
  getUserFromFirestore, 
  isUserInAdminWhitelist, 
  ensureSuperAdminExists,
  DEFAULT_SUPER_ADMIN_EMAILS,
  MASTER_ADMIN_EMAIL
} from "./firebase";
import { signInWithPopup, signOut as firebaseSignOut } from "firebase/auth";
import { 
  generateHardwareId, 
  generateCrossBrowserHardwareId,
  getCrossBrowserHardwareTraits,
  getHardwareId, 
  checkDeviceLock, 
  bindDeviceLock, 
  restorePrimaryAccount,
  clearSecondaryDraftSession, 
  isSuperAdminBypass 
} from "../SecurityManager";
import { generateDeviceHardwareUUID, bindHardwareDevice } from "../SecurityGuard";
import { logSecurityNotice } from "../NoticeBox";

export const POLICY_VIOLATION_MESSAGE = "আমাদের প্ল্যাটফর্মের সুরক্ষা নীতি অনুযায়ী এক ডিভাইসে কেবল একটি অ্যাকাউন্ট অনুমোদিত। আপনি এই ডিভাইসে নতুন বা একাধিক অ্যাকাউন্ট তৈরি করতে পারবেন না।";

import { getDiceBearAvatar, getHumanAvatar, getRandomHumanAvatar, BOYS_AVATARS_100, GIRLS_AVATARS_100 } from "../utils/avatar";

// Curated high-definition Male (Boy) Avatars (100+ variations)
export const MALE_AVATARS: string[] = BOYS_AVATARS_100;

// Curated high-definition Female (Girl) Avatars (100+ variations)
export const FEMALE_AVATARS: string[] = GIRLS_AVATARS_100;

/**
 * Returns a deterministic or randomized real human portrait based on gender (100+ variations).
 * Authentic human portraits - zero machines or robots.
 */
export function getRandomAvatar(gender: 'male' | 'female', seed?: number | string): string {
  if (seed !== undefined) {
    return getHumanAvatar(gender, seed);
  }
  return getRandomHumanAvatar(gender);
}

/**
 * Retrieve client public IP address from the server API or external lookup.
 */
export async function getClientIp(): Promise<string> {
  try {
    const res = await fetch("/api/auth/client-ip", { signal: AbortSignal.timeout(3000) });
    if (res.ok) {
      const data = await res.json();
      if (data.ip) return data.ip;
    }
  } catch {
    // fallback
  }

  try {
    const fallbackRes = await fetch("https://api.ipify.org?format=json", { signal: AbortSignal.timeout(3000) });
    if (fallbackRes.ok) {
      const data = await fallbackRes.json();
      if (data.ip) return data.ip;
    }
  } catch {
    // offline or sandboxed
  }

  return "127.0.0.1";
}

export interface DevicePolicyCheckResult {
  allowed: boolean;
  blocked?: boolean;
  error?: string;
  existingAccount?: {
    id?: string;
    email?: string;
    username?: string;
  };
  deviceFingerprint?: string;
  ipAddress?: string;
}

/**
 * STRICT 1-DEVICE 1-ACCOUNT ANTI-FRAUD SECURITY CHECK:
 * Validates whether this device fingerprint or registered IP is already bound to another account.
 * Super admins bypass this check to facilitate administration.
 */
export async function checkDevicePolicy(params: {
  deviceFingerprint: string;
  clientIp: string;
  userId?: string;
  email?: string;
}): Promise<DevicePolicyCheckResult> {
  const cleanEmail = (params.email || '').toLowerCase().trim();
  if (cleanEmail === MASTER_ADMIN_EMAIL.toLowerCase() || DEFAULT_SUPER_ADMIN_EMAILS.includes(cleanEmail)) {
    return { allowed: true };
  }

  try {
    const crossHwid = await generateCrossBrowserHardwareId();
    const hwid = await generateHardwareId();
    const traits = getCrossBrowserHardwareTraits();

    const res = await fetch("/api/auth/check-device", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_fingerprint: params.deviceFingerprint,
        hwid,
        cross_browser_hwid: crossHwid,
        gpu_renderer: traits.gpu_renderer,
        gpu_chipset: traits.gpu_chipset,
        screen_resolution: traits.screen_resolution,
        physical_screen: traits.physical_screen,
        hardware_concurrency: traits.hardware_concurrency,
        cpu_cores: traits.cpu_cores,
        timezone: traits.timezone,
        platform: traits.platform,
        platform_family: traits.platform_family,
        ip_address: params.clientIp,
        userId: params.userId,
        email: params.email
      })
    });

    if (res.status === 403 || !res.ok) {
      const data = await res.json();
      if (data.blocked || res.status === 403) {
        return {
          allowed: false,
          blocked: true,
          error: data.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          existingAccount: data.existingAccount || (data.primaryEmail ? { email: data.primaryEmail } : undefined),
          deviceFingerprint: params.deviceFingerprint,
          ipAddress: params.clientIp
        };
      }
    } else {
      const data = await res.json();
      if (data.blocked) {
        return {
          allowed: false,
          blocked: true,
          error: data.error || "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          existingAccount: data.existingAccount || (data.primaryEmail ? { email: data.primaryEmail } : undefined),
          deviceFingerprint: params.deviceFingerprint,
          ipAddress: params.clientIp
        };
      }
    }
  } catch (err) {}

  // Local storage check for secondary accounts on same device (Persistent even across logouts)
  try {
    const boundPrimaryEmail = 
      localStorage.getItem("tf_primary_bound_email") || 
      (localStorage.getItem("tf_hardware_device_lock") ? JSON.parse(localStorage.getItem("tf_hardware_device_lock") || "{}")?.primary_email : null) ||
      (localStorage.getItem("myteleflix_user") ? JSON.parse(localStorage.getItem("myteleflix_user") || "{}")?.email : null);

    if (boundPrimaryEmail && cleanEmail) {
      const boundClean = boundPrimaryEmail.toLowerCase().trim();
      if (boundClean && boundClean !== cleanEmail) {
        return {
          allowed: false,
          blocked: true,
          error: "আপনি অবৈধভাবে চেষ্টা করতেছেন আমাদের প্ল্যাটফর্মে শুধু একটি অ্যাকাউন্ট একটি ডিভাইসের জন্য গ্রহণযোগ্য",
          existingAccount: {
            email: boundClean,
            username: boundClean.split("@")[0]
          },
          deviceFingerprint: params.deviceFingerprint,
          ipAddress: params.clientIp
        };
      }
    }
  } catch (e) {}

  return { allowed: true };
}

/**
 * 1-Click Seamless Google Sign-In with strict anti-fraud policy enforcement.
 */
export async function signInWithGoogleSeamless(params?: {
  email?: string;
  fullName?: string;
  photoUrl?: string;
  googleId?: string;
  usePopup?: boolean;
}): Promise<{ user: User; needsOnboarding: boolean }> {
  // 1. Generate Hardware Fingerprint & Public IP
  const fp = await getDeviceFingerprint();
  const clientIp = await getClientIp();
  const gId = getGuestDeviceId(fp);

  let targetEmail = params?.email?.toLowerCase().trim();
  let targetName = params?.fullName;
  let targetPhoto = params?.photoUrl;
  let targetUid = params?.googleId;

  // 2. Perform Native Google Popup if requested or if no direct credentials provided
  if (params?.usePopup || !targetEmail) {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      targetEmail = (fbUser.email || "").toLowerCase().trim();
      targetName = fbUser.displayName || targetEmail.split("@")[0] || "Google Member";
      targetPhoto = fbUser.photoURL || undefined;
      targetUid = fbUser.uid;
    } catch (popupErr: any) {
      // If popup fails or is blocked by iframe, fallback to provided target or test credentials
      if (!targetEmail) {
        throw popupErr;
      }
    }
  }

  if (!targetEmail) {
    throw new Error("Google authentication failed. No email returned.");
  }

  const calculatedUid = targetUid || `g-${targetEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;

  // Hardware ID Generation & Verification
  const hwid = await generateHardwareId();

  if (targetEmail && !isSuperAdminBypass(targetEmail)) {
    const lockCheck = await checkDeviceLock(hwid, targetEmail);
    if (lockCheck.isBlocked) {
      if (typeof window !== "undefined") {
        await firebaseSignOut(auth).catch(() => {});
        try {
          localStorage.removeItem("myteleflix_user");
          localStorage.removeItem("myteleflix_auth_token");
          localStorage.removeItem("myteleflix_current_session");
        } catch (e) {}
      }
      clearSecondaryDraftSession();
      logSecurityNotice({
        primaryEmail: lockCheck.primaryEmail,
        attemptedEmail: targetEmail,
        hwid
      });
      const error: any = new Error(POLICY_VIOLATION_MESSAGE);
      error.blocked = true;
      error.existingAccount = lockCheck.primaryEmail;
      error.primaryEmail = lockCheck.primaryEmail;
      error.deviceFingerprint = fp;
      error.hwid = hwid;
      error.ipAddress = clientIp;
      throw error;
    }
  }

  // 3. Strict 1-Device 1-Account Anti-Fraud Policy Check
  const policyCheck = await checkDevicePolicy({
    deviceFingerprint: fp,
    clientIp,
    userId: calculatedUid,
    email: targetEmail
  });

  if (!policyCheck.allowed) {
    if (typeof window !== "undefined") {
      await firebaseSignOut(auth).catch(() => {});
      try {
        localStorage.removeItem("myteleflix_user");
        localStorage.removeItem("myteleflix_auth_token");
        localStorage.removeItem("myteleflix_current_session");
      } catch (e) {}
    }
    clearSecondaryDraftSession();
    const error: any = new Error(policyCheck.error || POLICY_VIOLATION_MESSAGE);
    error.blocked = true;
    error.existingAccount = policyCheck.existingAccount;
    error.primaryEmail = typeof policyCheck.existingAccount === 'object' ? policyCheck.existingAccount?.email : policyCheck.existingAccount;
    error.deviceFingerprint = fp;
    error.ipAddress = clientIp;
    throw error;
  }

  // 4. Determine Roles and Fetch Existing Firestore Record
  const isSuper = targetEmail === 'mostofa7077a@gmail.com' || DEFAULT_SUPER_ADMIN_EMAILS.includes(targetEmail);
  const isWhitelisted = await isUserInAdminWhitelist(targetEmail, calculatedUid);
  const assignedRole: 'super_admin' | 'admin' | 'user' = isSuper ? 'super_admin' : (isWhitelisted ? 'admin' : 'user');

  if (isSuper) {
    await ensureSuperAdminExists(targetEmail, targetName || undefined);
  }

  const existingDoc = await getUserFromFirestore(calculatedUid);

  // 5. Construct User Model
  const resolvedDisplayName = targetName || existingDoc?.displayName || existingDoc?.fullName || targetEmail.split("@")[0];
  const resolvedPhoto = existingDoc?.photoURL || existingDoc?.photoUrl || targetPhoto || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80";

  const loggedUser: User = {
    id: calculatedUid,
    googleId: calculatedUid,
    telegramId: existingDoc?.telegramId || "",
    username: targetEmail.split("@")[0],
    fullName: resolvedDisplayName,
    displayName: resolvedDisplayName,
    email: targetEmail,
    gender: existingDoc?.gender,
    photoUrl: resolvedPhoto,
    photoURL: resolvedPhoto,
    points: existingDoc?.points ?? 100,
    createdAt: existingDoc?.createdAt || new Date().toISOString(),
    last_active_at: new Date().toISOString(),
    device_fingerprint: fp,
    guest_device_id: gId,
    registered_ip: clientIp,
    profileInitialized: existingDoc?.profileInitialized || Boolean(existingDoc?.gender),
    isPremium: existingDoc?.isPremium || false,
    role: assignedRole,
    authProvider: 'google',
    status: 'active'
  };

  // 6. Save to Firestore
  await saveUserToFirestore(loggedUser);

  // 6.5. Bind hardware lock to primary email across browsers
  const hardwareUUID = await bindHardwareDevice(targetEmail);
  const crossHwid = await generateCrossBrowserHardwareId();
  const traits = getCrossBrowserHardwareTraits();
  loggedUser.device_hardware_uuid = hardwareUUID;
  await bindDeviceLock(targetEmail, calculatedUid, hwid);

  // 7. Register on Server backend
  try {
    const serverAuthRes = await fetch("/api/auth/google", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: loggedUser.email,
        fullName: loggedUser.fullName,
        photoUrl: loggedUser.photoUrl,
        googleId: loggedUser.googleId,
        device_fingerprint: fp,
        hwid,
        cross_browser_hwid: crossHwid,
        hardware_uuid: hardwareUUID,
        gpu_renderer: traits.gpu_renderer,
        gpu_chipset: traits.gpu_chipset,
        screen_resolution: traits.screen_resolution,
        physical_screen: traits.physical_screen,
        hardware_concurrency: traits.hardware_concurrency,
        cpu_cores: traits.cpu_cores,
        timezone: traits.timezone,
        platform: traits.platform,
        platform_family: traits.platform_family,
        ip_address: clientIp,
        guest_device_id: gId
      })
    });

    if (serverAuthRes.status === 403) {
      const errData = await serverAuthRes.json();
      const err: any = new Error(errData.error || POLICY_VIOLATION_MESSAGE);
      err.blocked = true;
      err.primaryEmail = errData.primaryEmail;
      err.existingAccount = errData.existingAccount;
      throw err;
    }

    if (serverAuthRes.ok) {
      const serverData = await serverAuthRes.json();
      if (serverData.user) {
        loggedUser.points = serverData.user.wallet?.points ?? serverData.user.points ?? loggedUser.points;
        if (serverData.user.taskStats) loggedUser.taskStats = serverData.user.taskStats;
      }
    }
  } catch (err: any) {
    if (err.blocked) throw err;
  }

  // 8. Persist to localStorage
  localStorage.setItem("myteleflix_user", JSON.stringify(loggedUser));

  const needsOnboarding = !loggedUser.profileInitialized || !loggedUser.gender;

  return {
    user: loggedUser,
    needsOnboarding
  };
}

/**
 * Saves gender selection and initializes avatar & profile for new users.
 */
export async function completeWelcomeOnboarding(
  user: User, 
  gender: 'male' | 'female',
  details?: {
    fullName?: string;
    displayName?: string;
    telegramUsername?: string;
  }
): Promise<User> {
  const dynamicAvatar = getRandomAvatar(gender);
  const cleanName = details?.fullName?.trim() || details?.displayName?.trim() || user.fullName || user.displayName || "TeleFlix Member";
  const rawTg = details?.telegramUsername?.trim();
  const cleanTelegram = rawTg ? (rawTg.startsWith('@') ? rawTg : `@${rawTg}`) : user.telegramUsername;
  const cleanUsername = cleanTelegram ? cleanTelegram.replace(/^@/, '') : user.username;
  
  const updatedUser: User = {
    ...user,
    fullName: cleanName,
    displayName: cleanName,
    gender: gender === 'female' ? 'Female' : 'Male',
    telegramUsername: cleanTelegram,
    username: cleanUsername || user.username,
    photoUrl: dynamicAvatar,
    photoURL: dynamicAvatar,
    isOnboarded: true,
    profileInitialized: true,
    isProfileCompleted: true,
    last_active_at: new Date().toISOString()
  };

  // Update in Firestore
  try {
    await saveUserToFirestore(updatedUser);
  } catch (err) {
    console.warn("Notice saving onboarding to Firestore:", err);
  }

  // Update on Server backend
  fetch("/api/auth/update-profile", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: updatedUser.id,
      displayName: cleanName,
      fullName: cleanName,
      gender: updatedUser.gender,
      telegramUsername: cleanTelegram,
      photoUrl: dynamicAvatar,
      isOnboarded: true,
      profileInitialized: true,
      isProfileCompleted: true
    })
  }).catch(() => {});

  // Update in localStorage
  try {
    localStorage.setItem("myteleflix_user", JSON.stringify(updatedUser));
    localStorage.setItem("myteleflix_isProfileCompleted", "true");
    localStorage.setItem("myteleflix_onboarding_completed", "true");
    if (user.id) {
      localStorage.setItem(`myteleflix_profile_completed_${user.id}`, "true");
      localStorage.setItem(`myteleflix_onboarding_${user.id}`, "true");
    }
  } catch (e) {
    console.warn("Storage write error during onboarding:", e);
  }

  return updatedUser;
}

/**
 * Activates mandatory user profile verification data (Telegram ID, Telegram Username, Gender, Display Name)
 */
export async function activateUserProfile(
  user: User, 
  data: { 
    telegramId: string; 
    telegramUsername: string; 
    gender: 'male' | 'female' | 'Male' | 'Female' | 'Other' | 'other'; 
    displayName: string; 
  }
): Promise<User> {
  const normGender = data.gender.toLowerCase() === 'female' ? 'female' : 'male';
  const dynamicAvatar = getRandomAvatar(normGender);
  const cleanTelegram = data.telegramUsername.startsWith('@') ? data.telegramUsername : `@${data.telegramUsername}`;
  const cleanUsername = cleanTelegram.replace(/^@/, '');

  const activatedUser: User = {
    ...user,
    telegramId: data.telegramId,
    telegramUsername: cleanTelegram,
    username: cleanUsername || user.username || data.telegramId,
    displayName: data.displayName,
    fullName: data.displayName,
    gender: data.gender.toLowerCase() === 'female' ? 'Female' : (data.gender.toLowerCase() === 'other' ? 'Other' : 'Male'),
    photoUrl: dynamicAvatar,
    photoURL: dynamicAvatar,
    isOnboarded: true,
    profileInitialized: true,
    isProfileCompleted: true,
    profileStatus: 'completed',
    last_active_at: new Date().toISOString()
  };

  try {
    await saveUserToFirestore(activatedUser);
  } catch (err) {
    console.warn("Notice saving activated profile to Firestore:", err);
  }

  fetch("/api/auth/update-profile", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      userId: activatedUser.id,
      telegramId: activatedUser.telegramId,
      telegramUsername: activatedUser.telegramUsername,
      displayName: activatedUser.displayName,
      fullName: activatedUser.fullName,
      gender: activatedUser.gender,
      photoUrl: activatedUser.photoUrl,
      isOnboarded: true,
      profileInitialized: true,
      isProfileCompleted: true,
      profileStatus: 'completed'
    })
  }).catch(() => {});

  try {
    localStorage.setItem("myteleflix_user", JSON.stringify(activatedUser));
    localStorage.setItem("myteleflix_isProfileCompleted", "true");
    localStorage.setItem("myteleflix_onboarding_completed", "true");
    if (user.id) {
      localStorage.setItem(`myteleflix_profile_completed_${user.id}`, "true");
      localStorage.setItem(`myteleflix_onboarding_${user.id}`, "true");
    }
  } catch (e) {
    console.warn("Storage write error during activation:", e);
  }

  return activatedUser;
}

/**
 * Clears active session and signs out safely.
 */
export async function logoutUser(): Promise<void> {
  try {
    await firebaseSignOut(auth);
  } catch (e) {
    console.warn("Firebase sign out warning:", e);
  }
  try {
    localStorage.removeItem("myteleflix_user");
    localStorage.removeItem("myteleflix_auth_token");
    sessionStorage.clear();
  } catch (e) {
    console.warn("Storage clear error:", e);
  }
}
