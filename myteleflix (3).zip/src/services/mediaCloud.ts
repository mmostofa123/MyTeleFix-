/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { app } from "./firebase";

// Singleton Firebase Storage Instance
export const storage = getStorage(app);

export interface UploadProgressCallback {
  (progress: {
    percent: number;
    bytesTransferred: number;
    totalBytes: number;
    speedMB: string;
    status: 'uploading' | 'optimizing' | 'completed' | 'error';
    downloadUrl?: string;
  }): void;
}

/**
 * Uploads media files (posters, banners, video clips) directly to Firebase Cloud Storage.
 * Generates an immutable, public-readable Cloud CDN URL for instant streaming.
 */
export async function uploadMediaToCloudStorage(
  file: File,
  folder: 'posters' | 'videos' | 'banners' | 'audio' = 'posters',
  onProgress?: UploadProgressCallback
): Promise<string> {
  // Generate safe cloud file path with timestamp & unique key
  const safeBase = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 50);
  const uniqueKey = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const fullPath = `media/${folder}/${uniqueKey}_${safeBase}`;
  const storageRef = ref(storage, fullPath);

  return new Promise<string>((resolve, reject) => {
    let lastTime = Date.now();
    let lastBytes = 0;

    const metadata = {
      contentType: file.type || 'application/octet-stream',
      cacheControl: 'public, max-age=31536000, immutable',
    };

    const uploadTask = uploadBytesResumable(storageRef, file, metadata);

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const now = Date.now();
        const timeDiff = (now - lastTime) / 1000;
        let speedMB = "0.0";
        if (timeDiff > 0.4) {
          const bytesDiff = snapshot.bytesTransferred - lastBytes;
          speedMB = ((bytesDiff / (1024 * 1024)) / timeDiff).toFixed(2);
          lastTime = now;
          lastBytes = snapshot.bytesTransferred;
        }

        const percent = Math.min(
          100,
          Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100)
        );

        onProgress?.({
          percent,
          bytesTransferred: snapshot.bytesTransferred,
          totalBytes: snapshot.totalBytes,
          speedMB,
          status: percent === 100 ? 'optimizing' : 'uploading',
        });
      },
      (error) => {
        console.warn("[Cloud Storage Upload Error]", error);
        onProgress?.({
          percent: 0,
          bytesTransferred: 0,
          totalBytes: file.size,
          speedMB: "0.0",
          status: 'error',
        });
        reject(error);
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          onProgress?.({
            percent: 100,
            bytesTransferred: file.size,
            totalBytes: file.size,
            speedMB: "Done",
            status: 'completed',
            downloadUrl,
          });
          resolve(downloadUrl);
        } catch (urlErr) {
          reject(urlErr);
        }
      }
    );
  });
}

/**
 * Validates whether a URL is a direct high-speed Cloud CDN endpoint.
 */
export function isCloudCdnUrl(url: string): boolean {
  if (!url) return false;
  return (
    url.includes("firebasestorage.googleapis.com") ||
    url.includes("cloudinary.com") ||
    url.includes("cloudflare.com") ||
    url.includes("r2.cloudflarestorage.com") ||
    url.includes("bunnycdn.com") ||
    url.includes("fastly.net") ||
    url.includes("akamaihd.net") ||
    url.startsWith("https://")
  );
}
