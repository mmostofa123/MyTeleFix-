/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SystemSettings } from "../types";
import { authenticatedFetch } from "./authBearer";
import { getDeviceFingerprint, getHardwareMetrics } from "../utils/fingerprint";

export interface AdNetworkConfig {
  networkType: 'adsterra' | 'monetag' | 'adsense' | 'direct' | 'adsgram';
  enabled: boolean;
  adsterraDirectLink: string;
  adsterraScriptTag: string;
  monetagDirectTag: string;
  monetagScriptCode: string;
  adsenseClient: string;
  adsenseSlot: string;
  directImpressionUrl: string;
  adRewardPoints: number;
  adCooldownSeconds: number;
  videoPreRollAd: boolean;
  videoMidRollAd: boolean;
}

// Fallback high-converting default direct links if not customized by Admin
export const DEFAULT_AD_CONFIG: AdNetworkConfig = {
  networkType: 'monetag',
  enabled: true,
  adsterraDirectLink: "https://www.profitablecpmrate.com/direct-sample-adsterra",
  adsterraScriptTag: "//pl23456789.profitablecpmrate.com/sample.js",
  monetagDirectTag: "https://alwingulla.com/4/sample-monetag-direct",
  monetagScriptCode: "https://alwingulla.com/tag.min.js",
  adsenseClient: "ca-pub-1234567890123456",
  adsenseSlot: "9876543210",
  directImpressionUrl: "https://t.me/myteleflix_bot",
  adRewardPoints: 150,
  adCooldownSeconds: 30,
  videoPreRollAd: true,
  videoMidRollAd: false,
};

/**
 * Parses dynamic settings from Admin Controller Room into normalized Ad Network Config.
 */
export function getAdNetworkConfig(settings?: SystemSettings): AdNetworkConfig {
  const s = (settings || {}) as any;
  return {
    networkType: s.adNetworkType || 'monetag',
    enabled: s.adNetworkEnabled ?? true,
    adsterraDirectLink: s.adsterraDirectLink || DEFAULT_AD_CONFIG.adsterraDirectLink,
    adsterraScriptTag: s.adsterraScriptTag || DEFAULT_AD_CONFIG.adsterraScriptTag,
    monetagDirectTag: s.monetagDirectTag || s.monetagKey || DEFAULT_AD_CONFIG.monetagDirectTag,
    monetagScriptCode: s.monetagScriptCode || DEFAULT_AD_CONFIG.monetagScriptCode,
    adsenseClient: s.adsenseClient || DEFAULT_AD_CONFIG.adsenseClient,
    adsenseSlot: s.adsenseSlot || DEFAULT_AD_CONFIG.adsenseSlot,
    directImpressionUrl: s.directImpressionUrl || DEFAULT_AD_CONFIG.directImpressionUrl,
    adRewardPoints: Number(s.adRewardPoints) || 150,
    adCooldownSeconds: Number(s.adCooldownSeconds) || 30,
    videoPreRollAd: s.videoPreRollAd ?? true,
    videoMidRollAd: s.videoMidRollAd ?? false,
  };
}

/**
 * Injects external real ad network script dynamically into DOM if not already present.
 */
export function injectAdNetworkScript(
  target: string | AdNetworkConfig,
  customId?: string
): Promise<boolean> {
  if (typeof document === "undefined" || !target) return Promise.resolve(false);

  if (typeof target !== "string") {
    // Passed AdNetworkConfig
    const config = target;
    if (!config.enabled) return Promise.resolve(false);

    if (config.networkType === "adsterra" && config.adsterraScriptTag) {
      return injectAdNetworkScript(config.adsterraScriptTag, "adsterra-dyn-tag");
    } else if (config.networkType === "monetag" && config.monetagScriptCode) {
      return injectAdNetworkScript(config.monetagScriptCode, "monetag-dyn-tag");
    } else if (config.networkType === "adsense" && config.adsenseClient) {
      return injectAdNetworkScript(
        `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${config.adsenseClient}`,
        "adsense-dyn-tag"
      );
    }
    return Promise.resolve(true);
  }

  const scriptUrl = target;
  const id = customId || `script-${Math.abs(scriptUrl.split("").reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0))}`;
  if (document.getElementById(id)) return Promise.resolve(true);

  return new Promise((resolve) => {
    try {
      const script = document.createElement("script");
      script.id = id;
      script.src = scriptUrl.startsWith("//") ? `https:${scriptUrl}` : scriptUrl;
      script.async = true;
      script.crossOrigin = "anonymous";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.head.appendChild(script);
    } catch {
      resolve(false);
    }
  });
}

/**
 * Triggers a real direct impression or sponsor ad in a new tab/window safely,
 * returning the generated impression identifier for server-side verification.
 */
export function openAdImpressionWindow(url: string): { windowRef: Window | null; impressionId: string } {
  const impressionId = `imp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  let win: Window | null = null;
  try {
    if (typeof window !== "undefined") {
      win = window.open(url, "_blank", "noopener,noreferrer");
    }
  } catch (err) {
    console.warn("Popup blocked or unsupported:", err);
  }
  return { windowRef: win, impressionId };
}

/**
 * Securely executes an ad reward claim through the protected /api/rewards/claim endpoint.
 * Requires valid Bearer token and hardware metrics to prevent automation.
 */
export interface ClaimAdRewardResponse {
  success: boolean;
  pointsEarned: number;
  newPointsTotal: number;
  activityStats?: any;
  activeDayNewlyAwarded?: boolean;
  activityMessage?: string;
  error?: string;
}

export async function claimAdRewardApi(params: {
  userId: string;
  missionId?: string;
  adNetwork: string;
  impressionId: string;
  adTitle?: string;
  rewardPoints?: number;
}): Promise<ClaimAdRewardResponse> {
  const fp = await getDeviceFingerprint();
  const metrics = getHardwareMetrics();
  const missionId = params.missionId || `ad_${params.adNetwork}_${params.impressionId}`;
  const idempotencyKey = `claim_${params.userId}_${missionId}_${params.impressionId}`;

  const res = await authenticatedFetch("/api/rewards/claim", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Idempotency-Key": idempotencyKey,
    },
    body: JSON.stringify({
      userId: params.userId,
      missionId,
      adNetwork: params.adNetwork,
      impressionId: params.impressionId,
      adTitle: params.adTitle || "Sponsored Ad Impression",
      rewardPoints: params.rewardPoints,
      device_fingerprint: fp,
      hardwareMetrics: metrics,
      timestamp: new Date().toISOString(),
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || `Reward claim failed (${res.status})`);
  }

  return data;
}
