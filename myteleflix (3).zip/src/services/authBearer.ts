/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { auth } from "./firebase";
import { getCachedDeviceFingerprint, getDeviceFingerprint, getHardwareMetrics } from "../utils/fingerprint";

const SESSION_TOKEN_KEY = "myteleflix_session_token";

/**
 * Stores an active session token received from the backend.
 */
export function setSessionToken(token: string) {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem(SESSION_TOKEN_KEY, token);
    } catch {}
  }
}

/**
 * Retrieves the stored session token.
 */
export function getSessionToken(): string | null {
  if (typeof window !== "undefined") {
    try {
      return localStorage.getItem(SESSION_TOKEN_KEY);
    } catch {}
  }
  return null;
}

/**
 * Resolves the most authoritative Bearer token for API authentication:
 * 1. Firebase Auth ID Token (if signed in with Google / Firebase Auth)
 * 2. Stored Session Token
 * 3. Telegram WebApp initData token
 * 4. Ephemeral client authorization token
 */
export async function getAuthBearerToken(): Promise<string> {
  // 1. Check for active Firebase Auth user
  try {
    if (auth && auth.currentUser) {
      const fbToken = await auth.currentUser.getIdToken(false);
      if (fbToken) return fbToken;
    }
  } catch (err) {
    console.warn("Firebase ID Token resolution notice:", err);
  }

  // 2. Check for stored session token
  const stored = getSessionToken();
  if (stored) return stored;

  // 3. Check for Telegram Mini App initData
  if (typeof window !== "undefined") {
    const tg = (window as any).Telegram?.WebApp;
    if (tg && tg.initData) {
      return `tg_init:${tg.initData}`;
    }
  }

  // 4. Return cached device token as fallback
  const fp = getCachedDeviceFingerprint();
  return `dev_token:${fp || "client"}`;
}

/**
 * Authenticated Fetch wrapper ensuring valid Authorization header is attached
 * along with device security headers.
 */
export async function authenticatedFetch(
  input: RequestInfo | URL,
  init: RequestInit = {}
): Promise<Response> {
  const token = await getAuthBearerToken();
  const fp = await getDeviceFingerprint();
  const metrics = getHardwareMetrics();

  const headers = new Headers(init.headers || {});
  
  if (!headers.has("Authorization") && token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  if (!headers.has("X-Device-Fingerprint") && fp) {
    headers.set("X-Device-Fingerprint", fp);
  }

  if (!headers.has("X-Hardware-Metrics")) {
    headers.set("X-Hardware-Metrics", JSON.stringify(metrics));
  }

  return fetch(input, {
    ...init,
    headers,
  });
}
