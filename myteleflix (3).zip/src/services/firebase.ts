/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider
} from "firebase/auth";
import {
  initializeFirestore,
  getFirestore,
  setLogLevel,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  getDocs,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  getDocFromServer,
  serverTimestamp,
  runTransaction,
  Unsubscribe
} from "firebase/firestore";
import { User, Movie, Video, Mission, WithdrawalRequest, CommunitySettings, ContentMapping, VerificationToken } from "../types";

// Active Firebase Project Configuration
export const firebaseConfig = {
  apiKey: "AIzaSyB2cLgll1nSEc3TrKZz97L_1pBF8qO6IYw",
  authDomain: "playmint-2f3b1.firebaseapp.com",
  projectId: "playmint-2f3b1",
  storageBucket: "playmint-2f3b1.firebasestorage.app",
  messagingSenderId: "503182419097",
  appId: "1:503182419097:web:318802940e3e2d407fc408"
};

// Singleton App Initialization
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Firebase Authentication & Google Provider
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: "select_account"
});

// Configure Firestore logging level to prevent transient retry noise
try {
  setLogLevel('error');
} catch {}

// Firestore Database Instance with forced long-polling to prevent WebChannel timeout / unavailable error in iframe/container sandbox
export const db = (() => {
  try {
    return initializeFirestore(app, {
      experimentalForceLongPolling: true,
    });
  } catch {
    return getFirestore(app);
  }
})();

// Standard OperationType enum for error tracing
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

// Standard Firestore Error Info Interface
export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

// Handle and format Firestore errors predictably
export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.warn('Firestore Operation Notice:', JSON.stringify(errInfo));
  return errInfo;
}

// Connectivity test
export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Connected to Firestore successfully.');
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn("Client is currently offline, cache storage active.");
    }
  }
}

// ==========================================
// 1. USER PERSISTENCE & ROLE/GENDER SYNC (/users collection)
// ==========================================

export const MASTER_ADMIN_EMAIL = "mostofa7077a@gmail.com";
export const DEFAULT_SUPER_ADMIN_EMAILS = [
  MASTER_ADMIN_EMAIL
];

/**
 * Sync user profile, resolving assigned role (Super Admin, Admin, User) 
 * and storing selected gender directly into Firestore /users collection.
 */
export async function saveUserToFirestore(userData: Partial<User> & { id: string }): Promise<void> {
  const path = `users/${userData.id}`;
  try {
    const userRef = doc(db, 'users', userData.id);
    const existingSnap = await getDoc(userRef);
    const existingData = existingSnap.exists() ? existingSnap.data() : {};

    // Calculate Role strictly: only MASTER_ADMIN_EMAIL or explicitly assignedAdmins receive admin privileges
    const emailNorm = (userData.email || (existingData as any).email || "").trim().toLowerCase();
    const isMaster = emailNorm === MASTER_ADMIN_EMAIL.toLowerCase();
    const assignedList: string[] = (existingData as any).assignedAdmins || (userData as any).assignedAdmins || [];
    const isAssigned = Array.isArray(assignedList) && assignedList.some(a => a.toLowerCase().trim() === emailNorm);

    let determinedRole: 'super_admin' | 'admin' | 'user' | 'guest' = 'user';
    if (userData.role === 'guest') {
      determinedRole = 'guest';
    } else if (isMaster) {
      determinedRole = 'super_admin';
    } else if (isAssigned) {
      determinedRole = 'admin';
    } else {
      // Force non-admin role
      determinedRole = 'user';
    }

    const displayName = userData.displayName || userData.fullName || (existingData as any).displayName || (existingData as any).fullName || "";
    const photoURL = userData.photoURL || userData.photoUrl || (existingData as any).photoURL || (existingData as any).photoUrl || "";
    const points = typeof userData.points === 'number' ? userData.points : ((existingData as any).points ?? 100);

    const userGender = userData.gender || (existingData as any).gender;
    const formattedGender = userGender 
      ? (String(userGender).toLowerCase() === 'female' ? 'Female' : String(userGender).toLowerCase() === 'other' ? 'Other' : 'Male')
      : 'Male';

    const isOnboardedVal = userData.onboardingCompleted !== undefined
      ? Boolean(userData.onboardingCompleted)
      : (userData.isOnboarded !== undefined 
        ? Boolean(userData.isOnboarded) 
        : Boolean((existingData as any).onboardingCompleted ?? (existingData as any).isOnboarded ?? (existingData as any).profileInitialized));

    const isProfileCompletedVal = userData.isProfileCompleted !== undefined
      ? Boolean(userData.isProfileCompleted)
      : Boolean((existingData as any).isProfileCompleted ?? isOnboardedVal);

    const profileStatusVal = userData.profileStatus || (existingData as any).profileStatus || (isProfileCompletedVal ? 'completed' : 'pending');

    const rawTgId = userData.telegramId !== undefined ? String(userData.telegramId).trim() : (existingData as any).telegramId || "";
    const numericTgId = rawTgId && /^\d+$/.test(rawTgId) ? Number(rawTgId) : rawTgId;
    const rawTgUser = userData.telegramUsername !== undefined ? String(userData.telegramUsername).trim() : (existingData as any).telegramUsername || "";
    const cleanTgUsername = rawTgUser ? (rawTgUser.startsWith('@') ? rawTgUser : `@${rawTgUser}`) : "";

    // Profile identity: allow updates from user profile editing (pencil icon) and save permanently
    const finalDisplayName = displayName || userData.fullName || (existingData as any).displayName || (existingData as any).fullName || (emailNorm ? emailNorm.split('@')[0] : "Member");

    const finalGender = (userData.gender !== undefined)
      ? (String(userData.gender).toLowerCase() === 'female' ? 'Female' : String(userData.gender).toLowerCase() === 'other' ? 'Other' : 'Male')
      : ((existingData as any).gender ? (String((existingData as any).gender).toLowerCase() === 'female' ? 'Female' : String((existingData as any).gender).toLowerCase() === 'other' ? 'Other' : 'Male') : formattedGender);

    const effectiveStatus = userData.status || (existingData as any).status || "ACTIVE";

    const cleanData: Record<string, any> = {
      ...existingData,
      ...userData,
      uid: userData.uid || userData.id,
      id: userData.id || userData.uid,
      displayName: finalDisplayName,
      fullName: finalDisplayName,
      email: emailNorm || userData.email || (existingData as any).email || "",
      photoURL,
      photoUrl: photoURL,
      points,
      role: determinedRole,
      gender: finalGender,
      telegramId: numericTgId,
      telegramUsername: cleanTgUsername,
      isOnboarded: isOnboardedVal,
      onboardingCompleted: isOnboardedVal,
      profileInitialized: isOnboardedVal,
      isProfileCompleted: isProfileCompletedVal,
      profileStatus: profileStatusVal,
      status: effectiveStatus,
      updatedAt: serverTimestamp(),
    };

    // Strip undefined values
    Object.keys(cleanData).forEach(key => {
      if (cleanData[key] === undefined) {
        delete cleanData[key];
      }
    });

    await setDoc(userRef, {
      ...cleanData,
      createdAt: cleanData.createdAt || (existingData as any).createdAt || new Date().toISOString(),
    }, { merge: true });

    // Phase 2 Identity Locking: Ensure users collection document ID is telegramId (numeric ID locked permanently)
    if (numericTgId) {
      const tgUserRef = doc(db, 'users', String(numericTgId));
      await setDoc(tgUserRef, {
        ...cleanData,
        telegramId: typeof numericTgId === 'number' ? numericTgId : Number(numericTgId) || numericTgId,
        email: emailNorm || userData.email || (existingData as any).email || "",
        joinedAt: cleanData.createdAt || (existingData as any).createdAt || serverTimestamp(),
        isVerified: true,
      }, { merge: true });
    }

    // If Super Admin, also maintain in /admins for rules compatibility
    if (determinedRole === 'super_admin' || determinedRole === 'admin') {
      if (emailNorm) {
        const adminRef = doc(db, 'admins', emailNorm);
        await setDoc(adminRef, {
          id: emailNorm,
          email: emailNorm,
          role: determinedRole,
          userId: userData.id,
          updatedAt: serverTimestamp(),
        }, { merge: true });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getUserFromFirestore(userId: string): Promise<User | null> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as User;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

export function subscribeToUser(userId: string, callback: (user: User | null) => void): Unsubscribe {
  const path = `users/${userId}`;
  const userRef = doc(db, 'users', userId);
  return onSnapshot(
    userRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as User);
      } else {
        callback(null);
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    }
  );
}

/**
 * 1-Click Update Gender Directly in Firestore
 */
export async function updateUserGenderInFirestore(userId: string, gender: 'male' | 'female' | 'other'): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      gender,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * 1-Click Update Role Directly in Firestore
 */
export async function updateUserRoleInFirestore(userId: string, role: 'super_admin' | 'admin' | 'user'): Promise<void> {
  const path = `users/${userId}`;
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      role,
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ==========================================
// 2. ADMIN WHITELIST (/admins collection)
// ==========================================

export async function isUserInAdminWhitelist(email?: string | null, uid?: string | null): Promise<boolean> {
  const normEmail = email?.trim().toLowerCase();
  if (normEmail && DEFAULT_SUPER_ADMIN_EMAILS.includes(normEmail)) {
    return true;
  }

  try {
    // Check by UID
    if (uid) {
      const uidRef = doc(db, 'admins', uid);
      const uidSnap = await getDoc(uidRef);
      if (uidSnap.exists()) return true;
    }

    // Check by Email
    if (normEmail) {
      const emailRef = doc(db, 'admins', normEmail);
      const emailSnap = await getDoc(emailRef);
      if (emailSnap.exists()) return true;

      // Also query by email field
      const adminsRef = collection(db, 'admins');
      const q = query(adminsRef, where('email', '==', normEmail));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) return true;
    }

    return false;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'admins');
    return false;
  }
}

export async function ensureSuperAdminExists(email: string, name?: string): Promise<void> {
  const normEmail = email.trim().toLowerCase();
  try {
    const adminRef = doc(db, 'admins', normEmail);
    const snap = await getDoc(adminRef);
    if (!snap.exists()) {
      await setDoc(adminRef, {
        id: normEmail,
        email: normEmail,
        fullName: name || "Super Admin",
        role: "super_admin",
        createdAt: new Date().toISOString(),
      });
    }
  } catch (err) {
    console.warn("Notice: Super Admin check complete.", err);
  }
}

export function subscribeToAdmins(callback: (admins: any[]) => void): Unsubscribe {
  const adminsRef = collection(db, 'admins');
  return onSnapshot(
    adminsRef,
    (snap) => {
      const list = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      callback(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'admins');
    }
  );
}

export async function addAdminToFirestore(email: string, fullName?: string, role = 'admin'): Promise<void> {
  const normEmail = email.trim().toLowerCase();
  const adminRef = doc(db, 'admins', normEmail);
  await setDoc(adminRef, {
    id: normEmail,
    email: normEmail,
    fullName: fullName || normEmail.split('@')[0],
    role,
    createdAt: new Date().toISOString(),
  }, { merge: true });
}

export async function removeAdminFromFirestore(adminIdOrEmail: string): Promise<void> {
  const adminRef = doc(db, 'admins', adminIdOrEmail);
  await deleteDoc(adminRef);
}


// ==========================================
// 4. CAMPAIGNS & POSTS PERSISTENCE (/campaigns collection)
// ==========================================

export function subscribeToCampaigns(callback: (campaigns: Movie[]) => void): Unsubscribe {
  const campaignsRef = collection(db, 'campaigns');
  return onSnapshot(
    campaignsRef,
    (snap) => {
      const list: Movie[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Movie));
      callback(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'campaigns');
    }
  );
}

export async function saveCampaignToFirestore(campaign: Partial<Movie> & { id: string }): Promise<void> {
  const path = `campaigns/${campaign.id}`;
  try {
    const ref = doc(db, 'campaigns', campaign.id);
    const cleanData = { ...campaign };
    Object.keys(cleanData).forEach(k => {
      if ((cleanData as any)[k] === undefined) delete (cleanData as any)[k];
    });
    await setDoc(ref, {
      ...cleanData,
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteCampaignFromFirestore(id: string): Promise<void> {
  const path = `campaigns/${id}`;
  try {
    const ref = doc(db, 'campaigns', id);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ==========================================
// 5. TASKS & MISSIONS PERSISTENCE (/tasks collection)
// ==========================================

export function subscribeToTasks(callback: (tasks: Mission[]) => void): Unsubscribe {
  const tasksRef = collection(db, 'tasks');
  return onSnapshot(
    tasksRef,
    (snap) => {
      const list: Mission[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Mission));
      callback(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'tasks');
    }
  );
}

export async function saveTaskToFirestore(task: Partial<Mission> & { id: string }): Promise<void> {
  const path = `tasks/${task.id}`;
  try {
    const ref = doc(db, 'tasks', task.id);
    const cleanData = { ...task };
    Object.keys(cleanData).forEach(k => {
      if ((cleanData as any)[k] === undefined) delete (cleanData as any)[k];
    });
    await setDoc(ref, {
      ...cleanData,
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteTaskFromFirestore(id: string): Promise<void> {
  const path = `tasks/${id}`;
  try {
    const ref = doc(db, 'tasks', id);
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ==========================================
// 6. WITHDRAWALS PERSISTENCE (/withdrawals collection)
// ==========================================

export function subscribeToWithdrawals(callback: (withdrawals: WithdrawalRequest[]) => void): Unsubscribe {
  let innerUnsub: Unsubscribe | null = null;

  const authUnsub = auth.onAuthStateChanged((currentUser) => {
    if (innerUnsub) {
      innerUnsub();
      innerUnsub = null;
    }

    if (currentUser) {
      try {
        const withsRef = collection(db, 'withdrawals');
        innerUnsub = onSnapshot(
          withsRef,
          (snap) => {
            const list: WithdrawalRequest[] = snap.docs.map(d => {
              const data = d.data();
              const normalizedStatus = (data.status || 'pending').toString().toLowerCase() as any;
              return { 
                id: d.id, 
                ...data,
                status: normalizedStatus,
              } as WithdrawalRequest;
            });
            callback(list);
          },
          (error) => {
            if ((error as any)?.code !== 'permission-denied') {
              handleFirestoreError(error, OperationType.LIST, 'withdrawals');
            }
          }
        );
      } catch (err) {
        console.warn("Withdrawal subscription notice:", err);
      }
    }
  });

  return () => {
    authUnsub();
    if (innerUnsub) innerUnsub();
  };
}

export async function saveWithdrawalToFirestore(withdrawal: WithdrawalRequest): Promise<void> {
  const path = `withdrawals/${withdrawal.id}`;
  try {
    const ref = doc(db, 'withdrawals', withdrawal.id);
    const cleanData: Record<string, any> = { 
      ...withdrawal,
      status: 'Pending', // Strictly 'Pending' as requested
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    Object.keys(cleanData).forEach(k => {
      if (cleanData[k] === undefined) delete cleanData[k];
    });
    await setDoc(ref, cleanData, { merge: true });

    // Also mirror to withdraw_requests for backwards compatibility
    try {
      const legacyRef = doc(db, 'withdraw_requests', withdrawal.id);
      await setDoc(legacyRef, cleanData, { merge: true });
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateWithdrawalStatusInFirestore(id: string, status: 'pending' | 'approved' | 'rejected' | 'paid' | 'Pending' | 'Approved' | 'Rejected' | 'Paid'): Promise<void> {
  const path = `withdrawals/${id}`;
  try {
    const ref = doc(db, 'withdrawals', id);
    await updateDoc(ref, { status, updatedAt: serverTimestamp() });
    
    // Also update legacy document if present
    try {
      const legacyRef = doc(db, 'withdraw_requests', id);
      await updateDoc(legacyRef, { status, updatedAt: serverTimestamp() });
    } catch {}
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ==========================================
// 7. MOVIES & VIDEOS CATALOG PERSISTENCE
// ==========================================

export function subscribeToMovies(callback: (movies: Movie[]) => void): Unsubscribe {
  const moviesRef = collection(db, 'movies');
  return onSnapshot(
    moviesRef,
    (snap) => {
      const list: Movie[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Movie));
      callback(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'movies');
    }
  );
}

export async function saveMovieToFirestore(movie: Movie): Promise<void> {
  const path = `movies/${movie.id}`;
  try {
    const ref = doc(db, 'movies', movie.id);
    const cleanData = { ...movie };
    Object.keys(cleanData).forEach(k => {
      if ((cleanData as any)[k] === undefined) delete (cleanData as any)[k];
    });
    await setDoc(ref, cleanData, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteMovieFromFirestore(id: string): Promise<void> {
  const path = `movies/${id}`;
  try {
    await deleteDoc(doc(db, 'movies', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeToVideos(callback: (videos: Video[]) => void): Unsubscribe {
  const videosRef = collection(db, 'videos');
  return onSnapshot(
    videosRef,
    (snap) => {
      const list: Video[] = snap.docs.map(d => ({ id: d.id, ...d.data() } as Video));
      callback(list);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'videos');
    }
  );
}

export async function saveVideoToFirestore(video: Video): Promise<void> {
  const path = `videos/${video.id}`;
  try {
    const ref = doc(db, 'videos', video.id);
    const cleanData = { ...video };
    Object.keys(cleanData).forEach(k => {
      if ((cleanData as any)[k] === undefined) delete (cleanData as any)[k];
    });
    await setDoc(ref, cleanData, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteVideoFromFirestore(id: string): Promise<void> {
  const path = `videos/${id}`;
  try {
    await deleteDoc(doc(db, 'videos', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ============================================================
// SYSTEM CONFIGS: COMMUNITY & SUPPORT LINKS REAL-TIME SYNC
// ============================================================

export const DEFAULT_COMMUNITY_SETTINGS: Required<Omit<CommunitySettings, 'updatedAt' | 'updatedBy'>> = {
  telegramChannelLink: "https://t.me/myteleflix",
  telegramSupportGroupLink: "https://t.me/myteleflix_support",
  whatsappSupportLink: "https://wa.me/?text=Hello%20MyTeleFlix",
  youtubeChannelLink: "https://youtube.com/@myteleflix",
  facebookLink: "https://facebook.com/myteleflix",
  promotionEmail: "SYNCTASKSOSPROMOTION@GMAIL.COM",
  supportOperatingHours: "প্রতিদিন সকাল ১০:০০ টা থেকে রাত ১০:০০ টা পর্যন্ত (10:00 AM - 10:00 PM)",
  supportGuidelines: "গ্রুপে যেকোনো থার্ড-পার্টি লিংক, স্প্যামিং, ব্যক্তিগত আক্রমণ কিংবা প্রতারণামূলক বার্তা দেওয়া কঠোরভাবে নিষিদ্ধ। আইন অমান্যকারীদের আইডি স্থায়ীভাবে ব্যান করা হবে।"
};

export function subscribeToCommunitySettings(callback: (settings: CommunitySettings) => void): Unsubscribe {
  const docRef = doc(db, 'system_configs', 'community_settings');
  return onSnapshot(
    docRef,
    (snap) => {
      if (snap.exists()) {
        const data = snap.data() as CommunitySettings;
        callback({
          ...DEFAULT_COMMUNITY_SETTINGS,
          ...data
        });
      } else {
        callback({ ...DEFAULT_COMMUNITY_SETTINGS });
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, 'system_configs/community_settings');
      callback({ ...DEFAULT_COMMUNITY_SETTINGS });
    }
  );
}

export async function getCommunitySettingsFromFirestore(): Promise<CommunitySettings> {
  const path = 'system_configs/community_settings';
  try {
    const docRef = doc(db, 'system_configs', 'community_settings');
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return {
        ...DEFAULT_COMMUNITY_SETTINGS,
        ...(snap.data() as CommunitySettings)
      };
    }
    return { ...DEFAULT_COMMUNITY_SETTINGS };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return { ...DEFAULT_COMMUNITY_SETTINGS };
  }
}

export async function saveCommunitySettingsToFirestore(
  settings: Partial<CommunitySettings>,
  updatedBy?: string
): Promise<void> {
  const path = 'system_configs/community_settings';
  try {
    const docRef = doc(db, 'system_configs', 'community_settings');
    const cleanData: any = {
      ...settings,
      updatedAt: new Date().toISOString(),
    };
    if (updatedBy) {
      cleanData.updatedBy = updatedBy;
    }
    Object.keys(cleanData).forEach(k => {
      if (cleanData[k] === undefined) delete cleanData[k];
    });
    await setDoc(docRef, cleanData, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

// ==========================================
// PHASE 2: FIRESTORE DATABASE IDENTITY LOCKING & MAPPING
// ==========================================

/**
 * Permanently locks user identity into collection 'users' using numeric telegramId as Document ID.
 * Document ID: telegramId (Numeric ID locked permanently)
 * Fields: telegramId, email, joinedAt, isVerified
 */
export async function saveLockedTelegramUser(
  telegramId: string | number,
  email?: string,
  isVerified: boolean = true
): Promise<void> {
  const rawId = String(telegramId).trim();
  if (!rawId) return;
  const numericId = /^\d+$/.test(rawId) ? Number(rawId) : rawId;
  const path = `users/${rawId}`;

  try {
    const userRef = doc(db, 'users', rawId);
    const existingSnap = await getDoc(userRef);
    const existingData = existingSnap.exists() ? existingSnap.data() : {};

    await setDoc(userRef, {
      ...existingData,
      telegramId: numericId,
      email: email || (existingData as any).email || "",
      joinedAt: (existingData as any).joinedAt || (existingData as any).createdAt || serverTimestamp(),
      isVerified: isVerified,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

/**
 * Saves or updates content mapping in collection 'content_mappings'
 * Document ID: contentId (e.g., MOV_102)
 * Fields: { contentId, title, universalTelegramLink, category, updatedAt }
 */
export async function saveContentMapping(mapping: ContentMapping): Promise<void> {
  const path = `content_mappings/${mapping.contentId}`;
  try {
    const docRef = doc(db, 'content_mappings', mapping.contentId);
    const cleanData: Record<string, any> = {
      contentId: String(mapping.contentId),
      title: mapping.title,
      universalTelegramLink: mapping.universalTelegramLink,
      category: mapping.category || 'movie',
      updatedAt: serverTimestamp(),
      ...(mapping.thumbnailUrl ? { thumbnailUrl: mapping.thumbnailUrl } : {}),
      ...(mapping.description ? { description: mapping.description } : {}),
    };

    Object.keys(cleanData).forEach(k => {
      if (cleanData[k] === undefined) delete cleanData[k];
    });

    await setDoc(docRef, cleanData, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

/**
 * Fetches content mapping from collection 'content_mappings' by contentId.
 * If not present, checks 'movies' collection and auto-seeds/locks it.
 */
export async function getContentMapping(contentId: string): Promise<ContentMapping | null> {
  const path = `content_mappings/${contentId}`;
  try {
    const docRef = doc(db, 'content_mappings', contentId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as ContentMapping;
    }

    // Auto-seed from 'movies' collection if exists
    const movieRef = doc(db, 'movies', contentId);
    const movieSnap = await getDoc(movieRef);
    if (movieSnap.exists()) {
      const m = movieSnap.data() as Movie;
      const universalLink = (m as any).universalTelegramLink || 
                            (m as any).originalLink || 
                            (m as any).banglaLink || 
                            (m as any).hindiLink || 
                            m.videoUrl || 
                            `https://t.me/myteleflix?start=dl_${contentId}`;
      const newMapping: ContentMapping = {
        contentId: m.id,
        title: m.title,
        universalTelegramLink: universalLink,
        category: m.category || (m as any).contentType || 'movie',
        thumbnailUrl: m.thumbnailUrl || (m as any).poster,
        description: m.description,
        updatedAt: serverTimestamp(),
      };
      await setDoc(docRef, newMapping, { merge: true });
      return newMapping;
    }

    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

/**
 * Generates a cryptographically secure single-use verification token in Firestore.
 */
export async function generateSingleUseVerificationToken(
  contentId: string,
  telegramId?: string | number,
  userEmail?: string
): Promise<string> {
  const randomPart = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
  const token = `vtok_${Date.now()}_${randomPart}`;
  const path = `verification_tokens/${token}`;

  try {
    const tokenDocRef = doc(db, 'verification_tokens', token);
    const payload: VerificationToken = {
      token,
      contentId,
      telegramId: telegramId ? (typeof telegramId === 'number' ? telegramId : Number(telegramId) || telegramId) : "",
      userEmail: userEmail || auth.currentUser?.email || "",
      createdAt: serverTimestamp(),
      expiresAt: Date.now() + 15 * 60 * 1000, // 15 minutes validity
      isUsed: false,
    };

    await setDoc(tokenDocRef, payload);
    return token;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

/**
 * Validates and consumes single-use verification token via Firestore transaction.
 * Ensures the token can never be re-used, protecting against URL tampering and replay attacks.
 */
export async function validateAndConsumeVerificationToken(
  token: string
): Promise<{ valid: boolean; tokenData?: VerificationToken; error?: string }> {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: "Missing or invalid token parameter" };
  }

  const tokenDocRef = doc(db, 'verification_tokens', token);

  try {
    return await runTransaction(db, async (transaction) => {
      const snap = await transaction.get(tokenDocRef);
      if (!snap.exists()) {
        return { valid: false, error: "Verification token does not exist or has expired" };
      }

      const data = snap.data() as VerificationToken;
      if (data.isUsed) {
        return { valid: false, error: "Verification token has already been used (single-use protection)" };
      }

      if (data.expiresAt && Date.now() > data.expiresAt) {
        return { valid: false, error: "Verification token has expired (15-minute window passed)" };
      }

      // Atomically mark token as used
      transaction.update(tokenDocRef, {
        isUsed: true,
        usedAt: serverTimestamp(),
      });

      return {
        valid: true,
        tokenData: data,
      };
    });
  } catch (err: any) {
    console.error("Token consumption error:", err);
    return { valid: false, error: err.message || "Failed to validate verification token" };
  }
}

/**
 * PHASE 2 SIGNAL DATA VERIFICATION ROUTINE:
 * Ties contentId to universalTelegramLink in Firestore and updates download_requests to VERIFIED.
 */
export async function verifySignalAndTieContentMapping(
  contentId: string,
  telegramId?: string | number,
  userEmail?: string,
  botUsername: string = "myteleflix_bot",
  userMode?: "GUEST" | "VIP",
  uid?: string
): Promise<{ success: boolean; mapping: ContentMapping | null; deepLink: string; error?: string; userMode: "GUEST" | "VIP" }> {
  const currentUser = auth.currentUser;
  const isVip = Boolean(currentUser && !currentUser.isAnonymous);
  const resolvedUserMode: "GUEST" | "VIP" = userMode || (isVip ? "VIP" : "GUEST");
  const resolvedUid = isVip ? currentUser?.uid : (uid || null);

  try {
    let mapping = await getContentMapping(contentId);
    const cleanBot = botUsername.replace(/^@/, '').replace('https://t.me/', '');
    const deepLink = `https://t.me/${cleanBot}?start=dl_${encodeURIComponent(contentId)}`;

    if (!mapping) {
      mapping = {
        contentId,
        title: `Content #${contentId}`,
        universalTelegramLink: deepLink,
        category: "movie",
        updatedAt: serverTimestamp()
      };
      await saveContentMapping(mapping);
    }

    // Tie signal and update download_requests to 'VERIFIED'
    const targetDocId = telegramId ? String(telegramId) : (currentUser?.uid || resolvedUid || "guest_request");
    const downloadReqRef = doc(db, 'download_requests', targetDocId);

    await runTransaction(db, async (transaction) => {
      transaction.set(downloadReqRef, {
        contentId,
        contentTitle: mapping!.title,
        universalLink: mapping!.universalTelegramLink,
        status: "VERIFIED",
        userMode: resolvedUserMode,
        uid: resolvedUid,
        verifiedAt: serverTimestamp(),
        deepLink,
        telegramId: telegramId ? (typeof telegramId === 'number' ? telegramId : Number(telegramId) || telegramId) : "",
        userEmail: userEmail || currentUser?.email || "",
      }, { merge: true });
    });

    return {
      success: true,
      mapping,
      deepLink,
      userMode: resolvedUserMode,
    };
  } catch (err: any) {
    console.error("Signal verification routine error:", err);
    const cleanBot = botUsername.replace(/^@/, '').replace('https://t.me/', '');
    return {
      success: false,
      mapping: null,
      deepLink: `https://t.me/${cleanBot}?start=dl_${encodeURIComponent(contentId)}`,
      error: err.message,
      userMode: resolvedUserMode,
    };
  }
}

