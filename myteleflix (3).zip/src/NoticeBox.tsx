/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Bell, 
  X, 
  ShieldAlert, 
  CheckCircle2, 
  Circle,
  Clock, 
  Inbox, 
  Layers
} from "lucide-react";
import { Notification } from "./types";
import { doc, setDoc, collection } from "firebase/firestore";
import { db } from "./services/firebase";

export const NOTICES_STORAGE_KEY = "myteleflix_notifications";
export const SYSTEM_NOTICES_STORAGE_KEY = "myteleflix_system_notices";
export const SEEN_NOTICE_IDS_KEY = "seen_notice_ids";

/**
 * ID-tracking persistence: Get set of seen notice IDs
 */
export function getSeenNoticeIds(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(SEEN_NOTICE_IDS_KEY) || localStorage.getItem("myteleflix_seen_notification_ids");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
}

/**
 * Record a notice ID as seen permanently so popups/banners render strictly ONCE
 */
export function markNoticeAsSeen(id: string): void {
  if (!id || typeof window === "undefined") return;
  try {
    const existing = new Set(getSeenNoticeIds());
    existing.add(id);
    const updated = Array.from(existing).slice(-300);
    localStorage.setItem(SEEN_NOTICE_IDS_KEY, JSON.stringify(updated));
    localStorage.setItem("myteleflix_seen_notification_ids", JSON.stringify(updated));
  } catch (e) {}
}

/**
 * Checks whether a notice/popup ID has already been seen/dismissed
 */
export function isNoticeSeen(id: string): boolean {
  if (!id || typeof window === "undefined") return false;
  try {
    const ids = getSeenNoticeIds();
    return ids.includes(id);
  } catch (e) {
    return false;
  }
}

/**
 * AUTOMATIC SYSTEM NOTICE LOGGING:
 * When a multi-account attempt is detected, automatically log an entry into the user's Notice Box under the "System" tab.
 */
export function logSecurityNotice(params?: {
  primaryEmail?: string;
  attemptedEmail?: string;
  hwid?: string;
  customContent?: string;
}): Notification {
  const timestamp = new Date().toISOString();
  const noticeId = `notice_sec_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const content = params?.customContent || "Security Warning: Secondary account attempt blocked on this device. Please stick to your primary authorized account.";

  const notice: Notification = {
    id: noticeId,
    notification_id: noticeId,
    userId: params?.primaryEmail || "system",
    user_id: params?.primaryEmail || "system",
    title: "⛔ MULTI-ACCOUNT SECURITY ALERT",
    message: content,
    content: content,
    category: "System Security",
    type: "SYSTEM",
    isRead: false,
    is_read: false,
    timestamp: timestamp,
    created_at: timestamp,
    reference_id: params?.hwid
  };

  // 1. Write to LocalStorage (notifications list)
  if (typeof window !== "undefined") {
    try {
      const existing = getStoredNotices();
      // Avoid duplicate alert within 10 seconds for same hardware
      const isDuplicate = existing.some(
        n => n.category === "System Security" && 
             Date.now() - new Date(n.created_at || n.timestamp).getTime() < 10000
      );

      if (!isDuplicate) {
        const updated = [notice, ...existing.slice(0, 49)];
        localStorage.setItem(NOTICES_STORAGE_KEY, JSON.stringify(updated));
        
        // Also save to dedicated system notices store
        try {
          const sysSaved = localStorage.getItem(SYSTEM_NOTICES_STORAGE_KEY);
          const sysList = sysSaved ? JSON.parse(sysSaved) : [];
          localStorage.setItem(SYSTEM_NOTICES_STORAGE_KEY, JSON.stringify([notice, ...sysList.slice(0, 49)]));
        } catch (e) {}

        // Notify active UI listeners immediately
        window.dispatchEvent(new CustomEvent("myteleflix_new_notice", { detail: notice }));
        window.dispatchEvent(new CustomEvent("myteleflix_security_alert", { detail: notice }));
      }
    } catch (e) {
      console.warn("NoticeBox storage warning:", e);
    }
  }

  // 2. Persist to Firestore /notifications collection asynchronously
  try {
    const noticeRef = doc(collection(db, "notifications"), noticeId);
    setDoc(noticeRef, {
      ...notice,
      created_at: timestamp
    }).catch(() => {});
  } catch (err) {}

  // 3. Persist to Server backend API
  try {
    fetch("/api/notifications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(notice)
    }).catch(() => {});
  } catch (e) {}

  return notice;
}

// Alias for convenience
export const logSystemSecurityNotice = logSecurityNotice;

/**
 * Retrieve stored notifications from localStorage
 */
export function getStoredNotices(): Notification[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(NOTICES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
}

/**
 * Mark all notifications as read in storage
 */
export function markAllNoticesRead(): void {
  if (typeof window === "undefined") return;
  try {
    const notices = getStoredNotices();
    const updated = notices.map(n => ({ ...n, isRead: true, is_read: true }));
    localStorage.setItem(NOTICES_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent("myteleflix_notices_updated"));
  } catch (e) {}
}

export const markAllAsRead = markAllNoticesRead;

/**
 * Clear all notifications from storage
 */
export function clearAllNotices(): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(NOTICES_STORAGE_KEY);
    localStorage.removeItem(SYSTEM_NOTICES_STORAGE_KEY);
    window.dispatchEvent(new CustomEvent("myteleflix_notices_cleared"));
    window.dispatchEvent(new CustomEvent("myteleflix_notices_updated"));
  } catch (e) {}
}

export const clearAllNotifications = clearAllNotices;

/**
 * Mark a single notice as read in storage
 */
export function markNoticeRead(id: string): void {
  if (typeof window === "undefined" || !id) return;
  markNoticeAsSeen(id);
  try {
    const notices = getStoredNotices();
    const updated = notices.map(n => 
      (n.id === id || n.notification_id === id) ? { ...n, isRead: true, is_read: true } : n
    );
    localStorage.setItem(NOTICES_STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent("myteleflix_notices_updated"));
  } catch (e) {}
}

export type NoticeFilterTab = "All" | "Unread" | "System";

export interface NoticeBoxProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: NoticeFilterTab;
  notifications?: Notification[];
  onMarkRead?: (id: string) => void;
  onMarkAllRead?: () => void;
  onClearAll?: () => void;
}

export default function NoticeBox({
  isOpen,
  onClose,
  defaultTab = "All",
  notifications: propsNotifications,
  onMarkRead,
  onMarkAllRead,
  onClearAll
}: NoticeBoxProps) {
  const [activeTab, setActiveTab] = useState<NoticeFilterTab>(defaultTab);
  const [localNotices, setLocalNotices] = useState<Notification[]>(() => getStoredNotices());

  // Listen to new notices dispatched from security engine or store changes
  useEffect(() => {
    const handleUpdate = () => {
      setLocalNotices(getStoredNotices());
    };

    window.addEventListener("myteleflix_new_notice", handleUpdate);
    window.addEventListener("myteleflix_notices_updated", handleUpdate);
    window.addEventListener("myteleflix_notices_cleared", handleUpdate);
    window.addEventListener("storage", handleUpdate);

    return () => {
      window.removeEventListener("myteleflix_new_notice", handleUpdate);
      window.removeEventListener("myteleflix_notices_updated", handleUpdate);
      window.removeEventListener("myteleflix_notices_cleared", handleUpdate);
      window.removeEventListener("storage", handleUpdate);
    };
  }, []);

  // When NoticeBox is opened, automatically mark all notices as read and record them in seen_notice_ids
  // This immediately silences the red notification indicator and prevents popup re-triggering.
  useEffect(() => {
    if (isOpen) {
      const stored = getStoredNotices();
      stored.forEach(n => {
        const id = n.id || n.notification_id;
        if (id) markNoticeAsSeen(id);
      });
      if (onMarkAllRead) {
        onMarkAllRead();
      }
      markAllNoticesRead();
      setLocalNotices(getStoredNotices());
    }
  }, [isOpen, onMarkAllRead]);

  if (!isOpen) return null;

  const currentNotices = propsNotifications && propsNotifications.length > 0 ? propsNotifications : localNotices;

  // Filter based on active tab: All, Unread, and System ONLY
  const filteredNotices = currentNotices.filter(n => {
    const isUnread = !(n.is_read ?? n.isRead);
    if (activeTab === "Unread") return isUnread;
    if (activeTab === "System") {
      const type = (n.type || "SYSTEM").toUpperCase();
      return type === "SYSTEM" || type === "SECURITY" || n.category === "System Security";
    }
    return true; // "All"
  });

  const unreadCount = currentNotices.filter(n => !(n.is_read ?? n.isRead)).length;
  const systemCount = currentNotices.filter(n => {
    const type = (n.type || "SYSTEM").toUpperCase();
    return type === "SYSTEM" || type === "SECURITY" || n.category === "System Security";
  }).length;

  const handleToggleRead = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (onMarkRead) {
      onMarkRead(id);
    } else {
      markNoticeRead(id);
      setLocalNotices(getStoredNotices());
    }
  };

  const handleItemClick = (id: string) => {
    if (onMarkRead) {
      onMarkRead(id);
    } else {
      markNoticeRead(id);
      setLocalNotices(getStoredNotices());
    }
  };

  // Button 1: [ 👀 দেখেছি ] -> Triggers markAllAsRead()
  const handleMarkAllReadClick = () => {
    if (onMarkAllRead) {
      onMarkAllRead();
    }
    markAllNoticesRead();
    setLocalNotices(getStoredNotices());
  };

  // Button 2: [ 🗑️ ক্লিয়ার ] -> Triggers clearAllNotifications()
  const handleClearAllClick = () => {
    if (onClearAll) {
      onClearAll();
    }
    clearAllNotifications();
    setLocalNotices([]);
  };

  return (
    <AnimatePresence>
      <div 
        id="notice-box-overlay"
        className="fixed inset-0 z-[220] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none"
        role="dialog"
        aria-modal="true"
        aria-label="নোটিশ বোর্ড"
        onClick={onClose}
      >
        <motion.div
          id="notice-box-card"
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.16, ease: "easeOut" }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-lg bg-[#0A0D14] border border-[#1E2536] rounded-2xl sm:rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[85vh]"
        >
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-0 w-48 h-24 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />

          {/* 1. CLEAN HEADER LAYOUT & TYPOGRAPHY */}
          <div className="flex items-center justify-between px-4 sm:px-5 py-3.5 border-b border-[#1A2234] bg-[#0E131E] relative z-10">
            {/* Left side: Clean bold title "নোটিশ বোর্ড" */}
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 shrink-0">
                <Bell size={16} />
              </div>
              <h2 className="text-base sm:text-[17px] font-bold text-white tracking-tight truncate">
                নোটিশ বোর্ড
              </h2>
            </div>

            {/* 2. ACTION BUTTONS (TOP RIGHT) */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Button 1: [ 👀 দেখেছি ] */}
              <button
                type="button"
                id="notice-box-mark-all-read-btn"
                onClick={handleMarkAllReadClick}
                className="px-2.5 py-1.5 rounded-xl bg-[#151C2C] hover:bg-[#1E283E] active:bg-[#25324E] text-slate-200 hover:text-white border border-[#222D44] text-[11px] sm:text-xs font-semibold flex items-center gap-1 transition cursor-pointer select-none"
                title="সবগুলো পঠিত হিসেবে চিহ্নিত করুন"
              >
                <span>👀</span>
                <span>দেখেছি</span>
              </button>

              {/* Button 2: [ 🗑️ ক্লিয়ার ] */}
              <button
                type="button"
                id="notice-box-clear-all-btn"
                onClick={handleClearAllClick}
                className="px-2.5 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 active:bg-rose-900 text-rose-300 hover:text-rose-100 border border-rose-800/40 text-[11px] sm:text-xs font-semibold flex items-center gap-1 transition cursor-pointer select-none"
                title="সব নোটিশ মুছে ফেলুন"
              >
                <span>🗑️</span>
                <span>ক্লিয়ার</span>
              </button>

              {/* Far Right: Simple ✕ Close Icon with high contrast */}
              <button
                type="button"
                id="notice-box-close-btn"
                onClick={onClose}
                className="p-1.5 sm:p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.14] active:bg-white/[0.2] text-slate-300 hover:text-white border border-white/[0.1] transition cursor-pointer shrink-0 ml-0.5"
                aria-label="Close Notice Box"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* 3. CLEAN TABS (Strictly All, Unread, System ONLY) */}
          <div className="grid grid-cols-3 gap-1.5 px-3 sm:px-4 py-2 bg-[#070A10] border-b border-[#1A2234] text-xs font-semibold relative z-10">
            <button
              type="button"
              id="notice-tab-all"
              onClick={() => setActiveTab("All")}
              className={`py-1.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer font-medium ${
                activeTab === "All"
                  ? "bg-[#161F32] text-white border border-amber-500/40 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-[#111724]"
              }`}
            >
              <Layers size={13} className={activeTab === "All" ? "text-amber-400" : "text-slate-500"} />
              <span>All</span>
              <span className="text-[10px] opacity-70 font-mono">({currentNotices.length})</span>
            </button>

            <button
              type="button"
              id="notice-tab-unread"
              onClick={() => setActiveTab("Unread")}
              className={`py-1.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer font-medium ${
                activeTab === "Unread"
                  ? "bg-[#161F32] text-white border border-amber-500/40 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-[#111724]"
              }`}
            >
              <Circle size={11} className={activeTab === "Unread" ? "text-rose-400 fill-rose-400" : "text-slate-500"} />
              <span>Unread</span>
              {unreadCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500/25 text-rose-300 border border-rose-500/40 font-mono font-bold">
                  {unreadCount}
                </span>
              )}
            </button>

            <button
              type="button"
              id="notice-tab-system"
              onClick={() => setActiveTab("System")}
              className={`py-1.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer font-medium ${
                activeTab === "System"
                  ? "bg-[#1F1522] text-rose-300 border border-rose-500/50 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-[#111724]"
              }`}
            >
              <ShieldAlert size={13} className={activeTab === "System" ? "text-rose-400" : "text-slate-500"} />
              <span>System</span>
              {systemCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-950 text-rose-300 border border-rose-800/60 font-mono font-bold">
                  {systemCount}
                </span>
              )}
            </button>
          </div>

          {/* 4. NOTIFICATION CARDS LIST */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2.5 relative z-10 scrollbar-thin">
            {filteredNotices.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-14 text-center text-slate-500 space-y-2.5">
                <div className="p-3.5 rounded-2xl bg-[#0F1420] border border-[#1E2536] text-slate-600">
                  <Inbox size={26} />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-slate-300">কোনো নোটিশ নেই</p>
                  <p className="text-xs text-slate-500">
                    {activeTab === "Unread"
                      ? "সব নোটিশ পড়া হয়ে গেছে।"
                      : activeTab === "System"
                      ? "কোনো সিস্টেম বা সিকিউরিটি সতর্কতা নেই।"
                      : "আপনার নোটিশ বোর্ড একদম পরিষ্কার।"}
                  </p>
                </div>
              </div>
            ) : (
              filteredNotices.map((n) => {
                const isUnread = !(n.is_read ?? n.isRead);
                const isSystemSecurity = n.category === "System Security" || (n.type || "").toUpperCase() === "SECURITY";
                const noticeId = n.id || n.notification_id || `notice-${Math.random()}`;

                return (
                  <div
                    key={noticeId}
                    id={`notice-item-${noticeId}`}
                    onClick={() => handleItemClick(noticeId)}
                    className={`group p-3 sm:p-3.5 rounded-xl transition-all cursor-pointer border ${
                      isSystemSecurity 
                        ? "bg-gradient-to-r from-[#201018] to-[#121624] border-rose-900/60 hover:border-rose-600/80" 
                        : isUnread 
                          ? "bg-[#0E1422] border-amber-500/40 hover:border-amber-400/60 shadow-[0_0_15px_rgba(245,158,11,0.06)]" 
                          : "bg-[#0B0F18] border-[#182030] hover:border-[#222D42] opacity-85 hover:opacity-100"
                    }`}
                  >
                    {/* Card Top: Category Badge, Timestamp, Read/Unread Indicator */}
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[9.5px] font-mono font-bold px-2 py-0.5 rounded uppercase tracking-wider flex items-center gap-1 ${
                          isSystemSecurity 
                            ? "bg-rose-950 text-rose-300 border border-rose-700/60" 
                            : "bg-[#161F32] text-amber-300 border border-amber-600/40"
                        }`}>
                          {isSystemSecurity && <ShieldAlert size={10} className="text-rose-400" />}
                          {n.category || "System Notice"}
                        </span>

                        {isUnread && (
                          <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                            NEW
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center gap-1 text-[10.5px] text-slate-400 font-mono">
                          <Clock size={11} className="text-slate-500" />
                          <span>
                            {new Date(n.created_at || n.timestamp || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>

                        {/* Read/Unread Toggle Indicator */}
                        <button
                          type="button"
                          id={`btn-toggle-read-${noticeId}`}
                          onClick={(e) => handleToggleRead(e, noticeId)}
                          title={isUnread ? "পঠিত চিহ্নিত করতে ক্লিক করুন" : "পঠিত হয়েছে"}
                          className={`p-1 rounded-lg transition-colors cursor-pointer ${
                            isUnread 
                              ? "text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10" 
                              : "text-emerald-400/70"
                          }`}
                        >
                          {isUnread ? (
                            <Circle size={14} className="text-rose-400/80 hover:text-emerald-400" />
                          ) : (
                            <CheckCircle2 size={14} className="text-emerald-400" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className={`text-xs sm:text-[13px] font-bold tracking-tight mb-1 ${
                      isSystemSecurity ? "text-rose-200" : isUnread ? "text-white" : "text-slate-200"
                    }`}>
                      {n.title}
                    </h3>

                    {/* Message Body */}
                    <p className="text-[11.5px] text-slate-300 leading-relaxed font-normal">
                      {n.content || n.message}
                    </p>
                  </div>
                );
              })
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
