/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Strict Role-Based Access Control (RBAC) & Authority Verification Guard
 * Enforces zero-trust route protection, token validation, and violation auditing.
 */

import { ADMIN_WHITELIST, isEmailInAdminWhitelist, MASTER_ADMIN_EMAIL } from "./constants";

export const ADMIN_TOKEN_KEY = "myteleflix_admin_session_token";
export const AUTHORITY_ROLE_LOCK_KEY = "myteleflix_authority_role_lock";
export const SECURITY_VIOLATIONS_KEY = "myteleflix_security_violations";
export const SECURITY_VIOLATION_EVENT = "myteleflix:security_violation";

export interface SecurityViolationRecord {
  id: string;
  timestamp: string;
  attemptedEmail: string;
  attemptedPath: string;
  roleClaimed: string;
  reason: string;
  ipOrFingerprint?: string;
  hwid?: string;
  actionTaken: 'ABORT_SESSION_REDIRECT' | 'TOKEN_REVOKED' | 'ACCESS_BLOCKED';
}

export interface AuthorityGatewayResult {
  isMatch: boolean;
  role: 'ADMIN' | 'USER';
  authorityToken: string | null;
  message: string;
}

/**
 * Generate a tamper-resistant persistent admin session token
 */
export function generateAdminSessionToken(email: string): string {
  const cleanEmail = email.toLowerCase().trim();
  const timestamp = Date.now().toString(36);
  const randomSalt = Math.random().toString(36).substring(2, 10);
  
  // FNV-1a hash
  let hash = 2166136261;
  const raw = `${cleanEmail}:${timestamp}:${randomSalt}:MYTELEFLIX_MASTER_KEY`;
  for (let i = 0; i < raw.length; i++) {
    hash ^= raw.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  const hexHash = (hash >>> 0).toString(16).padStart(8, "0");
  
  const payload = btoa(JSON.stringify({
    e: cleanEmail,
    t: Date.now(),
    h: hexHash
  }));

  return `TF_AUTH_ADMIN_${payload}`;
}

/**
 * Verifies if an admin session token is valid and belongs to the given email
 */
export function verifyAdminSessionToken(token: string | null | undefined, email?: string | null): boolean {
  if (!token || !token.startsWith("TF_AUTH_ADMIN_")) return false;
  if (!email || !isEmailInAdminWhitelist(email)) return false;

  try {
    const rawPayload = token.replace("TF_AUTH_ADMIN_", "");
    const decoded = JSON.parse(atob(rawPayload));
    if (decoded && decoded.e && decoded.e.toLowerCase().trim() === email.toLowerCase().trim()) {
      return isEmailInAdminWhitelist(decoded.e);
    }
  } catch (err) {
    return false;
  }
  return false;
}

/**
 * Executes the Instant Authority Gateway evaluation:
 * Runs the email through the Authority Gateway BEFORE creating or fetching profile.
 */
export function evaluateAuthorityGateway(email?: string | null): AuthorityGatewayResult {
  if (!email) {
    clearPersistentAdminToken();
    return {
      isMatch: false,
      role: 'USER',
      authorityToken: null,
      message: 'No credentials provided. Defaulting to standard user access.'
    };
  }

  const cleanEmail = email.toLowerCase().trim();
  const isMatch = isEmailInAdminWhitelist(cleanEmail);

  if (isMatch) {
    const token = generateAdminSessionToken(cleanEmail);
    // Persist admin session token in LocalStorage
    try {
      if (typeof window !== "undefined") {
        localStorage.setItem(ADMIN_TOKEN_KEY, token);
        localStorage.setItem(`${AUTHORITY_ROLE_LOCK_KEY}_${cleanEmail}`, 'ADMIN');
      }
    } catch (e) {}

    return {
      isMatch: true,
      role: 'ADMIN',
      authorityToken: token,
      message: 'Master Admin authority verified. Full master privileges granted.'
    };
  }

  // Non-whitelisted user: enforce strict isolation
  clearPersistentAdminToken();
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(`${AUTHORITY_ROLE_LOCK_KEY}_${cleanEmail}`, 'USER');
    }
  } catch (e) {}

  return {
    isMatch: false,
    role: 'USER',
    authorityToken: null,
    message: 'Standard credentials verified. Routing strictly to normal user dashboard.'
  };
}

/**
 * Clears persistent admin session token from browser storage
 */
export function clearPersistentAdminToken(): void {
  try {
    if (typeof window !== "undefined") {
      localStorage.removeItem(ADMIN_TOKEN_KEY);
      localStorage.removeItem("myteleflix_authority_token");
    }
  } catch (e) {}
}

/**
 * Retrieves currently active admin session token
 */
export function getActiveAdminSessionToken(): string | null {
  try {
    if (typeof window !== "undefined") {
      return localStorage.getItem(ADMIN_TOKEN_KEY) || localStorage.getItem("myteleflix_authority_token");
    }
  } catch (e) {}
  return null;
}

/**
 * Logs a security violation and broadcasts the security event across the application
 */
export function logSecurityViolation(violation: Omit<SecurityViolationRecord, 'id' | 'timestamp'>): SecurityViolationRecord {
  const fullRecord: SecurityViolationRecord = {
    ...violation,
    id: `viol_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString()
  };

  try {
    if (typeof window !== "undefined") {
      const existing = localStorage.getItem(SECURITY_VIOLATIONS_KEY);
      const list: SecurityViolationRecord[] = existing ? JSON.parse(existing) : [];
      list.unshift(fullRecord);
      // Keep up to 50 security violation logs
      localStorage.setItem(SECURITY_VIOLATIONS_KEY, JSON.stringify(list.slice(0, 50)));

      // Dispatch real-time security event for UI interception
      window.dispatchEvent(new CustomEvent(SECURITY_VIOLATION_EVENT, { detail: fullRecord }));
    }
  } catch (e) {
    console.error("Failed to log security violation:", e);
  }

  return fullRecord;
}

/**
 * Retrieves all logged security violations
 */
export function getSecurityViolations(): SecurityViolationRecord[] {
  try {
    if (typeof window !== "undefined") {
      const existing = localStorage.getItem(SECURITY_VIOLATIONS_KEY);
      return existing ? JSON.parse(existing) : [];
    }
  } catch (e) {}
  return [];
}

/**
 * Hardened Route Access Verifier:
 * Inspects path/hash/query to block unauthorized access to /admin or management consoles.
 */
export function verifyAdminRouteAccess(params: {
  pathname?: string;
  hash?: string;
  search?: string;
  email?: string | null;
  role?: string | null;
  hwid?: string;
}): { allowed: boolean; violation?: SecurityViolationRecord } {
  const { pathname = "", hash = "", search = "", email, role, hwid } = params;
  
  const cleanEmail = (email || "").toLowerCase().trim();
  const isAdminPath = 
    pathname.toLowerCase().includes("/admin") ||
    hash.toLowerCase().includes("admin") ||
    search.toLowerCase().includes("tab=admin") ||
    search.toLowerCase().includes("route=admin");

  if (!isAdminPath) {
    return { allowed: true };
  }

  // Admin route requested: verify authority
  const isAuthorized = isEmailInAdminWhitelist(cleanEmail);
  const activeToken = getActiveAdminSessionToken();
  const tokenValid = verifyAdminSessionToken(activeToken, cleanEmail);

  if (isAuthorized && tokenValid) {
    return { allowed: true };
  }

  // Unauthorized attempt detected! Abort and record violation
  clearPersistentAdminToken();
  const violation = logSecurityViolation({
    attemptedEmail: cleanEmail || "anonymous_or_unauthenticated",
    attemptedPath: `${pathname}${hash}${search}`,
    roleClaimed: role || "unknown",
    reason: !cleanEmail 
      ? "Unauthenticated attempt to access /admin route directly"
      : `Unauthorized email '${cleanEmail}' attempted to bypass RBAC to access /admin`,
    hwid: hwid || "unknown_hwid",
    actionTaken: 'ABORT_SESSION_REDIRECT'
  });

  return { allowed: false, violation };
}

/**
 * STRICT HARDWARE-BASED DEVICE FINGERPRINTING:
 * Computes a deterministic, cross-browser, hardware-level unique identifier (UUID)
 * based on screen resolution, hardware concurrency, navigator language, device memory,
 * color depth, and canvas 2D graphical rendering data.
 */
export async function generateDeviceHardwareUUID(): Promise<string> {
  if (typeof window === "undefined") {
    return "DEV_HW_SSR_SERVER";
  }

  // 1. Check persistent storage first
  try {
    const cached = localStorage.getItem("device_hardware_uuid");
    if (cached && cached.startsWith("DEV_HW_") && cached.length >= 20) {
      return cached;
    }
  } catch (e) {}

  // 2. Extract canvas rendering fingerprint
  let canvasData = "no_canvas";
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 240;
    canvas.height = 60;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.textBaseline = "top";
      ctx.font = "14px 'Arial', sans-serif";
      ctx.fillStyle = "#f60";
      ctx.fillRect(100, 1, 62, 20);
      ctx.fillStyle = "#069";
      ctx.fillText("TeleFlix Vault 🛡️", 2, 15);
      canvasData = canvas.toDataURL();
    }
  } catch (err) {
    canvasData = "canvas_err";
  }

  // 3. Extract screen and hardware traits
  const screenResolution = `${window.screen?.width || 0}x${window.screen?.height || 0}x${window.screen?.colorDepth || 24}`;
  const hardwareConcurrency = String(navigator.hardwareConcurrency || 4);
  const language = String(navigator.language || "en");
  const deviceMemory = String((navigator as any).deviceMemory || 4);
  const timeZone = Intl?.DateTimeFormat()?.resolvedOptions()?.timeZone || "UTC";

  const rawHardwareSignature = [
    screenResolution,
    hardwareConcurrency,
    language,
    deviceMemory,
    timeZone,
    canvasData
  ].join("###");

  // 4. Hash to SHA-256 or resilient hex hash
  let hexHash = "";
  try {
    if (window.crypto && window.crypto.subtle) {
      const msgBuffer = new TextEncoder().encode(rawHardwareSignature);
      const hashBuffer = await window.crypto.subtle.digest("SHA-256", msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      hexHash = hashArray.map(b => b.toString(16).padStart(2, "0")).join("").slice(0, 24);
    }
  } catch (e) {}

  if (!hexHash) {
    // Resilient 32-bit FNV fallback
    let hash = 2166136261;
    for (let i = 0; i < rawHardwareSignature.length; i++) {
      hash ^= rawHardwareSignature.charCodeAt(i);
      hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
    }
    hexHash = (hash >>> 0).toString(16).padStart(8, "0").repeat(3).slice(0, 24);
  }

  const hardwareUUID = `DEV_HW_${hexHash.toUpperCase()}`;

  // 5. Store permanently
  try {
    localStorage.setItem("device_hardware_uuid", hardwareUUID);
  } catch (e) {}

  return hardwareUUID;
}

/**
 * Checks if the current hardware device is locked to another account.
 * Examines both hardware device UUID and stored hardware lock bindings.
 */
export async function checkHardwareDeviceLock(incomingEmail?: string): Promise<{
  isBlocked: boolean;
  boundEmail?: string;
  hardwareUUID: string;
}> {
  const hardwareUUID = await generateDeviceHardwareUUID();
  const cleanIncoming = (incomingEmail || "").toLowerCase().trim();

  // Admin bypass
  if (cleanIncoming === "mostofa7077a@gmail.com") {
    return { isBlocked: false, boundEmail: cleanIncoming, hardwareUUID };
  }

  try {
    if (typeof window !== "undefined") {
      const bound = localStorage.getItem(`myteleflix_hw_uuid_lock_${hardwareUUID}`) ||
                    localStorage.getItem("myteleflix_device_primary_email");
      if (bound) {
        const cleanBound = bound.toLowerCase().trim();
        if (cleanIncoming && cleanIncoming !== cleanBound) {
          return {
            isBlocked: true,
            boundEmail: cleanBound,
            hardwareUUID
          };
        }
        return { isBlocked: false, boundEmail: cleanBound, hardwareUUID };
      }

      // Check remote database if local storage is empty (e.g. secondary browser or incognito)
      const apiRes = await fetch("/api/security/check-device-lock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hardware_uuid: hardwareUUID, email: cleanIncoming })
      }).catch(() => null);

      if (apiRes && apiRes.status === 403) {
        const data = await apiRes.json();
        return { isBlocked: true, boundEmail: data.primaryEmail, hardwareUUID };
      }
    }
  } catch (e) {}

  return { isBlocked: false, hardwareUUID };
}

/**
 * Permanently locks the device hardware UUID to the specified user email
 */
export async function bindHardwareDevice(email: string): Promise<string> {
  const hardwareUUID = await generateDeviceHardwareUUID();
  const cleanEmail = email.toLowerCase().trim();
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(`myteleflix_hw_uuid_lock_${hardwareUUID}`, cleanEmail);
      localStorage.setItem("device_hardware_uuid", hardwareUUID);
      localStorage.setItem("myteleflix_device_primary_email", cleanEmail);
    }
  } catch (e) {}
  return hardwareUUID;
}

