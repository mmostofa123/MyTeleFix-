/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Central Enterprise Constants for MyTeleFlix
 * Includes Token-to-BDT conversion rates, withdrawal packages, and community defaults.
 */

// 100,000 Tokens = 100 BDT (1 Token = 0.001 BDT)
export const TOKEN_TO_BDT_RATE = 0.001;
export const TOKENS_PER_BDT = 1000; // 1,000 tokens = 1 BDT, so 100,000 tokens = 100 BDT

// ==========================================
// STRICT ENTERPRISE ADMIN ROLE WHITELIST
// ==========================================
export const ADMIN_WHITELIST: readonly string[] = Object.freeze([
  "mostofa7077a@gmail.com"
]);
export const MASTER_ADMIN_EMAIL = "mostofa7077a@gmail.com";
export const ADMIN_EMAILS: string[] = [...ADMIN_WHITELIST];

/**
 * Checks if a given email is explicitly authorized in the ADMIN_WHITELIST
 */
export function isEmailInAdminWhitelist(email?: string | null): boolean {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return ADMIN_WHITELIST.some((adm) => adm.toLowerCase().trim() === clean);
}

/**
 * Instantly computes user role based on ADMIN_WHITELIST
 * Returns 'ADMIN' if whitelisted, otherwise 'USER'
 */
export function computeUserRole(email?: string | null): 'ADMIN' | 'USER' {
  return isEmailInAdminWhitelist(email) ? 'ADMIN' : 'USER';
}


// Minimum cashout threshold (100,000 Tokens = 100 BDT)
export const MIN_WITHDRAWAL_TOKENS = 100000;
export const MIN_WITHDRAWAL_BDT = 100;

// Maximum daily withdrawal threshold
export const MAX_DAILY_WITHDRAWAL_TOKENS = 5000000;

// Quick Withdrawal Packages
export interface WithdrawalPackage {
  id: string;
  points: number;
  bdt: number;
  label: string;
  popular?: boolean;
}

export const QUICK_WITHDRAWAL_PACKAGES: WithdrawalPackage[] = [
  {
    id: "pkg_100k",
    points: 100000,
    bdt: 100,
    label: "100,000",
  },
  {
    id: "pkg_250k",
    points: 250000,
    bdt: 250,
    label: "250,000",
    popular: true,
  },
  {
    id: "pkg_500k",
    points: 500000,
    bdt: 500,
    label: "500,000",
  },
  {
    id: "pkg_1m",
    points: 1000000,
    bdt: 1000,
    label: "1,000,000",
  },
];

// Exclusive Payment Gateways
export type SupportedPaymentGateway = "bKash" | "Nagad";

export const PAYMENT_GATEWAYS: {
  id: SupportedPaymentGateway;
  name: string;
  brandColor: string;
  bgActive: string;
  borderActive: string;
  ringColor: string;
  badge: string;
  accountType: "Personal" | "Agent";
}[] = [
  {
    id: "bKash",
    name: "bKash",
    brandColor: "#E2136E",
    bgActive: "bg-[#360D23]",
    borderActive: "border-[#E2136E]",
    ringColor: "ring-[#E2136E]/40",
    badge: "Personal",
    accountType: "Personal",
  },
  {
    id: "Nagad",
    name: "Nagad",
    brandColor: "#FA541C",
    bgActive: "bg-[#3A1608]",
    borderActive: "border-[#FA541C]",
    ringColor: "ring-[#FA541C]/40",
    badge: "Personal",
    accountType: "Personal",
  },
];

// Helper to convert Tokens to BDT
export function tokensToBdt(tokens: number): number {
  if (!tokens || tokens <= 0) return 0;
  return Math.floor(tokens * TOKEN_TO_BDT_RATE * 100) / 100;
}

// Helper to format BDT currency
export function formatBdt(amount: number): string {
  return `৳ ${amount.toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// Official Telegram Support links
export const DEFAULT_TELEGRAM_SUPPORT_LINK = "https://t.me/myteleflix";
export const DEFAULT_TELEGRAM_COMMUNITY_LINK = "https://t.me/myteleflix";
