/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { User } from "../types";
import { getDeviceFingerprint, getCachedDeviceFingerprint, getGuestDeviceId } from "../utils/fingerprint";
import { 
  auth, 
  googleProvider, 
  saveUserToFirestore, 
  getUserFromFirestore, 
  isUserInAdminWhitelist, 
  ensureSuperAdminExists,
  DEFAULT_SUPER_ADMIN_EMAILS
} from "../services/firebase";
import { signInWithPopup, signOut as firebaseSignOut, onAuthStateChanged } from "firebase/auth";
import { 
  generateHardwareId, 
  generateCrossBrowserHardwareId,
  getCrossBrowserHardwareTraits,
  getHardwareId, 
  checkDeviceLock, 
  bindDeviceLock, 
  getBoundPrimaryEmail, 
  clearSecondaryDraftSession,
  isSuperAdminBypass
} from "../SecurityManager";
import SecurityWarningModal from "../SecurityWarningModal";
import { logSecurityNotice } from "../NoticeBox";
import { 
  saveUserProfileDB, 
  getUserProfileDB, 
  purgeSessionRetainLock, 
  generateTeleFlixUid,
  formatTelegramHandle,
  saveRoleLockDB,
  getRoleLockDB,
  isRoleLockedAdminDB,
  UserProfileData 
} from "../db";
import { 
  ADMIN_WHITELIST,
  ADMIN_EMAILS, 
  MASTER_ADMIN_EMAIL, 
  isEmailInAdminWhitelist, 
  computeUserRole 
} from "../constants";
import {
  evaluateAuthorityGateway,
  clearPersistentAdminToken,
  getActiveAdminSessionToken,
  verifyAdminSessionToken,
  AuthorityGatewayResult,
  generateDeviceHardwareUUID,
  bindHardwareDevice,
  checkHardwareDeviceLock
} from "../SecurityGuard";
import { getDiceBearAvatar, getHumanAvatar, isUnsplashOrBrokenPhoto } from "../utils/avatar";

export { ADMIN_WHITELIST, ADMIN_EMAILS, MASTER_ADMIN_EMAIL };
export const MASTER_ADMIN_PIN = "7077";
export const SUPER_ADMIN_EMAILS = ADMIN_EMAILS;
export const SUPER_ADMIN_EMAIL = MASTER_ADMIN_EMAIL;
export const SUPER_ADMIN_TELEGRAM_ID = "703119315615";
export const SUPER_ADMIN_USERNAME = "mostofashowkat";

/**
 * Resolves authentic user profile picture, filtering out broken/robot links with fallback to real human portraits.
 */
const resolveEffectivePhoto = (primaryPhoto?: string | null, fallbackGender?: string | null, id?: string | number | null): string => {
  if (primaryPhoto && !isUnsplashOrBrokenPhoto(primaryPhoto)) {
    return primaryPhoto;
  }
  return getHumanAvatar(fallbackGender, id);
};

/**
 * Zero-Trust Admin Email Check:
 * Strictly verifies against ADMIN_WHITELIST.
 */
export const isAuthorizedAdmin = (email?: string | null, assignedAdmins?: string[]): boolean => {
  if (!email) return false;
  const clean = email.toLowerCase().trim();
  return isEmailInAdminWhitelist(clean);
};

export const isSuperAdminEmail = (email?: string | null, assignedAdmins?: string[]): boolean => {
  return isAuthorizedAdmin(email, assignedAdmins);
};

interface AuthContextType {
  user: User | null;
  role: 'user' | 'guest' | 'admin' | 'super_admin' | 'ADMIN' | 'USER';
  deviceFingerprint: string;
  guestDeviceId: string;
  isGuest: boolean;
  isTelegram: boolean;
  telegramUser: {
    id: string;
    username: string;
    firstName: string;
    lastName: string;
    photoUrl?: string;
  } | null;
  isSyncing: boolean;
  isLockedToExisting: boolean;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  setRole: React.Dispatch<React.SetStateAction<'user' | 'guest' | 'admin' | 'super_admin' | 'ADMIN' | 'USER'>>;
  loginWithTelegram: (startParam?: string) => Promise<User>;
  loginWithGoogle: (googleData?: { email?: string; fullName?: string; photoUrl?: string; googleId?: string; adminPasskey?: string; gender?: 'male' | 'female' }, startParam?: string) => Promise<User>;
  triggerGooglePopupAuth: () => Promise<User>;
  updateGender: (gender: 'male' | 'female') => Promise<void>;
  updateUserProfile: (updates: Partial<User>) => Promise<void>;
  logout: () => void;
  recordSessionActivity: () => Promise<void>;
  verifyMasterPin: (pin: string) => boolean;
  hwid: string;
  securityWarning: {
    isOpen: boolean;
    primaryEmail: string;
    attemptedEmail?: string;
    hwid?: string;
    message?: string;
  } | null;
  triggerSecurityWarning: (data: { primaryEmail: string; attemptedEmail?: string; hwid?: string; message?: string }) => void;
  dismissSecurityWarning: () => void;
  switchToPrimaryAccount: (targetEmail?: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function createInitialGuestUser(fp: string, guestId: string): User {
  return {
    id: guestId,
    telegramId: "",
    username: "guest_visitor",
    fullName: "Guest Visitor",
    photoUrl: "",
    role: 'guest',
    points: 0,
    createdAt: new Date().toISOString(),
    last_active_at: new Date().toISOString(),
    device_fingerprint: fp,
    isPremium: false,
    authProvider: 'guest',
    guest_device_id: guestId
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [deviceFingerprint, setDeviceFingerprint] = useState<string>(() => getCachedDeviceFingerprint());
  const [guestDeviceId, setGuestDeviceId] = useState<string>(() => getGuestDeviceId(getCachedDeviceFingerprint()));

  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("myteleflix_user");
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          if (parsed && parsed.id) {
            if (parsed.role === 'guest' || parsed.id.startsWith('guest_')) {
              parsed.role = 'guest';
            } else {
              // ZERO-TRUST AUTHORITY GATEWAY RESOLUTION:
              // Automatically evaluate email through the Authority Gateway BEFORE trusting role
              const cleanEmail = (parsed.email || "").toLowerCase().trim();
              const authResult = evaluateAuthorityGateway(cleanEmail);
              parsed.role = authResult.role;
            }
            return parsed;
          }
        } catch (e) {
          console.warn("Failed to parse saved user in AuthProvider:", e);
        }
      }
    }
    const fp = getCachedDeviceFingerprint();
    const guestId = getGuestDeviceId(fp);
    return createInitialGuestUser(fp, guestId);
  });

  const [role, setRole] = useState<'user' | 'guest' | 'admin' | 'super_admin' | 'ADMIN' | 'USER'>(() => {
    if (user?.role === 'guest') return 'guest';
    if (user?.email) {
      const authResult = evaluateAuthorityGateway(user.email);
      return authResult.role;
    }
    return 'USER';
  });

  // Rehydrate persistent profile from IndexedDB on startup or user change
  useEffect(() => {
    if (user?.email && user.role !== 'guest') {
      getUserProfileDB(user.email).then((cachedProfile) => {
        if (cachedProfile) {
          setUser((prev) => {
            if (!prev) return prev;
            return {
              ...prev,
              displayName: cachedProfile.displayName || prev.displayName,
              fullName: cachedProfile.displayName || prev.fullName,
              gender: cachedProfile.gender ? (cachedProfile.gender.toLowerCase() as 'male' | 'female') : prev.gender,
              telegramUsername: cachedProfile.telegramHandle || prev.telegramUsername,
              photoURL: cachedProfile.photoURL || prev.photoURL,
              photoUrl: cachedProfile.photoURL || prev.photoUrl,
            };
          });
        }
      }).catch(() => {});
    }
  }, [user?.email]);

  const isGuest = role === 'guest' || !user || user.role === 'guest';
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLockedToExisting, setIsLockedToExisting] = useState(false);

  // Hardware ID & Strict Security Engine State
  const [hwid, setHwid] = useState<string>(() => getHardwareId());
  const [securityWarning, setSecurityWarning] = useState<{
    isOpen: boolean;
    primaryEmail: string;
    attemptedEmail?: string;
    hwid?: string;
    message?: string;
  } | null>(null);

  const triggerSecurityWarning = useCallback((data: {
    primaryEmail: string;
    attemptedEmail?: string;
    hwid?: string;
    message?: string;
  }) => {
    // Immediately terminate any unauthorized session and enforce strictly logged-out state
    clearSecondaryDraftSession();
    try {
      localStorage.removeItem("myteleflix_user");
      localStorage.removeItem("myteleflix_auth_token");
      localStorage.removeItem("myteleflix_current_session");
      firebaseSignOut(auth).catch(() => {});
    } catch (e) {}
    setUser(null);
    setRole('guest');
    setIsSyncing(false);

    setSecurityWarning({
      isOpen: true,
      primaryEmail: data.primaryEmail,
      attemptedEmail: data.attemptedEmail,
      hwid: data.hwid || hwid,
      message: data.message || "আমাদের প্ল্যাটফর্মের সুরক্ষা ও ফেয়ার রিওয়ার্ড বজায় রাখতে একটি ডিভাইসের জন্য শুধুমাত্র একটি মূল অ্যাকাউন্ট বরাদ্দ। আপনি এই ডিভাইসে নতুন বা ভিন্ন কোনো অ্যাকাউন্টে প্রবেশ করতে পারবেন না। আপনার এই প্রচেষ্টা অবিলম্বে ব্লক করা হয়েছে এবং আপনাকে লগআউট অবস্থায় রাখা হয়েছে।"
    });
  }, [hwid]);

  const dismissSecurityWarning = useCallback(() => {
    // Dismissing strictly keeps the user in logged-out state
    clearSecondaryDraftSession();
    try {
      localStorage.removeItem("myteleflix_user");
      localStorage.removeItem("myteleflix_auth_token");
      localStorage.removeItem("myteleflix_current_session");
      firebaseSignOut(auth).catch(() => {});
    } catch (e) {}
    setUser(null);
    setRole('guest');
    setIsSyncing(false);
    setSecurityWarning(null);
  }, []);

  // Initialize and ensure Hardware ID is persistently generated on startup
  useEffect(() => {
    generateHardwareId().then((generatedHwid) => {
      setHwid(generatedHwid);
    });
  }, []);

  // Detect Telegram environment
  const [isTelegram, setIsTelegram] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return Boolean((window as any).Telegram?.WebApp?.initDataUnsafe?.user?.id);
  });

  const [telegramUser, setTelegramUser] = useState<{
    id: string;
    username: string;
    firstName: string;
    lastName: string;
    photoUrl?: string;
  } | null>(() => {
    if (typeof window === "undefined") return null;
    const tgUser = (window as any).Telegram?.WebApp?.initDataUnsafe?.user;
    if (tgUser && tgUser.id) {
      return {
        id: String(tgUser.id),
        username: tgUser.username || `tg_${tgUser.id}`,
        firstName: tgUser.first_name || "Telegram",
        lastName: tgUser.last_name || "User",
        photoUrl: tgUser.photo_url || ""
      };
    }
    return null;
  });

  // Calculate & persist device fingerprint and guest device ID on startup
  useEffect(() => {
    let isMounted = true;
    getDeviceFingerprint().then((fp) => {
      if (isMounted && fp) {
        setDeviceFingerprint(fp);
        const guestId = getGuestDeviceId(fp);
        setGuestDeviceId(guestId);
        setUser((prev) => {
          if (!prev || prev.role === 'guest') {
            return {
              ...(prev || createInitialGuestUser(fp, guestId)),
              id: guestId,
              device_fingerprint: fp,
              guest_device_id: guestId
            };
          }
          return prev;
        });
      }
    });

    // Check Telegram environment ready
    if (typeof window !== "undefined" && (window as any).Telegram?.WebApp) {
      try {
        (window as any).Telegram.WebApp.ready();
        (window as any).Telegram.WebApp.expand();
        const tgUser = (window as any).Telegram.WebApp.initDataUnsafe?.user;
        if (tgUser && tgUser.id) {
          setIsTelegram(true);
          setTelegramUser({
            id: String(tgUser.id),
            username: tgUser.username || `tg_${tgUser.id}`,
            firstName: tgUser.first_name || "Telegram",
            lastName: tgUser.last_name || "User",
            photoUrl: tgUser.photo_url || ""
          });
        }
      } catch (e) {
        console.warn("Telegram WebApp initialization error:", e);
      }
    }

    return () => {
      isMounted = false;
    };
  }, []);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const email = (fbUser.email || "").toLowerCase().trim();
          const currentHwid = hwid && hwid.startsWith("HWID_") ? hwid : getHardwareId();

          // HARDWARE DEVICE SECURITY CHECK
          if (email && !isSuperAdminBypass(email)) {
            const lockCheck = await checkDeviceLock(currentHwid, email);
            if (lockCheck.isBlocked) {
              await firebaseSignOut(auth).catch(() => {});
              clearSecondaryDraftSession();
              try {
                localStorage.removeItem("myteleflix_user");
                localStorage.removeItem("myteleflix_auth_token");
                localStorage.removeItem("myteleflix_current_session");
              } catch (e) {}
              setUser(null);
              setRole('guest');
              setIsSyncing(false);
              logSecurityNotice({
                primaryEmail: lockCheck.primaryEmail,
                attemptedEmail: email,
                hwid: currentHwid
              });
              triggerSecurityWarning({
                primaryEmail: lockCheck.primaryEmail || "Authorized Account",
                attemptedEmail: email,
                hwid: currentHwid,
                message: "আমাদের প্ল্যাটফর্মের সুরক্ষা ও ফেয়ার রিওয়ার্ড বজায় রাখতে একটি ডিভাইসের জন্য শুধুমাত্র একটি মূল অ্যাকাউন্ট বরাদ্দ। আপনি এই ডিভাইসে নতুন বা ভিন্ন কোনো অ্যাকাউন্টে প্রবেশ করতে পারবেন না। আপনার এই প্রচেষ্টা অবিলম্বে ব্লক করা হয়েছে।"
              });
              return;
            }
          }

          // ========================================================
          // INSTANT AUTHORITY GATEWAY ENGINE (Zero-Trust RBAC)
          // Run email through Authority Gateway BEFORE creating or fetching profile
          // MATCH FOUND: role 'ADMIN', master dashboard privileges, persistent admin token
          // NO MATCH: role 'USER', immutable user permissions, normal user dashboard
          // ========================================================
          const authority = evaluateAuthorityGateway(email);
          const assignedRole: 'ADMIN' | 'USER' = authority.role;
          await saveRoleLockDB(email, assignedRole, authority.authorityToken || undefined);

          if (assignedRole === 'ADMIN') {
            await ensureSuperAdminExists(email, fbUser.displayName || undefined);
          }

          // Fetch existing user data from Firestore
          const firestoreDoc = await getUserFromFirestore(fbUser.uid);
          const cachedProfile = await getUserProfileDB(email);

          const fp = deviceFingerprint || getCachedDeviceFingerprint();
          const gId = guestDeviceId || getGuestDeviceId(fp);

          const resolvedName = cachedProfile?.displayName || fbUser.displayName || firestoreDoc?.displayName || firestoreDoc?.fullName || fbUser.email?.split("@")[0] || "Google Member";
          const resolvedGender = cachedProfile?.gender ? (cachedProfile.gender.toLowerCase() as 'male' | 'female') : firestoreDoc?.gender;
          const resolvedTg = cachedProfile?.telegramHandle || firestoreDoc?.telegramUsername || "";
          const teleflixUid = cachedProfile?.uid || generateTeleFlixUid(fbUser.uid);
          const rawPhoto = fbUser.photoURL || firestoreDoc?.photoURL || firestoreDoc?.photoUrl || cachedProfile?.photoURL;
          const resolvedPhoto = resolveEffectivePhoto(rawPhoto, resolvedGender, fbUser.uid || teleflixUid);

          const updatedUser: User = {
            id: fbUser.uid,
            googleId: fbUser.uid,
            telegramId: firestoreDoc?.telegramId || cachedProfile?.telegramId || "",
            telegramUsername: resolvedTg,
            username: firestoreDoc?.username || fbUser.email?.split("@")[0] || "google_user",
            fullName: resolvedName,
            displayName: resolvedName,
            email: fbUser.email || firestoreDoc?.email || "",
            photoUrl: resolvedPhoto,
            photoURL: resolvedPhoto,
            gender: resolvedGender,
            points: firestoreDoc?.points ?? 100,
            createdAt: cachedProfile?.joinDate || firestoreDoc?.createdAt || new Date().toISOString(),
            last_active_at: new Date().toISOString(),
            device_fingerprint: fp,
            guest_device_id: gId,
            isPremium: firestoreDoc?.isPremium || false,
            role: assignedRole,
            authProvider: 'google',
            onboardingCompleted: Boolean((firestoreDoc as any)?.onboardingCompleted ?? firestoreDoc?.isOnboarded ?? firestoreDoc?.profileInitialized),
            isOnboarded: Boolean((firestoreDoc as any)?.onboardingCompleted ?? firestoreDoc?.isOnboarded ?? firestoreDoc?.profileInitialized),
            profileInitialized: Boolean((firestoreDoc as any)?.onboardingCompleted ?? firestoreDoc?.profileInitialized ?? firestoreDoc?.isOnboarded),
            isProfileCompleted: Boolean((firestoreDoc as any)?.onboardingCompleted ?? firestoreDoc?.isProfileCompleted),
            profileStatus: firestoreDoc?.profileStatus || (firestoreDoc?.isProfileCompleted ? 'completed' : 'pending'),
            status: 'active'
          };

          // Synchronize back to Firestore
          await saveUserToFirestore(updatedUser);

          // Save to persistent IndexedDB
          await saveUserProfileDB({
            uid: teleflixUid,
            email: email,
            displayName: resolvedName,
            gender: resolvedGender === 'female' ? 'Female' : resolvedGender === 'other' ? 'Other' : 'Male',
            telegramHandle: formatTelegramHandle(resolvedTg),
            telegramId: firestoreDoc?.telegramId || cachedProfile?.telegramId || "",
            photoURL: resolvedPhoto,
            joinDate: cachedProfile?.joinDate || firestoreDoc?.createdAt || new Date().toISOString(),
            role: assignedRole === 'ADMIN' ? 'ADMIN' : 'USER',
            points: firestoreDoc?.points ?? 100,
            hwid: currentHwid,
            isProfileCompleted: Boolean(firestoreDoc?.isProfileCompleted),
            profileStatus: firestoreDoc?.profileStatus || (firestoreDoc?.isProfileCompleted ? 'completed' : 'pending')
          });

          // Auto-bind device lock to primary email
          if (email) {
            bindDeviceLock(email, fbUser.uid, currentHwid).catch(() => {});
          }

          setUser(updatedUser);
          setRole(assignedRole);
          localStorage.setItem("myteleflix_user", JSON.stringify(updatedUser));
        } catch (err) {
          console.warn("Notice: onAuthStateChanged Firestore sync:", err);
        }
      }
    });

    return () => unsubscribe();
  }, [deviceFingerprint, guestDeviceId, hwid, triggerSecurityWarning]);

  // Synchronize role whenever user state updates - Strict Admin-User Isolation & Zero-Trust Enforcement
  useEffect(() => {
    if (user) {
      if (user.role === 'guest' || user.id?.startsWith('guest_')) {
        if (role !== 'guest') setRole('guest');
      } else {
        const cleanEmail = (user.email || "").toLowerCase().trim();
        const isAdmin = isAuthorizedAdmin(cleanEmail, user.assignedAdmins);
        const expectedRole: 'ADMIN' | 'USER' = isAdmin ? 'ADMIN' : 'USER';

        if (user.role !== expectedRole) {
          setUser(prev => prev ? { ...prev, role: expectedRole } : null);
        }
        if (role !== expectedRole) {
          setRole(expectedRole);
        }
      }
    }
  }, [user?.email, user?.role, user?.assignedAdmins]);

  // Record session activity timestamp (last_active_at)
  const recordSessionActivity = useCallback(async () => {
    if (!user?.id || user.role === 'guest') return;
    try {
      const fp = deviceFingerprint || getCachedDeviceFingerprint();
      const now = new Date().toISOString();
      await saveUserToFirestore({ id: user.id, last_active_at: now });
      setUser(prev => prev ? { ...prev, last_active_at: now } : prev);
      fetch(`/api/auth?userId=${encodeURIComponent(user.id)}&device_fingerprint=${encodeURIComponent(fp)}`).catch(() => {});
    } catch (e) {
      console.warn("Session activity sync warning:", e);
    }
  }, [user?.id, user?.role, deviceFingerprint]);

  // Telegram Authentication with Device Fingerprint Hard-Lock & Guest Merge
  const loginWithTelegram = useCallback(async (startParam?: string): Promise<User> => {
    setIsSyncing(true);
    const fp = await getDeviceFingerprint();
    setDeviceFingerprint(fp);
    const gId = getGuestDeviceId(fp);
    setGuestDeviceId(gId);

    const tgUser = (typeof window !== "undefined") ? (window as any).Telegram?.WebApp?.initDataUnsafe?.user : null;
    const resolvedStartParam = startParam || (typeof window !== "undefined" 
      ? ((window as any).Telegram?.WebApp?.initDataUnsafe?.start_param || new URLSearchParams(window.location.search).get("ref") || undefined)
      : undefined);

    const payload = tgUser ? {
      telegramId: String(tgUser.id),
      username: tgUser.username,
      firstName: tgUser.first_name,
      lastName: tgUser.last_name,
      photoUrl: tgUser.photo_url,
      startParam: resolvedStartParam,
      device_fingerprint: fp,
      guest_device_id: gId
    } : {
      telegramId: "703119315615",
      username: "mostofashowkat",
      firstName: "Mostofa",
      lastName: "Showkat",
      photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
      startParam: resolvedStartParam,
      device_fingerprint: fp,
      guest_device_id: gId
    };

    try {
      const response = await fetch("/api/auth/telegram", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Telegram-Init-Data": (typeof window !== "undefined" ? (window as any).Telegram?.WebApp?.initData || "" : "")
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      if (data.user) {
        const u = data.user;
        const cleanEmail = (u.email || "").toLowerCase().trim();
        const isTargetAdmin = isAuthorizedAdmin(cleanEmail, u.assignedAdmins);
        u.role = isTargetAdmin ? 'ADMIN' : 'USER';

        if (data.isLockedToExisting) {
          setIsLockedToExisting(true);
        }
        setUser(u);
        setRole(isTargetAdmin ? 'ADMIN' : 'USER');
        localStorage.setItem("myteleflix_user", JSON.stringify(u));
        // Also persist to Firestore
        await saveUserToFirestore(u);
        setIsSyncing(false);
        return u;
      }
      throw new Error("No user returned from Telegram auth");
    } catch (err) {
      console.warn("Telegram auth backend offline fallback active:", err);
      // Strict fallback: all standard users receive 'USER' role without administrative access
      const fallbackUser: User = {
        id: `tg-${payload.telegramId}`,
        telegramId: String(payload.telegramId),
        username: payload.username || "telegram_user",
        fullName: [payload.firstName, payload.lastName].filter(Boolean).join(" ") || "Telegram User",
        photoUrl: payload.photoUrl || getDiceBearAvatar('male', payload.telegramId),
        points: 100,
        createdAt: new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        device_fingerprint: fp,
        guest_device_id: gId,
        isPremium: false,
        role: 'USER',
        authProvider: 'telegram'
      };
      setUser(fallbackUser);
      setRole('USER');
      localStorage.setItem("myteleflix_user", JSON.stringify(fallbackUser));
      await saveUserToFirestore(fallbackUser);
      setIsSyncing(false);
      return fallbackUser;
    }
  }, []);

  // Native Google Popup Authentication via Firebase Auth
  const triggerGooglePopupAuth = useCallback(async (): Promise<User> => {
    setIsSyncing(true);
    const fp = await getDeviceFingerprint();
    setDeviceFingerprint(fp);
    const gId = getGuestDeviceId(fp);
    setGuestDeviceId(gId);
    const currentHwid = hwid && hwid.startsWith("HWID_") ? hwid : await generateHardwareId();
    setHwid(currentHwid);

    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const email = (fbUser.email || "").toLowerCase().trim();

      // STRICT HARDWARE ANTI-MULTI ACCOUNT CHECK:
      // Prevent multi-account usage by binding Hardware IDs (HwID) to specific Google accounts.
      if (email && !isSuperAdminBypass(email)) {
        const lockCheck = await checkDeviceLock(currentHwid, email);
        if (lockCheck.isBlocked) {
          // Block immediately: do NOT create account, do NOT issue auth tokens
          await firebaseSignOut(auth).catch(() => {});
          clearSecondaryDraftSession();
          try {
            localStorage.removeItem("myteleflix_user");
            localStorage.removeItem("myteleflix_auth_token");
            localStorage.removeItem("myteleflix_current_session");
          } catch (e) {}
          setUser(null);
          setRole('guest');
          setIsSyncing(false);

          // Log entry into NoticeBox under System tab
          logSecurityNotice({
            primaryEmail: lockCheck.primaryEmail,
            attemptedEmail: email,
            hwid: currentHwid
          });

          const bengaliBlockMsg = "আমাদের প্ল্যাটফর্মের সুরক্ষা নীতি অনুযায়ী এক ডিভাইসে কেবল একটি অ্যাকাউন্ট অনুমোদিত। আপনি এই ডিভাইসে নতুন বা একাধিক অ্যাকাউন্ট তৈরি করতে পারবেন না।";

          // Trigger strict security warning modal
          triggerSecurityWarning({
            primaryEmail: lockCheck.primaryEmail || "Authorized Primary Account",
            attemptedEmail: email,
            hwid: currentHwid,
            message: bengaliBlockMsg
          });

          const blockedErr: any = new Error(bengaliBlockMsg);
          blockedErr.blocked = true;
          blockedErr.primaryEmail = lockCheck.primaryEmail;
          blockedErr.hwid = currentHwid;
          throw blockedErr;
        }
      }

      // ========================================================
      // INSTANT AUTHORITY GATEWAY ENGINE (Zero-Trust RBAC)
      // Run email through Authority Gateway BEFORE fetching/creating profile
      // MATCH FOUND: role 'ADMIN', master dashboard privileges, persistent admin token
      // NO MATCH: role 'USER', immutable user permissions, normal user dashboard
      // ========================================================
      const authority = evaluateAuthorityGateway(email);
      const assignedRole: 'ADMIN' | 'USER' = authority.role;
      await saveRoleLockDB(email, assignedRole, authority.authorityToken || undefined);

      if (assignedRole === 'ADMIN') {
        await ensureSuperAdminExists(email, fbUser.displayName || undefined);
      }

      const existingDoc = await getUserFromFirestore(fbUser.uid);
      const cachedProfile = await getUserProfileDB(email);

      const resolvedName = cachedProfile?.displayName || fbUser.displayName || existingDoc?.displayName || existingDoc?.fullName || email.split("@")[0] || "Google Member";
      const resolvedGender = cachedProfile?.gender ? (cachedProfile.gender.toLowerCase() as 'male' | 'female') : existingDoc?.gender;
      const resolvedTg = cachedProfile?.telegramHandle || existingDoc?.telegramUsername || "";
      const teleflixUid = cachedProfile?.uid || generateTeleFlixUid(fbUser.uid);
      const rawPhoto = fbUser.photoURL || existingDoc?.photoURL || existingDoc?.photoUrl || cachedProfile?.photoURL;
      const resolvedPhoto = resolveEffectivePhoto(rawPhoto, resolvedGender, fbUser.uid || teleflixUid);

      const loggedUser: User = {
        id: fbUser.uid,
        googleId: fbUser.uid,
        telegramId: existingDoc?.telegramId || "",
        telegramUsername: resolvedTg,
        username: fbUser.email?.split("@")[0] || "google_user",
        fullName: resolvedName,
        displayName: resolvedName,
        email,
        photoUrl: resolvedPhoto,
        photoURL: resolvedPhoto,
        gender: resolvedGender,
        points: existingDoc?.points ?? 100,
        createdAt: cachedProfile?.joinDate || existingDoc?.createdAt || new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        device_fingerprint: fp,
        guest_device_id: gId,
        isPremium: false,
        role: assignedRole,
        authProvider: 'google',
        onboardingCompleted: Boolean((existingDoc as any)?.onboardingCompleted ?? existingDoc?.isOnboarded ?? existingDoc?.profileInitialized),
        isOnboarded: Boolean((existingDoc as any)?.onboardingCompleted ?? existingDoc?.isOnboarded ?? existingDoc?.profileInitialized),
        profileInitialized: Boolean((existingDoc as any)?.onboardingCompleted ?? existingDoc?.profileInitialized ?? existingDoc?.isOnboarded),
        isProfileCompleted: Boolean((existingDoc as any)?.onboardingCompleted ?? existingDoc?.isProfileCompleted),
        status: 'active'
      };

      // Write to Firestore /users collection permanently
      await saveUserToFirestore(loggedUser);

      // Save to persistent IndexedDB
      await saveUserProfileDB({
        uid: teleflixUid,
        email: email,
        displayName: resolvedName,
        gender: resolvedGender === 'female' ? 'Female' : 'Male',
        telegramHandle: formatTelegramHandle(resolvedTg),
        photoURL: resolvedPhoto,
        joinDate: cachedProfile?.joinDate || existingDoc?.createdAt || new Date().toISOString(),
        role: assignedRole === 'ADMIN' ? 'ADMIN' : 'USER',
        points: existingDoc?.points ?? 100,
        hwid: currentHwid
      });

      // Bind device lock on first registration or if not yet bound
      if (email) {
        const hardwareUUID = await bindHardwareDevice(email);
        loggedUser.device_hardware_uuid = hardwareUUID;
        await bindDeviceLock(email, fbUser.uid, currentHwid);
      }

      setUser(loggedUser);
      setRole(assignedRole);
      localStorage.setItem("myteleflix_user", JSON.stringify(loggedUser));

      const crossHwid = await generateCrossBrowserHardwareId();
      const traits = getCrossBrowserHardwareTraits();

      // Also register on local server if active
      fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: loggedUser.email,
          fullName: loggedUser.fullName,
          photoUrl: loggedUser.photoUrl,
          googleId: loggedUser.googleId,
          device_fingerprint: fp,
          guest_device_id: gId,
          hwid: currentHwid,
          cross_browser_hwid: crossHwid,
          gpu_renderer: traits.gpu_renderer,
          gpu_chipset: traits.gpu_chipset,
          screen_resolution: traits.screen_resolution,
          physical_screen: traits.physical_screen,
          hardware_concurrency: traits.hardware_concurrency,
          cpu_cores: traits.cpu_cores,
          timezone: traits.timezone,
          platform: traits.platform,
          platform_family: traits.platform_family
        })
      }).catch(() => {});

      setIsSyncing(false);
      return loggedUser;
    } catch (popupErr: any) {
      setIsSyncing(false);
      throw popupErr;
    }
  }, [guestDeviceId, hwid, triggerSecurityWarning]);

  // Google Authentication with Dual Firebase Popup & 1-Click Fast Sync
  const loginWithGoogle = useCallback(async (
    googleData?: { email?: string; fullName?: string; photoUrl?: string; googleId?: string; adminPasskey?: string; gender?: 'male' | 'female' },
    startParam?: string
  ): Promise<User> => {
    setIsSyncing(true);
    const fp = await getDeviceFingerprint();
    setDeviceFingerprint(fp);
    const gId = getGuestDeviceId(fp);
    setGuestDeviceId(gId);
    const currentHwid = hwid && hwid.startsWith("HWID_") ? hwid : await generateHardwareId();
    setHwid(currentHwid);

    // If an email is provided (from quick 1-click account button)
    if (googleData?.email) {
      const targetEmail = googleData.email.trim().toLowerCase();

      // STRICT HARDWARE ANTI-MULTI ACCOUNT CHECK
      if (targetEmail && !isSuperAdminBypass(targetEmail)) {
        const lockCheck = await checkDeviceLock(currentHwid, targetEmail);
        if (lockCheck.isBlocked) {
          clearSecondaryDraftSession();
          try {
            localStorage.removeItem("myteleflix_user");
            localStorage.removeItem("myteleflix_auth_token");
            localStorage.removeItem("myteleflix_current_session");
          } catch (e) {}
          setUser(null);
          setRole('guest');
          setIsSyncing(false);

          logSecurityNotice({
            primaryEmail: lockCheck.primaryEmail,
            attemptedEmail: targetEmail,
            hwid: currentHwid
          });

          const bengaliBlockMsg = "আমাদের প্ল্যাটফর্মের সুরক্ষা নীতি অনুযায়ী এক ডিভাইসে কেবল একটি অ্যাকাউন্ট অনুমোদিত। আপনি এই ডিভাইসে নতুন বা একাধিক অ্যাকাউন্ট তৈরি করতে পারবেন না।";

          triggerSecurityWarning({
            primaryEmail: lockCheck.primaryEmail || "Authorized Primary Account",
            attemptedEmail: targetEmail,
            hwid: currentHwid,
            message: bengaliBlockMsg
          });

          const blockedErr: any = new Error(bengaliBlockMsg);
          blockedErr.blocked = true;
          blockedErr.primaryEmail = lockCheck.primaryEmail;
          blockedErr.hwid = currentHwid;
          throw blockedErr;
        }
      }

      // ========================================================
      // INSTANT AUTHORITY GATEWAY ENGINE (Zero-Trust RBAC)
      // Run email through Authority Gateway BEFORE creating or fetching profile
      // MATCH FOUND: role 'ADMIN', master dashboard privileges, persistent admin token
      // NO MATCH: role 'USER', immutable user permissions, normal user dashboard
      // ========================================================
      const authority = evaluateAuthorityGateway(targetEmail);
      const assignedRole: 'ADMIN' | 'USER' = authority.role;
      await saveRoleLockDB(targetEmail, assignedRole, authority.authorityToken || undefined);

      if (assignedRole === 'ADMIN') {
        await ensureSuperAdminExists(targetEmail, googleData.fullName || undefined);
      }

      const calculatedId = googleData.googleId || `g-${targetEmail.replace(/[^a-zA-Z0-9]/g, '_')}`;
      const existingDoc = await getUserFromFirestore(calculatedId);
      const resolvedGender = googleData.gender || existingDoc?.gender || 'male';
      const rawTargetPhoto = googleData.photoUrl || existingDoc?.photoUrl || existingDoc?.photoURL;
      const resolvedPhoto = resolveEffectivePhoto(rawTargetPhoto, resolvedGender, calculatedId);

      const targetUser: User = {
        id: calculatedId,
        googleId: calculatedId,
        telegramId: existingDoc?.telegramId || "",
        username: targetEmail.split("@")[0],
        fullName: googleData.fullName || existingDoc?.fullName || targetEmail.split("@")[0],
        email: targetEmail,
        gender: resolvedGender,
        photoUrl: resolvedPhoto,
        photoURL: resolvedPhoto,
        points: existingDoc?.points ?? 100,
        createdAt: existingDoc?.createdAt || new Date().toISOString(),
        last_active_at: new Date().toISOString(),
        device_fingerprint: fp,
        guest_device_id: gId,
        isPremium: false,
        role: assignedRole,
        authProvider: 'google'
      };

      // Permanently write to Firestore /users collection
      await saveUserToFirestore(targetUser);

      // Auto-bind device lock to primary email
      await bindDeviceLock(targetEmail, calculatedId, currentHwid);

      setUser(targetUser);
      setRole(assignedRole);
      localStorage.setItem("myteleflix_user", JSON.stringify(targetUser));

      const crossHwid = await generateCrossBrowserHardwareId();
      const traits = getCrossBrowserHardwareTraits();

      // Local API notification
      fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: targetUser.email,
          fullName: targetUser.fullName,
          photoUrl: targetUser.photoUrl,
          googleId: targetUser.googleId,
          device_fingerprint: fp,
          guest_device_id: gId,
          hwid: currentHwid,
          cross_browser_hwid: crossHwid,
          gpu_renderer: traits.gpu_renderer,
          gpu_chipset: traits.gpu_chipset,
          screen_resolution: traits.screen_resolution,
          physical_screen: traits.physical_screen,
          hardware_concurrency: traits.hardware_concurrency,
          cpu_cores: traits.cpu_cores,
          timezone: traits.timezone,
          platform: traits.platform,
          platform_family: traits.platform_family,
          startParam
        })
      }).catch(() => {});

      setIsSyncing(false);
      return targetUser;
    }

    // Otherwise, trigger standard Firebase Google Auth Popup
    try {
      return await triggerGooglePopupAuth();
    } catch (err: any) {
      setIsSyncing(false);
      throw err;
    }
  }, [triggerGooglePopupAuth, hwid, triggerSecurityWarning]);

  // Update User Profile Helper with Firestore persistence and IndexedDB layer
  const updateUserProfile = useCallback(async (updates: Partial<User>) => {
    setUser((prev) => {
      if (!prev) return prev;
      const updated = { ...prev, ...updates };
      try {
        localStorage.setItem("myteleflix_user", JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    if (user?.email && user.role !== 'guest') {
      try {
        const uid = user.id?.startsWith("#TF-") ? user.id : generateTeleFlixUid(user.id);
        const finalGender = updates.gender ? (updates.gender === 'female' ? 'Female' : 'Male') : (user.gender === 'female' ? 'Female' : 'Male');
        const finalName = updates.displayName || updates.fullName || user.displayName || user.fullName || "User";
        const finalTg = formatTelegramHandle(updates.telegramUsername || user.telegramUsername || "");
        const finalPhoto = updates.photoURL || updates.photoUrl || user.photoURL || user.photoUrl || "";

        await saveUserProfileDB({
          uid,
          email: user.email,
          displayName: finalName,
          gender: finalGender,
          telegramHandle: finalTg,
          photoURL: finalPhoto,
          joinDate: user.createdAt || new Date().toISOString(),
          role: user.role === 'ADMIN' ? 'ADMIN' : 'USER',
          points: user.points ?? 100,
          hwid
        });
      } catch (dbErr) {
        console.warn("IndexedDB sync warning in updateUserProfile:", dbErr);
      }
    }

    if (user?.id && !user.id.startsWith("guest_") && user.id !== "tg-guest") {
      try {
        // Write to Firestore /users collection
        await saveUserToFirestore({ id: user.id, ...updates });

        // Update local backend if running
        fetch("/api/auth/update-profile", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ userId: user.id, ...updates })
        }).catch(() => {});
      } catch (e) {
        console.warn("Failed to sync profile update to server/firestore:", e);
      }
    }
  }, [user?.id, user?.email, user?.role, user?.displayName, user?.fullName, user?.gender, user?.telegramUsername, user?.photoURL, user?.photoUrl, user?.createdAt, user?.points, hwid]);

  // Update Gender Helper
  const updateGender = useCallback(async (gender: 'male' | 'female') => {
    await updateUserProfile({ gender });
  }, [updateUserProfile]);

  // INSTANT HARD LOGOUT & PURGE SESSION (RETAINS HARDWARE DEVICE LOCK):
  // Clears user sessions and auth tokens, but permanently retains hardware ID device locks in DB
  const logout = useCallback(async () => {
    try {
      await firebaseSignOut(auth);
    } catch (e) {
      console.warn("Firebase signout notice:", e);
    }

    try {
      if (typeof window !== "undefined") {
        clearPersistentAdminToken();
        purgeSessionRetainLock();
        (window as any).__ASSIGNED_ADMINS__ = [];
      }
    } catch (e) {
      console.warn("Storage purge notice:", e);
    }

    // Immediately reset user state & role
    setUser(null);
    setRole('guest');
  }, []);

  const verifyMasterPin = useCallback((pin: string): boolean => {
    if (!pin) return false;
    return pin.trim() === MASTER_ADMIN_PIN;
  }, []);

  const switchToPrimaryAccount = useCallback(async (targetEmail?: string) => {
    clearSecondaryDraftSession();
    dismissSecurityWarning();
    const bound = targetEmail || getBoundPrimaryEmail() || securityWarning?.primaryEmail;
    if (bound) {
      try {
        await loginWithGoogle({ email: bound });
      } catch (e) {
        console.warn("Switch to primary error:", e);
      }
    }
  }, [securityWarning?.primaryEmail, loginWithGoogle, dismissSecurityWarning]);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        deviceFingerprint,
        guestDeviceId,
        isGuest,
        isTelegram,
        telegramUser,
        isSyncing,
        isLockedToExisting,
        setUser,
        setRole,
        loginWithTelegram,
        loginWithGoogle,
        triggerGooglePopupAuth,
        updateGender,
        updateUserProfile,
        logout,
        recordSessionActivity,
        verifyMasterPin,
        hwid,
        securityWarning,
        triggerSecurityWarning,
        dismissSecurityWarning,
        switchToPrimaryAccount
      }}
    >
      {children}
      {securityWarning && (
        <SecurityWarningModal
          isOpen={securityWarning.isOpen}
          primaryEmail={securityWarning.primaryEmail}
          attemptedEmail={securityWarning.attemptedEmail}
          hwid={securityWarning.hwid || hwid}
          message={securityWarning.message}
          onClose={dismissSecurityWarning}
          onSwitchToPrimary={switchToPrimaryAccount}
        />
      )}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
