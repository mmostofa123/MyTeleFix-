/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * 3-Language Enterprise Localization Engine (i18n)
 * Default: 'en' (English) as specified by platform requirements
 * Supported: 'en' (English), 'bn' (Bangla / বাংলা), 'hi' (Hindi / हिंदी)
 * Persistent across sessions via LocalStorage ('myteleflix_language')
 */

import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from "react";

export type SupportedLanguage = "en" | "bn" | "hi";

export interface LanguageOption {
  code: SupportedLanguage;
  label: string;
  nativeLabel: string;
  flagEmblem: string;
  isDefault?: boolean;
}

export const LANGUAGE_OPTIONS: LanguageOption[] = [
  {
    code: "en",
    label: "English",
    nativeLabel: "English",
    flagEmblem: "🇺🇸",
    isDefault: true,
  },
  {
    code: "bn",
    label: "Bengali",
    nativeLabel: "বাংলা",
    flagEmblem: "🇧🇩",
  },
  {
    code: "hi",
    label: "Hindi",
    nativeLabel: "हिंदी",
    flagEmblem: "🇮🇳",
  },
];

const TRANSLATIONS: Record<SupportedLanguage, Record<string, string>> = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.movies": "Movies",
    "nav.videos": "Videos",
    "nav.earn": "Earn",
    "tabs.earn": "Earn",
    "nav.profile": "Profile",
    "nav.wallet": "Wallet",

    // Actions
    "action.download": "DOWNLOAD",
    "action.get_link": "DOWNLOAD",
    "action.opening": "OPENING...",
    "action.all_episodes": "ALL EPISODES",
    "action.back_to_all": "Back to All",
    "action.clear": "Clear",
    "action.copy": "Copy",
    "action.copied": "Copied",
    "action.open_direct": "Open Directly",
    "action.listen": "Listen",
    "action.pause": "Pause",
    "action.close": "Close",
    "action.back": "Back",
    "action.popular": "POPULAR",

    // Search & Placeholders
    "search.placeholder_home": "Search movies, natok, web series & videos...",
    "search.placeholder_movies": "Search movies by title, genre...",
    "search.placeholder_series": "Search web series by title, season, episodes...",
    "search.placeholder_drama": "Filter drama & natok by title, actors, genre...",
    "search.no_results": "No media found matching",
    "search.clear_search": "Clear Search",

    // Tabs
    "tabs.all": "All",
    "tabs.movies": "Movies",
    "tabs.adult_movies": "Adult Movies",
    "tabs.drama": "Drama / Natok",
    "tabs.series": "Web Series",
    "tabs.videos": "Videos",

    // Settings
    "settings.language_title": "Display Language",
    "settings.language_desc": "Select your preferred platform language",
    "settings.language_badge": "Active",
    "settings.safemode_title": "Content Safety & Parental Filter",
    "settings.safemode_desc": "Family-friendly catalog protection",

    // Modal
    "modal.tutorial_prompt": "Having trouble downloading? Tap the picture below to watch the guide video.",
    "modal.tutorial_guide": "Tutorial Guide",
    "modal.watch_guide": "Tap here to watch guide video",
    "modal.voice_guide": "Voice Guide",
    "modal.ready_link": "Direct Link Ready",
    "modal.ready_sub": "Active",
    "modal.available_links": "Available Language Links",
    "modal.direct_video": "Direct Video Download",
    "modal.orig_print": "Original Print",
    "modal.bangla_dub": "Bangla Dubbed",
    "modal.hindi_dub": "Hindi Dubbed",
    "modal.english_dub": "English Dubbed",

    // Wallet
    "wallet.title": "My Wallet & Cashout",
    "wallet.badge": "Official Wallet",
    "wallet.subtitle": "Instant & reliable payouts via bKash and Nagad",
    "wallet.rate": "100,000 Points = 100 ৳",
    "wallet.points_balance": "Total Points Balance",
    "wallet.points_rate_sub": "1 Point = 0.001 BDT",
    "wallet.bdt_value": "BDT Equivalent",
    "wallet.bdt_sub": "bKash • Nagad Cashout",
    "wallet.min_limit": "Minimum Limit",
    "wallet.eligible": "✓ Eligible for Cashout",
    "wallet.need_more": "Points Needed",
    "wallet.quick_redeem": "Quick Redeem Packages",
    "wallet.quick_redeem_sub": "Tap to select package amount",
    "wallet.points_suffix": "Points",
    "wallet.taka_suffix": "BDT",
    "wallet.has_balance": "✓ In Balance",
    "wallet.need_balance": "Points Needed",
    "wallet.withdraw_form": "Withdrawal Form",
    "wallet.zero_fee": "0% Cashout Fee",
    "wallet.step_method": "1. Select Payment Method",
    "wallet.bkash": "bKash",
    "wallet.nagad": "Nagad",
    "wallet.personal_acc": "Personal Account",
    "wallet.acc_type": "Account Type:",
    "wallet.personal_only": "Personal Numbers Only",
    "wallet.step_mobile": "2. Personal Mobile Number",
    "wallet.mobile_note": "Enter valid 11-digit personal number.",
    "wallet.step_amount": "3. Points Amount",
    "wallet.equivalent": "Equivalent",
    "wallet.min_link": "Minimum Limit",
    "wallet.max_link": "Full Balance",
    "wallet.submit_btn": "Submit Cashout Request",
    "wallet.submitting": "Submitting Request...",
    "wallet.history_title": "Cashout History",
    "wallet.history_sub": "Complete record of your bKash & Nagad cashouts",
    "wallet.tx_count": "Transactions",
    "wallet.all_tx": "All Transactions",
    "wallet.withdrawals": "Withdrawals",
    "wallet.no_tx": "No cashout transactions recorded yet.",
    "wallet.no_tx_sub": "Submit a cashout request once you reach 100,000 points.",
    "wallet.approved": "Approved",
    "wallet.pending": "Pending",
    "wallet.rejected": "Rejected",
    "wallet.task_review": "Task Review & Audit",
    "wallet.task_review_sub": "Automated audit & instant point reward",
    "wallet.task_review_tag": "Auto Audit",
    "wallet.review_time": "Review Time: Audits are completed automatically within 12 to 24 hours.",
    "wallet.review_rule": "Work Validity: Watching full videos and following task rules ensures quick approval.",
    "wallet.official_support": "Official Support",
    "wallet.support_sub": "24/7 Helpline & Assistance",
    "wallet.support_tag": "24/7 Helpline",
    "wallet.support_rule": "For any inquiries regarding cashout or tasks, contact official support directly.",
    "wallet.support_btn": "Contact Telegram Support",
    "wallet.live_ticker": "Live Cashout",
    "wallet.live_ticker_action": "successfully withdrew",
  },

  bn: {
    // Navigation
    "nav.home": "হোম",
    "nav.movies": "মুভিজ",
    "nav.videos": "ভিডিও",
    "nav.earn": "ইনকাম সাইট",
    "tabs.earn": "ইনকাম সাইট",
    "nav.profile": "প্রোফাইল",
    "nav.wallet": "ওয়ালেট",

    // Actions
    "action.download": "ডাউনলোড",
    "action.get_link": "ডাউনলোড",
    "action.opening": "লোড হচ্ছে...",
    "action.all_episodes": "সকল পর্ব ও লিংক",
    "action.back_to_all": "সবগুলোতে ফিরে যান",
    "action.clear": "মুছুন",
    "action.copy": "কপি",
    "action.copied": "কপি হয়েছে",
    "action.open_direct": "সরাসরি ওপেন করুন",
    "action.listen": "শুনুন",
    "action.pause": "থামান",
    "action.close": "বন্ধ করুন",
    "action.back": "ফিরে যান",
    "action.popular": "জনপ্রিয়",

    // Search & Placeholders
    "search.placeholder_home": "মুভি, নাটক, ওয়েব সিরিজ বা ভিডিও খুঁজুন...",
    "search.placeholder_movies": "মুভির নাম বা ধরণ দিয়ে খুঁজুন...",
    "search.placeholder_series": "সিরিজের নাম, সিজন বা পর্ব দিয়ে খুঁজুন...",
    "search.placeholder_drama": "নাটক বা টেলিফিল্মের নাম দিয়ে খুঁজুন...",
    "search.no_results": "কোনো ফলাফল পাওয়া যায়নি",
    "search.clear_search": "সার্চ ক্লিয়ার করুন",

    // Tabs
    "tabs.all": "সকল",
    "tabs.movies": "মুভিজ",
    "tabs.adult_movies": "অ্যাডাল্ট মুভি",
    "tabs.drama": "নাটক / ড্রামা",
    "tabs.series": "ওয়েব সিরিজ",
    "tabs.videos": "ভিডিও",

    // Settings
    "settings.language_title": "অ্যাপের ভাষা (Language)",
    "settings.language_desc": "আপনার পছন্দের ভাষা নির্বাচন করুন",
    "settings.language_badge": "সক্রিয়",
    "settings.safemode_title": "কনটেন্ট সেফটি ও প্যারেন্টাল ফিল্টার",
    "settings.safemode_desc": "পারিবারিক ও সুরক্ষিত কনটেন্ট নিয়ন্ত্রণ",

    // Modal
    "modal.tutorial_prompt": "ডাউনলোড করতে সমস্যা? নিচের ছবিতে চাপ দিয়ে গাইড ভিডিওটি দেখে নিন।",
    "modal.tutorial_guide": "টিউটোরিয়াল গাইড",
    "modal.watch_guide": "গাইড ভিডিও দেখতে এখানে চাপুন",
    "modal.voice_guide": "ভয়েস গাইড",
    "modal.ready_link": "সরাসরি লিংক প্রস্তুত",
    "modal.ready_sub": "সক্রিয়",
    "modal.available_links": "উপলব্ধ ভাষার লিংকসমূহ",
    "modal.direct_video": "সরাসরি ভিডিও ডাউনলোড",
    "modal.orig_print": "অরিজিনাল প্রিন্ট",
    "modal.bangla_dub": "বাংলা ডাবিং",
    "modal.hindi_dub": "হিন্দি ডাব",
    "modal.english_dub": "ইংলিশ ডাব",

    // Wallet
    "wallet.title": "মাই ওয়ালেট ও ক্যাশআউট",
    "wallet.badge": "অফিশিয়াল ওয়ালেট",
    "wallet.subtitle": "বিকাশ ও নগদে সরাসরি ও নির্ভরযোগ্য পেমেন্ট সিস্টেম",
    "wallet.rate": "১০০,০০০ পয়েন্ট = ১০০ ৳",
    "wallet.points_balance": "মোট পয়েন্ট ব্যালেন্স",
    "wallet.points_rate_sub": "১ পয়েন্ট = ০.০০১ টাকা",
    "wallet.bdt_value": "টাকার সমপরিমাণ",
    "wallet.bdt_sub": "বিকাশ ও নগদ ক্যাশআউট",
    "wallet.min_limit": "ন্যূনতম সীমা",
    "wallet.eligible": "✓ ক্যাশআউটের উপযোগী",
    "wallet.need_more": "পয়েন্ট প্রয়োজন",
    "wallet.quick_redeem": "কুইক রিডিম প্যাকেজ",
    "wallet.quick_redeem_sub": "ক্লিক করে দ্রুত নির্বাচন করুন",
    "wallet.points_suffix": "পয়েন্ট",
    "wallet.taka_suffix": "টাকা",
    "wallet.has_balance": "✓ ব্যালেন্স রয়েছে",
    "wallet.need_balance": "পয়েন্ট প্রয়োজন",
    "wallet.withdraw_form": "মাই ওয়ে টু উইথড্র",
    "wallet.zero_fee": "০% ক্যাশআউট ফি",
    "wallet.step_method": "১. পেমেন্ট মাধ্যম বেছে নিন",
    "wallet.bkash": "বিকাশ",
    "wallet.nagad": "নগদ",
    "wallet.personal_acc": "পার্সোনাল একাউন্ট",
    "wallet.acc_type": "অ্যাকাউন্টের ধরন:",
    "wallet.personal_only": "শুধু পার্সোনাল নাম্বার প্রযোজ্য",
    "wallet.step_mobile": "২. পার্সোনাল মোবাইল নম্বর",
    "wallet.mobile_note": "সঠিক ১১ ডিজিটের পার্সোনাল নম্বর লিখুন।",
    "wallet.step_amount": "৩. পয়েন্টের পরিমাণ",
    "wallet.equivalent": "সমপরিমাণ",
    "wallet.min_link": "ন্যূনতম সীমা",
    "wallet.max_link": "সম্পূর্ণ ব্যালেন্স",
    "wallet.submit_btn": "ক্যাশআউট রিকোয়েস্ট জমা দিন",
    "wallet.submitting": "ক্যাশআউট রিকোয়েস্ট জমা হচ্ছে...",
    "wallet.history_title": "ক্যাশআউট লেনদেন হিস্ট্রি",
    "wallet.history_sub": "বিকাশ ও নগদে আপনার ক্যাশআউট লেনদেনের সম্পূর্ণ রেকর্ড",
    "wallet.tx_count": "লেনদেন",
    "wallet.all_tx": "সকল লেনদেন",
    "wallet.withdrawals": "ক্যাশআউট",
    "wallet.no_tx": "এখনও কোনো ক্যাশআউট লেনদেনের রেকর্ড নেই।",
    "wallet.no_tx_sub": "ন্যূনতম ১০০,০০০ পয়েন্ট অর্জন করার পর ক্যাশআউট রিকোয়েস্ট পাঠান।",
    "wallet.approved": "অনুমোদিত",
    "wallet.pending": "অপেক্ষমান",
    "wallet.rejected": "বাতিল",
    "wallet.task_review": "টাস্ক রিভিউ ও অনুমোদন",
    "wallet.task_review_sub": "স্বয়ংক্রিয় অডিট ও পয়েন্ট যোগ",
    "wallet.task_review_tag": "স্বয়ংক্রিয় অডিট",
    "wallet.review_time": "রিভিউ সময়: সাধারণত ১২ থেকে ২৪ ঘণ্টার মধ্যে অডিট সম্পন্ন হয়।",
    "wallet.review_rule": "কাজের সত্যতা: সঠিক নিয়ম মেনে ভিডিও দেখা ও নির্দেশ অনুসরণ করলে পয়েন্ট দ্রুত ব্যালেন্সে যুক্ত হয়।",
    "wallet.official_support": "অফিসিয়াল সাপোর্ট",
    "wallet.support_sub": "সার্বক্ষণিক সহায়তা কেন্দ্র",
    "wallet.support_tag": "সার্বক্ষণিক হেল্পলাইন",
    "wallet.support_rule": "ক্যাশআউট বা পয়েন্ট সংক্রান্ত যেকোনো প্রয়োজনে সরাসরি অফিসিয়াল অ্যাডমিন সাপোর্টে যোগাযোগ করুন।",
    "wallet.support_btn": "টেলিগ্রাম সাপোর্টে যোগাযোগ করুন",
    "wallet.live_ticker": "লাইভ ক্যাশআউট",
    "wallet.live_ticker_action": "সফলভাবে উত্তোলন করেছেন",
  },

  hi: {
    // Navigation
    "nav.home": "होम",
    "nav.movies": "फ़िल्में",
    "nav.videos": "वीडियो",
    "nav.earn": "कमाई",
    "tabs.earn": "कमाई",
    "nav.profile": "प्रोफ़ाइल",
    "nav.wallet": "वॉलेट",

    // Actions
    "action.download": "डाउनलोड",
    "action.get_link": "डाउनलोड",
    "action.opening": "लोड हो रहा है...",
    "action.all_episodes": "सभी एपिसोड",
    "action.back_to_all": "सभी पर वापस जाएं",
    "action.clear": "साफ़ करें",
    "action.copy": "कॉपी",
    "action.copied": "कॉपी हो गया",
    "action.open_direct": "सीधा खोलें",
    "action.listen": "सुनें",
    "action.pause": "रोकें",
    "action.close": "बंद करें",
    "action.back": "वापस जाएं",
    "action.popular": "लोकप्रिय",

    // Search & Placeholders
    "search.placeholder_home": "फ़िल्में, नाटक, वेब सीरीज़ या वीडियो खोजें...",
    "search.placeholder_movies": "फ़िल्म का नाम या शैली खोजें...",
    "search.placeholder_series": "वेब सीरीज़ का नाम, सीज़न या एपिसोड खोजें...",
    "search.placeholder_drama": "नाटक या टेलीफ़िल्म का नाम खोजें...",
    "search.no_results": "कोई परिणाम नहीं मिला",
    "search.clear_search": "सर्च साफ़ करें",

    // Tabs
    "tabs.all": "सभी",
    "tabs.movies": "फ़िल्में",
    "tabs.adult_movies": "एडल्ट फ़िल्में",
    "tabs.drama": "नाटक / ड्रामा",
    "tabs.series": "वेब सीरीज़",
    "tabs.videos": "वीडियो",

    // Settings
    "settings.language_title": "ऐप की भाषा (Language)",
    "settings.language_desc": "अपनी पसंदीदा भाषा चुनें",
    "settings.language_badge": "सक्रिय",
    "settings.safemode_title": "कंटेंट सुरक्षा एवं पैरेंटल फ़िल्टर",
    "settings.safemode_desc": "पारिवारिक व सुरक्षित सामग्री नियंत्रण",

    // Modal
    "modal.tutorial_prompt": "डाउनलोड करने में समस्या? गाइड वीडियो देखने के लिए नीचे दी गई तस्वीर पर टैप करें।",
    "modal.tutorial_guide": "ट्यूटोरियल गाइड",
    "modal.watch_guide": "गाइड वीडियो देखने के लिए यहाँ टैप करें",
    "modal.voice_guide": "वॉयस गाइड",
    "modal.ready_link": "सीधा लिंक तैयार",
    "modal.ready_sub": "सक्रिय",
    "modal.available_links": "उपलब्ध भाषाओं के लिंक",
    "modal.direct_video": "सीधा वीडियो डाउनलोड",
    "modal.orig_print": "ओरिजिनल प्रिंट",
    "modal.bangla_dub": "बांग्ला डब",
    "modal.hindi_dub": "हिंदी डब",
    "modal.english_dub": "इंग्लिश डब",

    // Wallet
    "wallet.title": "माई वॉलेट और कैशआउट",
    "wallet.badge": "आधिकारिक वॉलेट",
    "wallet.subtitle": "bKash और Nagad के माध्यम से सुरक्षित भुगतान प्रणाली",
    "wallet.rate": "100,000 पॉइंट्स = 100 ৳",
    "wallet.points_balance": "कुल पॉइंट्स बैलेंस",
    "wallet.points_rate_sub": "1 पॉइंट = 0.001 BDT",
    "wallet.bdt_value": "BDT समतुल्य मूल्य",
    "wallet.bdt_sub": "bKash • Nagad निकासी",
    "wallet.min_limit": "न्यूनतम सीमा",
    "wallet.eligible": "✓ निकासी के योग्य",
    "wallet.need_more": "पॉइंट्स आवश्यक",
    "wallet.quick_redeem": "त्वरित रिडीम पैकेज",
    "wallet.quick_redeem_sub": "पैकेज चुनने के लिए टैप करें",
    "wallet.points_suffix": "पॉइंट्स",
    "wallet.taka_suffix": "रुपये/टका",
    "wallet.has_balance": "✓ बैलेंस उपलब्ध",
    "wallet.need_balance": "पॉइंट्स चाहिए",
    "wallet.withdraw_form": "कैशआउट निकासी फ़ॉर्म",
    "wallet.zero_fee": "0% निकासी शुल्क",
    "wallet.step_method": "१. भुगतान माध्यम चुनें",
    "wallet.bkash": "bKash",
    "wallet.nagad": "Nagad",
    "wallet.personal_acc": "पर्सनल अकाउंट",
    "wallet.acc_type": "अकाउंट का प्रकार:",
    "wallet.personal_only": "केवल पर्सनल नंबर मान्य",
    "wallet.step_mobile": "२. पर्सनल मोबाइल नंबर",
    "wallet.mobile_note": "सही 11 अंकों का पर्सनल नंबर लिखें।",
    "wallet.step_amount": "३. पॉइंट्स की संख्या",
    "wallet.equivalent": "समतुल्य",
    "wallet.min_link": "न्यूनतम सीमा",
    "wallet.max_link": "पूरा बैलेंस",
    "wallet.submit_btn": "कैशआउट अनुरोध जमा करें",
    "wallet.submitting": "अनुरोध जमा हो रहा है...",
    "wallet.history_title": "लेन-देन इतिहास",
    "wallet.history_sub": "आपके द्वारा की गई सभी निकासियों का पूरा विवरण",
    "wallet.tx_count": "लेन-देन",
    "wallet.all_tx": "सभी लेन-देन",
    "wallet.withdrawals": "निकासी",
    "wallet.no_tx": "अभी कोई निकासी लेन-देन रिकॉर्ड नहीं है।",
    "wallet.no_tx_sub": "100,000 पॉइंट्स पूरे होने पर निकासी अनुरोध भेजें।",
    "wallet.approved": "स्वीकृत",
    "wallet.pending": "लंबित",
    "wallet.rejected": "अस्वीकृत",
    "wallet.task_review": "टास्क समीक्षा व अनुमोदन",
    "wallet.task_review_sub": "स्वचालित ऑडिट व तत्काल पॉइंट्स",
    "wallet.task_review_tag": "स्वचालित ऑडिट",
    "wallet.review_time": "समीक्षा समय: 12 से 24 घंटे में स्वचालित ऑडिट पूरा होता है।",
    "wallet.review_rule": "सत्यता: नियम अनुसार वीडियो देखने पर तुरंत पॉइंट्स प्राप्त होते हैं।",
    "wallet.official_support": "आधिकारिक सहायता",
    "wallet.support_sub": "24/7 हेल्पलाइन व समाधान",
    "wallet.support_tag": "24/7 हेल्पलाइन",
    "wallet.support_rule": "कैशआउट या पॉइंट्स संबंधी किसी भी समस्या के लिए सहायता से संपर्क करें।",
    "wallet.support_btn": "टेलीग्राम सहायता से संपर्क करें",
    "wallet.live_ticker": "लाइव निकासी",
    "wallet.live_ticker_action": "ने सफलतापूर्वक निकाले",
  },
};

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: (key: string, defaultVal?: string) => string;
  options: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key: string, defaultVal?: string) => defaultVal || key,
  options: LANGUAGE_OPTIONS,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Read initial language: strictly defaults to 'en' (English) as requested
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    try {
      if (typeof window !== "undefined") {
        const savedCode = localStorage.getItem("myteleflix_language");
        if (savedCode === "bn" || savedCode === "hi" || savedCode === "en") {
          return savedCode;
        }
        const savedNamed = localStorage.getItem("user_app_language");
        if (savedNamed === "বাংলা" || savedNamed === "bn") return "bn";
        if (savedNamed === "हिंदी" || savedNamed === "hi") return "hi";
      }
    } catch {}
    return "en";
  });

  useEffect(() => {
    const handleGlobalLang = (e: any) => {
      const detail = e.detail;
      if (detail === "বাংলা" || detail === "bn") setLanguageState("bn");
      else if (detail === "हिंदी" || detail === "hi") setLanguageState("hi");
      else if (detail === "English" || detail === "en") setLanguageState("en");
    };
    window.addEventListener("user_app_language_changed", handleGlobalLang);
    return () => window.removeEventListener("user_app_language_changed", handleGlobalLang);
  }, []);

  const setLanguage = useCallback((newLang: SupportedLanguage) => {
    setLanguageState(newLang);
    try {
      if (typeof window !== "undefined") {
        localStorage.setItem("myteleflix_language", newLang);
        const mappedName = newLang === "bn" ? "বাংলা" : newLang === "hi" ? "हिंदी" : "English";
        localStorage.setItem("user_app_language", mappedName);
        window.dispatchEvent(new CustomEvent("user_app_language_changed", { detail: mappedName }));
      }
    } catch {}
  }, []);

  const t = useCallback((key: string, defaultVal?: string): string => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.en;
    if (langDict && langDict[key] !== undefined) {
      return langDict[key];
    }
    const fallbackDict = TRANSLATIONS.en;
    if (fallbackDict && fallbackDict[key] !== undefined) {
      return fallbackDict[key];
    }
    return defaultVal || key;
  }, [language]);

  const value = useMemo(() => ({
    language,
    setLanguage,
    t,
    options: LANGUAGE_OPTIONS,
  }), [language, setLanguage, t]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}

export default LanguageContext;
