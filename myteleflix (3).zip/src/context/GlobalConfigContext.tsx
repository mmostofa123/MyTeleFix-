/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { SystemConfigRecord, CampaignRecord, GlobalConfigMap, SystemConfigResponse } from "../types";

export const DEFAULT_CONFIG_MAP: GlobalConfigMap = {
  MIN_WITHDRAWAL_POINTS: 5000,
  MAX_DAILY_WITHDRAWAL_POINTS: 100000,
  SALARY_LEVEL_1_TARGET: 50,
  SALARY_LEVEL_2_TARGET: 100,
  SALARY_LEVEL_3_TARGET: 200,
  SALARY_LEVEL_1_AMOUNT_BDT: 1000,
  SALARY_LEVEL_2_AMOUNT_BDT: 2500,
  SALARY_LEVEL_3_AMOUNT_BDT: 6000,
  SALARY_NEW_VERIFIED_TARGET: 5,
  SALARY_ACTIVE_DAYS_TARGET: 10,
  MAINTENANCE_MODE: false,
  MAINTENANCE_MESSAGE: "System is undergoing scheduled optimization. All balances are safe.",
  TASK_BASE_REWARD_POINTS: 100,
  TELEGRAM_REACTION_REWARD_POINTS: 50,
  DAILY_STREAK_BONUS_POINTS: 25,
  PURGE_INACTIVE_DAYS: 30,
  INACTIVITY_WARNING_HOURS: 72
};

interface GlobalConfigContextType {
  configs: SystemConfigRecord[];
  configMap: GlobalConfigMap;
  activeCampaign: CampaignRecord | null;
  loading: boolean;
  error: string | null;
  isMaintenance: boolean;
  maintenanceMessage: string;
  refreshConfig: () => Promise<void>;
  getConfig: <T = any>(key: string, defaultValue: T) => T;
  updateConfig: (key: string, value: any, description?: string, reason?: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  bulkUpdateConfig: (configs: Array<{ key: string; value: any; description?: string }>, reason?: string) => Promise<{ success: boolean; message?: string; error?: string }>;
  saveCampaignAction: (campaign: Partial<CampaignRecord> & { title: string }, reason?: string) => Promise<{ success: boolean; campaign?: CampaignRecord; message?: string; error?: string }>;
  activateCampaignAction: (campaignId: string, reason?: string) => Promise<{ success: boolean; message?: string; error?: string }>;
}

const GlobalConfigContext = createContext<GlobalConfigContextType | undefined>(undefined);

export const GlobalConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [configs, setConfigs] = useState<SystemConfigRecord[]>([]);
  const [configMap, setConfigMap] = useState<GlobalConfigMap>(DEFAULT_CONFIG_MAP);
  const [activeCampaign, setActiveCampaign] = useState<CampaignRecord | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchConfig = useCallback(async () => {
    try {
      const res = await fetch("/api/system/config");
      if (!res.ok) {
        throw new Error(`Failed to load system config: ${res.statusText}`);
      }
      const data: SystemConfigResponse = await res.json();
      if (data.success) {
        setConfigs(data.configs || []);
        setConfigMap(prev => ({
          ...prev,
          ...(data.configMap || {})
        }));
        setActiveCampaign(data.activeCampaign || null);
        setError(null);
      }
    } catch (err: any) {
      console.warn("[GlobalConfigContext] Failed to fetch server config, using fallback:", err.message);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchConfig();

    // REAL-TIME PROPAGATION: poll every 12 seconds to ensure seamless sync across tabs & users
    const interval = setInterval(fetchConfig, 12000);

    // Also listen for internal broadcast events
    const handleSyncEvent = () => {
      fetchConfig();
    };
    window.addEventListener("vrms_config_updated", handleSyncEvent);

    return () => {
      clearInterval(interval);
      window.removeEventListener("vrms_config_updated", handleSyncEvent);
    };
  }, [fetchConfig]);

  const getConfig = useCallback(<T = any>(key: string, defaultValue: T): T => {
    if (configMap && configMap[key] !== undefined) {
      return configMap[key] as T;
    }
    const found = configs.find(c => c.config_key === key);
    if (found && found.config_value !== undefined) {
      return found.config_value as T;
    }
    return defaultValue;
  }, [configMap, configs]);

  const updateConfig = async (key: string, value: any, description?: string, reason?: string) => {
    try {
      // Optimistic local update
      setConfigMap(prev => ({
        ...prev,
        [key]: value
      }));

      const res = await fetch("/api/admin/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          config_key: key,
          config_value: value,
          description,
          reason
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        // Revert on failure
        await fetchConfig();
        return { success: false, error: data.error || "Failed to update configuration" };
      }

      if (data.configs) setConfigs(data.configs);
      if (data.configMap) setConfigMap(prev => ({ ...prev, ...data.configMap }));

      // Dispatch event for other listeners
      window.dispatchEvent(new Event("vrms_config_updated"));

      return { success: true, message: data.message };
    } catch (err: any) {
      await fetchConfig();
      return { success: false, error: err.message };
    }
  };

  const bulkUpdateConfig = async (items: Array<{ key: string; value: any; description?: string }>, reason?: string) => {
    try {
      const res = await fetch("/api/admin/config/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ configs: items, reason })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        await fetchConfig();
        return { success: false, error: data.error || "Bulk update failed" };
      }

      if (data.configs) setConfigs(data.configs);
      if (data.configMap) setConfigMap(prev => ({ ...prev, ...data.configMap }));
      window.dispatchEvent(new Event("vrms_config_updated"));

      return { success: true, message: data.message };
    } catch (err: any) {
      await fetchConfig();
      return { success: false, error: err.message };
    }
  };

  const saveCampaignAction = async (campaign: Partial<CampaignRecord> & { title: string }, reason?: string) => {
    try {
      const res = await fetch("/api/admin/campaigns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...campaign, reason })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || "Failed to save campaign" };
      }

      if (data.activeCampaign) {
        setActiveCampaign(data.activeCampaign);
      }
      window.dispatchEvent(new Event("vrms_config_updated"));

      return { success: true, campaign: data.campaign, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const activateCampaignAction = async (campaignId: string, reason?: string) => {
    try {
      const res = await fetch(`/api/admin/campaigns/${campaignId}/activate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || "Failed to activate campaign" };
      }

      if (data.activeCampaign) {
        setActiveCampaign(data.activeCampaign);
      }
      window.dispatchEvent(new Event("vrms_config_updated"));

      return { success: true, message: data.message };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const isMaintenance = Boolean(configMap.MAINTENANCE_MODE);
  const maintenanceMessage = String(configMap.MAINTENANCE_MESSAGE || "System is undergoing scheduled maintenance.");

  return (
    <GlobalConfigContext.Provider
      value={{
        configs,
        configMap,
        activeCampaign,
        loading,
        error,
        isMaintenance,
        maintenanceMessage,
        refreshConfig: fetchConfig,
        getConfig,
        updateConfig,
        bulkUpdateConfig,
        saveCampaignAction,
        activateCampaignAction
      }}
    >
      {children}
    </GlobalConfigContext.Provider>
  );
};

export const useGlobalConfig = () => {
  const context = useContext(GlobalConfigContext);
  if (!context) {
    throw new Error("useGlobalConfig must be used within a GlobalConfigProvider");
  }
  return context;
};
